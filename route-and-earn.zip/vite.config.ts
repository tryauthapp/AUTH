// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - TanStack devtools (dev-only, first), tanstackStart, viteReact, tailwindcss, tsConfigPaths,
//     nitro (build-only using cloudflare as a default target), VITE_* env injection, @ path alias,
//     React/TanStack dedupe, error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { fileURLToPath } from "node:url";

import { defineConfig } from "@lovable.dev/vite-tanstack-config";

// Several @solana/codecs-* packages (pulled in by @solana/spl-token) publish
// only "browser"/"node" export conditions, so the Worker build cannot resolve
// them. Point them at their browser ESM builds explicitly — these are pure JS.
const solanaCodecAliases = [
  "@solana/codecs",
  "@solana/codecs-core",
  "@solana/codecs-data-structures",
  "@solana/codecs-numbers",
  "@solana/codecs-strings",
  "@solana/errors",
  "@solana/options",
  "rpc-websockets",
].map((name) => ({
  find: new RegExp(`^${name.replace("/", "\\/")}$`),
  replacement: fileURLToPath(
    new URL(`./node_modules/${name}/dist/index.browser.mjs`, import.meta.url),
  ),
}));

export default defineConfig({
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },
  vite: {
    resolve: {
      alias: solanaCodecAliases,
    },
  },
});
