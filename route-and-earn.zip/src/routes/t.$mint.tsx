import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ExternalLink } from "lucide-react";
import { safeHref } from "@/lib/links";
import {
  feeEventsQuery,
  payoutsQuery,
  recipientsQuery,
  publicRoutingQuery,
  tokenQuery,
  tokenRecipientsQuery,
  tokenStats,
} from "@/lib/queries";
import {
  EmptyState,
  ErrorState,
  LoadingRows,
  SectionHeading,
  StatCard,
  StatusPill,
} from "@/components/primitives";
import { LedgerTable, PayoutStatusPill } from "@/components/LedgerTable";
import { RoutingBreakdown } from "@/components/RoutingBreakdown";
import { explorerAddress, shortAddress, timeAgo, usd } from "@/lib/format";
import { useServerFn } from "@tanstack/react-start";
import { getMintOverview } from "@/lib/tokens.functions";
import { explorerTx } from "@/lib/format";

export const Route = createFileRoute("/t/$mint")({
  head: ({ params }) => ({
    meta: [
      { title: `Token ${params.mint.slice(0, 6)} — fee routing on AUTH` },
      {
        name: "description",
        content:
          "Total creator fees generated, recipients, routing configuration, recent transactions and payout history for this token.",
      },
      { property: "og:title", content: "Token fee routing — AUTH" },
      {
        property: "og:description",
        content: "Total fees generated, recipients, routing and payout history.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: TokenPage,
});

function TokenPage() {
  const { mint } = Route.useParams();
  const token = useQuery(tokenQuery(mint));
  const events = useQuery(feeEventsQuery());
  const payouts = useQuery(payoutsQuery());
  const links = useQuery(tokenRecipientsQuery());
  const recipients = useQuery(recipientsQuery());

  const recipientId = links.data?.find((l) => l.token_id === token.data?.id)?.recipient_id;
  const routing = useQuery(publicRoutingQuery(recipientId));

  if (token.isPending || events.isPending || payouts.isPending) {
    return (
      <div className="w-full px-4 py-8 sm:py-10">
        <LoadingRows rows={8} />
      </div>
    );
  }
  if (token.error) {
    return (
      <div className="w-full px-4 py-8 sm:py-10">
        <ErrorState error={token.error} retry={token.refetch} />
      </div>
    );
  }
  if (!token.data) {
    return (
      <div className="w-full px-4 py-8 sm:py-10">
        <EmptyState title="Token not found" description="No token with this mint is tracked by AUTH." />
      </div>
    );
  }

  const t = token.data;
  const stats = tokenStats(events.data ?? [], t.id);
  const eventIds = new Set(stats.events.map((e) => e.id));
  const tokenPayouts = (payouts.data ?? []).filter((p) => eventIds.has(p.fee_event_id));
  const tokenRecipients = (links.data ?? [])
    .filter((l) => l.token_id === t.id)
    .map((l) => ({
      share: l.share_percent,
      recipient: (recipients.data ?? []).find((r) => r.id === l.recipient_id),
    }));

  return (
    <div className="w-full px-4 py-5 sm:px-6 lg:px-8">
      <div className="panel p-4 sm:p-5">
        <div className="flex flex-wrap items-center gap-3">
          {t.image_url ? (
            <img
              src={t.image_url}
              alt={`${t.symbol} token`}
              loading="lazy"
              className="size-12 shrink-0 rounded-full border border-border object-cover"
            />
          ) : null}
          <h1 className="num text-xl font-bold sm:text-2xl">${t.symbol}</h1>
          <span className="min-w-0 truncate text-muted-foreground">{t.name}</span>
          <StatusPill status="neutral">
            {t.source === "pumpfun" ? "pump.fun" : t.source}
          </StatusPill>
        </div>
        {t.description ? (
          <p className="mt-3 max-w-2xl text-sm text-muted-foreground">{t.description}</p>
        ) : null}
        <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2">
          <a
            href={explorerAddress(t.mint)}
            target="_blank"
            rel="noreferrer noopener"
            className="num inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
          >
            {shortAddress(t.mint, 8)} <ExternalLink className="size-3" />
          </a>
          {(
            [
              ["Website", t.website_url],
              ["X", t.x_url],
              ["Telegram", t.telegram_url],
              ["Community", t.community_url],
            ] as const
          ).map(([label, value]) => {
            const href = safeHref(value);
            if (!href) return null;
            return (
              <a
                key={label}
                href={href}
                target="_blank"
                rel="noreferrer noopener nofollow"
                className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
              >
                {label} <ExternalLink className="size-3" />
              </a>
            );
          })}
        </div>
      </div>


      <OnChainPanel mint={t.mint} />

      <div className="workspace-panel mt-4 grid grid-cols-2 divide-x divide-y divide-border overflow-hidden py-2 sm:grid-cols-4 sm:divide-y-0">
        <StatCard label="Total fees generated" value={usd(stats.total, { compact: true })} accent />
        <StatCard label="Last 24 hours" value={usd(stats.last24h, { compact: true })} />
        <StatCard label="Protocol fees" value={usd(stats.protocolFees, { compact: true })} />
        <StatCard label="Fee events" value={stats.eventCount} />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <div>
          <SectionHeading title="Recipients" description="Who this token's creator fees are attributed to." />
          {tokenRecipients.length === 0 ? (
            <EmptyState title="No recipients linked" />
          ) : (
            <div className="panel divide-y divide-border">
              {tokenRecipients.map((tr, i) =>
                tr.recipient ? (
                  <Link
                    key={tr.recipient.id}
                    to="/u/$handle"
                    params={{ handle: tr.recipient.handle }}
                    className="flex items-center gap-3 p-4 hover:bg-secondary/40"
                  >
                    <span className="font-medium">@{tr.recipient.handle}</span>
                    <StatusPill
                      status={tr.recipient.verification === "verified" ? "verified" : "unverified"}
                    >
                      {tr.recipient.verification}
                    </StatusPill>
                    <span className="num ml-auto">{tr.share}%</span>
                  </Link>
                ) : (
                  <div key={i} className="p-4 text-sm text-muted-foreground">
                    Unresolved recipient
                  </div>
                ),
              )}
            </div>
          )}
        </div>
        <div>
          <SectionHeading title="Routing" description="Active routing for the primary recipient." />
          {routing.isPending ? (
            <LoadingRows rows={3} />
          ) : routing.data && routing.data.splits.length > 0 ? (
            <div className="panel p-5">
              <RoutingBreakdown splits={routing.data.splits} />
            </div>
          ) : (
            <EmptyState title="No routing configured" />
          )}
        </div>
      </div>

      <div className="mt-4 workspace-panel p-4">
        <SectionHeading title="Payout history" description="Every routed payout from this token's fees." />
        {tokenPayouts.length === 0 ? (
          <EmptyState title="No payouts yet" />
        ) : (
          <div className="panel divide-y divide-border">
            {tokenPayouts.slice(0, 25).map((p) => (
              <div key={p.id} className="flex flex-wrap items-center gap-3 p-4 text-sm">
                <span className="font-medium">{p.label}</span>
                <PayoutStatusPill status={p.status} />
                <span className="text-xs text-muted-foreground">via {p.adapter}</span>
                <span className="text-xs text-muted-foreground">{timeAgo(p.created_at)}</span>
                <span className="num ml-auto">{usd(p.amount_usd)}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="mt-4">
        <SectionHeading title="Recent transactions" />
        {stats.events.length === 0 ? (
          <EmptyState title="No fee events yet" />
        ) : (
          <LedgerTable events={stats.events.slice(0, 40)} payouts={tokenPayouts} showToken={false} />
        )}
      </div>
    </div>
  );
}

function OnChainPanel({ mint }: { mint: string }) {
  const overviewFn = useServerFn(getMintOverview);
  const overview = useQuery({
    queryKey: ["mint-overview", mint],
    queryFn: () => overviewFn({ data: { mint } }),
    staleTime: 60_000,
  });

  return (
    <div className="mt-6">
      <SectionHeading title="On-chain" description="Read live from Solana mainnet." />
      <div className="panel p-4 sm:p-5">
        {overview.isPending ? (
          <LoadingRows rows={2} />
        ) : overview.data?.ok ? (
          <>
            <div className="flex flex-wrap gap-6 text-sm">
              <div>
                <div className="text-xs text-muted-foreground">Supply</div>
                <div className="num font-medium">
                  {overview.data.supply?.toLocaleString() ?? "—"}
                </div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Decimals</div>
                <div className="num font-medium">{overview.data.decimals ?? "—"}</div>
              </div>
            </div>
            {overview.data.signatures.length > 0 ? (
              <ul className="mt-4 space-y-1.5">
                {overview.data.signatures.map((s) => (
                  <li key={s.signature} className="flex items-center gap-2 text-xs">
                    <StatusPill status={s.succeeded ? "paid" : "failed"}>
                      {s.succeeded ? "ok" : "failed"}
                    </StatusPill>
                    <a
                      href={explorerTx(s.signature)}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="num text-muted-foreground hover:text-foreground"
                    >
                      {shortAddress(s.signature, 6)}
                    </a>
                    <span className="ml-auto text-muted-foreground">
                      {s.blockTime ? timeAgo(new Date(s.blockTime * 1000).toISOString()) : "—"}
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="mt-3 text-xs text-muted-foreground">No recent mint activity indexed.</p>
            )}
          </>
        ) : (
          <p className="text-sm text-muted-foreground">
            {overview.data?.message ?? "On-chain data is unavailable right now."}
          </p>
        )}
      </div>
    </div>
  );
}
