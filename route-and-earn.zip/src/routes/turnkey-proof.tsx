import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowUpRight,
  BadgeCheck,
  CircleAlert,
  FileCode2,
  KeyRound,
  Loader2,
  RefreshCw,
  ShieldCheck,
} from "lucide-react";

import { turnkeyProof } from "@/lib/turnkey.functions";
import {
  PUBLIC_SOURCE_BASE_URL,
  TURNKEY_EVIDENCE_FILES,
  TURNKEY_PUBLIC_CONFIG,
  TURNKEY_SDK_DECLARED_RANGE,
  TURNKEY_SDK_NPM_URL,
  TURNKEY_SDK_PACKAGE,
} from "@/lib/turnkey-evidence";
import { TURNKEY_DOCS_URL, TURNKEY_SITE_URL } from "@/lib/external-links";
import { ExternalLink } from "@/components/ExternalLink";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/turnkey-proof")({
  head: () => ({
    meta: [
      { title: "Turnkey proof — AUTH" },
      {
        name: "description",
        content:
          "Verifiable evidence that AUTH's embedded wallets really run on Turnkey: a live verification call, the SDK in use, public configuration and excerpts from the real integration code.",
      },
      { property: "og:title", content: "Turnkey proof — AUTH" },
      {
        property: "og:description",
        content: "Live verification, real code excerpts, and no secrets. Check the claim yourself.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: TurnkeyProofPage,
});

function StatusBanner({
  tone,
  icon,
  title,
  body,
}: {
  tone: "success" | "warn" | "neutral";
  icon: React.ReactNode;
  title: string;
  body: string;
}) {
  const toneClass =
    tone === "success"
      ? "border-success/40 bg-success/8 text-success"
      : tone === "warn"
        ? "border-border bg-muted/50 text-muted-foreground"
        : "border-border bg-surface text-muted-foreground";
  return (
    <div className={`flex items-start gap-3 rounded-2xl border p-4 ${toneClass}`}>
      <span className="mt-0.5 shrink-0">{icon}</span>
      <div className="min-w-0">
        <p className="text-sm font-semibold">{title}</p>
        <p className="mt-1 text-xs leading-5 text-muted-foreground">{body}</p>
      </div>
    </div>
  );
}

function Fact({ label, value, note }: { label: string; value: string; note?: string | undefined }) {
  return (
    <div className="rounded-xl border border-border bg-surface p-3.5">
      <p className="text-[11px] font-medium uppercase tracking-[0.12em] text-muted-foreground">
        {label}
      </p>
      <p className="mt-1.5 break-words font-mono text-xs text-foreground">{value}</p>
      {note ? <p className="mt-1 text-[11px] leading-4 text-muted-foreground">{note}</p> : null}
    </div>
  );
}

function TurnkeyProofPage() {
  const proof = useQuery({
    queryKey: ["turnkey-proof"],
    queryFn: () => turnkeyProof(),
    staleTime: 30_000,
  });

  const d = proof.data;
  const verified = Boolean(d?.configured && d.reachable);

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-8 sm:px-6 lg:px-8">
      <p className="workspace-label">Transparency</p>
      <h1 className="mt-3 text-3xl font-bold tracking-[-0.02em] sm:text-4xl">
        Turnkey proof
      </h1>
      <p className="mt-3 max-w-2xl text-sm leading-6 text-muted-foreground">
        AUTH says its embedded wallets are secured by Turnkey. This page exists so you don&apos;t
        have to take that on trust: it runs a live verification call against Turnkey when you open
        it, and shows the actual code, package and configuration behind the claim. No key material,
        credential or secret value appears here or is ever sent to your browser.
      </p>

      {/* live status */}
      <section className="mt-7">
        <div className="mb-3 flex items-center justify-between gap-3">
          <h2 className="text-sm font-semibold tracking-tight">Live verification</h2>
          <Button
            variant="outline"
            size="sm"
            className="h-8"
            onClick={() => void proof.refetch()}
            disabled={proof.isFetching}
          >
            {proof.isFetching ? (
              <Loader2 className="size-3.5 animate-spin" />
            ) : (
              <RefreshCw className="size-3.5" />
            )}
            Re-check
          </Button>
        </div>

        {proof.isPending ? (
          <StatusBanner
            tone="neutral"
            icon={<Loader2 className="size-5 animate-spin" />}
            title="Checking with Turnkey…"
            body="Calling Turnkey's getWhoami endpoint from the AUTH server."
          />
        ) : proof.error ? (
          <StatusBanner
            tone="warn"
            icon={<CircleAlert className="size-5" />}
            title="Verification unavailable"
            body="The verification call could not be completed right now. Nothing about the integration status can be confirmed from this page until it succeeds."
          />
        ) : verified ? (
          <StatusBanner
            tone="success"
            icon={<BadgeCheck className="size-5" />}
            title="Connected — Turnkey answered a live call from AUTH"
            body={`Turnkey confirmed the organization behind AUTH's wallets at ${new Date(d!.checkedAt).toLocaleString()}. This status is shown only because the call actually succeeded.`}
          />
        ) : d?.configured ? (
          <StatusBanner
            tone="warn"
            icon={<CircleAlert className="size-5" />}
            title="Configured, not confirmed"
            body={d.message ?? "Turnkey credentials are present on this deployment, but Turnkey did not answer the verification call, so AUTH will not claim an active connection."}
          />
        ) : (
          <StatusBanner
            tone="warn"
            icon={<CircleAlert className="size-5" />}
            title="Not configured on this deployment"
            body="No Turnkey credentials are present here, so no wallets can be created and no connection is claimed."
          />
        )}

        {d ? (
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <Fact label="API host" value={d.apiHost} />
            <Fact
              label="Organization"
              value={d.organizationName ?? "Unavailable"}
              note={d.organizationName ? "Returned live by Turnkey." : "Not returned by the last check."}
            />
            <Fact
              label="Organization ID"
              value={d.organizationIdMasked ?? "Unavailable"}
              note="Deliberately masked — first and last four characters only."
            />
            <Fact
              label="Wallets provisioned through Turnkey"
              value={d.walletsProvisioned === null ? "Unavailable" : d.walletsProvisioned.toLocaleString()}
              note="Count of embedded wallets recorded with Turnkey as the provider."
            />
          </div>
        ) : null}
      </section>

      {/* what Turnkey does here */}
      <section className="mt-9">
        <h2 className="text-sm font-semibold tracking-tight">What Turnkey does in AUTH</h2>
        <div className="mt-3 space-y-3 text-sm leading-6 text-muted-foreground">
          <p>
            When someone proves they own a social account, AUTH asks Turnkey to create a dedicated
            sub-organization for that identity and one Solana wallet inside it. The private key is
            generated and used inside Turnkey&apos;s secure infrastructure. AUTH receives only the
            public Solana address — the same address anyone can look up on an explorer.
          </p>
          <p>
            The wallet is bound to the platform&apos;s immutable user ID rather than the visible
            handle, so renaming an account never moves or duplicates a wallet. AUTH never stores,
            displays, imports or exports a private key, and there is no path in the product that
            would reveal one.
          </p>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button asChild variant="outline" size="sm" className="h-8">
            <ExternalLink href={TURNKEY_SITE_URL}>
              Turnkey <ArrowUpRight className="size-3.5" />
            </ExternalLink>
          </Button>
          <Button asChild variant="ghost" size="sm" className="h-8">
            <ExternalLink href={TURNKEY_DOCS_URL}>
              Turnkey docs <ArrowUpRight className="size-3.5" />
            </ExternalLink>
          </Button>
          <Button asChild variant="ghost" size="sm" className="h-8">
            <Link to="/docs/integrations">All integration statuses</Link>
          </Button>
        </div>
      </section>

      {/* SDK */}
      <section className="mt-9">
        <h2 className="text-sm font-semibold tracking-tight">SDK in use</h2>
        <div className="mt-3 rounded-2xl border border-border bg-card p-4">
          <div className="flex flex-wrap items-center gap-2">
            <KeyRound className="size-4 text-muted-foreground" />
            <code className="font-mono text-sm font-semibold">{TURNKEY_SDK_PACKAGE}</code>
            <span className="rounded-full bg-muted px-2 py-0.5 font-mono text-[11px] text-muted-foreground">
              {TURNKEY_SDK_DECLARED_RANGE}
            </span>
            <ExternalLink
              href={TURNKEY_SDK_NPM_URL}
              className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground hover:underline"
            >
              npm <ArrowUpRight className="size-3" />
            </ExternalLink>
          </div>
          <p className="mt-2 text-xs leading-5 text-muted-foreground">
            Turnkey&apos;s official server SDK, declared in this project&apos;s dependencies and
            imported inside server-only code. It is never bundled into the browser.
          </p>
        </div>
      </section>

      {/* public config */}
      <section className="mt-9">
        <h2 className="text-sm font-semibold tracking-tight">Public configuration</h2>
        <p className="mt-1.5 text-xs leading-5 text-muted-foreground">
          The non-secret parameters the integration is wired with. Credential names are listed so
          you can see what the deployment expects; their values stay on the server.
        </p>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          {TURNKEY_PUBLIC_CONFIG.map((c) => (
            <Fact key={c.label} label={c.label} value={c.value} note={c.note} />
          ))}
        </div>
      </section>

      {/* code */}
      <section className="mt-9">
        <h2 className="text-sm font-semibold tracking-tight">Integration code</h2>
        <p className="mt-1.5 text-xs leading-5 text-muted-foreground">
          Excerpts copied from the files that actually run in AUTH. Nothing here is a sample.
          {PUBLIC_SOURCE_BASE_URL
            ? ""
            : " This project has no public source repository yet, so these files cannot be linked to a public commit — the excerpts and filenames are given instead."}
        </p>
        <div className="mt-3 space-y-4">
          {TURNKEY_EVIDENCE_FILES.map((f, i) => (
            <figure key={`${f.path}-${i}`} className="overflow-hidden rounded-2xl border border-border bg-card">
              <figcaption className="flex flex-wrap items-center gap-2 border-b border-border px-4 py-3">
                <FileCode2 className="size-4 shrink-0 text-muted-foreground" />
                {PUBLIC_SOURCE_BASE_URL ? (
                  <ExternalLink
                    href={`${PUBLIC_SOURCE_BASE_URL}/${f.path}`}
                    className="font-mono text-xs font-medium hover:underline"
                  >
                    {f.path}
                  </ExternalLink>
                ) : (
                  <span className="font-mono text-xs font-medium">{f.path}</span>
                )}
                <span className="basis-full text-xs leading-5 text-muted-foreground">{f.role}</span>
              </figcaption>
              <pre className="overflow-x-auto bg-surface p-4 text-[11.5px] leading-5">
                <code className="font-mono">{f.excerpt}</code>
              </pre>
            </figure>
          ))}
        </div>
      </section>

      <section className="mt-9 rounded-2xl border border-border bg-surface p-4">
        <div className="flex items-start gap-3">
          <ShieldCheck className="mt-0.5 size-5 shrink-0 text-success" />
          <div>
            <p className="text-sm font-semibold">What this page will never show</p>
            <p className="mt-1.5 text-xs leading-5 text-muted-foreground">
              API private keys, API public keys, the full organization ID, wallet private keys,
              seed phrases, session material or any environment variable value. Where something
              cannot be verified safely and publicly, it is labelled unavailable rather than
              guessed.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
