import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { integrationsQuery } from "@/lib/queries";
import { turnkeyProof } from "@/lib/turnkey.functions";
import { socialProviderStatus } from "@/lib/social-auth.functions";
import { ProviderIcon } from "@/components/social/ProviderIcon";
import {
  EmptyState,
  ErrorState,
  LoadingRows,
  SectionHeading,
  StatusPill,
} from "@/components/primitives";
import { adapterRegistry } from "@/integrations/adapters/registry";
import { ArrowUpRight } from "lucide-react";
import { TURNKEY_PROOF_PATH } from "@/lib/external-links";


export const Route = createFileRoute("/docs/integrations")({
  head: () => ({
    meta: [
      { title: "Integration status — AUTH" },
      {
        name: "description",
        content:
          "Live, sandbox, planned and disabled status for every AUTH adapter: indexer, launchpads, swaps, identity, payouts and charities.",
      },
      { property: "og:title", content: "Integration status — AUTH" },
      { property: "og:description", content: "What is actually connected, and what is not." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: IntegrationsPage,
});

function IntegrationsPage() {
  const integrations = useQuery(integrationsQuery());
  const turnkey = useQuery({
    queryKey: ["turnkey-proof"],
    queryFn: () => turnkeyProof(),
    staleTime: 60_000,
  });

  return (
    <div>
      <SectionHeading
        title="Embedded wallet infrastructure"
        description="Live verification against Turnkey, checked when this page loads."
      />
      <div className="panel p-4 text-sm">
        {turnkey.isPending ? (
          <LoadingRows rows={2} />
        ) : turnkey.error ? (
          <ErrorState error={turnkey.error} retry={turnkey.refetch} />
        ) : (
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <Link
                to={TURNKEY_PROOF_PATH}
                className="inline-flex items-center gap-1 font-medium hover:underline"
              >
                Turnkey <ArrowUpRight className="size-3" />
              </Link>
              <StatusPill
                status={
                  turnkey.data?.reachable ? "live" : turnkey.data?.configured ? "sandbox" : "planned"
                }
              >
                {turnkey.data?.reachable
                  ? "verified"
                  : turnkey.data?.configured
                    ? "unverified"
                    : "not configured"}
              </StatusPill>
            </div>
            <dl className="grid gap-x-6 gap-y-2 sm:grid-cols-2">
              <div>
                <dt className="text-xs text-muted-foreground">Organization</dt>
                <dd className="font-medium">{turnkey.data?.organizationName ?? "—"}</dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground">Organization ID</dt>
                <dd className="num">{turnkey.data?.organizationIdMasked ?? "—"}</dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground">API host</dt>
                <dd className="num">{turnkey.data?.apiHost}</dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground">Solana wallets provisioned</dt>
                <dd className="num">{turnkey.data?.walletsProvisioned ?? "—"}</dd>
              </div>
              <div>
                <dt className="text-xs text-muted-foreground">Checked</dt>
                <dd className="num">
                  {turnkey.data ? new Date(turnkey.data.checkedAt).toLocaleString() : "—"}
                </dd>
              </div>
            </dl>
            {turnkey.data?.message ? (
              <p className="text-xs text-muted-foreground">{turnkey.data.message}</p>
            ) : null}
            <p className="text-xs text-muted-foreground">
              Each verified X identity gets one Solana wallet created inside a dedicated Turnkey
              sub-organization. Key material stays in Turnkey's secure enclaves — AUTH never sees,
              stores or displays a private key, and API credentials are never sent to the browser.
              Wallet addresses are public Solana addresses you can check on any explorer.
            </p>
          </div>
        )}
      </div>


      <SocialProviderDocs />


      <SectionHeading
        title="Integrations"
        description="Nothing here implies real money movement until credentials are configured."
      />

      {integrations.isPending ? (
        <LoadingRows rows={6} />
      ) : integrations.error ? (
        <ErrorState error={integrations.error} retry={integrations.refetch} />
      ) : (integrations.data ?? []).length === 0 ? (
        <EmptyState title="No integrations registered" />
      ) : (
        <div className="panel divide-y divide-border">
          {(integrations.data ?? []).map((i) => (
            <div key={i.key} className="flex flex-wrap items-start gap-3 p-4">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-medium">{i.name}</span>
                  <span className="text-xs text-muted-foreground">{i.category}</span>
                </div>
                {i.description ? (
                  <p className="mt-1 text-sm text-muted-foreground">{i.description}</p>
                ) : null}
              </div>
              <StatusPill status={i.status as "live"}>{i.status}</StatusPill>
            </div>
          ))}
        </div>
      )}

      <SectionHeading
        title="Adapter interfaces"
        description="Each integration is a swappable interface behind the product logic."
      />
      <div className="panel divide-y divide-border">
        {Object.values(adapterRegistry).map((a) => (
          <div key={a.key} className="flex flex-wrap items-center gap-3 p-4 text-sm">
            <span className="num text-xs text-muted-foreground">{a.category}</span>
            <span className="font-medium">{a.name}</span>
            <span className="ml-auto">
              <StatusPill status={a.status}>{a.status}</StatusPill>
            </span>
          </div>
        ))}
      </div>
      <p className="mt-4 text-xs text-muted-foreground">
        Adapters that are not configured return an explicit "not configured" result. They never
        fabricate a successful transfer, swap or identity check.
      </p>
    </div>
  );
}

/**
 * Social identity providers: exactly which ones are live on this deployment,
 * which secret names are missing, and the callback URL each developer
 * dashboard must register. No secret values are ever read or shown here.
 */
function SocialProviderDocs() {
  const providers = useQuery({
    queryKey: ["social-provider-status"],
    queryFn: () => socialProviderStatus(),
  });

  return (
    <>
      <SectionHeading
        title="Social identity providers"
        description="A provider is only live once its server-side credentials are configured and its callback is registered."
      />
      {providers.isPending ? (
        <LoadingRows rows={4} />
      ) : (
        <div className="panel divide-y divide-border">
          {(providers.data ?? []).map((p) => (
            <div key={p.id} className="space-y-2 p-4">
              <div className="flex flex-wrap items-center gap-2">
                <ProviderIcon provider={p.id} brand className="size-4.5" />
                <span className="font-medium">{p.label}</span>
                <StatusPill status={p.configured ? "live" : "planned"}>
                  {p.configured ? "live" : "not configured"}
                </StatusPill>
              </div>
              <dl className="grid gap-x-6 gap-y-1 text-sm sm:grid-cols-2">
                <div>
                  <dt className="text-xs text-muted-foreground">Callback URL</dt>
                  <dd className="num break-all">{p.callbackUrl}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground">Scopes requested</dt>
                  <dd className="num break-all">{p.scopes.join(", ")}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground">Server secret names</dt>
                  <dd className="num break-all">{p.secretNames?.join(", ") ?? "—"}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground">Developer console</dt>
                  <dd className="break-all">
                    <a
                      href={p.consoleUrl}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="text-primary hover:underline"
                    >
                      {p.consoleUrl}
                    </a>
                  </dd>
                </div>
              </dl>
              {!p.configured ? (
                <p className="text-xs text-warning">
                  Missing: {p.missingSecrets.join(", ")} — add these in project secrets, then
                  register the callback URL above in the {p.label} developer app.
                </p>
              ) : null}
            </div>
          ))}
        </div>
      )}
    </>
  );
}
