import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  Rocket,
  Send,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { EmptyState, LoadingRows, PageShell, StatusPill } from "@/components/primitives";
import { IdentityAvatar, TokenAvatar } from "@/components/Avatar";
import { AUTH_ERA_START, feeEventsQuery, launchedTokensQuery, paymentsQuery } from "@/lib/queries";
import { timeAgo, usd } from "@/lib/format";
import { explorerTx } from "@/lib/solana";
import { Button } from "@/components/ui/button";
import { TURNKEY_PROOF_PATH } from "@/lib/external-links";
import { ClaimableFeed } from "@/components/ClaimableFeed";
import { PlatformSupport } from "@/components/PlatformSupport";
import { AssetIcon } from "@/components/AssetIcon";
import { ProviderIcon, providerTint } from "@/components/social/ProviderIcon";
import { SocialAvatar } from "@/components/social/SocialIdentity";
import { lookupXProfile } from "@/lib/x-profile.functions";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Home — AUTH" },
    { name: "description", content: "Free token launches with no AUTH platform fee: pay social identities on X, TikTok, YouTube, Twitch and Instagram in SOL or USDC, launch on pump.fun, and route creator fees on Solana." },
    { property: "og:title", content: "AUTH — social payments and creator fees" },
    { property: "og:description", content: "Launch for anyone. They choose how they get paid." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Home,
});

const SUPPORTED_PLATFORMS = [
  { id: "x", label: "X", live: true },
  { id: "tiktok", label: "TikTok", live: false },
  { id: "youtube", label: "YouTube", live: true },
  { id: "twitch", label: "Twitch", live: true },
  { id: "instagram", label: "Instagram", live: false },
] as const;

type Activity =
  | { kind: "payment"; id: string; at: string; handle: string; amount: string; status: string; signature: string | null }
  | { kind: "fee"; id: string; at: string; handle: string; symbol: string; signature: string | null; value: number }
  | { kind: "launch"; id: string; at: string; symbol: string; name: string; mint: string };

function Home() {
  const events = useQuery(feeEventsQuery());
  const payments = useQuery(paymentsQuery(30));
  const launched = useQuery(launchedTokensQuery());
  const currentLaunches = (launched.data ?? []).filter(
    (token) => !token.is_demo && token.created_at >= AUTH_ERA_START,
  );
  const activity: Activity[] = [
    ...(payments.data ?? []).map((p) => ({ kind: "payment" as const, id: p.id, at: p.created_at, handle: p.recipient_handle, amount: `${Number(p.amount)} ${p.asset}`, status: p.status, signature: p.tx_signature })),
    ...(events.data ?? []).map((e) => ({ kind: "fee" as const, id: e.id, at: e.occurred_at, handle: e.recipient?.handle ?? "unknown", symbol: e.token?.symbol ?? "token", signature: e.tx_signature, value: Number(e.net_usd) })),
    ...currentLaunches.map((t) => ({ kind: "launch" as const, id: t.id, at: t.created_at, symbol: t.symbol, name: t.name, mint: t.mint })),
  ].sort((a, b) => b.at.localeCompare(a.at));
  const feeTotal = (events.data ?? []).reduce((sum, event) => sum + Number(event.net_usd), 0);
  const pending = events.isPending || payments.isPending || launched.isPending;
  const launchUpdatedAt = currentLaunches[0]?.created_at ?? (launched.dataUpdatedAt ? new Date(launched.dataUpdatedAt).toISOString() : null);
  const feeUpdatedAt = events.data?.[0]?.occurred_at ?? (events.dataUpdatedAt ? new Date(events.dataUpdatedAt).toISOString() : null);

  return (
    <PageShell className="space-y-4 sm:space-y-5">
      {/* Hero */}
      <section className="workspace-panel grid items-center gap-7 px-5 py-8 sm:gap-8 sm:px-10 sm:py-14 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)] lg:gap-12">
        <div>
          <p className="workspace-label">Social identity on Solana</p>
          <h1 className="hero-title mt-4 max-w-xl">
            Launch for anyone.
            <br />
            <span className="text-muted-foreground">
              They choose how they get <span className="text-success">paid</span>.
            </span>
          </h1>
          <p className="mt-5 max-w-lg text-[17px] leading-7 text-muted-foreground">
            Pay a social identity on X, TikTok, YouTube, Twitch or Instagram in SOL or USDC, launch a
            token for that identity, and route creator fees in public with readable on-chain
            receipts. No wallet connection needed.
          </p>
          <div className="mt-7 flex flex-wrap gap-2.5">
            <Button asChild className="h-11 px-6 text-[15px]"><Link to="/pay"><Send /> Pay a social identity</Link></Button>
            <Button asChild variant="outline" className="h-11 px-6 text-[15px]"><Link to="/launch"><Rocket /> Launch a token</Link></Button>
          </div>
          <div className="mt-7 flex flex-wrap gap-x-6 gap-y-2 text-[13px] font-medium text-success">
            <span className="inline-flex items-center gap-1.5"><Check className="size-4" /> 0 SOL platform fee</span>
            <span className="inline-flex items-center gap-1.5"><ShieldCheck className="size-4" /> No private keys</span>
            <span className="inline-flex items-center gap-1.5"><Check className="size-4" /> Solana mainnet</span>
            <span className="inline-flex items-center gap-1.5"><Check className="size-4" /> Public receipts</span>
          </div>
        </div>

        <DemoIdentityCard />
      </section>

      {/* Real claimable balances */}
      <ClaimableFeed />

      {/* Platforms */}
      <PlatformSupport />

      {/* How it works */}
      <section className="workspace-panel px-6 py-7 sm:px-8">
        <p className="workspace-label">How it works</p>
        <h2 className="mt-2 text-2xl font-semibold tracking-tight">
          How a social identity becomes a <span className="text-success">readable receipt</span>
        </h2>
        <p className="mt-2 max-w-2xl text-[15px] leading-6 text-muted-foreground">
          People are easier to remember than wallet addresses. AUTH maps a social identity to a real
          Solana destination, then records what happened against that identity.
        </p>

        {/* The same flow works across every supported platform. */}
        <div className="mt-5 flex flex-wrap items-center gap-2">
          {SUPPORTED_PLATFORMS.map((p) => (
            <span
              key={p.id}
              className="inline-flex items-center gap-2 rounded-full border border-border bg-surface px-3 py-1.5 text-[13px] font-medium"
              style={providerTint(p.id)}
            >
              <ProviderIcon provider={p.id} brand className="size-4" />
              {p.label}
              <span className="rounded-full bg-emerald-500/10 px-2 py-0.5 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
                Active
              </span>
            </span>
          ))}
          <span className="text-xs text-muted-foreground">
            All five platforms are active on AUTH.
          </span>
        </div>

        <ol className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { step: "1", title: "Social identity", body: <>A payment or launch names a social account on X, TikTok, YouTube, Twitch or Instagram. AUTH resolves the real profile through that platform&apos;s official API when it offers one. Nothing about the person is invented.</> },
            { step: "2", title: "Ownership proof", body: <>Before anyone can claim funds, they prove they control the account through that platform&apos;s official sign-in flow.</> },
            { step: "3", title: "Solana destination", body: <>The verified identity is bound to one embedded Solana wallet secured by <TurnkeyLink />, or an address they configure. AUTH never exposes or stores private keys.</> },
            { step: "4", title: "Readable receipt", body: <>The settled transaction is stored with its Solana mainnet signature next to the social identity, so the Fee Ledger reads &quot;@handle received X&quot; and still links to the explorer.</> },
          ].map((item) => (
            <li key={item.step}>
              <span className="inline-flex size-7 items-center justify-center rounded-full bg-primary/10 text-xs font-semibold text-primary">
                {item.step}
              </span>
              <p className="mt-3 text-[15px] font-semibold">{item.title}</p>
              <p className="mt-1.5 text-sm leading-6 text-muted-foreground">{item.body}</p>
            </li>
          ))}
        </ol>
        <div className="mt-6 flex flex-wrap items-center gap-2">
          <Button asChild variant="outline" className="h-10 px-5"><Link to="/pay"><Send /> Pay a social identity</Link></Button>
          <Button asChild variant="ghost" className="h-10 px-4"><Link to="/docs">Read the docs <ArrowRight /></Link></Button>
        </div>
        <p className="mt-5 text-xs leading-5 text-muted-foreground">
          AUTH charges no launch fee. Solana network costs for the launch transaction and any dev
          buy you choose are separate from AUTH and are not charged by AUTH.
        </p>
      </section>


      {/* Proof / receipts */}
      <section className="grid gap-5 xl:grid-cols-[minmax(0,1.3fr)_minmax(320px,0.7fr)]">
        <div className="workspace-panel overflow-hidden">
          <div className="grid grid-cols-3 divide-x divide-border border-b border-border">
            <Metric label="Live launches" value={currentLaunches.length.toLocaleString()} source="AUTH index" updatedAt={launchUpdatedAt} />
            <Metric label="Fee events" value={(events.data ?? []).length.toLocaleString()} source="Confirmed fee ledger" updatedAt={feeUpdatedAt} />
            <Metric label="Routed net" value={usd(feeTotal, { compact: true })} source="Fee ledger" updatedAt={feeUpdatedAt} />
          </div>
          <div className="flex items-end justify-between px-5 pt-5">
            <div>
              <p className="workspace-label">Receipts</p>
              <h2 className="mt-1.5 text-lg font-semibold">Payments, creator fees and launches</h2>
            </div>
            <Link to="/ledger" className="text-sm text-muted-foreground hover:text-foreground">Fee Ledger</Link>
          </div>
          {pending ? (
            <div className="p-5"><LoadingRows rows={5} /></div>
          ) : activity.length === 0 ? (
            <div className="p-5">
              <EmptyState
                title="No activity yet"
                description="Confirmed payments, creator fees and launches appear here with their Solana signature."
                icon={<Sparkles className="size-5" />}
                action={
                  <Button asChild size="sm" className="h-9 px-4"><Link to="/pay">Make a payment</Link></Button>
                }
              />
            </div>
          ) : (
            <ol className="mt-3 divide-y divide-border">{activity.slice(0, 10).map((item) => <ActivityRow key={`${item.kind}-${item.id}`} item={item} />)}</ol>
          )}
        </div>

        <div className="workspace-panel overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4">
            <div><p className="workspace-label">Discovery</p><h2 className="mt-1.5 text-lg font-semibold">Recent launches</h2></div>
            <Link to="/explore" className="text-sm text-muted-foreground hover:text-foreground">Explore</Link>
          </div>
          {pending ? (
            <div className="px-5 pb-5"><LoadingRows rows={4} /></div>
          ) : currentLaunches.length === 0 ? (
            <div className="px-5 pb-5">
              <EmptyState
                title="No launches yet"
                description="Verified mainnet launches appear here as soon as they confirm."
                icon={<Rocket className="size-5" />}
                action={<Button asChild size="sm" className="h-9 px-4"><Link to="/launch">Launch a token</Link></Button>}
              />
            </div>
          ) : (
            <ul className="divide-y divide-border border-t border-border">{currentLaunches.slice(0, 6).map((token) => (
              <li key={token.id}><Link to="/t/$mint" params={{ mint: token.mint }} className="row-hover flex items-center gap-3 px-5 py-3.5">
                <TokenAvatar symbol={token.symbol} size="sm" />
                <span className="min-w-0 flex-1"><span className="block truncate text-sm font-medium">{token.name}</span><span className="block text-xs text-muted-foreground">${token.symbol} · {timeAgo(token.created_at)}</span></span>
                <ArrowUpRight className="size-4 text-muted-foreground" />
              </Link></li>
            ))}</ul>
          )}
        </div>
      </section>
    </PageShell>
  );
}

/**
 * Illustrative product preview. Every number here is an example used to explain
 * the product — it is labelled ILLUSTRATIVE and is never sourced from or
 * written to AUTH accounting.
 */
/** Fixed example figures. Not a price feed, not accounting — see the card label. */
const DEMO_SOL = 50000;
const DEMO_USDC = 2700000;
const DEMO_SOL_USD = 186;
const DEMO_TOTAL_USD = DEMO_SOL * DEMO_SOL_USD + DEMO_USDC; // = $12,000,000 exactly
const demoUsd = (n: number) =>
  n.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });

function DemoIdentityCard() {
  // Real X profile for @elonmusk via the official X API. Only the balance is
  // illustrative — the identity shown is the live profile when lookup works.
  const profile = useQuery({
    queryKey: ["x-profile", "elonmusk"],
    queryFn: () => lookupXProfile({ data: { handle: "elonmusk" } }),
    staleTime: 30 * 60 * 1000,
    gcTime: 60 * 60 * 1000,
    retry: 1,
  });

  const resolved = profile.data?.status === "ok" ? profile.data.profile : undefined;
  const avatarUnavailable = !profile.isPending && !resolved?.avatarUrl;

  return (
    <div className="relative">
      <div className="rounded-3xl border border-border bg-card p-5 shadow-[0_30px_60px_-45px_rgb(0_0_0/0.45)] sm:p-6">
        <div className="flex items-center justify-between gap-3">
          <span className="workspace-label">Available to claim</span>
          <span className="rounded-full bg-warning/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.16em] text-warning">
            Illustrative
          </span>
        </div>

        <div className="mt-5 flex items-center gap-3">
          <SocialAvatar
            provider="x"
            handle={resolved?.username ?? "elonmusk"}
            avatarUrl={resolved?.avatarUrl ?? null}
            size="lg"
          />
          <div className="min-w-0">
            <p className="truncate text-base font-semibold">{resolved?.name ?? "Elon Musk"}</p>
            <p className="flex items-center gap-1.5 truncate text-sm text-muted-foreground">
              <ProviderIcon provider="x" brand className="size-3.5" />@
              {resolved?.username ?? "elonmusk"} · X identity
            </p>
          </div>
        </div>

        {avatarUnavailable ? (
          <p className="mt-2.5 text-[11px] leading-4 text-muted-foreground">
            Live X profile photo couldn&apos;t be loaded right now — showing initials instead.
          </p>
        ) : null}

        <p className="num mt-6 text-[clamp(2.75rem,8vw,4.25rem)] font-bold leading-none tracking-[-0.03em] text-success">
          {demoUsd(DEMO_TOTAL_USD)}
        </p>
        <p className="mt-2 text-sm text-muted-foreground">
          Illustrative total claimable value, not real funds.
        </p>

        <div className="mt-5 grid grid-cols-2 gap-3">
          <div className="rounded-2xl bg-surface p-3.5">
            <div className="flex items-center gap-2">
              <AssetIcon symbol="SOL" assetKey="solana:SOL" chainKey="solana" size="xs" showNetwork={false} />
              <span className="text-xs font-semibold text-muted-foreground">SOL</span>
            </div>
            <p className="mt-2 text-lg font-semibold text-success">
              {DEMO_SOL.toLocaleString("en-US", { minimumFractionDigits: 2 })}
            </p>
            <p className="text-xs text-muted-foreground">≈ {demoUsd(DEMO_SOL * DEMO_SOL_USD)}</p>
          </div>
          <div className="rounded-2xl bg-surface p-3.5">
            <div className="flex items-center gap-2">
              <AssetIcon symbol="USDC" assetKey="solana:USDC" chainKey="solana" size="xs" showNetwork={false} />
              <span className="text-xs font-semibold text-muted-foreground">USDC</span>
            </div>
            <p className="mt-2 text-lg font-semibold text-success">
              {DEMO_USDC.toLocaleString("en-US", { minimumFractionDigits: 2 })}
            </p>
            <p className="text-xs text-muted-foreground">≈ {demoUsd(DEMO_USDC)}</p>
          </div>
        </div>

        {/* Demo CTA only — routes to the real claim flow; the illustrative
            balance is never treated as claimable funds. */}
        <Button asChild size="lg" className="mt-5 w-full text-base font-semibold">
          <Link to="/claim">Claim</Link>
        </Button>



        <p className="mt-3 text-[11px] leading-4 text-muted-foreground">
          Example figures at an illustrative ${DEMO_SOL_USD}/SOL. The balance is illustrative; the
          profile is the live X account.
        </p>




        <p className="mt-5 text-xs leading-5 text-muted-foreground">
          This card explains how a claim looks. Real balances only ever appear in
          {" "}
          <Link to="/explore" className="font-medium text-foreground underline underline-offset-2">
            Explore
          </Link>{" "}
          and on identity pages.
        </p>
      </div>
    </div>
  );
}

function Metric({ label, value, source, updatedAt }: { label: string; value: string; source: string; updatedAt: string | null }) {
  return <div className="min-w-0 px-4 py-4 sm:px-5">
    <p className="workspace-label truncate">{label}</p>
    <p className="num mt-2 text-2xl font-semibold">{value}</p>
    <p className="mt-2 text-[11px] leading-4 text-muted-foreground" title={updatedAt ?? undefined}>
      <span className="block truncate">{source}</span>
      <span className="block truncate">Updated {updatedAt ? timeAgo(updatedAt) : "when data loads"}</span>
    </p>
  </div>;
}

function ActivityRow({ item }: { item: Activity }) {
  const handle = item.kind === "launch" ? null : item.handle;
  return <li className="row-hover grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 px-5 py-3.5">
    {item.kind === "launch" ? <TokenAvatar symbol={item.symbol} size="sm" /> : <IdentityAvatar handle={handle ?? "unknown"} size="sm" />}
    <div className="min-w-0">
      <p className="truncate text-sm"><span className="font-medium">{item.kind === "launch" ? `$${item.symbol}` : `@${handle}`}</span> <span className="text-muted-foreground">{item.kind === "payment" ? `received ${item.amount}` : item.kind === "fee" ? `received ${usd(item.value)} from $${item.symbol}` : `launched ${item.name}`}</span></p>
      <p className="mt-0.5 text-xs text-muted-foreground">{timeAgo(item.at)}</p>
    </div>
    {item.kind === "launch" ? <Link to="/t/$mint" params={{ mint: item.mint }} className="text-xs text-muted-foreground hover:text-foreground">View</Link> : item.signature ? <a href={explorerTx(item.signature)} target="_blank" rel="noreferrer noopener" className="text-xs text-muted-foreground hover:text-foreground">Receipt</a> : item.kind === "payment" ? <StatusPill status={item.status === "sent" ? "paid" : "pending"}>{item.status.replace(/_/g, " ")}</StatusPill> : null}
  </li>;
}

/** Turnkey brand reference — opens AUTH's public Turnkey proof page. */
function TurnkeyLink() {
  return (
    <Link
      to={TURNKEY_PROOF_PATH}
      className="font-medium text-foreground underline decoration-border underline-offset-2 hover:decoration-foreground"
    >
      Turnkey
    </Link>
  );
}
