import { createFileRoute, Link } from "@tanstack/react-router";
import { SectionHeading } from "@/components/primitives";

export const Route = createFileRoute("/docs/")({
  head: () => ({
    meta: [
      { title: "How AUTH works — payments, claims and routing" },
      {
        name: "description",
        content:
          "How creator fees are detected, split, paid out, and claimed on AUTH, plus payout statuses and security assumptions.",
      },
      { property: "og:title", content: "How AUTH works" },
      {
        property: "og:description",
        content: "Fee flow, recipient claims, routing, payout status and security assumptions.",
      },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DocsIndex,
});

function Block({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="border-t border-border py-6 text-sm leading-6 text-muted-foreground first:border-t-0">
      <h2 className="mb-3 text-base font-semibold text-foreground">{title}</h2>
      {children}
    </section>
  );
}

function DocsIndex() {
  return (
    <article className="workspace-panel px-6 py-8 sm:px-10">
      <div className="mb-8"><p className="workspace-label">AUTH documentation</p><SectionHeading
        title="How it works"
        description="AUTH routes creator fees from Solana tokens to the people a community wants to pay."
      /></div>

      <Block title="1. Fee flow">
        <p>
          A token is associated with an X handle at launch or afterwards. When that token generates
          creator fees on-chain, an indexer adapter records a fee event: source mint, transaction
          signature, gross amount, protocol fee and recipient net amount.
        </p>
        <p>
          Each event is keyed by its transaction signature. Re-delivery of the same signature is
          ignored, so replays and indexer retries cannot double-credit or double-pay a recipient.
        </p>
      </Block>

      <Block title="2. Routing">
        <p>
          A recipient's routing configuration is a set of destination splits that must total exactly
          100%. Destinations include holding in SOL, converting to USDC, withdrawing to a Solana
          wallet, an optional X Money payout adapter, token buyback, burn, a charity, or another
          recipient handle for creator/artist/community/charity splits.
        </p>
        <p>
          Routing is evaluated per fee event. Changing routing never rewrites already-processed
          events.
        </p>
      </Block>

      <Block title="3. Payout statuses">
        <ul className="list-disc space-y-1 pl-5">
          <li><span className="text-foreground">Pending</span> — attributed and queued for a rail.</li>
          <li><span className="text-foreground">Processing</span> — handed to a payout adapter.</li>
          <li><span className="text-foreground">Paid</span> — the adapter confirmed delivery.</li>
          <li><span className="text-foreground">Claimable</span> — the rail failed or isn't configured; the funds stay attributed to the recipient.</li>
          <li><span className="text-foreground">Failed</span> — a terminal adapter error; the balance becomes claimable, never swept.</li>
        </ul>
      </Block>

      <Block title="4. Claims and fallback">
        <p>
          If an off-chain payout cannot be delivered — no X Money account, a rejected transfer, a
          disabled adapter — the amount remains attributable to the intended recipient. It is never
          redirected to the protocol treasury.
        </p>
        <p>
          To claim, the recipient signs in, verifies ownership of the handle, connects a Solana
          wallet and requests settlement of the claimable balance to that wallet.
        </p>
      </Block>

      <Block title="5. Security assumptions">
        <ul className="list-disc space-y-1 pl-5">
          <li>AUTH never asks for, stores, logs or displays private keys or seed phrases.</li>
          <li>Withdrawals are user-signed, or executed by explicitly configured server infrastructure — never by pasted keys.</li>
          <li>Row-level security scopes recipient data to its owner; admin actions require an assigned role and are written to an audit log.</li>
          <li>Event ingestion and payout execution are idempotent and replay-protected.</li>
        </ul>
      </Block>

      <Block title="6. Launch pricing">
        <p>
          <span className="text-foreground">AUTH charges a 0 SOL platform fee</span> to create a
          coin and adds no surcharge on top of pump.fun, which itself lists coin creation at 0 SOL.
        </p>
        <p>
          Every launch does require a dev buy of at least 0.001 SOL, funded by the launcher. A dev
          buy is SOL you spend buying your own token at launch; the purchased tokens belong to you
          and are delivered to the Solana wallet you provide. AUTH takes no cut of a dev buy. The
          Solana network cost of the create transaction is paid by the launch account that signs
          it. Creator fees stay separate and belong to the social recipient identity.
        </p>
      </Block>

      <Block title="7. Economics">
        <p>
          The protocol fee is a configurable setting, not a hard-coded constant. The current
          configuration is 90% recipient / 10% protocol and is visible in the admin settings area.
        </p>
      </Block>

      <Block title="8. Status of this deployment">
        <p>
          Payments, launches and creator-fee records shown in AUTH are real Solana mainnet
          activity — nothing is simulated. See{" "}
          <Link to="/docs/integrations" className="text-primary hover:underline">
            integrations
          </Link>{" "}
          for the exact status of each adapter.
        </p>
      </Block>
    </article>
  );
}
