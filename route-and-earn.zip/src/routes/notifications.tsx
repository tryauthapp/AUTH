import { SocialAvatar } from "@/components/social/SocialIdentity";
import { ProviderIcon, asProvider } from "@/components/social/ProviderIcon";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Bell, BellRing } from "lucide-react";
import { useSession } from "@/hooks/useSession";
import {
  feeEventsQuery,
  myPaymentsQuery,
  paymentsQuery,
  payoutsQuery,
  recipientsQuery,
} from "@/lib/queries";
import { EmptyState, LoadingRows, PageHeader, PageShell, SectionHeading } from "@/components/primitives";
import { Button } from "@/components/ui/button";
import { timeAgo, usd } from "@/lib/format";

export const Route = createFileRoute("/notifications")({
  head: () => ({
    meta: [
      { title: "Notifications — AUTH" },
      {
        name: "description",
        content:
          "Payments waiting for you, claimable balances and creator-fee activity for the X usernames you have claimed.",
      },
      { property: "og:title", content: "Notifications — AUTH" },
      {
        property: "og:description",
        content: "Payments waiting for you, claimable balances and fee activity.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Notifications,
});

function Notifications() {
  const { session, loading } = useSession();
  const recipients = useQuery(recipientsQuery());
  const payments = useQuery(paymentsQuery(200));
  const myPayments = useQuery(myPaymentsQuery(session?.user.id, 200));
  const payouts = useQuery(payoutsQuery());
  const events = useQuery(feeEventsQuery());

  if (loading || recipients.isPending) {
    return (
      <PageShell width="narrow">
        <LoadingRows rows={6} />
      </PageShell>
    );
  }

  if (!session) {
    return (
      <PageShell width="narrow">
        <Header />
        <EmptyState
          title="No activity yet"
          description="Notifications follow a claimed X handle. Paying needs no account — proving a handle you own does."
          icon={<BellRing className="size-5" />}
          action={
            <div className="flex flex-wrap justify-center gap-2">
              <Button asChild size="sm" className="h-9 px-4"><Link to="/claim">Claim your username</Link></Button>
              <Button asChild size="sm" variant="outline" className="h-9 px-4"><Link to="/pay">Make a payment</Link></Button>
              <Button asChild size="sm" variant="ghost" className="h-9 px-4"><Link to="/launch">Launch a token</Link></Button>
            </div>
          }
        />
      </PageShell>
    );
  }

  const mine = (recipients.data ?? []).filter((r) => r.claimed_by === session.user.id);
  const mineIds = new Set(mine.map((r) => r.id));
  const incoming = (payments.data ?? []).filter((p) => mineIds.has(p.recipient_id));
  const reserved = (myPayments.data ?? []).filter((p) => p.status === "awaiting_recipient");
  const claimable = (payouts.data ?? []).filter(
    (p) => mineIds.has(p.recipient_id) && p.status === "claimable",
  );
  const fees = (events.data ?? []).filter((e) => e.recipient && mineIds.has(e.recipient.id)).slice(0, 15);

  const empty =
    incoming.length === 0 && reserved.length === 0 && claimable.length === 0 && fees.length === 0;

  return (
    <PageShell width="narrow">
      <Header />

      {mine.length === 0 ? (
        <div className="mb-6 rounded-2xl bg-surface p-5">
          <p className="text-[15px] font-semibold">Claim your X handle</p>
          <p className="mt-1 text-sm leading-6 text-muted-foreground">
            Prove you own the handle to receive payments and creator fees against it.
          </p>
          <Button asChild size="sm" className="mt-3 h-9 px-4">
            <Link to="/dashboard">Claim your username</Link>
          </Button>
        </div>
      ) : null}

      {empty ? (
        <EmptyState
          title="Nothing new"
          description="Payments, claims and creator-fee activity appear here as they confirm."
          icon={<BellRing className="size-5" />}
          action={<Button asChild size="sm" variant="outline" className="h-9 px-4"><Link to="/pay">Make a payment</Link></Button>}
        />
      ) : null}

      {claimable.length > 0 ? (
        <section className="mb-6">
          <SectionHeading title="Claimable balances" description="A payout rail failed — the funds are still yours." />
          <ul className="space-y-2">
            {claimable.map((p) => (
              <li key={p.id} className="panel flex flex-wrap items-center gap-2 p-3 text-sm">
                <span className="font-medium">{p.label ?? p.destination}</span>
                <span className="num">{usd(Number(p.amount_usd))}</span>
                <Link to="/dashboard" className="ml-auto text-xs text-info hover:underline">
                  Claim →
                </Link>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {incoming.length > 0 ? (
        <section className="mb-6">
          <SectionHeading title="Payments to you" />
          <ul className="space-y-2">
            {incoming.map((p) => (
              <li key={p.id} className="panel flex flex-wrap items-center gap-2 p-3 text-sm">
                <span className="num font-medium">
                  {Number(p.amount)} {p.asset}
                </span>
                <span className="text-muted-foreground">{p.status.replace(/_/g, " ")}</span>
                <span className="ml-auto text-xs text-muted-foreground">{timeAgo(p.created_at)}</span>
                {p.note ? <p className="w-full text-xs text-muted-foreground">“{p.note}”</p> : null}
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {reserved.length > 0 ? (
        <section className="mb-6">
          <SectionHeading
            title="Payments you reserved"
            description="Unfunded until the username has a verified payout wallet."
          />
          <ul className="space-y-2">
            {reserved.map((p) => (
              <li key={p.id} className="panel flex flex-wrap items-center gap-2 p-3 text-sm">
                <Link
                  to="/u/$handle"
                  params={{ handle: p.recipient_handle }}
                  className="inline-flex items-center gap-1.5 font-medium hover:underline"
                >
                  <SocialAvatar
                    provider={asProvider(p.recipient_provider)}
                    handle={p.recipient_handle}
                    size="sm"
                  />
                  @{p.recipient_handle}
                </Link>
                <span className="num">
                  {Number(p.amount)} {p.asset}
                </span>
                <span className="ml-auto text-xs text-muted-foreground">{timeAgo(p.created_at)}</span>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {fees.length > 0 ? (
        <section>
          <SectionHeading title="Creator-fee activity" />
          <ul className="space-y-2">
            {fees.map((e) => (
              <li key={e.id} className="panel flex flex-wrap items-center gap-2 p-3 text-sm">
                <span className="font-medium">${e.token?.symbol ?? "—"}</span>
                <span className="num">{usd(Number(e.net_usd))}</span>
                <span className="ml-auto text-xs text-muted-foreground">{timeAgo(e.occurred_at)}</span>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </PageShell>
  );
}

function Header() {
  return (
    <PageHeader
      eyebrow={
        <span className="inline-flex items-center gap-1.5">
          <Bell className="size-3.5" /> Activity
        </span>
      }
      title="Notifications"
      description="Payments, claims and creator-fee activity tied to your claimed username."
    />
  );
}
