import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/LegalPage";

export const Route = createFileRoute("/risk")({
  head: () => ({
    meta: [
      { title: "Risk disclosure — AUTH" },
      {
        name: "description",
        content: "Placeholder risk disclosure covering volatility, payout-rail failure, verification and compliance dependencies.",
      },
      { property: "og:title", content: "Risk disclosure — AUTH" },
      { property: "og:description", content: "Volatility, payout failure, verification and compliance risks." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <LegalPage
      title="Risk disclosure"
      sections={[
        {
          heading: "Placeholder document",
          body: ["A placeholder. Replace with a reviewed disclosure before production use."],
        },
        {
          heading: "Market risk",
          body: [
            "Creator fees originate from trading activity in volatile tokens. Fee income is unpredictable and can fall to zero. Amounts shown in USD are estimates at the time of the event.",
          ],
        },
        {
          heading: "Payout-rail risk",
          body: [
            "Off-chain payout rails can reject, delay or reverse a transfer. When that happens the amount remains attributable to the intended recipient as a claimable balance — it is never moved to the protocol treasury — but delivery timing is outside the protocol's control.",
          ],
        },
        {
          heading: "Verification and attribution",
          body: [
            "Anyone can associate a token with a handle. Attribution alone is not an endorsement by the handle's owner, and funds only become withdrawable after the handle is verified and a wallet is connected.",
          ],
        },
        {
          heading: "Compliance",
          body: [
            "Identity, tax, sanctions and payment requirements depend on the payout provider and the jurisdictions of the operator and recipient. Some recipients may be unable to receive payouts through some rails.",
          ],
        },
        {
          heading: "Software risk",
          body: [
            "Smart contracts, indexers and integrations can fail or contain defects. AUTH is provided without warranty.",
          ],
        },
      ]}
    />
  ),
});
