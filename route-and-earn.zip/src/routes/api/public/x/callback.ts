import { createFileRoute } from "@tanstack/react-router";

/**
 * X OAuth 2.0 callback.
 *
 * Kept on its original path because that URL is registered in the X developer
 * app. It runs the same shared link logic as every other provider.
 */

export const Route = createFileRoute("/api/public/x/callback")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const origin = url.origin;

        const { providerMeta } = await import("@/lib/social/providers");
        const { backToClaim, completeSocialLink, consumeState } = await import(
          "@/lib/social/link.server"
        );
        const meta = providerMeta("x")!;

        const code = url.searchParams.get("code");
        const state = url.searchParams.get("state");
        if (url.searchParams.get("error")) return backToClaim(origin, "x", { status: "invalid" });
        if (!code || !state) return backToClaim(origin, "x", { status: "invalid" });

        const row = await consumeState(state);
        if (!row || row.provider !== "x") {
          return backToClaim(origin, "x", { status: "expired" });
        }

        const outcome = await completeSocialLink({ meta, row, code });
        return backToClaim(origin, "x", outcome);
      },
    },
  },
});
