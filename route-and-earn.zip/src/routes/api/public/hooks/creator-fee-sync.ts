/**
 * Creator-fee reconciliation endpoint.
 *
 * Called every 5 minutes by the scheduler, and on demand by the admin panel.
 * Authenticated with the project cron secret — there is no unauthenticated way
 * to run reconciliation. Work is bounded per run and every run is recorded for
 * admin visibility.
 */
import { createFileRoute } from "@tanstack/react-router";
import { authenticateFeeSyncRequest } from "@/lib/fees/cron-guard.server";

async function runSync(trigger: string, mintFilter?: string | null) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { reconcileCreatorFees } = await import("@/lib/fees/creator-fee-indexer.server");
  const { settleCreatorFees } = await import("@/lib/fees/creator-fee-settlement.server");

  const { data: run } = await supabaseAdmin
    .from("creator_fee_sync_runs")
    .insert({ trigger, status: "running" })
    .select("id")
    .single();

  try {
    const reconciled = await reconcileCreatorFees(
      mintFilter ? { maxMints: 1, maxSignaturesPerMint: 50 } : undefined,
    );
    const settled = await settleCreatorFees();
    const errors = [...reconciled.errors, ...settled.errors];

    if (run) {
      await supabaseAdmin
        .from("creator_fee_sync_runs")
        .update({
          status: errors.length > 0 ? "partial" : "ok",
          mints_scanned: reconciled.mintsScanned,
          events_processed: reconciled.eventsProcessed,
          credits_created: reconciled.creditsCreated,
          lamports_credited: reconciled.lamportsCredited,
          settlements: settled.settlements,
          settlement_note: settled.note,
          error: errors.length > 0 ? errors.slice(0, 5).join(" | ").slice(0, 900) : null,
          finished_at: new Date().toISOString(),
        })
        .eq("id", run.id);
    }

    return {
      ok: true,
      mintsScanned: reconciled.mintsScanned,
      eventsProcessed: reconciled.eventsProcessed,
      creditsCreated: reconciled.creditsCreated,
      settlements: settled.settlements,
      errors,
    };
  } catch (e) {
    const message = e instanceof Error ? e.message : "Reconciliation failed.";
    if (run) {
      await supabaseAdmin
        .from("creator_fee_sync_runs")
        .update({ status: "failed", error: message.slice(0, 900), finished_at: new Date().toISOString() })
        .eq("id", run.id);
    }
    return { ok: false, error: message };
  }
}

export const Route = createFileRoute("/api/public/hooks/creator-fee-sync")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const unauthorized = await authenticateFeeSyncRequest(request);
        if (unauthorized) return unauthorized;

        let body: { trigger?: string; mint?: string } = {};
        try {
          body = (await request.json()) as typeof body;
        } catch {
          body = {};
        }

        const result = await runSync(
          typeof body.trigger === "string" ? body.trigger.slice(0, 40) : "cron",
          typeof body.mint === "string" ? body.mint : null,
        );
        return new Response(JSON.stringify(result), {
          status: result.ok ? 200 : 500,
          headers: { "Content-Type": "application/json" },
        });
      },
    },
  },
});
