/**
 * Event-driven creator-fee trigger.
 *
 * pump.fun publishes no per-mint fee webhook, so the event source here is the
 * chain: a Helius webhook on a launched mint (or its creator vault) calls this
 * endpoint the moment a trade lands, and AUTH reconciles those mints straight
 * away instead of waiting for the 5-minute fallback pass.
 *
 * Authenticated with the project cron secret sent as `Authorization: Bearer …`.
 * The same detection code path runs, so an event delivery, a retry and a cron
 * pass can never produce different or duplicated credits.
 */
import { createFileRoute } from "@tanstack/react-router";
import { authenticateFeeSyncRequest } from "@/lib/fees/cron-guard.server";

export const Route = createFileRoute("/api/public/hooks/creator-fee-event")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const unauthorized = await authenticateFeeSyncRequest(request);
        if (unauthorized) return unauthorized;

        const { reconcileCreatorFees } = await import("@/lib/fees/creator-fee-indexer.server");
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const { data: run } = await supabaseAdmin
          .from("creator_fee_sync_runs")
          .insert({ trigger: "event", status: "running" })
          .select("id")
          .single();

        const result = await reconcileCreatorFees({ maxMints: 10, maxSignaturesPerMint: 50 });

        if (run) {
          await supabaseAdmin
            .from("creator_fee_sync_runs")
            .update({
              status: result.errors.length > 0 ? "partial" : "ok",
              mints_scanned: result.mintsScanned,
              events_processed: result.eventsProcessed,
              credits_created: result.creditsCreated,
              lamports_credited: result.lamportsCredited,
              error: result.errors.length > 0 ? result.errors.slice(0, 5).join(" | ").slice(0, 900) : null,
              finished_at: new Date().toISOString(),
            })
            .eq("id", run.id);
        }

        return new Response(JSON.stringify({ ok: true, ...result }), {
          headers: { "Content-Type": "application/json" },
        });
      },
    },
  },
});
