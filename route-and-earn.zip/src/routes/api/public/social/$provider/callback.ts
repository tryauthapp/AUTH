import { createFileRoute } from "@tanstack/react-router";

/**
 * Unified social identity OAuth callback (TikTok, YouTube, Twitch).
 *
 * X keeps its original /api/public/x/callback path because that URL is already
 * registered in the X developer app; both paths run the same shared logic.
 *
 * Authorization codes and access tokens are handled server-side only and are
 * never stored. Completing OAuth links an identity — it never moves funds.
 */

export const Route = createFileRoute("/api/public/social/$provider/callback")({
  server: {
    handlers: {
      GET: async ({ request, params }) => {
        const url = new URL(request.url);
        const origin = url.origin;

        const { isSocialProvider, providerMeta } = await import("@/lib/social/providers");
        const { backToClaim, completeSocialLink, consumeState } = await import(
          "@/lib/social/link.server"
        );

        const providerId = params.provider;
        if (!isSocialProvider(providerId)) {
          return new Response("Unknown provider", { status: 404 });
        }
        const meta = providerMeta(providerId)!;

        const code = url.searchParams.get("code");
        const state = url.searchParams.get("state");

        // A bare GET with no OAuth parameters is not a real callback — it is a
        // crawler or a platform URL-ownership check (TikTok verifies the exact
        // redirect URL and looks for its verification meta tag in the HTML).
        if (!code && !state && ![...url.searchParams.keys()].length) {
          const tiktokVerification = "WWgzhmZaGUO7SclcTP8LWbjzjn7lbE6f";
          return new Response(
            `<!doctype html><html><head><meta charset="utf-8">` +
              `<meta name="tiktok-developers-site-verification" content="${tiktokVerification}">` +
              `<title>OAuth callback</title></head>` +
              `<body>OAuth callback endpoint.` +
              `<p>tiktok-developers-site-verification=${tiktokVerification}</p>` +
              `</body></html>`,
            { headers: { "content-type": "text/html; charset=utf-8" } },
          );
        }
        if (url.searchParams.get("error")) {
          return backToClaim(origin, providerId, { status: "invalid" });
        }
        if (!code || !state) return backToClaim(origin, providerId, { status: "invalid" });

        const row = await consumeState(state);
        if (!row || row.provider !== providerId) {
          return backToClaim(origin, providerId, { status: "expired" });
        }

        const outcome = await completeSocialLink({ meta, row, code });
        return backToClaim(origin, providerId, outcome);
      },
    },
  },
});
