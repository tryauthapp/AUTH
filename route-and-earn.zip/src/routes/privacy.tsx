import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/LegalPage";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy notice — AUTH" },
      {
        name: "description",
        content: "Privacy notice describing what AUTH stores and what it deliberately never stores.",
      },
      { property: "og:title", content: "Privacy notice — AUTH" },
      { property: "og:description", content: "What AUTH stores, and what it never stores." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <LegalPage
      title="Privacy notice"
      sections={[
        {
          heading: "Placeholder document",
          body: [
            "This is a placeholder and must be replaced with a reviewed notice before production use.",
          ],
        },
        {
          heading: "What is stored",
          body: [
            "Account email and sign-in metadata; claimed X handles and their verification state; Solana wallet addresses you add; routing configurations; and the fee, payout, claim and audit records that make the ledger auditable.",
          ],
        },
        {
          heading: "What is never stored",
          body: [
            "Private keys, seed phrases, or any material that could move funds without your signature. These are never requested, logged, transmitted or displayed anywhere in the product.",
          ],
        },
        {
          heading: "Public information",
          body: [
            "Recipient pages, token pages and the fee ledger are public by design. Handles, mints, transaction signatures and aggregate amounts on those pages are visible to anyone.",
          ],
        },
        {
          heading: "Third parties",
          body: [
            "Once configured, indexers, swap routers, identity providers and payout providers each receive only the data needed to perform their function. Their own notices apply and may vary by jurisdiction.",
          ],
        },
      ]}
    />
  ),
});
