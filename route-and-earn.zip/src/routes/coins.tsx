import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Rocket } from "lucide-react";
import { AUTH_ERA_START, launchedTokensQuery } from "@/lib/queries";
import {
  EmptyState,
  ErrorState,
  LoadingRows,
  SectionHeading,
  StatCard,
} from "@/components/primitives";
import { TokenAvatar } from "@/components/Avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { timeAgo } from "@/lib/format";

export const Route = createFileRoute("/coins")({
  head: () => ({
    meta: [
      { title: "Tokens launched on AUTH" },
      {
        name: "description",
        content:
          "Every token launched through AUTH on Solana mainnet, with its mint, creator-fee routing and launch details.",
      },
      { property: "og:title", content: "Tokens launched on AUTH" },
      {
        property: "og:description",
        content: "Every token launched through AUTH on Solana mainnet.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CoinsPage,
});

function CoinsPage() {
  const tokens = useQuery(launchedTokensQuery());
  const [q, setQ] = useState("");

  const all = (tokens.data ?? []).filter(
    (token) => !token.is_demo && token.created_at >= AUTH_ERA_START,
  );
  const query = q.trim().toLowerCase();
  const list = query
    ? all.filter(
        (t) =>
          t.symbol.toLowerCase().includes(query) ||
          t.name.toLowerCase().includes(query) ||
          t.mint.toLowerCase().includes(query),
      )
    : all;

  const launched = all.filter((t) => Boolean(t.launch_signature)).length;

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-6 md:px-7">
      <SectionHeading
        title="Coins"
         description="Every token launched through AUTH, newest first."
        action={
          <Button asChild size="sm" className="press rounded-full">
            <Link to="/launch">
              <Rocket className="size-4" /> Launch a coin
            </Link>
          </Button>
        }
      />

      <div className="mb-5 mt-4 grid gap-3 sm:grid-cols-2">
        <StatCard label="Coins indexed" value={String(all.length)} accent />
        <StatCard label="Launched via AUTH" value={String(launched)} />
      </div>

      <Input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Search by name, ticker or mint"
        className="mb-4"
      />

      {tokens.isPending ? (
        <LoadingRows rows={6} />
      ) : tokens.error ? (
        <ErrorState error={tokens.error} retry={tokens.refetch} />
      ) : list.length === 0 ? (
        <EmptyState
          title={all.length === 0 ? "No coins yet" : "No matches"}
          description={
            all.length === 0
              ? "Tokens launched through AUTH will appear here."
              : "Try another name, ticker or mint address."
          }
        />
      ) : (
        <ul className="space-y-2">
          {list.map((t) => (
            <li key={t.id}>
              <Link
                to="/t/$mint"
                params={{ mint: t.mint }}
                className="panel flex items-center gap-3 p-3 transition-colors hover:bg-secondary/60"
              >
                <TokenAvatar symbol={t.symbol} src={t.image_url} />
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-2">
                    <span className="truncate font-bold">{t.name}</span>
                    <span className="num text-sm text-muted-foreground">${t.symbol}</span>
                  </span>
                  <span className="num block truncate text-xs text-muted-foreground">
                    {t.mint.slice(0, 6)}…{t.mint.slice(-6)}
                  </span>
                </span>
                <span className="shrink-0 text-right text-xs text-muted-foreground">
                  <span className="block capitalize">{String(t.source).replace("_", ".")}</span>
                  <span className="block">{timeAgo(t.created_at)}</span>
                </span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
