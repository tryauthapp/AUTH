import { createFileRoute } from "@tanstack/react-router";
import { PlatformProfile } from "@/components/PlatformProfile";

export const Route = createFileRoute("/twitch/$handle")({
  head: ({ params }) => ({
    meta: [
      { title: `${params.handle} on Twitch — pay them in crypto on AUTH` },
      {
        name: "description",
        content: `Send SOL or USDC to ${params.handle} on Twitch and see their claimable creator fees on AUTH.`,
      },
      { property: "og:title", content: `${params.handle} on Twitch — AUTH` },
      {
        property: "og:description",
        content: `Pay ${params.handle} in crypto and see their creator-fee routing.`,
      },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => <PlatformProfile provider="twitch" handle={Route.useParams().handle} />,
});
