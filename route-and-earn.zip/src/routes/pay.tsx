import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { PayComposer } from "@/components/PayComposer";
import { paymentsQuery } from "@/lib/queries";
import { EmptyState, PageHeader, PageShell, SectionHeading, StatusPill } from "@/components/primitives";
import { timeAgo, shortAddress, usd } from "@/lib/format";
import { explorerTx } from "@/lib/solana";

export const Route = createFileRoute("/pay")({
  validateSearch: (search: Record<string, unknown>): { to?: string } =>
    typeof search["to"] === "string" ? { to: search["to"] as string } : {},
  head: () => ({
    meta: [
      { title: "Pay any @username — AUTH" },
      {
        name: "description",
        content:
          "Send SOL or USDC to any social username without creating an account. Payments settle on Solana straight away — even if the recipient has never joined AUTH. The funds stay tied to their account until they verify it and claim.",
      },
      { property: "og:title", content: "Pay any @username — AUTH" },
      {
        property: "og:description",
        content: "Send SOL or USDC to an X username. You authorize every transfer — no wallet extension needed.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PayPage,
});

function PayPage() {
  const { to } = Route.useSearch();
  const payments = useQuery(paymentsQuery(30));

  const recent = payments.data ?? [];

  return (
    <PageShell>
      <PageHeader
        eyebrow="Pay"
        title="Pay a username"
        description="Send SOL or USDC to a username. You authorize every transfer."
        action={<span className="workspace-label text-success">Solana mainnet</span>}
      />
      <div className={recent.length > 0 ? "grid gap-4 sm:gap-5 xl:grid-cols-[minmax(0,1fr)_380px]" : "mx-auto max-w-3xl"}>
        <section className="workspace-panel p-4 sm:p-6 lg:p-7"><PayComposer initialHandle={to ?? ""} /></section>
        {recent.length === 0 ? null : (
        <aside className="workspace-panel overflow-hidden">
        <div className="border-b border-border px-4 py-3"><SectionHeading title="Recent payments" description="Confirmed public activity." /></div>
        {(
          <ul className="divide-y divide-border">

            {(payments.data ?? []).map((p) => (
              <li key={p.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 p-3">
                <Link
                  to="/u/$handle"
                  params={{ handle: p.recipient_handle }}
                  className="font-medium hover:underline"
                >
                  @{p.recipient_handle}
                </Link>
                <span className="num text-sm">
                  {Number(p.amount)} {p.asset}
                </span>
                {p.amount_usd ? (
                  <span className="text-xs text-muted-foreground">{usd(Number(p.amount_usd))}</span>
                ) : null}
                <PaymentStatus status={p.status} />
                <span className="ml-auto text-xs text-muted-foreground">{timeAgo(p.created_at)}</span>
                {p.tx_signature ? (
                  <a
                    href={explorerTx(p.tx_signature)}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="num w-full text-xs text-primary hover:underline sm:w-auto"
                  >
                    {shortAddress(p.tx_signature, 6)}
                  </a>
                ) : null}
                {p.note ? <p className="w-full text-xs text-muted-foreground">“{p.note}”</p> : null}
              </li>
            ))}
          </ul>
        )}
        </aside>
        )}
      </div>
    </PageShell>
  );
}

export function PaymentStatus({ status }: { status: string }) {
  const map: Record<string, { tone: "paid" | "pending" | "failed" | "claimable"; label: string }> = {
    sent: { tone: "paid", label: "Sent" },
    processing: { tone: "pending", label: "Confirming" },
    ready: { tone: "pending", label: "Ready" },
    awaiting_recipient: { tone: "claimable", label: "Reserved · unfunded" },
    failed: { tone: "failed", label: "Failed" },
  };
  const entry = map[status] ?? { tone: "pending" as const, label: status };
  return <StatusPill status={entry.tone}>{entry.label}</StatusPill>;
}
