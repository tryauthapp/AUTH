import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/hooks/useSession";
import {
  claimsQuery,
  feeEventsQuery,
  payoutsQuery,
  recipientStats,
  recipientsQuery,
  routingQuery,
} from "@/lib/queries";
import {
  EmptyState,
  ErrorState,
  LoadingRows,
  SectionHeading,
  StatCard,
  StatusPill,
} from "@/components/primitives";
import { RoutingEditor } from "@/components/RoutingEditor";
import { LedgerTable, PayoutStatusPill } from "@/components/LedgerTable";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { shortAddress, timeAgo, usd } from "@/lib/format";
import { PayoutAccountPanel } from "@/components/PayoutAccountPanel";
import { PayoutSigner } from "@/components/PayoutSigner";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — AUTH" },
      {
        name: "description",
        content: "Claim your handle, configure fee routing, set a payout destination and settle claimable balances.",
      },
      { property: "og:title", content: "Dashboard — AUTH" },
      { property: "og:description", content: "Configure routing and settle claimable balances." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const { user } = useSession();
  const recipients = useQuery(recipientsQuery());
  const events = useQuery(feeEventsQuery());
  const payouts = useQuery(payoutsQuery());

  const mine = (recipients.data ?? []).filter((r) => r.claimed_by === user?.id);
  const recipient = mine[0] ?? null;
  const routing = useQuery(routingQuery(recipient?.id));
  const claims = useQuery(claimsQuery(recipient?.id));

  if (recipients.isPending || events.isPending || payouts.isPending) {
    return (
      <div className="w-full px-4 py-8 sm:py-10">
        <LoadingRows rows={7} />
      </div>
    );
  }
  if (recipients.error) {
    return (
      <div className="w-full px-4 py-8 sm:py-10">
        <ErrorState error={recipients.error} retry={recipients.refetch} />
      </div>
    );
  }

  if (!recipient) {
    return (
      <div className="mx-auto w-full max-w-2xl px-4 py-10 sm:py-12">
        <SectionHeading
          title="Claim your handle"
          description="Link an X handle to this account so you can configure routing and settle balances."
        />
        <ClaimHandleForm />
      </div>
    );
  }

  const stats = recipientStats(events.data ?? [], payouts.data ?? [], recipient.id);
  const myEvents = (events.data ?? []).filter((e) => e.recipient?.id === recipient.id);
  const myPayouts = (payouts.data ?? []).filter((p) => p.recipient_id === recipient.id);
  const claimable = myPayouts.filter((p) => p.status === "claimable" || p.status === "failed");

  return (
    <div className="w-full px-4 py-8 sm:py-10">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="text-xl font-bold sm:text-2xl">@{recipient.handle}</h1>
        <StatusPill status={recipient.verification === "verified" ? "verified" : "unverified"}>
          {recipient.verification}
        </StatusPill>
        <Link
          to="/u/$handle"
          params={{ handle: recipient.handle }}
          className="ml-auto text-sm text-primary hover:underline"
        >
          View public page →
        </Link>
      </div>

      {recipient.verification !== "verified" ? (
        <div className="panel mt-4 border-warning/40 p-4 text-sm">
          <p className="font-medium text-warning">Verification pending</p>
          <p className="mt-1 text-muted-foreground">
            Complete X verification from the claim page, or use the proof-post fallback for manual
            review. Your balance keeps accruing and is never reassigned while you wait.
          </p>
        </div>
      ) : null}

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Lifetime net" value={usd(stats.lifetime, { compact: true })} accent />
        <StatCard label="Paid out" value={usd(stats.paid, { compact: true })} />
        <StatCard label="Pending" value={usd(stats.pending, { compact: true })} />
        <StatCard label="Claimable" value={usd(stats.claimable, { compact: true })} />
      </div>

      <div className="mt-10">
        <SectionHeading
          title="Routing"
          description="Splits must total exactly 100%. Nothing is routed off-platform until adapters are configured."
        />
        {routing.isPending ? (
          <LoadingRows rows={3} />
        ) : (
          <RoutingEditor recipientId={recipient.id} config={routing.data ?? null} />
        )}
      </div>

      <div className="mt-10 grid gap-6 lg:grid-cols-2">
        <div>
          <SectionHeading
            title="Payout destination"
            description="Authorize a plain-text ownership message from your passkey account. Verified destinations receive on-chain payouts."
          />
          <PayoutAccountPanel recipientId={recipient.id} />
          <div className="mt-4">
            <WalletManager recipientId={recipient.id} />
          </div>
        </div>
        <div>
          <SectionHeading
            title="Claimable balances"
            description="Payouts awaiting your signature, or that a rail could not deliver. They stay yours."
          />
          {claimable.length === 0 ? (
            <EmptyState title="Nothing to claim" description="Every payout was delivered or is still pending." />
          ) : (
            <div className="panel divide-y divide-border">
              {claimable.map((p) => (
                <div key={p.id} className="space-y-3 p-4">
                  <ClaimRow
                    payoutId={p.id}
                    recipientId={recipient.id}
                    label={p.label ?? p.destination}
                    amount={Number(p.amount_usd)}
                    reason={p.failure_reason}
                    claimed={(claims.data ?? []).some((c) => c.payout_id === p.id)}
                  />
                  <PayoutSigner
                    payoutId={p.id}
                    label={p.label ?? p.destination}
                    amountUsd={Number(p.amount_usd)}
                  />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {(claims.data ?? []).length > 0 ? (
        <div className="mt-10">
          <SectionHeading title="Claim requests" />
          <div className="panel divide-y divide-border">
            {(claims.data ?? []).map((c) => (
              <div key={c.id} className="flex flex-wrap items-center gap-3 p-4 text-sm">
                <PayoutStatusPill status={c.status} />
                <span className="num text-xs text-muted-foreground">
                  {c.wallet_address ? shortAddress(c.wallet_address, 6) : "No wallet set"}
                </span>
                <span className="text-xs text-muted-foreground">{timeAgo(c.created_at)}</span>
                <span className="num ml-auto">{usd(Number(c.amount_usd))}</span>
              </div>
            ))}
          </div>
        </div>
      ) : null}

      <div className="mt-10">
        <SectionHeading title="Your fee events" />
        {myEvents.length === 0 ? (
          <EmptyState title="No fee events yet" />
        ) : (
          <LedgerTable events={myEvents.slice(0, 40)} payouts={myPayouts} showRecipient={false} />
        )}
      </div>
    </div>
  );
}

function ClaimHandleForm() {
  const { user } = useSession();
  const queryClient = useQueryClient();
  const [handle, setHandle] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const normalized = handle.trim().replace(/^@/, "").toLowerCase();
    if (!normalized || !user) return;
    setBusy(true);
    try {
      const { data: existing, error: lookupError } = await supabase
        .from("recipients")
        .select("id,claimed_by")
        .eq("handle", normalized)
        .maybeSingle();
      if (lookupError) throw new Error(lookupError.message);

      if (existing?.claimed_by && existing.claimed_by !== user.id) {
        throw new Error("That handle is already claimed by another account.");
      }

      if (existing) {
        const { error } = await supabase
          .from("recipients")
          .update({ claimed_by: user.id, verification: "pending" })
          .eq("id", existing.id);
        if (error) throw new Error(error.message);
      } else {
        const { error } = await supabase.from("recipients").insert({
          handle: normalized,
          display_name: `@${normalized}`,
          claimed_by: user.id,
          verification: "pending",
          is_demo: false,
        });
        if (error) throw new Error(error.message);
      }

      await queryClient.invalidateQueries({ queryKey: ["recipients"] });
      toast.success(`@${normalized} linked. An admin will confirm ownership.`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not claim that handle.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="panel space-y-4 p-6">
      <div className="space-y-2">
        <Label htmlFor="claim-handle">X handle</Label>
        <Input
          id="claim-handle"
          value={handle}
          onChange={(e) => setHandle(e.target.value)}
          placeholder="@username"
          required
        />
      </div>
      <Button type="submit" disabled={busy}>
        {busy ? "Linking…" : "Claim handle"}
      </Button>
      <p className="text-xs text-muted-foreground">
        Claiming marks the handle as pending verification. It does not move any funds, and no
        private key or seed phrase is ever requested.
      </p>
    </form>
  );
}

function WalletManager({ recipientId }: { recipientId: string }) {
  const { user } = useSession();
  const queryClient = useQueryClient();
  const [address, setAddress] = useState("");
  const [busy, setBusy] = useState(false);

  const wallets = useQuery({
    queryKey: ["wallets", user?.id],
    enabled: Boolean(user?.id),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("wallets")
        .select("id,address,chain,verified_at,created_at")
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });
      if (error) throw new Error(error.message);
      return data ?? [];
    },
  });

  async function add(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    const value = address.trim();
    if (value.length < 32 || value.length > 44) {
      toast.error("That doesn't look like a Solana address.");
      return;
    }
    setBusy(true);
    const { error } = await supabase
      .from("wallets")
      .insert({ user_id: user.id, recipient_id: recipientId, address: value, chain: "solana" });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setAddress("");
    await queryClient.invalidateQueries({ queryKey: ["wallets"] });
    toast.success("Wallet added.");
  }

  async function remove(id: string) {
    const { error } = await supabase.from("wallets").delete().eq("id", id);
    if (error) {
      toast.error(error.message);
      return;
    }
    await queryClient.invalidateQueries({ queryKey: ["wallets"] });
  }

  return (
    <div className="panel p-5">
      {wallets.isPending ? (
        <LoadingRows rows={2} />
      ) : (wallets.data ?? []).length === 0 ? (
        <p className="text-sm text-muted-foreground">No wallet connected yet.</p>
      ) : (
        <ul className="mb-4 space-y-2">
          {(wallets.data ?? []).map((w) => (
            <li key={w.id} className="flex items-center gap-3 rounded-md border border-border p-3 text-sm">
              <span className="num">{shortAddress(w.address, 6)}</span>
              <StatusPill status={w.verified_at ? "verified" : "pending"}>
                {w.verified_at ? "verified" : "unverified"}
              </StatusPill>
              <button
                type="button"
                onClick={() => remove(w.id)}
                className="ml-auto text-xs text-muted-foreground hover:text-destructive"
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}

      <form onSubmit={add} className="space-y-3">
        <Label htmlFor="wallet">Add a Solana address</Label>
        <Input
          id="wallet"
          value={address}
          className="num"
          placeholder="Public address only"
          onChange={(e) => setAddress(e.target.value)}
        />
        <Button type="submit" variant="outline" disabled={busy}>
          {busy ? "Adding…" : "Add wallet"}
        </Button>
        <p className="text-xs text-muted-foreground">
          Public address only. Never paste a private key or seed phrase — AUTH will never ask for
          one. Addresses added here are unverified until you sign the ownership message above.
        </p>
      </form>
    </div>
  );
}

function ClaimRow({
  payoutId,
  recipientId,
  label,
  amount,
  reason,
  claimed,
}: {
  payoutId: string;
  recipientId: string;
  label: string;
  amount: number;
  reason: string | null;
  claimed: boolean;
}) {
  const { user } = useSession();
  const queryClient = useQueryClient();
  const [busy, setBusy] = useState(false);

  async function openClaim() {
    if (!user) return;
    setBusy(true);
    const { data: wallet } = await supabase
      .from("wallets")
      .select("address")
      .eq("user_id", user.id)
      .limit(1)
      .maybeSingle();

    if (!wallet?.address) {
      setBusy(false);
      toast.error("Add a Solana wallet before claiming.");
      return;
    }

    const { error } = await supabase.from("claims").insert({
      payout_id: payoutId,
      recipient_id: recipientId,
      claimed_by: user.id,
      wallet_address: wallet.address,
      amount_usd: amount,
      status: "open",
    });
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    await queryClient.invalidateQueries({ queryKey: ["claims"] });
    toast.success("Claim opened. Settlement happens once a payout rail is configured.");
  }

  return (
    <div className="flex flex-wrap items-center gap-3 text-sm">
      <div className="min-w-0">
        <div className="font-medium">{label}</div>
        {reason ? <div className="text-xs text-muted-foreground">{reason}</div> : null}
      </div>
      <span className="num ml-auto">{usd(amount)}</span>
      <Button size="sm" variant="outline" disabled={busy || claimed} onClick={openClaim}>
        {claimed ? "Claim open" : busy ? "…" : "Claim"}
      </Button>
    </div>
  );
}
