import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    // No login exists in AUTH. These screens belong to a verified handle
    // owner, so anyone without a verification session is sent to /claim.
    if (error || !data.user) throw redirect({ to: "/claim" });
    return { user: data.user };
  },
  component: () => <Outlet />,
});
