import { createFileRoute } from "@tanstack/react-router";
import { PlatformStatusPanel } from "@/components/admin/PlatformStatusPanel";
import { LaunchWalletPanel } from "@/components/admin/LaunchWalletPanel";
import { LiveClaimTestPanel } from "@/components/admin/LiveClaimTestPanel";
import { CreatorFeeIndexerPanel } from "@/components/admin/CreatorFeeIndexerPanel";
import { PageHeader, PageShell } from "@/components/primitives";

export const Route = createFileRoute("/_authenticated/integrations")({
  head: () => ({
    meta: [
      { title: "Social integrations — AUTH" },
      {
        name: "description",
        content:
          "Live, sandbox, planned and disabled status for the X, YouTube, Twitch, TikTok and Instagram identity integrations, with read-only connectivity tests.",
      },
      { property: "og:title", content: "Social integrations — AUTH" },
      {
        property: "og:description",
        content:
          "Per-platform integration lifecycle, missing credentials and safe read-only test controls.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: IntegrationsPage,
});

function IntegrationsPage() {
  return (
    <PageShell>
      <PageHeader
        title="Social integrations"
        description="What each platform can actually do right now: X, YouTube, Twitch, TikTok and Instagram. States come from live configuration, and every test is a read-only lookup."
      />
      <div className="mt-6">
        <LaunchWalletPanel />
      </div>
      <div className="mt-6">
        <CreatorFeeIndexerPanel />
      </div>
      <div className="mt-6">
        <LiveClaimTestPanel />
      </div>
      <div className="mt-6">
        <PlatformStatusPanel />
      </div>
    </PageShell>
  );
}
