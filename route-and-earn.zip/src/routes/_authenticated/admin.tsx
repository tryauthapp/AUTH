import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/hooks/useSession";
import {
  integrationsQuery,
  launchedTokensQuery,
  recipientsQuery,
  settingsQuery,
} from "@/lib/queries";
import {
  EmptyState,
  ErrorState,
  LoadingRows,
  SectionHeading,
  StatusPill,
} from "@/components/primitives";
import { SmokeTestPanel } from "@/components/admin/SmokeTestPanel";
import { LaunchAuditTimeline } from "@/components/admin/LaunchAuditTimeline";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PlatformStatusPanel } from "@/components/admin/PlatformStatusPanel";
import { timeAgo, explorerAddress, explorerTx } from "@/lib/format";
import { useServerFn } from "@tanstack/react-start";
import { getChainStatus, lookupTransaction } from "@/lib/chain.functions";
import { pendingHandleClaims, reviewHandleClaim } from "@/lib/identity.functions";
import { checkLaunchDataHealth } from "@/lib/data-health.functions";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Admin — AUTH" },
      {
        name: "description",
        content: "Protocol economics, integration status, recipient verification and the audit log.",
      },
      { property: "og:title", content: "Admin — AUTH" },
      { property: "og:description", content: "Protocol settings, integrations, verification and audit log." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AdminPage,
});

function AdminPage() {
  const { isAdmin, loading } = useSession();
  const [smokeRun, setSmokeRun] = useState<string | undefined>(undefined);

  if (loading) {
    return (
      <div className="w-full px-4 py-8 sm:py-10">
        <LoadingRows rows={5} />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="mx-auto w-full max-w-2xl px-4 py-12 sm:py-16">
        <EmptyState
          title="Admin access required"
          description="Your account doesn't have the admin role. Roles are stored server-side and cannot be granted from the browser."
        />
      </div>
    );
  }

  return (
    <div className="w-full px-4 py-8 sm:py-10">
      <h1 className="text-xl font-bold sm:text-2xl">Admin</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Every change here is written to the audit log with your user id.
      </p>

      <Tabs defaultValue="settings" className="mt-8">
        <TabsList className="flex w-full flex-wrap justify-start gap-1 h-auto">
          <TabsTrigger value="settings">Economics</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
          <TabsTrigger value="platforms">Platforms</TabsTrigger>
          <TabsTrigger value="chain">Chain</TabsTrigger>
          <TabsTrigger value="launch">Launch checks</TabsTrigger>
          <TabsTrigger value="health">Data health</TabsTrigger>
          <TabsTrigger value="claims">Identity claims</TabsTrigger>
          <TabsTrigger value="recipients">Verification</TabsTrigger>
          <TabsTrigger value="audit">Audit log</TabsTrigger>
        </TabsList>
        <TabsContent value="settings" className="mt-6">
          <SettingsPanel />
        </TabsContent>
        <TabsContent value="integrations" className="mt-6">
          <IntegrationsPanel />
        </TabsContent>
        <TabsContent value="platforms" className="mt-6">
          <PlatformStatusPanel />
        </TabsContent>
        <TabsContent value="chain" className="mt-6">
          <ChainPanel />
        </TabsContent>
        <TabsContent value="launch" className="mt-6 space-y-4">
          <SmokeTestPanel onComplete={setSmokeRun} />
          <LaunchAuditTimeline refreshKey={smokeRun} />
        </TabsContent>
        <TabsContent value="health" className="mt-6">
          <DataHealthPanel />
        </TabsContent>
        <TabsContent value="claims" className="mt-6">
          <IdentityClaimsPanel />
        </TabsContent>
        <TabsContent value="recipients" className="mt-6">
          <VerificationPanel />
        </TabsContent>
        <TabsContent value="audit" className="mt-6">
          <AuditPanel />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function DataHealthPanel() {
  const launches = useQuery(launchedTokensQuery());
  const checkHealth = useServerFn(checkLaunchDataHealth);
  const cachedCount = launches.data?.length ?? 0;
  const cachedNewestAt = launches.data?.[0]?.created_at ?? null;
  const cacheUpdatedAt = launches.dataUpdatedAt ? new Date(launches.dataUpdatedAt).toISOString() : new Date(0).toISOString();
  const health = useQuery({
    queryKey: ["admin", "launch-data-health", cachedCount, cachedNewestAt, cacheUpdatedAt],
    enabled: !launches.isPending,
    queryFn: () => checkHealth({ data: { cachedCount, cachedNewestAt, cacheUpdatedAt } }),
    refetchInterval: 60_000,
  });

  if (launches.isPending || health.isPending) return <LoadingRows rows={4} />;
  if (launches.error) return <ErrorState error={launches.error} retry={launches.refetch} />;
  if (health.error) return <ErrorState error={health.error} retry={health.refetch} />;
  const result = health.data;
  if (!result) return <EmptyState title="No health result" description="Run the check again." />;

  return <div className="space-y-4">
    <div className="panel p-5">
      <div className="flex flex-wrap items-center gap-3">
        <div className="min-w-0 flex-1">
          <h2 className="font-semibold">Launch index consistency</h2>
          <p className="mt-1 text-sm text-muted-foreground">Compares the current app response with authoritative AUTH-era records.</p>
        </div>
        <StatusPill status={result.status === "healthy" ? "live" : "pending"}>{result.status}</StatusPill>
        <Button variant="outline" size="sm" onClick={() => health.refetch()}>Check now</Button>
      </div>
      <div className="mt-5 grid grid-cols-2 divide-x divide-border border-y border-border sm:grid-cols-4">
        <HealthMetric label="Cached launches" value={String(result.cachedCount)} />
        <HealthMetric label="Database launches" value={String(result.databaseCount)} />
        <HealthMetric label="Count match" value={result.countMatches ? "Yes" : "No"} />
        <HealthMetric label="Cache fresh" value={result.stale ? "No" : "Yes"} />
      </div>
      <div className="mt-4 space-y-1 text-xs text-muted-foreground">
        <p>App response: {timeAgo(result.cacheUpdatedAt)} · AUTH launch index</p>
        <p>Database check: {timeAgo(result.checkedAt)} · Authoritative records</p>
        {!result.countMatches ? <p className="font-medium text-warning">Count mismatch detected. Refresh or invalidate the public launch response.</p> : null}
        {!result.newestMatches ? <p className="font-medium text-warning">Newest launch differs between the app response and database.</p> : null}
      </div>
    </div>
  </div>;
}

function HealthMetric({ label, value }: { label: string; value: string }) {
  return <div className="min-w-0 px-3 py-4"><p className="workspace-label truncate">{label}</p><p className="num mt-2 text-lg font-semibold">{value}</p></div>;
}

async function writeAudit(action: string, entity: string, entityId: string, metadata: unknown) {
  const { data } = await supabase.auth.getUser();
  await supabase.from("audit_log").insert({
    actor_id: data.user?.id ?? null,
    action,
    entity,
    entity_id: entityId,
    metadata: metadata as never,
  });
}

function SettingsPanel() {
  const settings = useQuery(settingsQuery());
  const queryClient = useQueryClient();
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState<string | null>(null);

  if (settings.isPending) return <LoadingRows rows={4} />;
  if (settings.error) return <ErrorState error={settings.error} retry={settings.refetch} />;

  async function save(key: string, raw: string) {
    setBusy(key);
    let parsed: unknown = raw;
    try {
      parsed = JSON.parse(raw);
    } catch {
      /* keep raw string value */
    }
    const { error } = await supabase
      .from("protocol_settings")
      .update({ value: parsed as never, updated_at: new Date().toISOString() })
      .eq("key", key);
    if (!error) await writeAudit("protocol_setting.update", "protocol_settings", key, { value: parsed });
    setBusy(null);
    if (error) {
      toast.error(error.message);
      return;
    }
    await queryClient.invalidateQueries({ queryKey: ["protocol_settings"] });
    toast.success(`${key} updated.`);
  }

  return (
    <div className="panel divide-y divide-border">
      {(settings.data ?? []).map((s) => {
        const current = drafts[s.key] ?? JSON.stringify(s.value);
        return (
          <div key={s.key} className="grid gap-3 p-4 sm:grid-cols-[1fr_auto] sm:items-end">
            <div className="space-y-2">
              <div className="num text-xs uppercase tracking-widest text-muted-foreground">{s.key}</div>
              {s.description ? (
                <p className="text-sm text-muted-foreground">{s.description}</p>
              ) : null}
              <Input
                className="num"
                value={current}
                onChange={(e) => setDrafts((d) => ({ ...d, [s.key]: e.target.value }))}
              />
            </div>
            <Button
              variant="outline"
              disabled={busy === s.key}
              onClick={() => save(s.key, current)}
            >
              {busy === s.key ? "Saving…" : "Save"}
            </Button>
          </div>
        );
      })}
      <p className="p-4 text-xs text-muted-foreground">
        Protocol economics are stored as settings, never hard-coded. The current configuration is 90%
        recipient / 10% protocol.
      </p>
    </div>
  );
}

function IntegrationsPanel() {
  const integrations = useQuery(integrationsQuery());
  const queryClient = useQueryClient();

  if (integrations.isPending) return <LoadingRows rows={5} />;
  if (integrations.error) return <ErrorState error={integrations.error} retry={integrations.refetch} />;

  async function setStatus(key: string, status: string) {
    const { error } = await supabase
      .from("integrations")
      .update({ status: status as "live", updated_at: new Date().toISOString() })
      .eq("key", key);
    if (error) {
      toast.error(error.message);
      return;
    }
    await writeAudit("integration.status", "integrations", key, { status });
    await queryClient.invalidateQueries({ queryKey: ["integrations"] });
    toast.success(`${key} marked ${status}.`);
  }

  return (
    <div className="panel divide-y divide-border">
      {(integrations.data ?? []).map((i) => (
        <div key={i.key} className="flex flex-wrap items-center gap-3 p-4">
          <div className="min-w-0">
            <div className="font-medium">{i.name}</div>
            <div className="text-xs text-muted-foreground">{i.category}</div>
          </div>
          <StatusPill status={i.status as "live"}>{i.status}</StatusPill>
          <div className="ml-auto w-40">
            <Select value={i.status} onValueChange={(v) => setStatus(i.key, v)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {["live", "sandbox", "planned", "disabled"].map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      ))}
      <p className="p-4 text-xs text-muted-foreground">
        Marking something live does not connect it. Credentials must be configured before any real
        money moves.
      </p>
    </div>
  );
}

function VerificationPanel() {
  const recipients = useQuery(recipientsQuery());
  const queryClient = useQueryClient();

  if (recipients.isPending) return <LoadingRows rows={5} />;
  if (recipients.error) return <ErrorState error={recipients.error} retry={recipients.refetch} />;

  async function setVerification(id: string, handle: string, verification: string) {
    const { error } = await supabase
      .from("recipients")
      .update({ verification: verification as "verified" })
      .eq("id", id);
    if (error) {
      toast.error(error.message);
      return;
    }
    await writeAudit("recipient.verification", "recipients", id, { handle, verification });
    await queryClient.invalidateQueries({ queryKey: ["recipients"] });
    toast.success(`@${handle} marked ${verification}.`);
  }

  return (
    <div className="panel divide-y divide-border">
      {(recipients.data ?? []).map((r) => (
        <div key={r.id} className="flex flex-wrap items-center gap-3 p-4">
          <span className="font-medium">@{r.handle}</span>
          <StatusPill status={r.verification === "verified" ? "verified" : r.verification === "pending" ? "pending" : "unverified"}>
            {r.verification}
          </StatusPill>
          <span className="text-xs text-muted-foreground">
            {r.claimed_by ? "account linked" : "unclaimed"}
          </span>
          <div className="ml-auto w-40">
            <Select value={r.verification} onValueChange={(v) => setVerification(r.id, r.handle, v)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {["unverified", "pending", "verified", "rejected"].map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      ))}
    </div>
  );
}

function AuditPanel() {
  const logs = useQuery({
    queryKey: ["audit_logs"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("audit_log")
        .select("id,actor_id,action,entity,entity_id,metadata,created_at")
        .order("created_at", { ascending: false })
        .limit(100);
      if (error) throw new Error(error.message);
      return data ?? [];
    },
  });

  if (logs.isPending) return <LoadingRows rows={5} />;
  if (logs.error) return <ErrorState error={logs.error} retry={logs.refetch} />;
  if ((logs.data ?? []).length === 0)
    return <EmptyState title="No audit entries yet" description="Admin actions appear here." />;

  return (
    <div className="panel divide-y divide-border">
      {(logs.data ?? []).map((l) => (
        <div key={l.id} className="flex flex-wrap items-center gap-3 p-4 text-sm">
          <span className="num text-xs">{l.action}</span>
          <span className="text-xs text-muted-foreground">
            {l.entity}
            {l.entity_id ? ` · ${l.entity_id.slice(0, 8)}` : ""}
          </span>
          <span className="ml-auto text-xs text-muted-foreground">{timeAgo(l.created_at)}</span>
        </div>
      ))}
    </div>
  );
}

function ChainPanel() {
  const fetchStatus = useServerFn(getChainStatus);
  const lookup = useServerFn(lookupTransaction);
  const [sig, setSig] = useState("");
  const [result, setResult] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);

  const status = useQuery({
    queryKey: ["chain_status"],
    queryFn: () => fetchStatus(),
    refetchInterval: 60_000,
  });

  async function check() {
    setChecking(true);
    setResult(null);
    try {
      const r = await lookup({ data: { signature: sig.trim() } });
      setResult(
        r.ok
          ? `Confirmed in slot ${r.tx.slot} · ${r.tx.succeeded ? "success" : "failed"} · network fee ${(r.tx.feeLamports / 1e9).toFixed(6)} SOL`
          : r.message,
      );
    } catch (e) {
      setResult(e instanceof Error ? e.message : "Lookup failed.");
    }
    setChecking(false);
  }

  return (
    <div className="space-y-6">
      <div className="panel p-5">
        <SectionHeading
          title="Solana RPC"
          description="Read-only access through Helius. No private keys or seed phrases are ever requested or stored."
        />
        {status.isPending ? (
          <LoadingRows rows={3} />
        ) : status.error ? (
          <ErrorState error={status.error} retry={status.refetch} />
        ) : (
          <div className="mt-4 space-y-4">
            <div className="flex flex-wrap items-center gap-3">
              <StatusPill status={status.data?.configured ? "live" : "planned"}>
                {status.data?.configured ? "live" : "not configured"}
              </StatusPill>
              {status.data?.error ? (
                <span className="text-xs text-muted-foreground">{status.data.error}</span>
              ) : null}
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="rounded-xl border border-border p-4">
                <div className="text-xs uppercase tracking-widest text-muted-foreground">
                  Protocol fee treasury
                </div>
                {status.data?.treasuryAddress ? (
                  <a
                    className="num mt-2 block break-all text-sm text-primary hover:underline"
                    href={explorerAddress(status.data.treasuryAddress)}
                    target="_blank"
                    rel="noreferrer"
                  >
                    {status.data.treasuryAddress}
                  </a>
                ) : (
                  <p className="mt-2 text-sm text-muted-foreground">Not set.</p>
                )}
              </div>
              <div className="rounded-xl border border-border p-4">
                <div className="text-xs uppercase tracking-widest text-muted-foreground">
                  Live balance
                </div>
                <div className="num mt-2 text-2xl font-semibold">
                  {status.data?.treasurySol === null || status.data?.treasurySol === undefined
                    ? "—"
                    : `${status.data.treasurySol.toFixed(4)} SOL`}
                </div>
              </div>
            </div>

            <div>
              <div className="text-xs uppercase tracking-widest text-muted-foreground">
                Recent treasury transactions (on-chain)
              </div>
              {(status.data?.recent ?? []).length === 0 ? (
                <p className="mt-2 text-sm text-muted-foreground">
                  No on-chain activity for this address yet.
                </p>
              ) : (
                <div className="mt-2 divide-y divide-border">
                  {(status.data?.recent ?? []).map((t) => (
                    <a
                      key={t.signature}
                      href={explorerTx(t.signature)}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-3 py-2 text-sm hover:text-primary"
                    >
                      <span className="num truncate">{t.signature.slice(0, 24)}…</span>
                      <span className="ml-auto text-xs text-muted-foreground">
                        {t.succeeded ? "success" : "failed"}
                        {t.blockTime ? ` · ${timeAgo(new Date(t.blockTime * 1000).toISOString())}` : ""}
                      </span>
                    </a>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      <div className="panel p-5">
        <SectionHeading
          title="Transaction lookup"
          description="Verify any signature against Solana mainnet."
        />
        <div className="mt-4 flex flex-wrap gap-3">
          <Input
            className="num min-w-0 flex-1"
            placeholder="Transaction signature"
            value={sig}
            onChange={(e) => setSig(e.target.value)}
          />
          <Button variant="outline" disabled={checking || sig.trim().length < 32} onClick={check}>
            {checking ? "Checking…" : "Check on-chain"}
          </Button>
        </div>
        {result ? <p className="mt-3 text-sm text-muted-foreground">{result}</p> : null}
      </div>
    </div>
  );
}

/** Review queue for X username ownership proofs. */
function IdentityClaimsPanel() {
  const listFn = useServerFn(pendingHandleClaims);
  const reviewFn = useServerFn(reviewHandleClaim);
  const queryClient = useQueryClient();
  const claims = useQuery({ queryKey: ["identity-claims"], queryFn: () => listFn() });
  const [busy, setBusy] = useState<string | null>(null);

  async function review(claimId: string, approve: boolean) {
    setBusy(claimId);
    const res = await reviewFn({ data: { claimId, approve } });
    setBusy(null);
    if (!res.ok) {
      toast.error(res.message);
      return;
    }
    toast.success(res.message);
    await queryClient.invalidateQueries({ queryKey: ["identity-claims"] });
    await queryClient.invalidateQueries({ queryKey: ["recipients"] });
  }

  if (claims.isPending) return <LoadingRows rows={4} />;
  const rows = claims.data?.claims ?? [];

  return (
    <div>
      <SectionHeading
        title="Identity claims"
        description="Someone posted a one-time code from an X account and submitted the link. Open the post, check the code, then approve or reject. Approval marks the username verified."
      />
      {rows.length === 0 ? (
        <EmptyState title="No claims waiting" description="Submitted proofs appear here." />
      ) : (
        <div className="panel mt-4 divide-y divide-border">
          {rows.map((c) => (
            <div key={c.id} className="flex flex-wrap items-center gap-3 p-4 text-sm">
              <span className="font-medium">@{c.handle}</span>
              <StatusPill status={c.status === "submitted" ? "pending" : "unverified"}>
                {c.status === "submitted" ? "Proof submitted" : "Code issued"}
              </StatusPill>
              <span className="num text-xs text-muted-foreground">{c.proof_code}</span>
              {c.proof_url ? (
                <a
                  href={c.proof_url}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="text-xs text-primary hover:underline"
                >
                  Open post
                </a>
              ) : null}
              <span className="text-xs text-muted-foreground">{timeAgo(c.created_at)}</span>
              <span className="ml-auto flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  disabled={busy === c.id || !c.proof_url}
                  onClick={() => review(c.id, true)}
                >
                  Approve
                </Button>
                <Button size="sm" variant="ghost" disabled={busy === c.id} onClick={() => review(c.id, false)}>
                  Reject
                </Button>
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
