import { createFileRoute, Link } from "@tanstack/react-router";
import { Receipt } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { feeEventsQuery, payoutsQuery } from "@/lib/queries";
import { LedgerTable } from "@/components/LedgerTable";
import { ErrorState, LoadingRows, EmptyState, PageHeader, PageShell, StatCard } from "@/components/primitives";
import { usd } from "@/lib/format";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/ledger")({
  head: () => ({
    meta: [
      { title: "Transparent fee ledger — AUTH" },
      {
        name: "description",
        content:
          "Every creator-fee event with source token, transaction signature, gross amount, protocol fee, recipient net and payout status.",
      },
      { property: "og:title", content: "Transparent fee ledger — AUTH" },
      {
        property: "og:description",
        content: "Creator-fee events, protocol fees, recipient net amounts and payout status.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LedgerPage,
});

function LedgerPage() {
  const events = useQuery(feeEventsQuery());
  const payouts = useQuery(payoutsQuery());
  const [q, setQ] = useState("");

  const filtered = (events.data ?? []).filter((e) => {
    if (!q.trim()) return true;
    const needle = q.trim().toLowerCase();
    return (
      e.token?.symbol.toLowerCase().includes(needle) ||
      e.token?.mint.toLowerCase().includes(needle) ||
      e.recipient?.handle.toLowerCase().includes(needle) ||
      e.tx_signature.toLowerCase().includes(needle)
    );
  });

  const totals = filtered.reduce(
    (acc, e) => {
      acc.gross += Number(e.gross_usd);
      acc.protocol += Number(e.protocol_fee_usd);
      acc.net += Number(e.net_usd);
      return acc;
    },
    { gross: 0, protocol: 0, net: 0 },
  );

  return (
    <PageShell>
      <PageHeader
        eyebrow="Public receipts"
        title="Fee Ledger"
        description="Append-only record of every creator-fee event AUTH has attributed, with the Solana signature behind each one."
      />

      <div className="workspace-panel grid grid-cols-2 divide-x divide-border overflow-hidden sm:grid-cols-4">
        <StatCard label="Gross fees" value={usd(totals.gross, { compact: true })} />
        <StatCard label="Protocol fees" value={usd(totals.protocol, { compact: true })} />
        <StatCard label="Recipient net" value={usd(totals.net, { compact: true })} accent />
        <StatCard label="Events" value={filtered.length.toLocaleString()} />
      </div>

      <div className="mt-4 flex justify-stretch sm:justify-end">
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Filter by token, mint, handle or signature"
          className="field h-10 w-full bg-surface text-sm sm:max-w-md"
        />
      </div>

      <div className="mt-4">
        {events.isPending || payouts.isPending ? (
          <LoadingRows rows={8} />
        ) : events.error || payouts.error ? (
          <ErrorState
            error={events.error ?? payouts.error}
            retry={() => {
              events.refetch();
              payouts.refetch();
            }}
          />
        ) : filtered.length === 0 ? (
          <EmptyState
            title={q.trim() ? "No fee events match" : "No fee events yet"}
            description={
              q.trim()
                ? "Try a different token symbol, handle or signature."
                : "Creator-fee receipts appear here once a launch starts earning."
            }
            icon={<Receipt className="size-5" />}
            action={
              <Button asChild size="sm" variant="outline" className="h-9 px-4">
                <Link to="/docs">View how routing works</Link>
              </Button>
            }
          />
        ) : (
          <LedgerTable events={filtered.slice(0, 200)} payouts={payouts.data ?? []} />
        )}
      </div>
    </PageShell>
  );
}
