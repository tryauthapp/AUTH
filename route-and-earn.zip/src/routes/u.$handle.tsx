import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { BadgeCheck, Coins, Send, Wallet } from "lucide-react";
import {
  feeEventsQuery,
  paymentsForHandleQuery,
  payoutsQuery,
  recipientQuery,
  recipientStats,
  publicRoutingQuery,
  tokenRecipientsQuery,
  tokensQuery,
  walletsForRecipientQuery,
} from "@/lib/queries";
import {
  EmptyState,
  ErrorState,
  LoadingRows,
  SectionHeading,
  StatCard,
  StatusPill,
} from "@/components/primitives";
import { LedgerTable } from "@/components/LedgerTable";
import { RoutingBreakdown } from "@/components/RoutingBreakdown";
import { PaymentStatus } from "@/routes/pay";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useSession } from "@/hooks/useSession";
import { shortAddress, timeAgo, usd } from "@/lib/format";
import { explorerAddress, explorerTx } from "@/lib/solana";

export const Route = createFileRoute("/u/$handle")({
  head: ({ params }) => ({
    meta: [
      { title: `@${params.handle} on AUTH — pay them in crypto` },
      {
        name: "description",
        content: `Send SOL or USDC to @${params.handle}, see their payout setup, creator-fee earnings, launched coins and payment activity.`,
      },
      { property: "og:title", content: `@${params.handle} on AUTH` },
      {
        property: "og:description",
        content: `Pay @${params.handle} in crypto and see their creator-fee routing.`,
      },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const { handle } = Route.useParams();
  const { session } = useSession();
  const recipient = useQuery(recipientQuery(handle));
  const events = useQuery(feeEventsQuery());
  const payouts = useQuery(payoutsQuery());
  const payments = useQuery(paymentsForHandleQuery(handle));
  const routing = useQuery(publicRoutingQuery(recipient.data?.id));
  const wallets = useQuery(walletsForRecipientQuery(recipient.data?.id));
  const tokenLinks = useQuery(tokenRecipientsQuery());
  const tokens = useQuery(tokensQuery());

  if (recipient.isPending) {
    return (
      <div className="px-4 py-6">
        <LoadingRows rows={8} />
      </div>
    );
  }
  if (recipient.error) {
    return (
      <div className="px-4 py-6">
        <ErrorState error={recipient.error} retry={recipient.refetch} />
      </div>
    );
  }

  const r = recipient.data;

  // Unclaimed identity: still payable as a reservation, and claimable by its owner.
  if (!r) {
    return (
      <div className="px-4 py-6">
        <IdentityHeader handle={handle} claimed={false} verification="unverified" />
        <div className="mt-4 grid gap-3">
          <div className="panel p-4">
            <p className="text-sm">
              @{handle} isn't on AUTH yet. You can still reserve a payment for them — it stays in
              your account, unfunded, until they claim the username and set a payout destination.
            </p>
            <Button asChild className="press mt-3 rounded-full">
              <Link to="/pay" search={{ to: handle }}>
                <Send className="size-4" /> Pay @{handle}
              </Link>
            </Button>
          </div>
          <PublicClaimableLink handle={handle} />
          <ClaimPanel handle={handle} signedIn={Boolean(session)} />
        </div>
      </div>
    );
  }

  const stats = recipientStats(events.data ?? [], payouts.data ?? [], r.id);
  const myEvents = (events.data ?? []).filter((e) => e.recipient?.id === r.id);
  const myPayouts = (payouts.data ?? []).filter((p) => p.recipient_id === r.id);
  const claimable = myPayouts.filter((p) => p.status === "claimable");
  const verifiedWallet = (wallets.data ?? []).find((w) => w.verified_at);
  const tokenById = new Map((tokens.data ?? []).map((t) => [t.id, t]));
  const coins = (tokenLinks.data ?? [])
    .filter((t) => t.recipient_id === r.id)
    .map((t) => tokenById.get(t.token_id))
    .filter((t): t is NonNullable<typeof t> => Boolean(t));
  const isOwner = Boolean(session && r.claimed_by === session.user.id);

  return (
    <div className="pb-8">
      <div className="px-4 pt-5 sm:px-6 lg:px-8">
        <IdentityHeader
          handle={r.handle}
          displayName={r.display_name}
          bio={r.bio}
          avatarUrl={r.avatar_url}
          claimed={Boolean(r.claimed_by)}
          verification={r.verification}
          payable={Boolean(verifiedWallet)}
        />

        <div className="mt-4"><PublicClaimableLink handle={r.handle} /></div>

        <div className="mt-4 flex flex-wrap gap-2">
           <Button asChild className="press h-9 rounded-md px-4 font-semibold">
            <Link to="/pay" search={{ to: r.handle }}>
              <Send className="size-4" /> Pay @{r.handle}
            </Link>
          </Button>
          {isOwner ? (
             <Button asChild variant="outline" className="press h-9 rounded-md px-4">
              <Link to="/dashboard">Manage routing</Link>
            </Button>
          ) : null}
        </div>

      <div className="mt-4 flex flex-wrap items-center gap-2 border-y border-border p-3 text-sm">
          <Wallet className="size-4 text-muted-foreground" />
          {verifiedWallet ? (
            <>
              <span className="text-muted-foreground">Payout wallet</span>
              <a
                href={explorerAddress(verifiedWallet.address)}
                target="_blank"
                rel="noreferrer noopener"
                className="num font-medium text-info hover:underline"
              >
                {shortAddress(verifiedWallet.address, 6)}
              </a>
              <StatusPill status="verified">Verified</StatusPill>
            </>
          ) : (
            <span className="text-muted-foreground">
              No verified payout wallet yet — payments to @{r.handle} stay reserved and unfunded.
            </span>
          )}
        </div>
      </div>

      <div className="mx-4 mt-4 grid grid-cols-2 overflow-hidden rounded-md border border-border bg-surface py-2 sm:mx-6 lg:mx-8 lg:grid-cols-4">
        <StatCard label="Lifetime fees" value={usd(stats.lifetime, { compact: true })} accent hint="Net after protocol fee" />
        <StatCard label="Last 24 hours" value={usd(stats.last24h, { compact: true })} />
        <StatCard label="Claimable" value={usd(stats.claimable, { compact: true })} hint={claimable.length > 0 ? "A payout rail failed — funds still attributed here" : undefined} />
        <StatCard label="Contributing coins" value={stats.coinCount} hint={`${stats.eventCount} fee events`} />
      </div>

      <div className="mx-4 mt-4 workspace-panel overflow-hidden sm:mx-6 lg:mx-8">
        <Tabs defaultValue="activity">
           <TabsList className="flex h-11 w-full flex-wrap justify-start gap-1 border-b border-border px-2">
            <TabsTrigger value="activity">Activity</TabsTrigger>
            <TabsTrigger value="payments">Payments</TabsTrigger>
            <TabsTrigger value="routing">Routing</TabsTrigger>
            <TabsTrigger value="coins">Coins</TabsTrigger>
          </TabsList>

           <TabsContent value="activity" className="m-0 p-4">
            <SectionHeading title="Creator-fee activity" description="Fee events attributed to this username." />
            {myEvents.length === 0 ? (
              <EmptyState title="No fee events yet" description="Nothing has been attributed to this username." />
            ) : (
              <LedgerTable events={myEvents.slice(0, 60)} payouts={myPayouts} showRecipient={false} />
            )}
          </TabsContent>

           <TabsContent value="payments" className="m-0 p-4">
            <SectionHeading title="Payments" description="Person-to-person payments addressed to this username." />
            {(payments.data ?? []).length === 0 ? (
              <EmptyState title="No payments yet" description={`Be the first to pay @${r.handle}.`} />
            ) : (
              <ul className="space-y-2">
                {(payments.data ?? []).map((p) => (
                  <li key={p.id} className="panel flex flex-wrap items-center gap-2 p-3 text-sm">
                    <span className="num font-medium">
                      {Number(p.amount)} {p.asset}
                    </span>
                    {p.amount_usd ? (
                      <span className="text-xs text-muted-foreground">{usd(Number(p.amount_usd))}</span>
                    ) : null}
                    <PaymentStatus status={p.status} />
                    <span className="ml-auto text-xs text-muted-foreground">{timeAgo(p.created_at)}</span>
                    {p.tx_signature ? (
                      <a
                        href={explorerTx(p.tx_signature)}
                        target="_blank"
                        rel="noreferrer noopener"
                        className="num text-xs text-info hover:underline"
                      >
                        tx
                      </a>
                    ) : null}
                    {p.note ? <p className="w-full text-xs text-muted-foreground">“{p.note}”</p> : null}
                  </li>
                ))}
              </ul>
            )}
          </TabsContent>

           <TabsContent value="routing" className="m-0 p-4">
            <SectionHeading title="Routing configuration" description="How incoming creator fees are split." />
            {routing.isPending ? (
              <LoadingRows rows={3} />
            ) : routing.data && routing.data.splits.length > 0 ? (
              <div className="panel p-5">
                <RoutingBreakdown splits={routing.data.splits} />
              </div>
            ) : (
              <EmptyState
                title="No routing configured"
                description="Fees stay attributed to this username until they set routing rules."
              />
            )}
          </TabsContent>

           <TabsContent value="coins" className="m-0 p-4">
            <SectionHeading title="Launched coins" description="Coins whose creator fees route to this username." />
            {coins.length === 0 ? (
              <EmptyState title="No coins yet" description="Nobody has registered a coin for this username." />
            ) : (
              <ul className="space-y-2">
                {coins.map((c) => (
                  <li key={c.id} className="panel flex flex-wrap items-center gap-2 p-3">
                    <Coins className="size-4 text-muted-foreground" />
                    <Link to="/t/$mint" params={{ mint: c.mint }} className="font-medium hover:underline">
                      ${c.symbol}
                    </Link>
                    <span className="truncate text-sm text-muted-foreground">{c.name}</span>
                  </li>
                ))}
              </ul>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {!r.claimed_by ? (
        <div className="mt-6 px-4">
          <ClaimPanel handle={r.handle} signedIn={Boolean(session)} />
        </div>
      ) : null}
    </div>
  );
}

function IdentityHeader({
  handle,
  displayName,
  bio,
  avatarUrl,
  claimed,
  verification,
  isDemo,
  payable,
}: {
  handle: string;
  displayName?: string | null;
  bio?: string | null;
  avatarUrl?: string | null;
  claimed: boolean;
  verification: string;
  isDemo?: boolean;
  payable?: boolean;
}) {
  return (
    <div className="workspace-panel overflow-hidden">
      <div className="h-28 border-b border-border bg-surface-2 sm:h-32" />
      <div className="grid grid-cols-[auto_minmax(0,1fr)] items-start gap-4 p-4 sm:flex sm:p-5">
        <div className="-mt-12 grid size-20 shrink-0 place-items-center overflow-hidden rounded-full border-4 border-background bg-secondary text-xl font-semibold">
          {avatarUrl ? (
            <img src={avatarUrl} alt="" className="size-full object-cover" />
          ) : (
            handle.slice(0, 2).toUpperCase()
          )}
        </div>
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="truncate text-2xl font-bold">{displayName || `@${handle}`}</h1>
            {claimed ? (
              <StatusPill status={verification === "verified" ? "verified" : "pending"}>
                {verification === "verified" ? "Claimed & verified" : "Claimed"}
              </StatusPill>
            ) : (
              <StatusPill status="unverified">Unclaimed</StatusPill>
            )}
            {payable ? <StatusPill status="live">Payable</StatusPill> : null}
          </div>
          <p className="text-sm text-muted-foreground">@{handle}</p>
          {bio ? <p className="mt-2 max-w-xl text-sm text-muted-foreground">{bio}</p> : null}
        </div>
      </div>
    </div>
  );
}

function ClaimPanel({ handle }: { handle: string; signedIn?: boolean }) {
  const steps = [
    {
      title: "Start verification",
      body: "Only claiming needs this. Anyone can send to @" + handle + " right now with no account.",
    },
    {
      title: `Prove you own @${handle}`,
      body: "Post a one-time code from the account and paste the link. A person reviews it — AUTH is not affiliated with X and does not use X sign-in.",
    },
    {
      title: "Set a payout destination",
      body: "Authorize a plain-text ownership message. AUTH never sees your keys or seed phrase.",
    },
    {
      title: "Collect what's attributed to you",
      body: "Reserved payments and claimable balances become payable once a verified wallet exists.",
    },
  ];
  return (
     <section className="panel p-4 sm:p-5">
      <div className="flex items-center gap-2">
        <BadgeCheck className="size-4 text-success" />
        <h2 className="text-base font-semibold">Is @{handle} you?</h2>
      </div>
      <ol className="mt-3 space-y-3">
        {steps.map((s, i) => (
          <li key={s.title} className="flex gap-3">
            <span className="num grid size-6 shrink-0 place-items-center rounded-full bg-secondary text-xs font-semibold">
              {i + 1}
            </span>
            <div>
              <p className="text-sm font-medium">{s.title}</p>
              <p className="text-sm text-muted-foreground">{s.body}</p>
            </div>
          </li>
        ))}
      </ol>
      <Button asChild className="press mt-4 rounded-full">
        <Link to="/claim" search={{ handle }}>
          Claim @{handle}
        </Link>
      </Button>
    </section>
  );
}

/** Links to the shareable public claim page for this identity. */
function PublicClaimableLink({ handle }: { handle: string }) {
  return (
    <Link
      to="/c/$handle"
      params={{ handle }}
      search={{ provider: "x" as const }}
      className="panel flex items-center justify-between gap-3 p-4 hover:bg-secondary"
    >
      <span className="min-w-0">
        <span className="block text-sm font-semibold">Claimable balance</span>
        <span className="block text-sm text-muted-foreground">
          Public page showing what @{handle} can claim in SOL and USDC.
        </span>
      </span>
      <span className="shrink-0 text-sm font-semibold text-brand">View</span>
    </Link>
  );
}
