import { createFileRoute } from "@tanstack/react-router";
import { PlatformProfile } from "@/components/PlatformProfile";

export const Route = createFileRoute("/tiktok/$handle")({
  head: ({ params }) => ({
    meta: [
      { title: `@${params.handle} on TikTok — pay them in crypto on AUTH` },
      {
        name: "description",
        content: `Send SOL or USDC to @${params.handle} on TikTok and see their claimable creator fees on AUTH.`,
      },
      { property: "og:title", content: `@${params.handle} on TikTok — AUTH` },
      {
        property: "og:description",
        content: `Pay @${params.handle} in crypto and see their creator-fee routing.`,
      },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => <PlatformProfile provider="tiktok" handle={Route.useParams().handle} />,
});
