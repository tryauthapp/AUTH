import { SocialAvatar } from "@/components/social/SocialIdentity";
import { ProviderIcon, asProvider } from "@/components/social/ProviderIcon";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { useMemo, useState } from "react";
import { assetsQuery } from "@/lib/assets";
import { AUTH_ERA_START, launchedTokensQuery, paymentsQuery, recipientsQuery } from "@/lib/queries";
import { Chip, ChipRow, EmptyState, LoadingRows, PageHeader, PageShell } from "@/components/primitives";
import { IdentityAvatar, TokenAvatar } from "@/components/Avatar";
import { AssetIcon } from "@/components/AssetIcon";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { timeAgo } from "@/lib/format";
import { listPublicClaimable } from "@/lib/claimable.functions";
import { SOCIAL_PROVIDERS, type SocialProvider } from "@/lib/social/providers";
import { PlatformChip } from "@/components/social/PlatformChips";
import { PlatformIdentityPicker } from "@/components/social/PlatformIdentityPicker";

export const Route = createFileRoute("/explore")({
  head: () => ({ meta: [
    { title: "Explore — AUTH" },
    { name: "description", content: "Search people, assets, launches and live activity on AUTH." },
    { property: "og:title", content: "Explore — AUTH" },
    { property: "og:description", content: "Discover social identities and real Solana activity." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Explore,
});

function Explore() {
  const [query, setQuery] = useState("");
  // null = every platform.
  const [platform, setPlatform] = useState<SocialProvider | null>(null);
  const people = useQuery(recipientsQuery());
  const assets = useQuery(assetsQuery());
  const launches = useQuery(launchedTokensQuery());
  const payments = useQuery(paymentsQuery(60));
  const claimable = useQuery({
    queryKey: ["public-claimable-list"],
    queryFn: () => listPublicClaimable(),
    staleTime: 60_000,
  });
  const q = query.trim().replace(/^[@$]/, "").toLowerCase();

  const filteredPeople = useMemo(
    () =>
      (people.data ?? []).filter(
        (p) =>
          (!platform || (p.provider ?? "x") === platform) &&
          (!q || p.handle.toLowerCase().includes(q) || p.display_name?.toLowerCase().includes(q)),
      ),
    [people.data, q, platform],
  );
  const filteredClaimable = useMemo(
    () =>
      (claimable.data ?? []).filter(
        (c) =>
          (!platform || c.provider === platform) &&
          (!q || c.handle.toLowerCase().includes(q) || c.displayName?.toLowerCase().includes(q)),
      ),
    [claimable.data, q, platform],
  );
  const filteredAssets = useMemo(() => (assets.data ?? []).filter((a) => a.status === "live" && a.is_payable && (!q || a.symbol.toLowerCase().includes(q) || a.name.toLowerCase().includes(q))), [assets.data, q]);
  const filteredLaunches = useMemo(
    () => (launches.data ?? []).filter(
      (t) => !t.is_demo && t.created_at >= AUTH_ERA_START && (!q || t.symbol.toLowerCase().includes(q) || t.name.toLowerCase().includes(q)),
    ),
    [launches.data, q],
  );

  return (
    <PageShell>
      <PageHeader
        eyebrow="Discovery"
        title="Explore"
        description="Search identities on X, TikTok, YouTube, Twitch and Instagram, plus live assets and real launches. Everything here is real activity — nothing is simulated."
      />
      <div>
        <div className="relative">
          <Search className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search a username, asset or launch"
            className="field h-12 rounded-xl bg-card pl-11 text-[15px] shadow-sm"
          />
        </div>
        <ChipRow className="mt-3">
          <Chip active={platform === null} onClick={() => setPlatform(null)}>
            All platforms
          </Chip>
          {SOCIAL_PROVIDERS.map((p) => (
            <PlatformChip
              key={p.id}
              provider={p.id}
              active={p.id === platform}
              onSelect={(id) => setPlatform(id === platform ? null : id)}
            />
          ))}
        </ChipRow>
      </div>

      {platform && q ? (
        <div className="mt-4 workspace-panel p-4">
          <p className="text-sm font-medium">
            Look up {SOCIAL_PROVIDERS.find((p) => p.id === platform)!.label} directly
          </p>
          <div className="mt-3">
            <PlatformIdentityPicker
              provider={platform}
              onProviderChange={setPlatform}
              handle={q}
              onHandleChange={setQuery}
              label="Username"
            />
          </div>
        </div>
      ) : null}

      <Tabs defaultValue="people" className="mt-5 workspace-panel overflow-hidden">
        <TabsList className="grid h-11 w-full grid-cols-5 border-b border-border p-0">
          <TabsTrigger value="people">People</TabsTrigger>
          <TabsTrigger value="unclaimed">Unclaimed</TabsTrigger>
          <TabsTrigger value="assets">Assets</TabsTrigger>
          <TabsTrigger value="launches">Launches</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
        </TabsList>

        <TabsContent value="unclaimed" className="m-0">
          {claimable.isPending ? (
            <LoadingRows rows={5} />
          ) : filteredClaimable.length === 0 ? (
            <ExploreEmpty label="Nothing is waiting to be claimed right now" />
          ) : (
            <ul className="divide-y divide-border">
              {filteredClaimable.map((c) => (
                <li key={`${c.provider}:${c.handle}`} className="row-hover flex items-center gap-3 px-4 py-3">
                  <SocialAvatar provider={c.provider} handle={c.handle} avatarUrl={c.avatarUrl} />
                  <Link
                    to="/c/$handle"
                    params={{ handle: c.handle }}
                    search={{ provider: c.provider }}
                    className="min-w-0 flex-1"
                  >
                    <span className="block truncate font-bold">{c.displayName ?? `@${c.handle}`}</span>
                    <span className="block truncate text-sm text-muted-foreground">
                      @{c.handle} · {c.isClaimed ? "claimed identity" : "unclaimed identity"}
                    </span>
                  </Link>
                  <span className="shrink-0 text-right text-sm font-semibold text-success">
                    {c.SOL > 0 ? <span className="num block">{c.SOL} SOL</span> : null}
                    {c.USDC > 0 ? <span className="num block">{c.USDC} USDC</span> : null}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </TabsContent>


        <TabsContent value="people" className="m-0">
          {people.isPending ? <LoadingRows rows={7} /> : filteredPeople.length === 0 ? <ExploreEmpty label={q ? "No people match this search" : "No people on AUTH yet"} /> : (
            <ul className="divide-y divide-border">{filteredPeople.map((p) => (
               <li key={p.id} className="row-hover flex items-center gap-3 px-4 py-3">
                <SocialAvatar provider={asProvider(p.provider)} handle={p.handle} avatarUrl={p.avatar_url} />
                <Link to="/u/$handle" params={{ handle: p.handle }} className="min-w-0 flex-1"><span className="block truncate font-bold">{p.display_name ?? `@${p.handle}`}</span><span className="block truncate text-sm text-muted-foreground">@{p.handle}{p.bio ? ` · ${p.bio}` : ""}</span></Link>
                 <Button asChild size="sm" className="rounded-md px-4"><Link to="/pay" search={{ to: p.handle }}>Pay</Link></Button>
              </li>
            ))}</ul>
          )}
        </TabsContent>

        <TabsContent value="assets" className="m-0">
          {assets.isPending ? <LoadingRows rows={7} /> : filteredAssets.length === 0 ? <ExploreEmpty label="No assets match this search" /> : (
            <ul className="divide-y divide-border">{filteredAssets.map((a) => (
               <li key={a.key} className="row-hover flex items-center gap-3 px-4 py-3">
                <AssetIcon symbol={a.symbol} assetKey={a.key} chainKey={a.chain_key} logoUrl={a.logo_url} />
                <span className="min-w-0 flex-1"><span className="block font-bold">{a.name}</span><span className="block text-sm text-muted-foreground">{a.symbol} · Solana</span></span>
                 <Button asChild size="sm" variant="outline" className="rounded-md"><Link to="/pay">Use {a.symbol}</Link></Button>
              </li>
            ))}</ul>
          )}
        </TabsContent>

        <TabsContent value="launches" className="m-0">
          {launches.isPending ? <LoadingRows rows={7} /> : filteredLaunches.length === 0 ? <ExploreEmpty label="No launches match this search" /> : (
            <ul className="divide-y divide-border">{filteredLaunches.map((t) => (
              <li key={t.mint} className="row-hover px-5 py-4"><Link to="/t/$mint" params={{ mint: t.mint }} className="flex items-center gap-3.5"><TokenAvatar symbol={t.symbol} /><span className="min-w-0 flex-1"><span className="block truncate font-bold">{t.name}</span><span className="block text-sm text-muted-foreground">${t.symbol} · launched {timeAgo(t.created_at)}</span></span></Link></li>
            ))}</ul>
          )}
        </TabsContent>

        <TabsContent value="activity" className="m-0">
          {(payments.data ?? []).length === 0 ? <ExploreEmpty label="No payment activity yet" /> : <ul className="divide-y divide-border">{(payments.data ?? []).map((p) => (
            <li key={p.id} className="row-hover flex items-start gap-3.5 px-5 py-4"><SocialAvatar provider={asProvider(p.recipient_provider)} handle={p.recipient_handle} size="lg" /><div className="min-w-0 flex-1"><p className="text-[15px] leading-6"><Link to="/u/$handle" params={{ handle: p.recipient_handle }} className="inline-flex items-center gap-1.5 font-bold hover:underline">@{p.recipient_handle}</Link> received <strong>{Number(p.amount)} {p.asset}</strong></p><p className="text-sm text-muted-foreground">{timeAgo(p.created_at)}</p></div></li>
          ))}</ul>}
        </TabsContent>
      </Tabs>
    </PageShell>
  );
}

function ExploreEmpty({ label, description }: { label: string; description?: string }) {
  return (
    <div className="p-5">
      <EmptyState
        title={label}
        description={description ?? "Search any username, or check back as activity arrives."}
        icon={<Search className="size-5" />}
        action={
          <div className="flex flex-wrap justify-center gap-2">
            <Button asChild size="sm" className="h-9 px-4"><Link to="/pay">Pay a username</Link></Button>
            <Button asChild size="sm" variant="outline" className="h-9 px-4"><Link to="/launch">Launch for a creator</Link></Button>
          </div>
        }
      />
    </div>
  );
}