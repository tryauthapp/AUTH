import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/LegalPage";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms of service — AUTH" },
      {
        name: "description",
        content: "Terms of service for AUTH, a Solana payment and creator-fee routing platform.",
      },
      { property: "og:title", content: "Terms of service — AUTH" },
      { property: "og:description", content: "Terms of service for AUTH." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <LegalPage
      title="Terms of service"
      sections={[
        {
          heading: "Placeholder document",
          body: [
            "This is a placeholder. It is not legal advice and has not been reviewed by counsel. Replace it before operating a production service or moving real funds.",
          ],
        },
        {
          heading: "Transfers are real",
          body: [
            "Payments and payouts executed through AUTH settle on Solana mainnet and are irreversible once confirmed. Verify the recipient, asset and amount before you authorize a transfer.",
          ],
        },
        {
          heading: "Accounts and handles",
          body: [
            "Associating a token with an X handle does not create an account for that handle's owner. Attribution is provisional until the handle is verified.",
            "Handle verification, identity checks and payout eligibility requirements depend on the payout provider used and on the jurisdiction of both operator and recipient.",
          ],
        },
        {
          heading: "No custody of keys",
          body: [
            "AUTH never requests, stores or displays private keys or seed phrases. Transactions are user-signed or executed by explicitly configured server infrastructure operated by the deployer.",
          ],
        },
        {
          heading: "Protocol fees",
          body: [
            "The protocol fee is a configurable setting visible in the admin area. Operators are responsible for disclosing the active rate to recipients.",
          ],
        },
      ]}
    />
  ),
});
