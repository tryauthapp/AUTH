import { createFileRoute } from "@tanstack/react-router";
import { PlatformProfile } from "@/components/PlatformProfile";

export const Route = createFileRoute("/instagram/$handle")({
  head: ({ params }) => ({
    meta: [
      { title: `@${params.handle} on Instagram — pay them in crypto on AUTH` },
      {
        name: "description",
        content: `Send SOL or USDC to @${params.handle} on Instagram and see their claimable creator fees on AUTH.`,
      },
      { property: "og:title", content: `@${params.handle} on Instagram — AUTH` },
      {
        property: "og:description",
        content: `Pay @${params.handle} in crypto and see their creator-fee routing.`,
      },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => <PlatformProfile provider="instagram" handle={Route.useParams().handle} />,
});
