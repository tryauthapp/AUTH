import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  ArrowUpRight,
  Check,
  Copy,
  ExternalLink,
  Globe,
  MessageCircle,
  Rocket,
  Share2,
} from "lucide-react";
import { launchResult } from "@/lib/launch-attempts.functions";
import { EmptyState, ErrorState, LoadingRows, SectionHeading, StatusPill } from "@/components/primitives";
import { Button } from "@/components/ui/button";
import { explorerTx, shortAddress } from "@/lib/format";
import { safeHref } from "@/lib/links";

export const Route = createFileRoute("/launched/$mint")({
  head: ({ params }) => ({
    meta: [
      { title: `Launch confirmed — ${params.mint.slice(0, 6)} on AUTH` },
      {
        name: "description",
        content:
          "A confirmed pump.fun launch on Solana mainnet: verified mint address, launch transaction, creator-fee routing and project links.",
      },
      { property: "og:title", content: "Launch confirmed — AUTH" },
      {
        property: "og:description",
        content: "Verified mint, launch transaction and creator-fee routing for a new pump.fun token.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LaunchSuccessPage,
});

function copy(value: string, label: string) {
  navigator.clipboard
    .writeText(value)
    .then(() => toast.success(`${label} copied`))
    .catch(() => toast.error("Could not copy"));
}

function LaunchSuccessPage() {
  const { mint } = Route.useParams();
  const resultFn = useServerFn(launchResult);
  const result = useQuery({
    queryKey: ["launch-result", mint],
    queryFn: () => resultFn({ data: { mint } }),
  });

  if (result.isPending) {
    return (
      <div className="w-full px-4 py-8 sm:py-10">
        <LoadingRows rows={6} />
      </div>
    );
  }
  if (result.error) {
    return (
      <div className="w-full px-4 py-8 sm:py-10">
        <ErrorState error={result.error} retry={result.refetch} />
      </div>
    );
  }
  if (!result.data?.found) {
    return (
      <div className="w-full px-4 py-8 sm:py-10">
        <EmptyState
          title="No verified launch here"
          description="AUTH only shows a launch once its mint is verified on Solana mainnet. Nothing verified is recorded for this address."
        />
      </div>
    );
  }

  const { token, recipient, splits, ownership } = result.data;
  const pumpUrl = `https://pump.fun/coin/${token.mint}`;
  const links = [
    { label: "Website", url: token.website_url, icon: Globe },
    { label: "X", url: token.x_url, icon: ArrowUpRight },
    { label: "Telegram", url: token.telegram_url, icon: MessageCircle },
    { label: "Community", url: token.community_url, icon: MessageCircle },
  ].filter((l) => Boolean(safeHref(l.url ?? "")));

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-8 sm:py-10">
      <div className="rounded-lg border border-success/30 bg-success/5 p-5 sm:p-6">
        <div className="flex items-center gap-2 text-success">
          <span className="grid size-7 place-items-center rounded-full bg-success/15">
            <Check className="size-4" />
          </span>
          <span className="text-sm font-semibold">Launch successful</span>
          <StatusPill status="live">mainnet</StatusPill>
        </div>

        <div className="mt-5 flex flex-col gap-4 sm:flex-row sm:items-center">
          {token.image_url ? (
            <img
              src={token.image_url}
              alt={`${token.symbol} token image`}
              className="size-20 shrink-0 rounded-lg border border-border object-cover"
            />
          ) : (
            <div className="grid size-20 shrink-0 place-items-center rounded-lg border border-border bg-muted">
              <Rocket className="size-6 text-muted-foreground" />
            </div>
          )}
          <div className="min-w-0">
            <h1 className="truncate text-xl font-semibold tracking-tight">{token.name}</h1>
            <p className="text-sm text-muted-foreground">
              ${token.symbol}
              {recipient ? ` · fees routed for @${recipient.handle}` : ""}
            </p>
            {token.description ? (
              <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{token.description}</p>
            ) : null}
          </div>
        </div>
      </div>

      <div className="mt-4 grid gap-4">
        <section className="rounded-lg border border-border bg-card p-4">
          <SectionHeading title="Contract address" />
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <code className="break-all rounded-sm bg-muted px-2 py-1 text-xs">{token.mint}</code>
            <Button size="sm" variant="outline" onClick={() => copy(token.mint, "Contract address")}>
              <Copy className="mr-1 size-3.5" /> Copy CA
            </Button>
          </div>
          <dl className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
            <div>
              <dt className="text-xs uppercase tracking-wide text-muted-foreground">Launch transaction</dt>
              <dd>
                {token.launch_signature ? (
                  <a
                    className="inline-flex items-center gap-1 text-primary hover:underline"
                    href={explorerTx(token.launch_signature)}
                    target="_blank"
                    rel="noreferrer noopener"
                  >
                    {shortAddress(token.launch_signature)} <ExternalLink className="size-3.5" />
                  </a>
                ) : (
                  <span className="text-muted-foreground">Not recorded</span>
                )}
              </dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-wide text-muted-foreground">Verified on-chain</dt>
              <dd>
                {token.verified_on_chain_at
                  ? new Date(token.verified_on_chain_at).toLocaleString()
                  : "—"}
              </dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-wide text-muted-foreground">Decimals</dt>
              <dd>{token.decimals ?? "—"}</dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-wide text-muted-foreground">Supply</dt>
              <dd>{token.supply ?? "—"}</dd>
            </div>
          </dl>
        </section>

        <section className="rounded-lg border border-border bg-card p-4">
          <SectionHeading
            title="Who owns what"
            description="Dev-buy tokens and creator fees are separate. AUTH records both explicitly."
          />
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <div className="rounded-md border border-border bg-muted/40 p-3">
              <p className="text-xs uppercase tracking-wide text-muted-foreground">Launcher dev buy</p>
              <p className="mt-1 text-lg font-semibold">{ownership.devBuySol} SOL</p>
              {ownership.devBuySol > 0 ? (
                ownership.devBuyDeliveryStatus === "delivered" ? (
                  <p className="mt-1 text-xs text-muted-foreground">
                    These tokens belong to the launcher and have been delivered to their wallet.
                  </p>
                ) : (
                  <p className="mt-1 text-xs leading-5 text-warning-foreground">
                    These tokens belong to the launcher, but they are still held in the
                    provider-hosted execution wallet
                    {ownership.executionWallet ? ` (${shortAddress(ownership.executionWallet)})` : ""}.
                    The launch provider offers no transfer endpoint, so delivery is pending manual
                    settlement — the launcher has not received them yet.
                  </p>
                )
              ) : (
                <p className="mt-1 text-xs text-muted-foreground">
                  No dev buy was made, so no tokens were purchased for the launcher.
                </p>
              )}
            </div>
            <div className="rounded-md border border-border bg-muted/40 p-3">
              <p className="text-xs uppercase tracking-wide text-muted-foreground">Creator fees</p>
              <p className="mt-1 text-sm font-medium">
                {recipient ? `@${recipient.handle}` : "No recipient recorded"}
              </p>
              <p className="mt-1 text-xs leading-5 text-muted-foreground">
                Creator fees belong to this social identity and can be claimed after ownership
                verification. The launcher has no claim on them.
              </p>
            </div>
          </div>
        </section>

        <section className="rounded-lg border border-border bg-card p-4">
          <SectionHeading title="Creator-fee routing" />
          {splits.length ? (
            <ul className="mt-2 divide-y divide-border text-sm">
              {splits.map((s, i) => (
                <li key={`${s.label}-${i}`} className="flex items-center justify-between py-2">
                  <span>{s.label}</span>
                  <span className="font-medium">{s.percent}%</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-2 text-sm text-muted-foreground">No active routing configuration found.</p>
          )}
        </section>

        {links.length ? (
          <section className="rounded-lg border border-border bg-card p-4">
            <SectionHeading title="Project links" />
            <div className="mt-2 flex flex-wrap gap-2">
              {links.map((l) => (
                <a
                  key={l.label}
                  className="inline-flex items-center gap-1 rounded-sm border border-border px-2 py-1 text-xs hover:bg-muted"
                  href={safeHref(l.url ?? "") ?? "#"}
                  target="_blank"
                  rel="noreferrer noopener"
                >
                  <l.icon className="size-3.5" /> {l.label}
                </a>
              ))}
            </div>
          </section>
        ) : null}

        <div className="flex flex-wrap gap-2">
          <Button asChild>
            <Link to="/t/$mint" params={{ mint: token.mint }}>
              Go to token page
            </Link>
          </Button>
          {token.launch_signature ? (
            <Button variant="outline" asChild>
              <a href={explorerTx(token.launch_signature)} target="_blank" rel="noreferrer noopener">
                View on Solscan
              </a>
            </Button>
          ) : null}
          <Button variant="outline" asChild>
            <a href={pumpUrl} target="_blank" rel="noreferrer noopener">
              View on pump.fun
            </a>
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              const url = `${window.location.origin}/launched/${token.mint}`;
              if (navigator.share) {
                navigator.share({ title: `${token.name} ($${token.symbol})`, url }).catch(() => undefined);
              } else {
                copy(url, "Link");
              }
            }}
          >
            <Share2 className="mr-1 size-3.5" /> Share
          </Button>
        </div>
      </div>
    </div>
  );
}
