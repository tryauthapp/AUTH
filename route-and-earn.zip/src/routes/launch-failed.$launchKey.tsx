import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { CircleAlert, ExternalLink } from "lucide-react";
import { launchAttempt } from "@/lib/launch-attempts.functions";
import { EmptyState, ErrorState, LoadingRows, SectionHeading, StatusPill } from "@/components/primitives";
import { Button } from "@/components/ui/button";
import { explorerTx, shortAddress } from "@/lib/format";
import { lamportsToSol } from "@/lib/launch-fee";

export const Route = createFileRoute("/launch-failed/$launchKey")({
  head: () => ({
    meta: [
      { title: "Launch failed — AUTH" },
      {
        name: "description",
        content:
          "What happened to a pump.fun launch attempt on AUTH: its state, any optional dev buy received, what was irreversibly spent and what remains recoverable.",
      },
      { property: "og:title", content: "Launch failed — AUTH" },
      {
        property: "og:description",
        content: "Launch attempt state and exact fee accounting for a failed pump.fun launch.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: LaunchFailedPage,
});

function LaunchFailedPage() {
  const { launchKey } = Route.useParams();
  const attemptFn = useServerFn(launchAttempt);
  const query = useQuery({
    queryKey: ["launch-attempt", launchKey],
    queryFn: () => attemptFn({ data: { launchKey } }),
  });

  if (query.isPending) {
    return (
      <div className="w-full px-4 py-8 sm:py-10">
        <LoadingRows rows={5} />
      </div>
    );
  }
  if (query.error) {
    return (
      <div className="w-full px-4 py-8 sm:py-10">
        <ErrorState error={query.error} retry={query.refetch} />
      </div>
    );
  }
  if (!query.data?.found) {
    return (
      <div className="w-full px-4 py-8 sm:py-10">
        <EmptyState
          title="No launch attempt found"
          description="AUTH has no record of this launch attempt for your account."
        />
      </div>
    );
  }

  const a = query.data.attempt;
  const received = Number(a.fee_lamports_received ?? 0);
  const spent = Number(a.spent_lamports ?? 0);
  const recoverable = Number(a.refundable_lamports ?? 0);
  const charged = received > 0;

  return (
    <div className="mx-auto w-full max-w-2xl px-4 py-8 sm:py-10">
      <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-5">
        <div className="flex items-center gap-2 text-destructive">
          <CircleAlert className="size-4" />
          <span className="text-sm font-semibold">
            {charged ? "Launch failed" : "Launch failed — no funds were charged"}
          </span>
          <StatusPill status="failed">{a.status}</StatusPill>
        </div>
        {a.failure_reason ? (
          <p className="mt-2 text-sm text-muted-foreground">{a.failure_reason}</p>
        ) : null}
        {!charged ? (
          <p className="mt-2 text-sm text-muted-foreground">
            AUTH charges no launch fee, and no dev-buy payment was received for this attempt, so
            nothing left your wallet through AUTH and there is nothing to refund.
          </p>
        ) : null}
      </div>

      {charged ? (
        <section className="mt-4 rounded-lg border border-border bg-card p-4">
          <SectionHeading title="Fee accounting" />
          <dl className="mt-2 divide-y divide-border text-sm">
            <div className="flex items-center justify-between py-2">
              <dt className="text-muted-foreground">Dev buy received</dt>
              <dd className="font-medium">{lamportsToSol(received)} SOL</dd>
            </div>
            <div className="flex items-center justify-between py-2">
              <dt className="text-muted-foreground">Irreversibly spent on-chain</dt>
              <dd className="font-medium">{lamportsToSol(spent)} SOL</dd>
            </div>
            <div className="flex items-center justify-between py-2">
              <dt className="text-muted-foreground">Provably unspent</dt>
              <dd className="font-medium">{lamportsToSol(recoverable)} SOL</dd>
            </div>
            {a.fee_signature ? (
              <div className="flex items-center justify-between py-2">
                <dt className="text-muted-foreground">Dev buy payment</dt>
                <dd>
                  <a
                    className="inline-flex items-center gap-1 text-primary hover:underline"
                    href={explorerTx(a.fee_signature)}
                    target="_blank"
                    rel="noreferrer noopener"
                  >
                    {shortAddress(a.fee_signature)} <ExternalLink className="size-3.5" />
                  </a>
                </dd>
              </div>
            ) : null}
            {a.launch_signature ? (
              <div className="flex items-center justify-between py-2">
                <dt className="text-muted-foreground">Launch transaction</dt>
                <dd>
                  <a
                    className="inline-flex items-center gap-1 text-primary hover:underline"
                    href={explorerTx(a.launch_signature)}
                    target="_blank"
                    rel="noreferrer noopener"
                  >
                    {shortAddress(a.launch_signature)} <ExternalLink className="size-3.5" />
                  </a>
                </dd>
              </div>
            ) : null}
            {a.refund_signature ? (
              <div className="flex items-center justify-between py-2">
                <dt className="text-muted-foreground">Refund transaction</dt>
                <dd>
                  <a
                    className="inline-flex items-center gap-1 text-primary hover:underline"
                    href={explorerTx(a.refund_signature)}
                    target="_blank"
                    rel="noreferrer noopener"
                  >
                    {shortAddress(a.refund_signature)} <ExternalLink className="size-3.5" />
                  </a>
                </dd>
              </div>
            ) : null}
          </dl>

          <div className="mt-4 rounded-md border border-border bg-muted/40 p-3 text-sm text-muted-foreground">
            {a.refund_status === "refunded" ? (
              <>
                This attempt was refunded to {a.refund_destination ?? "the paying wallet"}.
              </>
            ) : a.refund_status === "reconciling" ? (
              <>
                A launch transaction was submitted to Solana for this attempt, so the outcome must be
                reconciled on-chain before any amount can be treated as recoverable. Check the launch
                transaction above. AUTH will not mark funds refundable while the on-chain result is
                ambiguous.
              </>
            ) : a.refund_status === "manual_settlement" ? (
              <>
                {lamportsToSol(recoverable)} SOL of your dev buy was received and not spent on-chain.
                AUTH cannot return it automatically: it is paid into the provider-hosted
                launch account, and AUTH holds only an API credential that can create and trade pump.fun
                tokens — it cannot sign a SOL transfer out of that account, and holds no private key for
                it. This attempt is recorded with the exact amount and signature for settlement. No refund
                is shown here until a real, confirmed refund transaction exists.
              </>
            ) : (
              <>Nothing is recoverable for this attempt.</>
            )}
          </div>
        </section>
      ) : null}

      <div className="mt-4 flex flex-wrap gap-2">
        <Button asChild>
          <Link to="/launch">Try another launch</Link>
        </Button>
      </div>
    </div>
  );
}
