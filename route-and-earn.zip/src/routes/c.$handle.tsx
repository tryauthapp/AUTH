import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowUpRight, BadgeCheck, ShieldCheck, UserRound } from "lucide-react";
import { getPublicClaimable } from "@/lib/claimable.functions";
import { ClaimableBalance } from "@/components/ClaimableBalance";
import { ProviderIcon } from "@/components/social/ProviderIcon";
import { ExternalLink } from "@/components/ExternalLink";
import { socialProfileUrl } from "@/lib/external-links";
import { providerMeta, SOCIAL_PROVIDERS, type SocialProvider } from "@/lib/social/providers";
import { Button } from "@/components/ui/button";
import { ErrorState, LoadingRows } from "@/components/primitives";

export const Route = createFileRoute("/c/$handle")({
  validateSearch: (search: Record<string, unknown>) => {
    const raw = String(search["provider"] ?? "x").toLowerCase();
    const provider = (SOCIAL_PROVIDERS.find((p) => p.id === raw)?.id ?? "x") as SocialProvider;
    return { provider };
  },
  head: ({ params }) => ({
    meta: [
      { title: `Claimable balance for @${params.handle} — AUTH` },
      {
        name: "description",
        content: `See what @${params.handle} can claim on AUTH: real SOL and USDC entitlements from creator fees and payments sent to their social identity.`,
      },
      { property: "og:title", content: `@${params.handle} has a claimable balance on AUTH` },
      {
        property: "og:description",
        content: `Public, real-time view of the SOL and USDC waiting for @${params.handle}. Prove ownership of the account to claim it.`,
      },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PublicClaimPage,
});

function PublicClaimPage() {
  const { handle } = Route.useParams();
  const { provider } = Route.useSearch();
  const meta = providerMeta(provider);

  const balance = useQuery({
    queryKey: ["public-claimable", provider, handle.toLowerCase()],
    queryFn: () => getPublicClaimable({ data: { handle, provider } }),
    staleTime: 30_000,
  });

  const profileUrl = socialProfileUrl(provider, handle);
  const identity = balance.data?.identity ?? null;
  const displayHandle = balance.data?.handle ?? handle;

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-8">
      <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
        Public claim page
      </p>

      {/* identity header */}
      <div className="mt-3 flex flex-wrap items-center gap-4 rounded-2xl border border-border bg-card p-5">
        {profileUrl ? (
          <ExternalLink href={profileUrl} className="group flex min-w-0 flex-1 items-center gap-4">
            <IdentityAvatar url={identity?.avatarUrl ?? null} />
            <IdentityText
              name={identity?.displayName ?? null}
              handle={displayHandle}
              provider={provider}
              label={meta?.label ?? provider}
              linked
            />
          </ExternalLink>
        ) : (
          <div className="flex min-w-0 flex-1 items-center gap-4">
            <IdentityAvatar url={identity?.avatarUrl ?? null} />
            <IdentityText
              name={identity?.displayName ?? null}
              handle={displayHandle}
              provider={provider}
              label={meta?.label ?? provider}
            />
          </div>
        )}
        {identity?.isClaimed ? (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-success/10 px-2.5 py-1 text-xs font-semibold text-success">
            <BadgeCheck className="size-3.5" /> Claimed on AUTH
          </span>
        ) : (
          <span className="rounded-full bg-muted px-2.5 py-1 text-xs font-semibold text-muted-foreground">
            Unclaimed
          </span>
        )}
      </div>

      {balance.isPending ? (
        <div className="mt-4">
          <LoadingRows rows={4} />
        </div>
      ) : balance.error ? (
        <div className="mt-4">
          <ErrorState error={balance.error} retry={balance.refetch} />
        </div>
      ) : (
        <ClaimableBalance data={balance.data} className="mt-4" />
      )}

      {/* claim CTA */}
      <div className="mt-4 rounded-2xl border border-border bg-card p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="min-w-0">
            <h2 className="flex items-center gap-2 text-sm font-semibold">
              <ShieldCheck className="size-4 text-success" />
              Is this you?
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Authorize with {meta?.label ?? provider} to prove you own @{displayHandle}. Nothing is
              released until ownership is verified through the platform itself.
            </p>
          </div>
          <Button asChild>
            <Link to="/claim" search={{ handle: displayHandle, provider }}>
              Claim
            </Link>
          </Button>
        </div>
      </div>

      <p className="mt-4 text-xs text-muted-foreground">
        Balances are AUTH accounting totals for this identity, refreshed from the database on every
        load. Only public social details and public entitlement totals are shown here. AUTH does not
        assert that {meta?.label ?? provider} has verified this account.
      </p>
    </div>
  );
}

function IdentityAvatar({ url }: { url: string | null }) {
  if (url) {
    return (
      <img
        src={url}
        alt=""
        className="size-14 shrink-0 rounded-full border border-border object-cover"
      />
    );
  }
  return (
    <span className="grid size-14 shrink-0 place-items-center rounded-full border border-border bg-muted">
      <UserRound className="size-6 text-muted-foreground" />
    </span>
  );
}

function IdentityText({
  name,
  handle,
  provider,
  label,
  linked,
}: {
  name: string | null;
  handle: string;
  provider: SocialProvider;
  label: string;
  linked?: boolean;
}) {
  return (
    <span className="min-w-0 flex-1">
      {name ? <span className="block truncate text-xl font-bold">{name}</span> : null}
      <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
        <ProviderIcon provider={provider} brand className="size-3.5" />@{handle} · {label}
        {linked ? <ArrowUpRight className="size-3.5" /> : null}
      </span>
    </span>
  );
}
