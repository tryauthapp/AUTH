import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { AtSign, BadgeCheck, Copy, ExternalLink, Wallet } from "lucide-react";
import {
  myIdentityState,
  setPayoutWallet,
  startHandleClaim,
  submitHandleProof,
} from "@/lib/identity.functions";
import { createWalletNonce, verifyWalletOwnership } from "@/lib/wallet.functions";
import { paymentsForHandleQuery, payoutsQuery } from "@/lib/queries";
import { useWallet } from "@/lib/wallet/WalletProvider";
import { AccountPanel } from "@/components/AccountPanel";
import { useSession } from "@/hooks/useSession";
import { VerificationGate } from "@/components/VerificationGate";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { EmptyState, SectionHeading, StatusPill } from "@/components/primitives";
import { shortAddress, usd } from "@/lib/format";
import { providerMeta } from "@/lib/social/providers";
import { ConnectIdentity } from "@/components/social/ConnectIdentity";
import { ConnectedIdentities } from "@/components/social/ConnectedIdentities";
import { getMyEmbeddedWallet } from "@/lib/embedded-wallet.functions";
import { ClaimBalance } from "@/components/claim/ClaimBalance";
import { LedgerAssistant } from "@/components/LedgerAssistant";

export const Route = createFileRoute("/claim")({
  validateSearch: (search: Record<string, unknown>) => {
    const out: { handle?: string; link?: string; provider?: string; actual?: string; wallet?: string } = {};
    if (typeof search['handle'] === "string") out.handle = search['handle'];
    // `link` is the unified provider outcome; `x` is the legacy parameter name.
    const outcome = search['link'] ?? search['x'];
    if (typeof outcome === "string") out.link = outcome;
    if (typeof search['provider'] === "string") out.provider = search['provider'];
    if (typeof search['actual'] === "string") out.actual = search['actual'];
    if (typeof search['wallet'] === "string") out.wallet = search['wallet'];
    return out;
  },
  head: () => ({
    meta: [
      { title: "Claim your identity — AUTH" },
      {
        name: "description",
        content:
          "Prove you own an X, TikTok, YouTube or Twitch identity, connect a payout destination, and collect crypto sent to it.",
      },
      { property: "og:title", content: "Claim your identity — AUTH" },
      {
        property: "og:description",
        content: "Verify your identity, pick a payout destination, collect what's waiting for you.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ClaimPage,
});

function ClaimPage() {
  const search = Route.useSearch();
  const { session } = useSession();
  const queryClient = useQueryClient();
  const getState = useServerFn(myIdentityState);
  const state = useQuery({
    queryKey: ["identity-state", session?.user.id],
    enabled: Boolean(session),
    queryFn: () => getState(),
  });

  useEffect(() => {
    if (!search.link) return;
    const label = providerMeta(search.provider ?? "")?.label ?? "The provider";
    const messages: Record<string, string> = {
      verified: `${search.handle ?? "Your identity"} is verified and linked to AUTH.`,
      mismatch: `The ${label} account you authorized (${search.actual ?? "another account"}) does not match the identity being claimed.`,
      taken: "That identity is already linked to another AUTH account.",
      expired: "That verification request expired. Please try again.",
      claim_missing: "The identity claim could not be found. Start it again.",
      token_failed: `${label} could not complete authorization. Please try again.`,
      profile_failed: `AUTH could not read the authorized ${label} profile.`,
      no_channel: "That Google account has no YouTube channel to verify.",
      unconfigured: `${label} verification is unavailable right now.`,
      invalid: `${label} returned an invalid verification response.`,
    };
    if (search.link === "verified") {
      toast.success(messages["verified"]);
      void queryClient.invalidateQueries({ queryKey: ["identity-state"] });
      void queryClient.invalidateQueries({ queryKey: ["connected-identities"] });
      void queryClient.invalidateQueries({ queryKey: ["recipients"] });
      void queryClient.invalidateQueries({ queryKey: ["embedded-wallet"] });
      if (search.wallet && search.wallet !== "ready") {
        toast.error("Your identity is verified, but the payout wallet could not be created yet.");
      }
    } else {
      toast.error(messages[search.link] ?? "Verification did not complete.");
    }
  }, [queryClient, search.actual, search.handle, search.link, search.provider, search.wallet]);




  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-6 sm:px-7 sm:py-9">
      <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-primary">Identity ownership</p>
      <h1 className="mt-2 text-4xl sm:text-5xl">Claim your @username</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
         An @username is a payment address on AUTH. Anyone can be paid at a handle — and anyone
        can send without an account. Proving the username is the one step that needs identity: it
         is how AUTH knows the right person is attaching the payout destination. No ID documents, no
        KYC. AUTH never holds your funds or your keys.
      </p>

      {!session ? (
        <div className="mt-6 space-y-4">
          <VerificationGate
            title="Start verification"
             description="Three steps: prove you control the account, choose where the money lands, then collect anything held for your username. There is no AUTH login and no password — this only creates a private verification session on this device so the proof stays tied to you."
            action="Start verification"
          >
            <div />
          </VerificationGate>
          <p className="text-sm text-muted-foreground">
            Sending crypto never needs any of this.{" "}
            <Link to="/pay" className="text-info hover:underline">
              Send to an @username →
            </Link>
          </p>
        </div>
      ) : (
        <div className="mt-6 space-y-4">
          <StepOne
            initialHandle={search.handle ?? ""}
            onDone={() => queryClient.invalidateQueries({ queryKey: ["identity-state"] })}
            claims={state.data?.claims ?? []}
          />
          <ConnectedIdentities />
          <EmbeddedWalletCard />
          <StepWallet
            identities={state.data?.identities ?? []}
            wallets={state.data?.wallets ?? []}
            onDone={() => queryClient.invalidateQueries({ queryKey: ["identity-state"] })}
          />
          <StepFunds identities={state.data?.identities ?? []} />
        </div>
      )}
    </div>
  );
}

/**
 * The Solana wallet bound to a verified X identity. Turnkey secures the keys —
 * AUTH shows only the public address and never any key material.
 */
function EmbeddedWalletCard() {
  const { session } = useSession();
  const getWallet = useServerFn(getMyEmbeddedWallet);
  const wallet = useQuery({
    queryKey: ["embedded-wallet", session?.user.id],
    enabled: Boolean(session),
    queryFn: () => getWallet(),
  });

  if (!wallet.data) return null;

  return (
    <section className="rounded-2xl border border-border bg-card p-5">
      <SectionHeading
        title="Your payout wallet"
        description="Created when your X ownership was verified"
      />
      <div className="mt-3 flex flex-wrap items-center gap-3">
        <code className="rounded-lg bg-muted px-3 py-2 text-xs break-all">{wallet.data.address}</code>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            void navigator.clipboard.writeText(wallet.data!.address);
            toast.success("Address copied.");
          }}
        >
          <Copy className="mr-2 h-3.5 w-3.5" /> Copy
        </Button>
      </div>
      <p className="mt-3 text-xs text-muted-foreground">
        This address belongs to @{wallet.data.handle} only and can receive SOL and any supported
        Solana token. The keys are secured by {wallet.data.provider} — AUTH never sees, stores, or
        shows a private key.
      </p>
    </section>
  );
}

type ClaimRow = {
  claimId: string;
  handle: string;
  status: string;
  proofCode: string;
  proofUrl: string | null;
  verification: string;
  reviewNote: string | null;
};

function StepOne({
  initialHandle,
  claims,
  onDone,
}: {
  initialHandle: string;
  claims: ClaimRow[];
  onDone: () => void;
}) {
  const start = useServerFn(startHandleClaim);
  const submit = useServerFn(submitHandleProof);
  const [handle, setHandle] = useState(initialHandle);
  const [busy, setBusy] = useState(false);
  const [proofUrl, setProofUrl] = useState("");
  const [activeClaim, setActiveClaim] = useState<{ claimId: string; handle: string; proofCode: string; postText: string } | null>(
    null,
  );

  const pending = claims.filter((c) => c.status === "pending" || c.status === "submitted");

  async function begin() {
    setBusy(true);
    try {
      const res = await start({ data: { handle } });
      if (!res.ok) {
        toast.error(res.message ?? "Could not start that claim.");
        return;
      }
      setActiveClaim({
        claimId: res.claimId!,
        handle: res.handle!,
        proofCode: res.proofCode!,
        postText: res.postText!,
      });
      onDone();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not start that claim.");
    } finally {
      setBusy(false);
    }
  }


  async function sendProof(claimId: string) {
    setBusy(true);
    try {
      const res = await submit({ data: { claimId, proofUrl } });
      if (!res.ok) {
        toast.error(res.message);
        return;
      }
      toast.success(res.message);
      setProofUrl("");
      onDone();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not submit that link.");
    } finally {
      setBusy(false);
    }
  }

  const current = activeClaim;

  return (
    <section className="panel p-4 sm:p-5">
      <div className="flex items-center gap-2">
        <AtSign className="size-4 text-muted-foreground" />
        <h2 className="text-base font-semibold">1. Prove you own the identity</h2>
      </div>
      <p className="mt-1 text-xs text-muted-foreground">
        Claim with X, TikTok, YouTube or Twitch. AUTH stores the platform&apos;s permanent account
        or channel ID, so changing your handle later never breaks your payments.
      </p>

      <div className="mt-4">
        <ConnectIdentity initialHandle={handle} onClaimStarted={onDone} />
      </div>


      <div className="mt-4 border-t border-border pt-4">
        <p className="text-sm font-medium">Proof-post fallback (X only)</p>
        <p className="mt-1 text-xs text-muted-foreground">
          If provider authorization isn&apos;t available, post a unique code from the X account and
          submit the link for manual review.
        </p>
        <div className="mt-2 grid gap-2 sm:grid-cols-[minmax(0,1fr)_auto]">
          <Input
            value={handle}
            onChange={(e) => setHandle(e.target.value)}
            placeholder="X username"
            autoCapitalize="none"
            spellCheck={false}
            className="h-10 rounded-md"
          />
          <Button
            type="button"
            variant="outline"
            className="press h-10 rounded-md"
            onClick={begin}
            disabled={busy || !handle.trim()}
          >
            Get proof code
          </Button>
        </div>
      </div>


      {current ? (
        <div className="mt-4 rounded-xl border border-border bg-secondary/40 p-4 text-sm">
          <p className="font-medium">Post this from @{current.handle}:</p>
          <p className="num mt-2 break-words rounded-lg bg-background p-3">{current.postText}</p>
          <Button
            size="sm"
            variant="outline"
            className="press mt-2 rounded-full"
            onClick={() => {
              void navigator.clipboard.writeText(current.postText);
              toast.success("Copied");
            }}
          >
            <Copy className="size-3.5" /> Copy
          </Button>
          <div className="mt-4 flex flex-wrap gap-2">
            <Input
              value={proofUrl}
              onChange={(e) => setProofUrl(e.target.value)}
              placeholder="https://x.com/username/status/…"
              className="h-11 flex-1 rounded-xl"
            />
            <Button
              className="press h-11 rounded-full"
              onClick={() => sendProof(current.claimId)}
              disabled={busy || !proofUrl}
            >
              Submit proof
            </Button>
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            The link must be a post from @{current.handle}. A person reviews it before the verified
             badge appears. AUTH is not affiliated with X.
          </p>
        </div>
      ) : null}

      {pending.length > 0 ? (
        <ul className="mt-4 space-y-2 text-sm">
          {pending.map((c) => (
            <li key={c.claimId} className="flex flex-wrap items-center gap-2 rounded-xl border border-border p-3">
              <span className="font-medium">@{c.handle}</span>
              <StatusPill status={c.status === "submitted" ? "pending" : "unverified"}>
                {c.status === "submitted" ? "Awaiting review" : "Proof code issued"}
              </StatusPill>
              <span className="num ml-auto text-xs text-muted-foreground">{c.proofCode}</span>
            </li>
          ))}
        </ul>
      ) : null}
    </section>
  );
}

function StepWallet({
  identities,
  wallets,
  onDone,
}: {
  identities: { id: string; handle: string; verification: string }[];
  wallets: { id: string; address: string; recipientId: string | null; verifiedAt: string | null; isDefault: boolean }[];
  onDone: () => void;
}) {
  const { address, signer } = useWallet();
  const nonceFn = useServerFn(createWalletNonce);
  const verifyFn = useServerFn(verifyWalletOwnership);
  const setWallet = useServerFn(setPayoutWallet);
  const [busy, setBusy] = useState(false);
  const identity = identities[0] ?? null;

  async function verify() {
    if (!address || !signer || !identity) return;
    setBusy(true);
    try {
      const { nonce } = await nonceFn({ data: {} });
      const { ownershipMessage } = await import("@/lib/wallet.functions");
      const signed = await signer.signMessage(ownershipMessage(address, nonce));
      const res = await verifyFn({
        data: {
          address,
          signature: signed.signature,
          nonce,
          provider: signer.key,
          recipientId: identity.id,
        },
      });
      if (!res.ok) {
        toast.error(res.message);
        return;
      }
      toast.success("Wallet verified. Payments to your username now resolve here.");
      onDone();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Wallet verification failed.");
    } finally {
      setBusy(false);
    }
  }

  async function makeDefault(walletId: string) {
    if (!identity) return;
    const res = await setWallet({ data: { recipientId: identity.id, walletId } });
    if (!res.ok) {
      toast.error(res.message);
      return;
    }
    toast.success(res.message);
    onDone();
  }

  return (
    <section className="panel p-4 sm:p-5">
      <div className="flex items-center gap-2">
        <Wallet className="size-4 text-muted-foreground" />
        <h2 className="text-base font-semibold">2. Choose where payments land</h2>
      </div>

      {!identity ? (
        <p className="mt-3 text-sm text-muted-foreground">
          Claim a username above first — the wallet is mapped to that identity, and only after the
          username has been verified.
        </p>
      ) : identity.verification !== "verified" ? (
        <p className="mt-3 text-sm text-muted-foreground">
          @{identity.handle} is still being verified. A payout wallet can be set once ownership is
          confirmed — this is what stops anyone else redirecting payments meant for you.
        </p>
      ) : (
        <>
          <p className="mt-3 text-sm text-muted-foreground">
            Payments land wherever you point @{identity.handle}. Authorizing a plain-text ownership
            message proves the destination is yours — no transaction, no funds moved, never a
            private key.
          </p>
          <div className="mt-3 space-y-3">
            <AccountPanel />
            <Button className="press rounded-full" onClick={verify} disabled={!address || busy}>
              {busy ? "Waiting for wallet…" : "Verify ownership"}
            </Button>
          </div>


          {wallets.length > 0 ? (
            <ul className="mt-4 space-y-2 text-sm">
              {wallets.map((w) => (
                <li key={w.id} className="flex flex-wrap items-center gap-2 rounded-xl border border-border p-3">
                  <span className="num">{shortAddress(w.address, 6)}</span>
                  <StatusPill status={w.verifiedAt ? "verified" : "unverified"}>
                    {w.verifiedAt ? "Verified" : "Unverified"}
                  </StatusPill>
                  {w.isDefault && w.recipientId === identity.id ? (
                    <StatusPill status="live">Payout wallet</StatusPill>
                  ) : w.verifiedAt ? (
                    <Button
                      size="sm"
                      variant="outline"
                      className="press ml-auto rounded-full"
                      onClick={() => makeDefault(w.id)}
                    >
                      Use for @{identity.handle}
                    </Button>
                  ) : null}
                </li>
              ))}
            </ul>
          ) : null}
        </>
      )}
    </section>
  );
}

function StepFunds({ identities }: { identities: { id: string; handle: string }[] }) {
  const identity = identities[0] ?? null;
  const payments = useQuery(paymentsForHandleQuery(identity?.handle));
  const payouts = useQuery(payoutsQuery());

  const reserved = (payments.data ?? []).filter((p) => p.status === "awaiting_recipient");
  const claimable = (payouts.data ?? []).filter(
    (p) => p.recipient_id === identity?.id && (p.status === "claimable" || p.status === "failed"),
  );

  return (
    <section className="panel p-4 sm:p-5">
      <div className="flex items-center gap-2">
        <BadgeCheck className="size-4 text-success" />
        <h2 className="text-base font-semibold">3. Collect what's waiting</h2>
      </div>

      <div className="mt-4">
        <ClaimBalance enabled={identities.length > 0} />
      </div>

      {identities.length > 0 ? (
        <>
          <p className="mt-4 text-xs leading-5 text-muted-foreground">
            Creator fees are tracked automatically. AUTH reconciles fee activity continuously and
            every 5 minutes as a fallback. Claim when you're ready.
          </p>
          <div className="mt-4">
            <LedgerAssistant />
          </div>
        </>
      ) : null}

      {!identity ? (
        <p className="mt-3 text-sm text-muted-foreground">Claim a username to see anything held for it.</p>
      ) : reserved.length === 0 && claimable.length === 0 ? (
        <div className="mt-3">
          <EmptyState
            title={`Nothing held for @${identity.handle}`}
            description="Reserved payments and claimable creator-fee balances appear here."
          />
        </div>
      ) : (
        <div className="mt-4 space-y-4">
          {reserved.length > 0 ? (
            <div>
              <SectionHeading
                title="Legacy reserved payments"
                description="These were created before protected deposits and were never funded — they stay in the sender's wallet until they sign again."
              />
              <ul className="mt-3 space-y-2 text-sm">
                {reserved.map((p) => (
                  <li key={p.id} className="flex flex-wrap items-center gap-2 rounded-xl border border-border p-3">
                    <span className="num font-medium">
                      {Number(p.amount)} {p.asset}
                    </span>
                    {p.amount_usd ? (
                      <span className="text-xs text-muted-foreground">{usd(Number(p.amount_usd))}</span>
                    ) : null}
                    <StatusPill status="pending">Awaiting sender signature</StatusPill>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}

          {claimable.length > 0 ? (
            <div>
              <SectionHeading
                title="Claimable creator fees"
                description="Routed amounts whose payout rail failed. Open a claim from your dashboard."
              />
              <ul className="mt-3 space-y-2 text-sm">
                {claimable.map((p) => (
                  <li key={p.id} className="flex flex-wrap items-center gap-2 rounded-xl border border-border p-3">
                    <span>{p.label ?? p.destination}</span>
                    <span className="num ml-auto">{usd(Number(p.amount_usd))}</span>
                  </li>
                ))}
              </ul>
              <Button asChild variant="outline" className="press mt-3 rounded-full">
                <Link to="/dashboard">Open dashboard</Link>
              </Button>
            </div>
          ) : null}
        </div>
      )}
    </section>
  );
}

