import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  ArrowRight,
  AtSign,
  Check,
  CircleAlert,
  Coins,
  Copy,
  Image as ImageIcon,
  Link as LinkIcon,
  Loader2,
  Plus,
  Trash2,
  Wallet,
} from "lucide-react";
import { useSession } from "@/hooks/useSession";
import { VerificationGate } from "@/components/VerificationGate";
import { launchToken, launchAvailability, awaitLaunchFee } from "@/lib/tokens.functions";
import { reconcileLaunch } from "@/lib/launch-attempts.functions";
import {
  LAUNCH_FEE_ADDRESS,
  AUTH_LAUNCH_FEE_SOL,
  MIN_DEV_BUY_SOL,
  requiredLamportsForLaunch,
  lamportsToSol,
} from "@/lib/launch-fee";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PageHeader, PageShell, SectionHeading } from "@/components/primitives";
import { ImageUploader, type UploadedImage } from "@/components/ImageUploader";
import { XProfilePreview } from "@/components/XProfilePreview";
import { AssetIcon } from "@/components/AssetIcon";
import type { XProfile } from "@/lib/x-profile.functions";
import { PlatformIdentityPicker } from "@/components/social/PlatformIdentityPicker";
import { ProviderIcon, providerTint } from "@/components/social/ProviderIcon";
import { PlatformChips } from "@/components/social/PlatformChips";
import {
  SOCIAL_PROVIDERS,
  type SocialProvider,
} from "@/lib/social/providers";
import type { ResolvedIdentity } from "@/lib/platform-identity.functions";
import { urlError } from "@/lib/links";
import { launchWalletStatus } from "@/lib/launch-ownership.functions";
import { shortAddress } from "@/lib/format";
import { cn } from "@/lib/utils";



export const Route = createFileRoute("/launch")({
  head: () => ({
    meta: [
      { title: "Launch a token — AUTH" },
      {
        name: "description",
        content:
          "Create a new Solana token through pump.fun: name, ticker, image, description, project links and creator-fee routing to an @username.",
      },
      { property: "og:title", content: "Launch a token — AUTH" },
      {
        property: "og:description",
        content: "Create a new pump.fun token and route its creator fees to any X handle.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LaunchPage,
});


/**
 * Creator rewards follow the pump.fun launch pair, so the only two options are
 * the two pairs pump.fun supports: SOL and USDC.
 */
type RewardAsset = "sol" | "usdc";

const REWARD_ASSETS = [
  {
    value: "sol" as const,
    symbol: "SOL",
    name: "Solana",
    assetKey: "solana:SOL",
    blurb: "Creator fees are collected and paid in native SOL.",
  },
  {
    value: "usdc" as const,
    symbol: "USDC",
    name: "USD Coin",
    assetKey: "solana:USDC",
    blurb: "Creator fees are collected and paid in USDC on the USDC-paired market.",
  },
];

type PriorLaunch = {
  state: "confirmed" | "in_flight" | "failed" | "funded" | "none";
  message: string;
  mint: string | null;
  launchSignature: string | null;
  retryable: boolean;
};

function newLaunchKey() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

const STEPS = ["Recipient", "Token", "Review"] as const;

function LaunchPage() {
  const { session } = useSession();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const launchFn = useServerFn(launchToken);
  const availabilityFn = useServerFn(launchAvailability);

  const launchWalletFn = useServerFn(launchWalletStatus);
  // Public status only: address, balance and signer mode. Never the key.
  const launchWallet = useQuery({
    queryKey: ["launch-wallet-status"],
    queryFn: () => launchWalletFn(),
    staleTime: 60_000,
  });
  const availability = useQuery({
    queryKey: ["launch-availability"],
    queryFn: () => availabilityFn({}),
  });

  const [step, setStep] = useState(0);
  const [provider, setProvider] = useState<SocialProvider>("x");
  const [handle, setHandle] = useState("");
  const [xProfile, setXProfile] = useState<XProfile | null>(null);
  // Resolved identity for non-X platforms, from the shared lookup layer.
  const [identity, setIdentity] = useState<ResolvedIdentity | null>(null);
  // When lookup isn't configured we must not block the flow on a confirmation.
  const [lookupAvailable, setLookupAvailable] = useState(true);

  const [symbol, setSymbol] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [website, setWebsite] = useState("");
  const [xUrl, setXUrl] = useState("");
  const [telegram, setTelegram] = useState("");
  const [community, setCommunity] = useState("");
  const [image, setImage] = useState<UploadedImage | null>(null);
  const [devBuy, setDevBuy] = useState(String(MIN_DEV_BUY_SOL));
  const [devBuyWallet, setDevBuyWallet] = useState("");
  // Stable per-attempt key so a double submit cannot launch (and dev buy) twice.
  // A retry always gets a NEW key: the previous attempt stays untouched for audit.
  const [launchKey, setLaunchKey] = useState(newLaunchKey);
  // What happened to a previous attempt with this key, resolved on-chain.
  const [priorLaunch, setPriorLaunch] = useState<PriorLaunch | null>(null);
  const [checkingPrior, setCheckingPrior] = useState(false);
  const reconcileFn = useServerFn(reconcileLaunch);
  const [rewardAsset, setRewardAsset] = useState<RewardAsset>("sol");
  const [submitting, setSubmitting] = useState(false);
  const [retryOfKey, setRetryOfKey] = useState<string | null>(null);

  // AUTH charges no platform fee. The launcher funds the required dev buy.
  const feeFn = useServerFn(awaitLaunchFee);
  const [feePayer, setFeePayer] = useState("");
  const payerValid = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(feePayer.trim());
  const [feeSignature, setFeeSignature] = useState<string | null>(null);
  const [feeError, setFeeError] = useState<string | null>(null);

  // Canonical identity: the confirmed X profile's username, else raw input.
  const providerRow = SOCIAL_PROVIDERS.find((p) => p.id === provider)!;
  const normalized = (
    (provider === "x" ? xProfile?.username : identity?.profile?.handle) ??
    handle.trim().replace(/^@/, "")
  ).toLowerCase();

  // A pair is only selectable-and-launchable if the provider path supports it.
  const supportedRewardAssets = availability.data?.supportedRewardAssets ?? null;
  const rewardAssetSupported =
    supportedRewardAssets === null || supportedRewardAssets.includes(rewardAsset);
  const rewardAssetMeta = REWARD_ASSETS.find((a) => a.value === rewardAsset)!;

  const linkErrors = {
    website: urlError(website, "Website URL"),
    x: urlError(xUrl, "X URL"),
    telegram: urlError(telegram, "Telegram URL"),
    community: urlError(community, "Community URL"),
  };
  const linksValid = Object.values(linkErrors).every((e) => e === null);

  const devBuyTrimmed = devBuy.trim();
  // A dev buy is mandatory: every launch must have launcher-owned supply.
  const devBuyError = !devBuyTrimmed
    ? `A dev buy is required. Minimum ${MIN_DEV_BUY_SOL} SOL.`
    : !/^\d{1,4}(\.\d{1,9})?$/.test(devBuyTrimmed)
      ? "Enter a SOL amount with up to 9 decimal places."
      : Number(devBuyTrimmed) < MIN_DEV_BUY_SOL
        ? `The minimum dev buy is ${MIN_DEV_BUY_SOL} SOL.`
        : Number(devBuyTrimmed) > 100
          ? "Dev buy is capped at 100 SOL."
          : null;
  const devBuyAmount = devBuyError ? 0 : Number(devBuyTrimmed) || 0;
  // The dev buy is funded by the launcher and sent to whichever account actually
  // executes the buy. AUTH's launch balance is infrastructure funding only.
  const devBuyFundingAddress = availability.data?.devBuyFundingAddress ?? LAUNCH_FEE_ADDRESS;
  const devBuyAutoDelivery = availability.data?.devBuyAutoDelivery ?? false;
  // The launcher's own wallet, where the dev-buy tokens must end up.
  const devBuyWalletValue = (devBuyWallet.trim() || feePayer.trim()).trim();
  const devBuyWalletValid = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(devBuyWalletValue);
  const devBuyWalletError =
    devBuyAmount > 0 && devBuyWallet.trim() && !devBuyWalletValid
      ? "Enter a valid Solana wallet address."
      : null;
  // The dev buy is mandatory, so a valid launcher destination is always required.
  const devBuyDestinationReady = devBuyWalletValid;
  const devBuyLamports = requiredLamportsForLaunch(launchKey, devBuyAmount);
  const needsPayment = devBuyLamports > 0;
  const exactDevBuy = lamportsToSol(devBuyLamports);
  const paymentReady =
    !devBuyError && needsPayment && Boolean(feeSignature) && devBuyDestinationReady;

  useEffect(() => {
    if (step !== 2 || !needsPayment || feeSignature) return;
    let cancelled = false;
    async function poll() {
      try {
        const res = await feeFn({
          data: { payer: payerValid ? feePayer.trim() : "", launchKey, devBuySol: devBuyAmount },
        });
        if (cancelled) return;
        if (!res.ok) {
          setFeeError(res.message);
          return;
        }
        setFeeError(null);
        if (res.paid && res.signature) setFeeSignature(res.signature);
      } catch (e) {
        if (!cancelled) setFeeError(e instanceof Error ? e.message : "Could not check payment.");
      }
    }
    void poll();
    const id = setInterval(poll, 6000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [step, needsPayment, feeSignature, feeFn, feePayer, payerValid, launchKey, devBuyAmount]);


  /** Resolve the previous attempt on-chain, then start a clean new attempt. */
  async function retryLaunch() {
    setCheckingPrior(true);
    try {
      const prior = await reconcileFn({ data: { launchKey } });
      if (prior.state === "confirmed" || prior.state === "in_flight") {
        setPriorLaunch({
          state: prior.state,
          message: prior.message,
          mint: prior.mint,
          launchSignature: prior.launchSignature,
          retryable: false,
        });
        return;
      }
      setRetryOfKey(launchKey);
      setLaunchKey(newLaunchKey());
      setPriorLaunch(null);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not check the previous launch.");
    } finally {
      setCheckingPrior(false);
    }
  }

  async function submit() {
    setSubmitting(true);
    try {
      const res = await launchFn({
        data: {
          handle: normalized,
          provider,
          platformUserId:
            provider === "x"
              ? (xProfile?.id ?? identity?.profile?.platformUserId ?? null)
              : (identity?.profile?.platformUserId ?? null),
          displayName:
            provider === "x"
              ? (xProfile?.name ?? null)
              : (identity?.profile?.displayName ?? null),
          avatarUrl:
            provider === "x"
              ? (xProfile?.avatarUrl ?? null)
              : (identity?.profile?.avatarUrl ?? null),
          bio:
            provider === "x"
              ? (xProfile?.description ?? null)
              : (identity?.profile?.bio ?? null),

          symbol,
          name,
          description,
          imageUrl: image?.url ?? null,
          imagePath: image?.path ?? null,
          devBuySol: devBuy.trim(),
          devBuyDestination: devBuyWalletValue,
          launchKey,
          retryOfLaunchKey: retryOfKey ?? "",
          websiteUrl: website,
          xUrl,
          telegramUrl: telegram,
          communityUrl: community,
          feeSignature: feeSignature ?? "",
          rewardAsset,
        },
      });
      if (!res.ok) {
        const state = "state" in res ? res.state : null;
        // A previous attempt is in the way: show an actionable state, never a
        // dead end. Retry is offered as soon as it is provably safe.
        if (state === "confirmed" || state === "in_flight") {
          setPriorLaunch({
            state,
            message: res.message,
            mint: "priorMint" in res ? res.priorMint : null,
            launchSignature: "priorSignature" in res ? res.priorSignature : null,
            retryable: false,
          });
          toast.error(res.message);
          return;
        }
        setPriorLaunch({
          state: "failed",
          message: res.message,
          mint: null,
          launchSignature: null,
          retryable: true,
        });
        toast.error(res.message);
        // A funded attempt has a persisted record: show the accounting page.
        if (res.funded) {
          navigate({ to: "/launch-failed/$launchKey", params: { launchKey } });
        }
        return;
      }
      await queryClient.invalidateQueries();
      toast.success("Token launched on pump.fun");
      navigate({ to: "/launched/$mint", params: { mint: res.mint } });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not launch that token.");
    } finally {
      setSubmitting(false);
    }
  }

  const recipientReady =
    provider === "x"
      ? Boolean(normalized) && (!lookupAvailable || Boolean(xProfile))
      : providerRow.handlePattern.test(normalized);
  const stepReady = [
    recipientReady,
    Boolean(symbol.trim()) && Boolean(name.trim()) && linksValid && !devBuyError,
    rewardAssetSupported,
  ];

  // Live readiness — every status derives from real form/infrastructure state.
  const checks = [
    {
      label: "Recipient confirmed",
      done: recipientReady,
    },
    { label: "Token name and ticker set", done: Boolean(symbol.trim() && name.trim()) },
    { label: "Token image attached", done: Boolean(image?.url) },
    {
      label: `Creator rewards in ${rewardAssetMeta.symbol}`,
      done: rewardAssetSupported,
    },
    { label: "Launch infrastructure ready", done: availability.data?.ready === true },
    {
      label: needsPayment
        ? "Dev buy payment confirmed"
        : `Dev buy of at least ${MIN_DEV_BUY_SOL} SOL required`,
      done: paymentReady,
    },
  ];


  if (!session) {
    return (
      <PageShell width="narrow">
        <PageHeader
          eyebrow="pump.fun · Solana mainnet"
          title="Launch a token"
          description="A launch creates a real on-chain token and ties its creator fees to an @username, so it needs the same ownership verification as a claim."
        />
        <VerificationGate
          title="Verify ownership first"
           description="No AUTH login and no password — this creates a private verification session on this device so the launch can be tied to the handle you prove you own."
          action="Start verification"
        >
          <div />
        </VerificationGate>
      </PageShell>
    );
  }

  return (
    <PageShell className="workspace-ambient">
      <div className="relative z-10">
        <PageHeader
          eyebrow="pump.fun · Solana mainnet"
          title="Launch"
          action={<span className="workspace-label">Real mainnet launch</span>}
        />
      </div>
      <div className="relative z-10 grid gap-4 xl:grid-cols-[minmax(0,1fr)_340px]">
      <section className="workspace-panel bg-card p-4 shadow-[0_1px_2px_rgba(16,18,27,0.04)] sm:p-6 lg:p-7">
      <h2 className="text-xl font-semibold leading-tight tracking-[-0.01em] sm:text-[1.6rem]">Create a new token</h2>
      <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">
        Every AUTH launch creates a brand-new token on pump.fun. The mint address is produced by
        the launch itself and indexed here automatically — there is nothing to paste in.
      </p>

      {availability.data && !availability.data.ready ? (
        <p className="mt-4 flex items-start gap-2 rounded-xl border border-warning/30 bg-warning/10 p-3 text-xs text-warning-foreground">
          <CircleAlert className="mt-0.5 size-3.5 shrink-0" />
          <span>{availability.data.message}</span>
        </p>
      ) : null}


      <Stepper step={step} />

      <div className="mt-6 space-y-6">
        {step === 0 ? (
          <>
            <FormBlock
              icon={<AtSign className="size-4" />}
              title="Recipient"
              description="Creator fees are tied to this platform identity, not to a wallet."
            >
              {provider === "x" ? (
                <>
                  <PlatformChips
                    value={provider}
                    onChange={(p) => {
                      setProvider(p);
                      setXProfile(null);
                      setIdentity(null);
                    }}
                  />
                  <Label htmlFor="handle" className="mt-4 block">
                    {providerRow.handleLabel}
                  </Label>
                  <div
                    style={providerTint(provider)}
                    className="mt-2 flex items-center gap-2 rounded-md border border-border bg-background px-3 focus-within:border-primary/60"
                  >
                    <ProviderIcon provider={provider} brand />
                    <span className="text-sm text-muted-foreground">@</span>
                    <Input
                      id="handle"
                      value={handle}
                      onChange={(e) => {
                        setHandle(e.target.value);
                        setXProfile(null);
                      }}
                      placeholder={providerRow.handlePlaceholder}
                      className="h-11 border-0 bg-transparent px-0 text-sm shadow-none focus-visible:ring-0"
                    />
                  </div>
                  <XProfilePreview
                    handle={handle}
                    confirmed={xProfile}
                    onConfirm={(p) => {
                      setXProfile(p);
                      setHandle(p.username);
                    }}
                    onClear={() => setXProfile(null)}
                    onAvailabilityChange={setLookupAvailable}
                  />
                </>
              ) : (
                <PlatformIdentityPicker
                  provider={provider}
                  onProviderChange={(p) => {
                    setProvider(p);
                    setXProfile(null);
                    setIdentity(null);
                  }}
                  handle={handle}
                  onHandleChange={setHandle}
                  onResolved={setIdentity}
                  label="Creator-fee recipient"
                />
              )}
              <p className="mt-4 text-xs leading-5 text-muted-foreground">
                Fees route to the {providerRow.label} identity itself. The recipient claims them by
                proving they own the account — no wallet needed to be named here.
              </p>
            </FormBlock>
          </>
        ) : null}

        {step === 1 ? (
          <>
            <FormBlock
              icon={<Coins className="size-4" />}
              title="Token details"
              description="Name, ticker and the description shown on the token page."
            >
              <div className="grid gap-4 sm:grid-cols-[minmax(0,180px)_minmax(0,1fr)]">
                <div className="space-y-2">
                  <Label htmlFor="symbol">Token symbol</Label>
                  <Input
                    id="symbol"
                    value={symbol}
                    onChange={(e) => setSymbol(e.target.value)}
                    placeholder="TICKER"
                    className="field num text-sm uppercase tracking-[0.08em]"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="name">Token name</Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Token name"
                    className="field text-sm"
                  />
                </div>
              </div>

              <div className="mt-4 space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value.slice(0, 600))}
                  placeholder="What is this token for?"
                  rows={4}
                  className="resize-y text-sm leading-6"
                />
                <p className="text-right text-xs text-muted-foreground">
                  <span className="num">{description.length}</span>/600
                </p>
              </div>
            </FormBlock>

            <FormBlock
              icon={<ImageIcon className="size-4" />}
              title="Media"
              description="The token image used on pump.fun and across AUTH."
            >
              <ImageUploader
                value={image}
                onChange={setImage}
                userId={session.user.id}
                disabled={submitting}
              />
            </FormBlock>

            <FormBlock
              icon={<LinkIcon className="size-4" />}
              title="Project links"
              description="Optional. Included in the pump.fun token metadata."
            >
              <div className="grid gap-4 sm:grid-cols-2">
                {[
                  { id: "website", label: "Website", value: website, set: setWebsite, ph: "yourtoken.com", err: linkErrors.website },
                  { id: "x", label: "X / Twitter", value: xUrl, set: setXUrl, ph: "x.com/yourtoken", err: linkErrors.x },
                  { id: "telegram", label: "Telegram", value: telegram, set: setTelegram, ph: "t.me/yourtoken", err: linkErrors.telegram },
                  { id: "community", label: "Other community link", value: community, set: setCommunity, ph: "discord.gg/…", err: linkErrors.community },
                ].map((f) => (
                  <div key={f.id} className="space-y-2">
                    <Label htmlFor={`link-${f.id}`}>{f.label}</Label>
                    <Input
                      id={`link-${f.id}`}
                      value={f.value}
                      onChange={(e) => f.set(e.target.value)}
                      placeholder={f.ph}
                      inputMode="url"
                      className="field text-sm"
                      aria-invalid={Boolean(f.err)}
                    />
                    {f.err ? (
                      <p className="flex items-center gap-1.5 text-xs text-destructive">
                        <CircleAlert className="size-3" /> {f.err}
                      </p>
                    ) : null}
                  </div>
                ))}
              </div>
            </FormBlock>

            <FormBlock
              icon={<Wallet className="size-4" />}
              title="Dev buy"
              description={`AUTH charges a 0 SOL platform fee, but every launch requires a dev buy of at least ${MIN_DEV_BUY_SOL} SOL, funded by you. It is your own first buy of your token and AUTH takes no cut.`}
            >
              <div className="max-w-xs space-y-2">
                <Label htmlFor="devbuy">Amount (SOL)</Label>
                <div className="relative">
                  <Input
                    id="devbuy"
                    value={devBuy}
                    onChange={(e) => setDevBuy(e.target.value.replace(/[^0-9.]/g, "").slice(0, 16))}
                    inputMode="decimal"
                    className="field num pr-14 text-sm"
                    placeholder={String(MIN_DEV_BUY_SOL)}
                    aria-invalid={devBuyError ? true : undefined}
                  />
                  <span className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-xs font-semibold text-muted-foreground">
                    SOL
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Minimum dev buy: <span className="num">{MIN_DEV_BUY_SOL}</span> SOL
                </p>
              </div>
              {!devBuyError ? (
                <div className="mt-4 max-w-md space-y-2">
                  <Label htmlFor="devbuy-wallet">Your Solana wallet for the dev-buy tokens</Label>
                  <Input
                    id="devbuy-wallet"
                    value={devBuyWallet}
                    onChange={(e) => setDevBuyWallet(e.target.value.trim())}
                    placeholder="Your Solana wallet address"
                    className="num field text-sm"
                    spellCheck={false}
                    aria-invalid={devBuyWalletError ? true : undefined}
                  />
                  <p className="text-xs leading-5 text-muted-foreground">
                    Your dev-buy tokens will be delivered to this wallet. Use a wallet you have
                    verified in your profile, or the exact wallet you send the dev-buy SOL from —
                    AUTH will not send your tokens to an unproven address.
                  </p>
                  {devBuyWalletError ? (
                    <p className="flex items-center gap-1 text-xs text-destructive">
                      <CircleAlert className="size-3" /> {devBuyWalletError}
                    </p>
                  ) : null}
                </div>
              ) : null}
              {devBuyError ? (
                <p className="mt-2 flex items-center gap-1 text-xs text-destructive">
                  <CircleAlert className="size-3" /> {devBuyError}
                </p>
              ) : (
                <p className="mt-3 max-w-2xl text-xs leading-5 text-muted-foreground">
                  The dev buy is funded by you, not by AUTH — it buys your own new token in the
                  same pump.fun launch. The purchased tokens are forwarded to your wallet after the
                  launch confirms on Solana. AUTH takes no cut — only pump.fun and Solana network
                  costs apply.
                </p>
              )}
            </FormBlock>
          </>


        ) : null}

        {step === 2 ? (
          <>
            <SectionHeading
              title="Creator rewards"
              description="pump.fun pays creator fees in the asset the coin is paired with. Pick that asset."
            />
            <div className="grid gap-3 sm:grid-cols-2">
              {REWARD_ASSETS.map((asset) => {
                const selected = rewardAsset === asset.value;
                const supported =
                  supportedRewardAssets === null || supportedRewardAssets.includes(asset.value);
                return (
                  <button
                    key={asset.value}
                    type="button"
                    onClick={() => setRewardAsset(asset.value)}
                    aria-pressed={selected}
                    className={cn(
                      "press relative flex items-center gap-4 rounded-2xl border p-5 text-left transition-colors",
                      selected
                        ? "border-primary bg-primary/[0.06] ring-2 ring-primary/40 dark:bg-primary/10"
                        : "border-border bg-card hover:border-primary/40 hover:bg-secondary/40",
                    )}
                  >
                    <AssetIcon
                      symbol={asset.symbol}
                      assetKey={asset.assetKey}
                      chainKey="solana"
                      size="lg"
                      showNetwork={false}
                    />
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-2">
                        <span className="text-base font-semibold">{asset.symbol}</span>
                        <span className="text-xs text-muted-foreground">{asset.name}</span>
                      </span>
                      <span className="mt-1 block text-xs leading-5 text-muted-foreground">
                        {asset.blurb}
                      </span>
                      {!supported ? (
                        <span className="mt-2 flex items-start gap-1 text-xs text-warning">
                          <CircleAlert className="mt-0.5 size-3 shrink-0" />
                          Not launchable through AUTH&apos;s current pump.fun provider path.
                        </span>
                      ) : null}
                    </span>
                    {selected ? (
                      <span className="grid size-6 shrink-0 place-items-center rounded-full bg-success text-success-foreground">
                        <Check className="size-3.5" />
                      </span>
                    ) : (
                      <span className="size-6 shrink-0 rounded-full border border-border" />
                    )}
                  </button>
                );
              })}
            </div>
            <p className="text-xs leading-5 text-muted-foreground">
              Creator fees go to @{normalized || "username"} in {rewardAssetMeta.symbol}. There are
              no other routing destinations on an AUTH launch.
            </p>
            {!rewardAssetSupported ? (
              <p className="flex items-start gap-2 rounded-xl border border-warning/30 bg-warning/10 p-3 text-xs text-warning-foreground">
                <CircleAlert className="mt-0.5 size-3.5 shrink-0" />
                <span>
                  {rewardAssetMeta.symbol}-paired launches are not available through the provider
                  AUTH uses, so this launch is blocked. Select SOL to continue.
                </span>
              </p>
            ) : null}
            <SectionHeading
              title="Review"
              description="This creates a real token on pump.fun on Solana mainnet."
            />
            <dl className="divide-y divide-border border-y border-border text-sm [&>div]:py-3">
              <Line label="Recipient" value={`@${normalized}`} />
              <Line label="Token" value={`${symbol.toUpperCase()} — ${name || symbol.toUpperCase()}`} />
              <Line label="Launch destination" value="pump.fun (Solana mainnet)" />
              <Line label="Mint" value="Created by the launch" />
              <Line
                label="AUTH launch fee"
                value={<span className="num font-medium text-success">{AUTH_LAUNCH_FEE_SOL} SOL</span>}
              />
              <Line
                label="Launch costs"
                value="Solana network and provider costs, paid by AUTH launch infrastructure"
              />
              <Line
                label="Launcher dev buy"
                value={
                  devBuyAmount > 0 ? (
                    <span className="num">{devBuyAmount} SOL — paid by you, the launcher</span>
                  ) : (
                    `Required — enter at least ${MIN_DEV_BUY_SOL} SOL`
                  )
                }
              />
              <Line
                label="Dev buy wallet"
                value={
                  devBuyWalletValid ? (
                    <span className="num">{shortAddress(devBuyWalletValue)}</span>
                  ) : (
                    "Add your own Solana wallet"
                  )
                }
              />
              <Line
                label="Links"
                value={
                  [website, xUrl, telegram, community].filter(Boolean).length
                    ? `${[website, xUrl, telegram, community].filter(Boolean).length} added`
                    : "None"
                }
              />
</dl>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-xl border border-border bg-surface-2 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Launcher dev buy
                </p>
                <p className="mt-2 text-lg font-semibold">
                  <span className="num">{devBuyAmount || 0}</span> SOL
                </p>
                {devBuyAmount > 0 ? (
                  <>
                    <p className="mt-1 text-xs leading-5 text-muted-foreground">
                      Paid by you, the launcher — never from AUTH's launch balance. The purchased
                      tokens belong to you. AUTH takes no cut of them and the creator-fee recipient
                      has no claim on them.
                    </p>
                    <div className="mt-2 rounded-md border border-border bg-background p-2.5">
                      <p className="text-xs uppercase tracking-wide text-muted-foreground">
                        Your destination wallet
                      </p>
                      <p className="mt-1 font-mono text-xs">
                        {devBuyWalletValid ? shortAddress(devBuyWalletValue) : "Not set yet"}
                      </p>
                      <p className="mt-1 text-xs leading-5 text-muted-foreground">
                        {devBuyAutoDelivery
                          ? "Your dev-buy tokens will be delivered to this wallet. AUTH forwards them once the launch confirms, and only marks them delivered after that transfer is confirmed on Solana."
                          : "Launching is unavailable on the current provider path because AUTH cannot forward your dev-buy tokens to your wallet."}
                      </p>
                    </div>
                  </>
                ) : (
                  <p className="mt-1 text-xs leading-5 text-muted-foreground">
                    A dev buy of at least <span className="num">{MIN_DEV_BUY_SOL}</span> SOL is
                    required. Go back and enter an amount to continue.
                  </p>
                )}
              </div>

              <div className="rounded-xl border border-border bg-surface-2 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Creator fee recipient
                </p>
                <div className="mt-2 flex items-center gap-2">
                  {xProfile?.avatarUrl ? (
                    <img
                      src={xProfile.avatarUrl}
                      alt=""
                      className="size-8 shrink-0 rounded-full border border-border object-cover"
                    />
                  ) : (
                    <span className="grid size-8 shrink-0 place-items-center rounded-full border border-border bg-surface">
                      <AtSign className="size-3.5 text-muted-foreground" />
                    </span>
                  )}
                  <ProviderIcon provider={provider} className="size-4 shrink-0" />
                  <span className="truncate text-sm font-medium">
                    {providerRow.handlePrefix}
                    {normalized || "username"}
                  </span>
                </div>
                <p className="mt-2 inline-flex items-center gap-2 text-xs text-muted-foreground">
                  <AssetIcon
                    symbol={rewardAssetMeta.symbol}
                    assetKey={rewardAssetMeta.assetKey}
                    chainKey="solana"
                    size="xs"
                    showNetwork={false}
                  />
                  Creator rewards paid in {rewardAssetMeta.symbol}
                </p>
                <p className="mt-2 text-xs leading-5 text-muted-foreground">
                  Creator fees belong to this social identity and can be claimed after ownership
                  verification. They are tracked against the platform account itself, so they stay
                  attributable even if nobody has joined AUTH yet.
                </p>
              </div>
            </div>

            <dl className="divide-y divide-border border-y border-border text-sm [&>div]:py-3">


            </dl>

            {!needsPayment ? (
              <div className="rounded-md border border-border bg-surface p-4 text-sm">
                <p className="flex items-center gap-2 font-medium">
                  <CircleAlert className="size-4" /> A dev buy is required
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  AUTH charges a <span className="num text-success">0 SOL</span> platform fee, but
                  every launch needs a dev buy of at least{" "}
                  <span className="num">{MIN_DEV_BUY_SOL}</span> SOL funded by you. Go back to the
                  token step and set your dev buy amount.
                </p>
              </div>
            ) : feeSignature ? (
              <div className="rounded-md border border-success/30 bg-success/10 p-4 text-sm">
                <p className="flex items-center gap-2 font-medium text-success">
                  <Check className="size-4" /> Dev buy received — you can launch now
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  <span className="num">{exactDevBuy}</span> SOL confirmed on Solana mainnet.{" "}
                  <a
                    href={`https://solscan.io/tx/${feeSignature}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-info hover:underline"
                  >
                    View transaction
                  </a>
                </p>
              </div>
            ) : (
              <div className="rounded-md border border-border bg-surface p-4 text-sm">
                <p className="font-medium">
                  Fund your required <span className="num">{devBuyAmount}</span> SOL dev buy
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  AUTH's platform fee is <span className="num text-success">0 SOL</span>. This
                  payment is the required dev buy (minimum{" "}
                  <span className="num">{MIN_DEV_BUY_SOL}</span> SOL), used to buy your own token in
                  the launch. The tokens it buys are yours.
                </p>
                <div className="mt-3 rounded-md border border-foreground/40 bg-background p-4">
                  <p className="text-sm font-bold uppercase tracking-[0.14em] text-foreground">
                    Send exactly this much
                  </p>
                  <div className="mt-1 flex items-center justify-between gap-3">
                    <p className="num text-4xl font-bold leading-none text-foreground sm:text-5xl">
                      {exactDevBuy} <span className="text-xl font-semibold">SOL</span>
                    </p>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="press shrink-0"
                      aria-label="Copy exact amount"
                      onClick={() => {
                        void navigator.clipboard.writeText(exactDevBuy);
                        toast.success("Exact amount copied");
                      }}
                    >
                      <Copy className="size-5" />
                    </Button>
                  </div>
                  <p className="mt-2 text-sm font-medium text-foreground/90">
                    Send the EXACT amount above — that unique amount is how we link your payment to
                    this launch. A different amount cannot be matched and your dev buy will not
                    unlock.
                  </p>
                </div>
                <div className="mt-3 space-y-2">
                  <div>
                    <Label htmlFor="fee-payer" className="text-xs text-muted-foreground">
                      Paying from (your Solana address)
                    </Label>
                    <Input
                      id="fee-payer"
                      value={feePayer}
                      onChange={(e) => setFeePayer(e.target.value)}
                      placeholder="Your Solana wallet address"
                      className="num mt-1"
                      spellCheck={false}
                    />
                  </div>
                  <CopyRow label="Send to" value={devBuyFundingAddress} />
                </div>
                {payerValid ? (
                  <p className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
                    <Loader2 className="size-3.5 animate-spin" /> Watching Solana mainnet for a{" "}
                    {exactDevBuy} SOL payment from your address…
                  </p>
                ) : (
                  <p className="mt-3 text-xs text-muted-foreground">
                    Enter your Solana address above to start watching for the payment.
                  </p>
                )}
                {feeError ? (
                  <p className="mt-2 flex items-center gap-1.5 text-xs text-destructive">
                    <CircleAlert className="size-3" /> {feeError}
                  </p>
                ) : null}
              </div>
            )}

            <Button
              type="button"
              className="press w-full sm:w-auto"
              onClick={submit}
              disabled={
                submitting ||
                !paymentReady ||
                !stepReady[0] ||
                !stepReady[1] ||
                !stepReady[2] ||
                availability.data?.ready === false
              }
            >
              {submitting ? <Loader2 className="size-4 animate-spin" /> : null}
              {submitting ? "Launching…" : "Launch on pump.fun"}
            </Button>
            {priorLaunch ? (
              <div className="rounded-xl border border-border bg-muted/40 p-4 text-sm">
                <p className="flex items-center gap-2 font-medium">
                  {checkingPrior ? <Loader2 className="size-4 animate-spin" /> : null}
                  {checkingPrior
                    ? "Checking previous launch…"
                    : priorLaunch.state === "confirmed"
                      ? "Previous launch confirmed"
                      : priorLaunch.state === "in_flight"
                        ? "Launch already in progress"
                        : "Previous launch failed — retry available"}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">{priorLaunch.message}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {priorLaunch.mint ? (
                    <Button asChild size="sm" variant="secondary" className="press">
                      <Link to="/launched/$mint" params={{ mint: priorLaunch.mint }}>
                        View token
                      </Link>
                    </Button>
                  ) : null}
                  {priorLaunch.launchSignature ? (
                    <Button asChild size="sm" variant="ghost" className="press">
                      <a
                        href={`https://solscan.io/tx/${priorLaunch.launchSignature}`}
                        target="_blank"
                        rel="noreferrer noopener"
                      >
                        View transaction
                      </a>
                    </Button>
                  ) : null}
                  {priorLaunch.state !== "confirmed" ? (
                    <Button
                      type="button"
                      size="sm"
                      className="press"
                      onClick={retryLaunch}
                      disabled={checkingPrior || submitting}
                    >
                      {checkingPrior ? <Loader2 className="size-4 animate-spin" /> : null}
                      Retry launch
                    </Button>
                  ) : null}
                </div>
              </div>
            ) : null}
            {availability.data?.ready === false ? (
              <p className="text-xs text-muted-foreground">{availability.data.message}</p>
            ) : null}

          </>
        ) : null}


        <div className="sticky bottom-0 -mx-5 flex items-center justify-between gap-3 border-t border-border bg-card/85 px-5 py-4 backdrop-blur sm:-mx-7 sm:px-7">
          <Button
            type="button"
            variant="ghost"
            className="press"
            onClick={() => setStep((s) => Math.max(0, s - 1))}
            disabled={step === 0}
          >
            Back
          </Button>
          <div className="flex items-center gap-3">
            {step < STEPS.length - 1 && !stepReady[step] ? (
              <span className="hidden text-xs text-muted-foreground sm:inline">
                {step === 0 ? "Confirm the X recipient first" : "Add a token name and ticker"}
              </span>
            ) : null}
            {step < STEPS.length - 1 ? (
              <Button
                type="button"
                size="lg"
                className="press cta"
                onClick={() => setStep((s) => s + 1)}
                disabled={!stepReady[step]}
              >
                {step === 0 ? "Continue to token" : "Continue to review"}
                <ArrowRight className="size-4" />
              </Button>
            ) : null}
          </div>
        </div>

      </div>

       <div className="mt-8 border-t border-border pt-6">
        <SectionHeading title="What happens next" />
        <ol className="space-y-4 text-sm leading-6 text-muted-foreground">
          <li>
            <span className="text-foreground">1.</span> The token appears on its own page and in{" "}
            <Link to="/explore" className="text-info hover:underline">
              Explore
            </Link>{" "}
            with its real on-chain supply and activity.
          </li>
          <li>
            <span className="text-foreground">2.</span> Fee events attributed to the handle build a
            balance that is never reassigned.
          </li>
          <li>
            <span className="text-foreground">3.</span> The recipient signs each payout in their own
            wallet; every settled payout links to its Solana transaction in the{" "}
            <Link to="/ledger" className="text-info hover:underline">
              ledger
            </Link>
            .
          </li>
        </ol>
       </div>
       </section>
       <aside className="h-fit space-y-3 xl:sticky xl:top-5">
         <section className="workspace-panel overflow-hidden">
           <p className="workspace-label border-b border-border px-4 py-2.5">Launch preview</p>
           <div className="p-4">
             <div className="flex items-center gap-3">
               <div className="grid size-14 shrink-0 place-items-center overflow-hidden rounded-xl border border-border bg-background text-xs font-semibold text-muted-foreground">
                 {image?.url ? (
                   <img src={image.url} alt="Token preview" className="size-full object-cover" />
                 ) : (
                   symbol.trim().slice(0, 3).toUpperCase() || <ImageIcon className="size-5" />
                 )}
               </div>
               <div className="min-w-0">
                 <p className="truncate text-base font-semibold">
                   {name.trim() || "Untitled token"}
                 </p>
                 <p className="num text-xs text-muted-foreground">
                   ${symbol.trim().toUpperCase() || "SYMBOL"}
                 </p>
               </div>
             </div>

             <div className="mt-4 flex items-center gap-2 rounded-lg border border-border bg-background p-2.5">
               {xProfile?.avatarUrl ? (
                 <img
                   src={xProfile.avatarUrl}
                   alt=""
                   className="size-8 shrink-0 rounded-full border border-border object-cover"
                 />
               ) : (
                 <span className="grid size-8 shrink-0 place-items-center rounded-full border border-border bg-surface-2">
                   <AtSign className="size-3.5 text-muted-foreground" />
                 </span>
               )}
               <div className="min-w-0">
                 <p className="truncate text-sm font-medium">
                   {xProfile?.name ?? (normalized ? `@${normalized}` : "No recipient yet")}
                 </p>
                 <p className="truncate text-xs text-muted-foreground">
                   {normalized ? `@${normalized} · creator-fee recipient` : `Add a ${providerRow.handleLabel}`}
                 </p>
               </div>
             </div>

             <dl className="mt-4 space-y-2 text-xs">
               <Line
                 label="AUTH launch fee"
                 value={<span className="num font-medium text-success">0 SOL</span>}
               />
               <Line label="Dev buy (required)" value={<span className="num">{devBuyAmount || 0} SOL</span>} />
               <Line
                 label="You authorize"
                 value={<span className="num">{devBuyAmount || 0} SOL</span>}
               />
               <Line
                 label="Creator rewards"
                 value={
                   <span className="inline-flex items-center gap-2">
                     <AssetIcon
                       symbol={rewardAssetMeta.symbol}
                       assetKey={rewardAssetMeta.assetKey}
                       chainKey="solana"
                       size="xs"
                       showNetwork={false}
                     />
                     <span className="font-medium">{rewardAssetMeta.symbol}</span>
                   </span>
                 }
               />

             </dl>
           </div>
         </section>

         <section className="workspace-panel overflow-hidden">
           <p className="workspace-label border-b border-border px-4 py-2.5">Launch readiness</p>
           <ul className="space-y-2.5 p-4">
             {checks.map((c) => (
               <li key={c.label} className="flex items-start gap-2.5 text-xs">
                 <span
                   className={cn(
                     "mt-px grid size-4 shrink-0 place-items-center rounded-full border transition-colors",
                      c.done
                        ? "border-success bg-success text-success-foreground"
                        : "border-border text-transparent",
                   )}
                 >
                   <Check className="size-2.5" />
                 </span>
                 <span className={c.done ? "font-medium text-foreground" : "text-muted-foreground"}>
                   {c.label}
                 </span>
               </li>
             ))}
           </ul>
           <p className="border-t border-border px-4 py-3 text-xs leading-5 text-muted-foreground">
             The mint is generated by the real pump.fun launch and verified on Solana before AUTH
             indexes it.
           </p>
         </section>
       </aside>

      </div>
    </PageShell>
  );
}

function Line({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="text-right font-medium">{value}</dd>
    </div>
  );
}

function CopyRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-lg border border-border bg-background px-3 py-2">
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="num truncate text-sm font-medium">{value}</p>
      </div>
      <Button
        type="button"
        variant="ghost"
        size="icon"
        className="press shrink-0"
        aria-label={`Copy ${label}`}
        onClick={() => {
          void navigator.clipboard.writeText(value);
          toast.success(`${label} copied`);
        }}
      >
        <Copy className="size-4" />
      </Button>
    </div>
  );
}

function Stepper({ step }: { step: number }) {
  return (
    <ol className="relative mt-7 grid list-none grid-cols-3 p-0">
      <span className="step-line left-[16.6%] right-[16.6%]" aria-hidden />
      <span
        className="step-line left-[16.6%] bg-success transition-all duration-300"
        style={{ right: `${16.6 + (100 - 33.2) * (1 - Math.min(step, 2) / 2)}%` }}
        aria-hidden
      />
      {STEPS.map((s, i) => (
        <li key={s} className="relative z-10 flex flex-col items-center gap-2 text-center">
          <span
            className={cn(
              "grid size-[34px] place-items-center rounded-full border-2 bg-card text-xs font-semibold transition-colors",
              i < step
                ? "border-success bg-success text-success-foreground"
                : i === step
                  ? "border-primary text-primary"
                  : "border-border text-muted-foreground",
            )}
          >
            {i < step ? <Check className="size-4" /> : <span className="num">{i + 1}</span>}
          </span>
          <span
            className={cn(
              "text-xs font-semibold transition-colors",
              i <= step ? "text-foreground" : "text-muted-foreground",
            )}
          >
            {s}
          </span>
        </li>
      ))}
    </ol>
  );
}

function FormBlock({
  icon,
  title,
  description,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="form-block overflow-hidden">
      <header className="flex items-start gap-3 border-b border-border bg-surface-2/60 px-4 py-3">
        <span className="mt-0.5 grid size-7 shrink-0 place-items-center rounded-md border border-border bg-card text-muted-foreground">
          {icon}
        </span>
        <div className="min-w-0">
          <h3 className="text-sm font-semibold leading-5">{title}</h3>
          {description ? (
            <p className="mt-0.5 text-xs leading-5 text-muted-foreground">{description}</p>
          ) : null}
        </div>
      </header>
      <div className="p-4 sm:p-5">{children}</div>
    </section>
  );
}
