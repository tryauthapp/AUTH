import { createFileRoute, Link, Outlet, useRouterState } from "@tanstack/react-router";

export const Route = createFileRoute("/docs")({
  component: DocsLayout,
});

function DocsLayout() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <div className="page-enter mx-auto grid w-full max-w-5xl gap-4 px-4 py-5 sm:px-6 sm:py-7 lg:grid-cols-[180px_minmax(0,760px)] lg:px-8">
      <nav className="workspace-panel flex h-fit gap-1 p-2 lg:sticky lg:top-5 lg:flex-col">
        {[
          { to: "/docs", label: "How it works" },
          { to: "/docs/integrations", label: "Integrations" },
        ].map((item) => (
          <Link
            key={item.to}
            to={item.to}
            className={`rounded-sm px-3 py-2 text-xs font-medium ${
              pathname === item.to ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/50"
            }`}
          >
            {item.label}
          </Link>
        ))}
      </nav>
      <div className="min-w-0">
        <Outlet />
      </div>
    </div>
  );
}
