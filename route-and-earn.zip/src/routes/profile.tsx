import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { CalendarDays, Rocket, Send, User } from "lucide-react";
import { useSession } from "@/hooks/useSession";
import { myPaymentsQuery, recipientsQuery } from "@/lib/queries";
import { EmptyState, LoadingRows, PageHeader, PageShell, StatusPill } from "@/components/primitives";
import { AccountPanel } from "@/components/AccountPanel";
import { ConnectedIdentities } from "@/components/social/ConnectedIdentities";
import { useWallet } from "@/lib/wallet/WalletProvider";
import { Button } from "@/components/ui/button";
import { timeAgo } from "@/lib/format";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ThemeSetting } from "@/components/ThemeSetting";


export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Your identity — AUTH" },
      {
        name: "description",
        content:
          "Your claimed X usernames, your walletless payment account, payments you have sent and your creator-fee routing.",
      },
      { property: "og:title", content: "Your identity — AUTH" },
      {
        property: "og:description",
        content: "Claimed usernames, payment account and payment history.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Profile,
});

function Profile() {
  const { session, loading, isAdmin } = useSession();
  const { address } = useWallet();
  const recipients = useQuery(recipientsQuery());
  const payments = useQuery(myPaymentsQuery(session?.user.id, 100));

  if (loading || recipients.isPending) {
    return (
      <PageShell width="narrow">
        <LoadingRows rows={6} />
      </PageShell>
    );
  }

  const mine = session
    ? (recipients.data ?? []).filter((r) => r.claimed_by === session.user.id)
    : [];
  const sent = session ? (payments.data ?? []) : [];

  return (
    <PageShell>
      <PageHeader eyebrow="Social identity" title="Profile" />
      <section className="workspace-panel overflow-hidden">
        <div className="h-28 border-b border-border bg-surface-2 sm:h-36" />
        <div className="px-4 pb-5 sm:px-6">
          <div className="flex items-start justify-between gap-3">
            <div className="-mt-10 grid size-20 shrink-0 place-items-center rounded-full border-4 border-surface bg-background text-foreground sm:size-24"><User className="size-9" /></div>
            <div className="mt-3 flex gap-2">
               {session ? <Button asChild variant="outline" size="sm" className="press rounded-md px-3 sm:px-4"><Link to="/dashboard">Edit profile</Link></Button> : <Button asChild size="sm" className="press rounded-md px-3 sm:px-4"><Link to="/claim">Claim username</Link></Button>}
               {isAdmin ? <Button asChild variant="outline" size="sm" className="press rounded-md"><Link to="/admin">Admin</Link></Button> : null}
            </div>
          </div>
          <h2 className="mt-4 text-xl font-bold sm:text-2xl">{mine[0]?.display_name ?? "Your AUTH profile"}</h2>
          <p className="text-[15px] text-muted-foreground">{mine[0] ? `@${mine[0].handle}` : "Claim an @username to complete your profile"}</p>
          <p className="mt-4 max-w-xl text-[15px] leading-6">Payments, launches, and creator earnings tied to your social identity.</p>
          <p className="mt-3 inline-flex items-center gap-2 text-sm text-muted-foreground"><CalendarDays className="size-4" /> Your activity appears here after it is confirmed.</p>
        </div>
      </section>
      <Tabs defaultValue="activity" className="workspace-panel mt-4 overflow-hidden">
        <TabsList className="grid h-11 w-full grid-cols-3 border-b border-border p-0"><TabsTrigger value="activity">Activity</TabsTrigger><TabsTrigger value="identities">Identities</TabsTrigger><TabsTrigger value="account">Account</TabsTrigger></TabsList>
        <TabsContent value="activity" className="m-0">
          {sent.length === 0 ? <div className="p-5"><EmptyState title="No activity yet" description="Confirmed payments you send appear on your profile with their receipt." icon={<Send className="size-5" />} action={<Button asChild size="sm" className="h-9 px-4"><Link to="/pay">Make a payment</Link></Button>} /></div> : <ul className="divide-y divide-border">
            {sent.map((p) => (
              <li key={p.id} className="row-hover flex flex-wrap items-center gap-2 px-5 py-4 text-sm">
                <Link to="/u/$handle" params={{ handle: p.recipient_handle }} className="font-medium hover:underline">
                  @{p.recipient_handle}
                </Link>
                <span className="num">
                  {Number(p.amount)} {p.asset}
                </span>
                <span className="text-xs text-muted-foreground">{p.status.replace(/_/g, " ")}</span>
                <span className="ml-auto text-xs text-muted-foreground">{timeAgo(p.created_at)}</span>
              </li>
            ))}
          </ul>}
        </TabsContent>
        <TabsContent value="identities" className="m-0">{mine.length === 0 ? <div className="p-5"><EmptyState title="No claimed username yet" description="Claim your X handle to receive payments and route creator fees." icon={<Rocket className="size-5" />} action={<Button asChild size="sm" className="h-9 px-4"><Link to="/claim">Claim your username</Link></Button>} /></div> : <ul className="divide-y divide-border">{mine.map((r) => <li key={r.id} className="flex items-center gap-3 px-5 py-4"><Link to="/u/$handle" params={{ handle: r.handle }} className="font-bold hover:underline">@{r.handle}</Link><StatusPill status={r.verification === "verified" ? "verified" : "pending"}>{r.verification}</StatusPill><Link to="/dashboard" className="ml-auto text-sm font-semibold hover:underline">Manage</Link></li>)}</ul>}</TabsContent>
        <TabsContent value="account" className="m-0 space-y-4 p-5"><ConnectedIdentities /><AccountPanel /></TabsContent>
      </Tabs>
      <ThemeSetting className="mt-4" />

    </PageShell>
  );
}
