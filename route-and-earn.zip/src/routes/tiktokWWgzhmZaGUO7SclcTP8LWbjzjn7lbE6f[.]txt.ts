import { createFileRoute } from "@tanstack/react-router";

/**
 * TikTok domain-ownership verification file.
 *
 * TikTok's file-based URL property check fetches tiktok<code>.txt from the
 * site root and expects the verification string as plain text.
 */
export const Route = createFileRoute(
  "/tiktokWWgzhmZaGUO7SclcTP8LWbjzjn7lbE6f.txt",
)({
  server: {
    handlers: {
      GET: async () =>
        new Response(
          "tiktok-developers-site-verification=WWgzhmZaGUO7SclcTP8LWbjzjn7lbE6f",
          { headers: { "content-type": "text/plain; charset=utf-8" } },
        ),
    },
  },
});
