/**
 * Launch attempt reconciliation (SERVER ONLY).
 *
 * A launch attempt must never be able to permanently brick the Launch page.
 * This module is the single place that answers "what really happened to this
 * attempt?" using Solana as the source of truth — never an optimistic guess.
 *
 *   confirmed  -> a mint was verified on mainnet; show it, never relaunch
 *   in_flight  -> a submit is genuinely still running (recent, no outcome yet)
 *   failed     -> proven failed, or no trace on-chain after the stale window
 *   funded     -> paid but never submitted; the same attempt can resume
 *   none       -> nothing recorded; a normal first launch
 */

/** How long a `submitted` attempt may stay unresolved before it is retryable. */
const STALE_SUBMITTED_MS = 3 * 60 * 1000;

export type LaunchReconcileState =
  | "none"
  | "confirmed"
  | "in_flight"
  | "failed"
  | "funded";

export interface LaunchReconcileResult {
  state: LaunchReconcileState;
  /** Safe to start a fresh attempt (with a new launch key). */
  retryable: boolean;
  mint: string | null;
  launchSignature: string | null;
  /** User-facing, non-technical explanation of the current state. */
  message: string;
  /** True when this call changed the stored status. */
  reconciled: boolean;
}

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

/**
 * Inspects one attempt, verifies any stored signature on-chain, and transitions
 * `submitted` to `confirmed` or `failed`. Never fabricates a mint: a mint is
 * only reported when Solana confirms the mint account exists.
 */
export async function reconcileLaunchAttempt(
  userId: string,
  launchKey: string,
): Promise<LaunchReconcileResult> {
  const db = await admin();
  const { data: row } = await db
    .from("launch_attempts")
    .select("id,status,mint,launch_signature,submitted_at,created_at,failure_reason")
    .eq("user_id", userId)
    .eq("launch_key", launchKey)
    .maybeSingle();

  if (!row) {
    return {
      state: "none",
      retryable: true,
      mint: null,
      launchSignature: null,
      message: "No previous launch found for this attempt.",
      reconciled: false,
    };
  }

  const { launchAuditRecorder } = await import("@/lib/launch-audit.server");
  const audit = launchAuditRecorder(userId, launchKey, "launch");

  if (row.status === "confirmed" && row.mint) {
    return {
      state: "confirmed",
      retryable: false,
      mint: row.mint,
      launchSignature: row.launch_signature,
      message: "Previous launch confirmed.",
      reconciled: false,
    };
  }

  if (row.status === "failed") {
    return {
      state: "failed",
      retryable: true,
      mint: null,
      launchSignature: row.launch_signature,
      message: row.failure_reason
        ? `Previous launch failed — retry available. ${row.failure_reason}`
        : "Previous launch failed — retry available.",
      reconciled: false,
    };
  }

  if (row.status === "draft" || row.status === "funded") {
    return {
      state: "funded",
      retryable: true,
      mint: null,
      launchSignature: null,
      message:
        row.status === "funded"
          ? "Your funding is still reserved for this attempt — you can continue without paying again."
          : "Nothing was submitted yet — you can launch.",
      reconciled: false,
    };
  }

  // status === "submitted": resolve it against the chain.
  const startedAt = Date.parse(row.submitted_at ?? row.created_at);
  const age = Number.isFinite(startedAt) ? Date.now() - startedAt : STALE_SUBMITTED_MS + 1;
  const signature = row.launch_signature;

  if (signature) {
    const { getSignatureStatus, getTransactionSummary, getMintInfo } = await import(
      "@/integrations/adapters/helius.server"
    );
    const status = await getSignatureStatus(signature);
    const found = status.ok && status.data !== null;
    const failedOnChain = found && Boolean(status.data?.err);

    if (found && !failedOnChain) {
      // Succeeded on-chain. Only claim a mint when the mint truly exists.
      if (row.mint) {
        const mintInfo = await getMintInfo(row.mint);
        if (mintInfo.ok && mintInfo.data) {
          await db
            .from("launch_attempts")
            .update({
              status: "confirmed",
              confirmed_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            })
            .eq("id", row.id);
          await audit("confirmation", "pass", "Reconciled: launch confirmed on mainnet.", {
            signature,
            mint: row.mint,
          });
          return {
            state: "confirmed",
            retryable: false,
            mint: row.mint,
            launchSignature: signature,
            message: "Previous launch confirmed.",
            reconciled: true,
          };
        }
      }
      // A successful transaction with no verifiable mint stays unresolved until
      // the stale window passes — it is never reported as a launched token.
      if (age < STALE_SUBMITTED_MS) {
        return {
          state: "in_flight",
          retryable: false,
          mint: null,
          launchSignature: signature,
          message: "Checking previous launch…",
          reconciled: false,
        };
      }
      const summary = await getTransactionSummary(signature);
      await markFailed(
        userId,
        launchKey,
        summary.ok && summary.data?.succeeded
          ? "The launch transaction confirmed but no token mint could be verified."
          : "The previous launch could not be verified on-chain.",
        signature,
      );
      await audit("failure", "warn", "Reconciled: no verifiable mint; attempt marked failed.", {
        signature,
      });
      return {
        state: "failed",
        retryable: true,
        mint: null,
        launchSignature: signature,
        message: "Previous launch could not be verified on-chain — retry available.",
        reconciled: true,
      };
    }

    if (failedOnChain) {
      await markFailed(userId, launchKey, "The launch transaction failed on Solana.", signature);
      await audit("failure", "fail", "Reconciled: transaction failed on-chain.", { signature });
      return {
        state: "failed",
        retryable: true,
        mint: null,
        launchSignature: signature,
        message: "Previous launch failed on Solana — retry available.",
        reconciled: true,
      };
    }

    // Not found yet.
    if (age < STALE_SUBMITTED_MS) {
      return {
        state: "in_flight",
        retryable: false,
        mint: null,
        launchSignature: signature,
        message: "Checking previous launch…",
        reconciled: false,
      };
    }
    await markFailed(
      userId,
      launchKey,
      "The launch transaction was never found on Solana.",
      signature,
    );
    await audit("failure", "warn", "Reconciled: signature not found on-chain.", { signature });
    return {
      state: "failed",
      retryable: true,
      mint: null,
      launchSignature: signature,
      message: "Previous launch could not be found on-chain — retry available.",
      reconciled: true,
    };
  }

  // Submitted with no signature at all.
  if (age < STALE_SUBMITTED_MS) {
    return {
      state: "in_flight",
      retryable: false,
      mint: null,
      launchSignature: null,
      message: "Launch already in progress.",
      reconciled: false,
    };
  }
  await markFailed(userId, launchKey, "The launch never reached Solana.", null);
  await audit("failure", "warn", "Reconciled: stale submit with no signature.", {});
  return {
    state: "failed",
    retryable: true,
    mint: null,
    launchSignature: null,
    message: "Previous launch never reached Solana — retry available.",
    reconciled: true,
  };
}

async function markFailed(
  userId: string,
  launchKey: string,
  reason: string,
  launchSignature: string | null,
) {
  const { recordFailed } = await import("@/lib/launch-attempts.server");
  await recordFailed({ userId, launchKey, reason, launchSignature });
}
