/**
 * SERVER ONLY. Short-lived response cache with request coalescing.
 *
 * Under load the same public data is asked for by hundreds of visitors within
 * the same second. Without this, each visitor becomes one database round trip
 * or one external API call; with it, the first visitor pays the cost and the
 * rest are served from memory until the entry expires.
 *
 * Workers are stateless and horizontally scaled, so this is a per-instance
 * cache: it reduces load by a large factor, it does not guarantee a single
 * upstream call globally. Never cache per-user or authenticated data here.
 */

type Entry<T> = { value: T; expiresAt: number };

const store = new Map<string, Entry<unknown>>();
const inflight = new Map<string, Promise<unknown>>();

/** Hard ceiling so a hostile key space cannot grow memory without bound. */
const MAX_ENTRIES = 2000;

function sweep() {
  const now = Date.now();
  for (const [key, entry] of store) {
    if (entry.expiresAt <= now) store.delete(key);
  }
  if (store.size > MAX_ENTRIES) {
    // Drop oldest insertions first; Map preserves insertion order.
    const excess = store.size - MAX_ENTRIES;
    let i = 0;
    for (const key of store.keys()) {
      if (i++ >= excess) break;
      store.delete(key);
    }
  }
}

/**
 * Returns the cached value for `key`, or computes it. Concurrent callers for
 * the same key share one computation instead of stampeding the upstream.
 */
export async function cached<T>(key: string, ttlMs: number, load: () => Promise<T>): Promise<T> {
  const now = Date.now();
  const hit = store.get(key);
  if (hit && hit.expiresAt > now) return hit.value as T;

  const running = inflight.get(key);
  if (running) return running as Promise<T>;

  const promise = (async () => {
    try {
      const value = await load();
      store.set(key, { value, expiresAt: Date.now() + ttlMs });
      if (store.size > MAX_ENTRIES) sweep();
      return value;
    } finally {
      inflight.delete(key);
    }
  })();

  inflight.set(key, promise);
  return promise;
}

/** Invalidate one key (after a write that makes it wrong). */
export function invalidate(key: string) {
  store.delete(key);
}

/** Invalidate every key starting with `prefix`. */
export function invalidatePrefix(prefix: string) {
  for (const key of store.keys()) {
    if (key.startsWith(prefix)) store.delete(key);
  }
}
