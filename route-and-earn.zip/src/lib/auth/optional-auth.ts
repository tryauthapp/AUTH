import { createMiddleware } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

/**
 * Accountless-first auth.
 *
 * AUTH does not require a platform account to browse, search handles, or
 * construct and authorize a payment — the sender's own wallet signature is the
 * authorization. This middleware therefore *reads* a Supabase session when the
 * browser happens to have one (so receipts attach to that account) and simply
 * continues without one otherwise.
 *
 * Handlers that use it MUST treat `userId === null` as untrusted and derive
 * every authorization decision from on-chain facts or from data the caller
 * proves ownership of.
 */

function isNewSupabaseApiKey(value: string): boolean {
  return value.startsWith("sb_publishable_") || value.startsWith("sb_secret_");
}

function createSupabaseFetch(supabaseKey: string): typeof fetch {
  return (input, init) => {
    const headers = new Headers(
      typeof Request !== "undefined" && input instanceof Request ? input.headers : undefined,
    );
    if (init?.headers) {
      new Headers(init.headers).forEach((value, key) => headers.set(key, value));
    }
    if (isNewSupabaseApiKey(supabaseKey) && headers.get("Authorization") === `Bearer ${supabaseKey}`) {
      headers.delete("Authorization");
    }
    headers.set("apikey", supabaseKey);
    return fetch(input, { ...init, headers });
  };
}

export const optionalSupabaseAuth = createMiddleware({ type: "function" }).server(
  async ({ next }) => {
    const SUPABASE_URL = process.env["SUPABASE_URL"];
    const SUPABASE_PUBLISHABLE_KEY = process.env["SUPABASE_PUBLISHABLE_KEY"];
    const anonymous = { userId: null as string | null };

    if (!SUPABASE_URL || !SUPABASE_PUBLISHABLE_KEY) return next({ context: anonymous });

    const request = getRequest();
    const authHeader = request?.headers?.get("authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) return next({ context: anonymous });

    const token = authHeader.slice("Bearer ".length);
    if (token.split(".").length !== 3) return next({ context: anonymous });

    try {
      const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
        global: {
          fetch: createSupabaseFetch(SUPABASE_PUBLISHABLE_KEY),
          headers: { Authorization: `Bearer ${token}` },
        },
        auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
      });
      const { data, error } = await supabase.auth.getClaims(token);
      if (error || !data?.claims?.sub) return next({ context: anonymous });
      return next({ context: { userId: data.claims.sub as string | null } });
    } catch {
      return next({ context: anonymous });
    }
  },
);
