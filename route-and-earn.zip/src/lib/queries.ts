import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  getPublicRouting,
  listPublicFeeEvents,
  listPublicPayments,
  listPublicPayouts,
} from "@/lib/public-data.functions";

/** Public product history starts with the AUTH reset. */
export const AUTH_ERA_START = "2026-09-21T12:50:00.000Z";
const AUTH_PUBLIC_DATA_VERSION = "auth-era-2";

export type FeeEventRow = {
  id: string;
  tx_signature: string;
  gross_usd: number;
  protocol_fee_usd: number;
  net_usd: number;
  sol_amount: number | null;
  occurred_at: string;
  source: string;
  is_demo: boolean;
  token: { id: string; mint: string; symbol: string; name: string; source: string } | null;
  recipient: {
    id: string;
    handle: string;
    display_name: string | null;
    avatar_url?: string | null;
    provider?: string | null;
  } | null;
};

export type PayoutRow = {
  id: string;
  fee_event_id: string;
  recipient_id: string;
  destination: string;
  label: string | null;
  adapter: string;
  amount_usd: number;
  status: string;
  failure_reason: string | null;
  created_at: string;
  settled_at: string | null;
  tx_signature: string | null;
  network: string | null;
  signer_address: string | null;
  asset: string | null;
  asset_amount: number | null;
  confirmed_at: string | null;
  is_demo: boolean;
};

function unwrap<T>(res: { data: T | null; error: { message: string } | null }): T {
  if (res.error) throw new Error(res.error.message);
  return (res.data ?? []) as T;
}

const FEE_SELECT =
  "id,tx_signature,gross_usd,protocol_fee_usd,net_usd,sol_amount,occurred_at,source,is_demo," +
  "token:tokens(id,mint,symbol,name,source),recipient:recipients(id,handle,display_name,avatar_url,provider)";

export const feeEventsQuery = (limit = 500) =>
  queryOptions({
    queryKey: ["fee_events", AUTH_PUBLIC_DATA_VERSION, limit],
    queryFn: async () => (await listPublicFeeEvents({ data: { limit } })) as unknown as FeeEventRow[],
  });

export const payoutsQuery = () =>
  queryOptions({
    queryKey: ["payouts", AUTH_PUBLIC_DATA_VERSION],
    queryFn: async () => (await listPublicPayouts()) as unknown as PayoutRow[],
  });

export type RecipientRow = {
  id: string;
  handle: string;
  display_name: string | null;
  bio: string | null;
  avatar_url: string | null;
  verification: string;
  claimed_by: string | null;
  is_demo: boolean;
  provider?: string | null;
  follower_count?: number | null;
};

export const recipientsQuery = () =>
  queryOptions({
    queryKey: ["recipients", AUTH_PUBLIC_DATA_VERSION],
    queryFn: async () =>
      unwrap<RecipientRow[]>(
        (await supabase
          .from("recipients")
          .select("id,handle,display_name,bio,avatar_url,verification,claimed_by,is_demo,provider,follower_count")
          .eq("is_demo", false)
          .gte("created_at", AUTH_ERA_START)
          .order("handle")) as never,
      ),
  });

export const recipientQuery = (handle: string) =>
  queryOptions({
    queryKey: ["recipient", AUTH_PUBLIC_DATA_VERSION, handle],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("recipients")
        .select("id,handle,display_name,bio,avatar_url,verification,claimed_by,is_demo,provider,follower_count")
        .eq("is_demo", false)
        .gte("created_at", AUTH_ERA_START)
        .eq("handle", handle)
        .maybeSingle();
      if (error) throw new Error(error.message);
      return data as RecipientRow | null;
    },
  });

export type TokenRow = {
  id: string;
  mint: string;
  symbol: string;
  name: string;
  image_url: string | null;
  source: string;
  is_demo: boolean;
  description?: string | null;
  website_url?: string | null;
  x_url?: string | null;
  telegram_url?: string | null;
  community_url?: string | null;
};


export const tokensQuery = () =>
  queryOptions({
    queryKey: ["tokens", AUTH_PUBLIC_DATA_VERSION],
    queryFn: async () =>
      unwrap<TokenRow[]>(
        (await supabase
          .from("tokens")
          .select("id,mint,symbol,name,image_url,source,is_demo")
          .eq("is_demo", false)
          .gte("created_at", AUTH_ERA_START)
          .order("symbol")) as never,
      ),
  });

export const launchedTokensQuery = () =>
  queryOptions({
    queryKey: ["tokens", "launched", AUTH_PUBLIC_DATA_VERSION],
    queryFn: async () =>
      unwrap<
        (TokenRow & { created_at: string; launch_signature: string | null })[]
      >(
        (await supabase
          .from("tokens")
          .select(
            "id,mint,symbol,name,image_url,source,is_demo,description,website_url,x_url,telegram_url,community_url,created_at,launch_signature",
          )
          .eq("is_demo", false)
          .gte("created_at", AUTH_ERA_START)
          .order("created_at", { ascending: false })) as never,
      ),
  });

export const tokenQuery = (mint: string) =>
  queryOptions({
    queryKey: ["token", AUTH_PUBLIC_DATA_VERSION, mint],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("tokens")
        .select(
          "id,mint,symbol,name,image_url,source,is_demo,description,website_url,x_url,telegram_url,community_url",
        )
        .eq("is_demo", false)
        .gte("created_at", AUTH_ERA_START)
        .eq("mint", mint)
        .maybeSingle();
      if (error) throw new Error(error.message);
      return data as TokenRow | null;
    },
  });

export type RoutingSplitRow = {
  id: string;
  config_id: string;
  destination: string;
  label: string;
  percent: number;
  address: string | null;
  charity_id: string | null;
  sort_order: number;
};

export type RoutingConfigRow = {
  id: string;
  recipient_id: string;
  name: string;
  is_active: boolean;
  updated_at: string;
  splits: RoutingSplitRow[];
};

export const routingQuery = (recipientId: string | undefined) =>
  queryOptions({
    queryKey: ["routing", recipientId],
    enabled: Boolean(recipientId),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("routing_configs")
        .select(
          "id,recipient_id,name,is_active,updated_at,splits:routing_splits(id,config_id,destination,label,percent,address,charity_id,sort_order)",
        )
        .eq("recipient_id", recipientId!)
        .eq("is_active", true)
        .maybeSingle();
      if (error) throw new Error(error.message);
      return data as unknown as RoutingConfigRow | null;
    },
  });

/** Public routing view: percentages and labels only, never wallet addresses. */
export const publicRoutingQuery = (recipientId: string | undefined) =>
  queryOptions({
    queryKey: ["routing", "public", recipientId],
    enabled: Boolean(recipientId),
    queryFn: async () =>
      (await getPublicRouting({ data: { recipientId: recipientId! } })) as unknown as RoutingConfigRow | null,
  });

export const charitiesQuery = () =>
  queryOptions({
    queryKey: ["charities"],
    queryFn: async () =>
      unwrap<{ id: string; slug: string; name: string; description: string | null; wallet_address: string | null }[]>(
        (await supabase
          .from("charities")
          .select("id,slug,name,description,wallet_address")
          .eq("is_demo", false)
          .order("name")) as never,
      ),
  });

export const integrationsQuery = () =>
  queryOptions({
    queryKey: ["integrations"],
    queryFn: async () =>
      unwrap<
        { key: string; name: string; category: string; status: string; description: string | null }[]
      >(
        (await supabase
          .from("integrations")
          .select("key,name,category,status,description")
          .order("category")) as never,
      ),
  });

export const settingsQuery = () =>
  queryOptions({
    queryKey: ["protocol_settings"],
    queryFn: async () =>
      unwrap<{ key: string; value: unknown; description: string | null; updated_at: string }[]>(
        (await supabase
          .from("protocol_settings")
          .select("key,value,description,updated_at")
          .order("key")) as never,
      ),
  });

export const claimsQuery = (recipientId?: string) =>
  queryOptions({
    queryKey: ["claims", recipientId ?? "all"],
    queryFn: async () => {
      let q = supabase
        .from("claims")
        .select("id,payout_id,recipient_id,wallet_address,amount_usd,status,created_at,resolved_at")
        .order("created_at", { ascending: false });
      if (recipientId) q = q.eq("recipient_id", recipientId);
      const { data, error } = await q;
      if (error) throw new Error(error.message);
      return (data ?? []) as {
        id: string;
        payout_id: string;
        recipient_id: string;
        wallet_address: string | null;
        amount_usd: number;
        status: string;
        created_at: string;
        resolved_at: string | null;
      }[];
    },
  });

export const tokenRecipientsQuery = () =>
  queryOptions({
    queryKey: ["token_recipients"],
    queryFn: async () =>
      unwrap<{ token_id: string; recipient_id: string; share_percent: number }[]>(
        (await supabase
          .from("token_recipients")
          .select("token_id,recipient_id,share_percent")) as never,
      ),
  });

/* ---------- derived analytics (computed in memory over the ledger) ---------- */

const DAY = 24 * 60 * 60 * 1000;

export function recipientStats(events: FeeEventRow[], payouts: PayoutRow[], recipientId: string) {
  const mine = events.filter((e) => e.recipient?.id === recipientId);
  const now = Date.now();
  const byToken = new Map<string, { symbol: string; mint: string; total: number }>();
  for (const e of mine) {
    if (!e.token) continue;
    const entry = byToken.get(e.token.id) ?? { symbol: e.token.symbol, mint: e.token.mint, total: 0 };
    entry.total += Number(e.net_usd);
    byToken.set(e.token.id, entry);
  }
  const top = [...byToken.values()].sort((a, b) => b.total - a.total)[0] ?? null;
  const mypayouts = payouts.filter((p) => p.recipient_id === recipientId);
  const sum = (rows: PayoutRow[]) => rows.reduce((a, b) => a + Number(b.amount_usd), 0);
  return {
    lifetime: mine.reduce((a, b) => a + Number(b.net_usd), 0),
    gross: mine.reduce((a, b) => a + Number(b.gross_usd), 0),
    protocolFees: mine.reduce((a, b) => a + Number(b.protocol_fee_usd), 0),
    last24h: mine
      .filter((e) => now - new Date(e.occurred_at).getTime() < DAY)
      .reduce((a, b) => a + Number(b.net_usd), 0),
    coinCount: byToken.size,
    topToken: top,
    eventCount: mine.length,
    paid: sum(mypayouts.filter((p) => p.status === "paid")),
    pending: sum(mypayouts.filter((p) => p.status === "pending" || p.status === "processing")),
    claimable: sum(mypayouts.filter((p) => p.status === "claimable")),
    buybacks: sum(mypayouts.filter((p) => p.destination === "buyback" || p.destination === "burn")),
    charity: sum(mypayouts.filter((p) => p.destination === "charity")),
  };
}

export function tokenStats(events: FeeEventRow[], tokenId: string) {
  const mine = events.filter((e) => e.token?.id === tokenId);
  const now = Date.now();
  return {
    total: mine.reduce((a, b) => a + Number(b.gross_usd), 0),
    net: mine.reduce((a, b) => a + Number(b.net_usd), 0),
    protocolFees: mine.reduce((a, b) => a + Number(b.protocol_fee_usd), 0),
    last24h: mine
      .filter((e) => now - new Date(e.occurred_at).getTime() < DAY)
      .reduce((a, b) => a + Number(b.gross_usd), 0),
    eventCount: mine.length,
    events: mine,
  };
}

export function leaderboard(events: FeeEventRow[], windowHours?: number) {
  const cutoff = windowHours ? Date.now() - windowHours * 60 * 60 * 1000 : 0;
  const map = new Map<string, { handle: string; name: string | null; total: number; coins: Set<string> }>();
  for (const e of events) {
    if (!e.recipient) continue;
    if (cutoff && new Date(e.occurred_at).getTime() < cutoff) continue;
    const entry = map.get(e.recipient.id) ?? {
      handle: e.recipient.handle,
      name: e.recipient.display_name,
      total: 0,
      coins: new Set<string>(),
    };
    entry.total += Number(e.net_usd);
    if (e.token) entry.coins.add(e.token.id);
    map.set(e.recipient.id, entry);
  }
  return [...map.entries()]
    .map(([id, v]) => ({ id, handle: v.handle, name: v.name, total: v.total, coins: v.coins.size }))
    .sort((a, b) => b.total - a.total);
}

export function tokenBoard(events: FeeEventRow[], windowHours?: number) {
  const cutoff = windowHours ? Date.now() - windowHours * 60 * 60 * 1000 : 0;
  const map = new Map<string, { mint: string; symbol: string; name: string; total: number }>();
  for (const e of events) {
    if (!e.token) continue;
    if (cutoff && new Date(e.occurred_at).getTime() < cutoff) continue;
    const entry = map.get(e.token.id) ?? {
      mint: e.token.mint,
      symbol: e.token.symbol,
      name: e.token.name,
      total: 0,
    };
    entry.total += Number(e.gross_usd);
    map.set(e.token.id, entry);
  }
  return [...map.values()].sort((a, b) => b.total - a.total);
}

/**
 * Public activity shape. Wallet addresses and sender identity are deliberately
 * absent: the shared feed reads a view that never exposes them.
 */
export type PaymentRow = {
  id: string;
  recipient_id: string;
  recipient_handle: string;
  /** Canonical platform of the recipient identity; older rows default to X. */
  recipient_provider?: string | null;
  asset: string;
  amount: number;
  amount_usd: number | null;
  note: string | null;
  status: string;
  network: string;
  tx_signature: string | null;
  is_demo: boolean;
  created_at: string;
  settled_at: string | null;
};

/** Sender-scoped rows; readable only by the signed-in sender under RLS. */
export type MyPaymentRow = PaymentRow & {
  sender_id: string | null;
  sender_wallet: string | null;
  destination_wallet: string | null;
  failure_reason: string | null;
};

const MY_PAYMENT_SELECT =
  "id,recipient_id,recipient_handle,recipient_provider,asset,amount,amount_usd,note,status,network," +
  "tx_signature,is_demo,created_at,settled_at,sender_id,sender_wallet,destination_wallet,failure_reason";

export const paymentsQuery = (limit = 200) =>
  queryOptions({
    queryKey: ["payments", AUTH_PUBLIC_DATA_VERSION, limit],
    queryFn: async () => (await listPublicPayments({ data: { limit } })) as unknown as PaymentRow[],
  });

export const paymentsForHandleQuery = (handle: string | undefined) =>
  queryOptions({
    queryKey: ["payments", "handle", AUTH_PUBLIC_DATA_VERSION, handle],
    enabled: Boolean(handle),
    queryFn: async () =>
      (await listPublicPayments({ data: { handle: handle!, limit: 100 } })) as unknown as PaymentRow[],
  });

/** Payments the signed-in user sent. */
export const myPaymentsQuery = (userId: string | undefined, limit = 200) =>
  queryOptions({
    queryKey: ["payments", "mine", userId, limit],
    enabled: Boolean(userId),
    queryFn: async () =>
      unwrap<MyPaymentRow[]>(
        (await supabase
          .from("payments")
          .select(MY_PAYMENT_SELECT)
          .eq("is_demo", false)
          .eq("sender_id", userId!)
          .order("created_at", { ascending: false })
          .limit(limit)) as never,
      ),
  });

export type WalletRow = {
  id: string;
  recipient_id: string;
  address: string;
  label: string | null;
  verified_at: string | null;
};

export const walletsForRecipientQuery = (recipientId: string | undefined) =>
  queryOptions({
    queryKey: ["wallets", recipientId],
    enabled: Boolean(recipientId),
    queryFn: async () =>
      unwrap<WalletRow[]>(
        (await supabase
          .from("wallets")
          .select("id,recipient_id,address,label,verified_at")
          .eq("recipient_id", recipientId!)) as never,
      ),
  });
