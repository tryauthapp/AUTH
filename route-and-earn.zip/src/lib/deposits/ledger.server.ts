/**
 * Identity balance ledger — SERVER ONLY.
 *
 * One accounting model for everything owed to a social identity: direct
 * payments and creator fees both become rows in `identity_ledger`. Balances are
 * always summed from those immutable rows — there is no editable counter to
 * drift or be tampered with.
 *
 * Idempotency is enforced by the database, not by application guesswork:
 *  - unique (source, source_event_id) — one credit per originating event
 *  - unique tx_signature — the same deposit transaction can never be credited twice
 *
 * Statuses: deposited -> available -> claiming -> claimed, plus failed.
 * "deposited" means the money arrived and is on-chain but the on-chain check
 * has not completed; "available" means verified and claimable.
 */

export type LedgerAsset = "SOL" | "USDC";
export type LedgerSource = "payment" | "creator_fee";

export interface LedgerCredit {
  recipientId: string;
  provider: string;
  providerUserId: string | null;
  source: LedgerSource;
  sourceEventId: string;
  asset: LedgerAsset;
  assetKey: string | null;
  amount: number;
  amountUsd: number | null;
  depositAddress: string | null;
  txSignature: string | null;
  /**
   * "accrued" = detected creator fees that are real and attributed but still
   * sitting in the pump.fun creator vault / launch wallet. They are not
   * claimable until settlement moves them into the identity deposit wallet.
   */
  status?: "deposited" | "available" | "accrued";
}

/**
 * Credits the identity once. Safe to retry: a duplicate event or duplicate
 * transaction signature is ignored rather than double-counted.
 */
export async function creditIdentity(
  credit: LedgerCredit,
): Promise<{ ok: boolean; id?: string; duplicate?: boolean; message?: string }> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const { data: existing } = await supabaseAdmin
    .from("identity_ledger")
    .select("id")
    .eq("source", credit.source)
    .eq("source_event_id", credit.sourceEventId)
    .maybeSingle();
  if (existing) {
    // Retry of a settlement we already recorded: promote deposited -> available
    // if the on-chain check has now passed, but never add a second credit.
    if (credit.status === "available") {
      await supabaseAdmin
        .from("identity_ledger")
        .update({ status: "available", tx_signature: credit.txSignature })
        .eq("id", existing.id)
        .eq("status", "deposited");
    }
    return { ok: true, id: existing.id, duplicate: true };
  }

  const { data, error } = await supabaseAdmin
    .from("identity_ledger")
    .insert({
      recipient_id: credit.recipientId,
      provider: credit.provider,
      provider_user_id: credit.providerUserId,
      source: credit.source,
      source_event_id: credit.sourceEventId,
      chain_key: "solana",
      asset: credit.asset,
      asset_key: credit.assetKey,
      amount: credit.amount,
      amount_usd: credit.amountUsd,
      deposit_address: credit.depositAddress,
      tx_signature: credit.txSignature,
      status: credit.status ?? "deposited",
    })
    .select("id")
    .single();

  if (error) {
    // Unique violation = someone else recorded the same deposit first.
    if (error.code === "23505") return { ok: true, duplicate: true };
    return { ok: false, message: error.message };
  }
  return { ok: true, id: data.id };
}

export interface LedgerTotals {
  available: Record<LedgerAsset, number>;
  claimed: Record<LedgerAsset, number>;
  claiming: Record<LedgerAsset, number>;
  /** Detected creator fees not yet settled into the identity deposit wallet. */
  accrued: Record<LedgerAsset, number>;
  bySource: Record<LedgerSource, Record<LedgerAsset, number>>;
  recordedUsd: number;
}

export function emptyTotals(): LedgerTotals {
  return {
    available: { SOL: 0, USDC: 0 },
    claimed: { SOL: 0, USDC: 0 },
    claiming: { SOL: 0, USDC: 0 },
    accrued: { SOL: 0, USDC: 0 },
    bySource: {
      payment: { SOL: 0, USDC: 0 },
      creator_fee: { SOL: 0, USDC: 0 },
    },
    recordedUsd: 0,
  };
}

type LedgerRow = {
  status: string;
  asset: string;
  amount: number | string;
  amount_usd: number | string | null;
  source: string;
};

export function totalsFromRows(rows: LedgerRow[]): LedgerTotals {
  const totals = emptyTotals();
  for (const row of rows) {
    const asset = row.asset === "SOL" ? "SOL" : row.asset === "USDC" ? "USDC" : null;
    if (!asset) continue;
    const amount = Number(row.amount);
    if (!Number.isFinite(amount) || amount <= 0) continue;
    const source: LedgerSource = row.source === "creator_fee" ? "creator_fee" : "payment";

    if (row.status === "deposited" || row.status === "available") {
      totals.available[asset] += amount;
      totals.bySource[source][asset] += amount;
      const usd = Number(row.amount_usd);
      if (Number.isFinite(usd) && usd > 0) totals.recordedUsd += usd;
    } else if (row.status === "accrued") {
      totals.accrued[asset] += amount;
    } else if (row.status === "claiming") {
      totals.claiming[asset] += amount;
    } else if (row.status === "claimed") {
      totals.claimed[asset] += amount;
    }
  }
  return totals;
}

/** All ledger totals for one recipient identity. */
export async function ledgerTotalsFor(recipientId: string): Promise<LedgerTotals> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("identity_ledger")
    .select("status,asset,amount,amount_usd,source")
    .eq("recipient_id", recipientId);
  return totalsFromRows((data ?? []) as LedgerRow[]);
}
