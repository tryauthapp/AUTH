/**
 * Identity deposit wallets — SERVER ONLY.
 *
 * "Send now, claim later" needs somewhere real for money to land when the
 * recipient has never heard of AUTH. That destination is a Turnkey-held Solana
 * wallet bound to one canonical social identity:
 *
 *     provider + immutable provider_user_id
 *
 * Properties that make this safe:
 *  - key material lives in Turnkey's enclaves; AUTH stores only the address
 *  - the wallet is addressed by the immutable platform ID, so a handle change
 *    never moves ownership
 *  - nothing is swept to a treasury; funds sit against the identity until its
 *    verified owner claims
 *  - a claim can only be authorized after provider OAuth proves that exact
 *    provider_user_id belongs to the signed-in AUTH account
 */

export type DepositWallet = {
  address: string;
  subOrganizationId: string | null;
  walletId: string | null;
};

export type DepositWalletResult =
  | { ok: true; wallet: DepositWallet; created: boolean }
  | { ok: false; reason: "no_canonical_id" | "unconfigured" | "failed"; message: string };

/**
 * Returns (creating on first use) the deposit wallet for a canonical identity.
 * Refuses to invent one when the platform ID is unknown — a handle alone must
 * never own money.
 */
export async function ensureIdentityDepositWallet(params: {
  provider: string;
  providerUserId: string | null;
  recipientId: string;
  handle: string;
}): Promise<DepositWalletResult> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  if (!params.providerUserId) {
    return {
      ok: false,
      reason: "no_canonical_id",
      message:
        "AUTH could not confirm this account's permanent platform ID, so there is nowhere safe to hold the funds yet.",
    };
  }

  const { data: existing } = await supabaseAdmin
    .from("identity_deposit_wallets")
    .select("address,sub_organization_id,wallet_id")
    .eq("provider", params.provider)
    .eq("provider_user_id", params.providerUserId)
    .maybeSingle();

  if (existing) {
    // Keep the display handle current; ownership stays on the immutable ID.
    await supabaseAdmin
      .from("identity_deposit_wallets")
      .update({ handle: params.handle, recipient_id: params.recipientId })
      .eq("address", existing.address);
    return {
      ok: true,
      created: false,
      wallet: {
        address: existing.address,
        subOrganizationId: existing.sub_organization_id,
        walletId: existing.wallet_id,
      },
    };
  }

  const { turnkeyConfigured, createTurnkeyWallet } = await import("@/lib/turnkey.server");
  if (!turnkeyConfigured()) {
    return {
      ok: false,
      reason: "unconfigured",
      message: "Protected deposits are unavailable: the custody service is not configured.",
    };
  }

  let created;
  try {
    created = await createTurnkeyWallet(
      `deposit-${params.provider}`,
      params.providerUserId.slice(0, 24),
    );
  } catch {
    return {
      ok: false,
      reason: "failed",
      message: "Could not open a protected deposit destination for this account.",
    };
  }

  const { error } = await supabaseAdmin.from("identity_deposit_wallets").insert({
    provider: params.provider,
    provider_user_id: params.providerUserId,
    recipient_id: params.recipientId,
    handle: params.handle,
    address: created.address,
    custody: "turnkey",
    sub_organization_id: created.subOrganizationId,
    wallet_id: created.walletId,
  });
  if (error) {
    // Lost a race: another request created it first.
    const { data: raced } = await supabaseAdmin
      .from("identity_deposit_wallets")
      .select("address,sub_organization_id,wallet_id")
      .eq("provider", params.provider)
      .eq("provider_user_id", params.providerUserId)
      .maybeSingle();
    if (raced) {
      return {
        ok: true,
        created: false,
        wallet: {
          address: raced.address,
          subOrganizationId: raced.sub_organization_id,
          walletId: raced.wallet_id,
        },
      };
    }
    return { ok: false, reason: "failed", message: error.message };
  }

  return {
    ok: true,
    created: true,
    wallet: {
      address: created.address,
      subOrganizationId: created.subOrganizationId,
      walletId: created.walletId,
    },
  };
}

/** Deposit wallets holding funds for a recipient, for the claim sweep. */
export async function depositWalletsForRecipient(recipientId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("identity_deposit_wallets")
    .select("address,sub_organization_id,wallet_id,provider,provider_user_id")
    .eq("recipient_id", recipientId);
  return data ?? [];
}
