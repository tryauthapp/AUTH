/**
 * Vetted crypto logo registry.
 *
 * Logos are local, transparent, square SVGs (plus one official raster where no
 * SVG exists) so nothing depends on a third-party image host at runtime.
 * Lookup order: explicit registry key (chain + symbol) → plain symbol → none.
 * "None" renders a neutral initials chip; we never substitute a similar logo.
 */

const tokenFiles = import.meta.glob("../assets/crypto/tokens/*.{svg,jpg,png}", {
  eager: true,
  query: "?url",
  import: "default",
}) as Record<string, string>;

const networkFiles = import.meta.glob("../assets/crypto/networks/*.svg", {
  eager: true,
  query: "?url",
  import: "default",
}) as Record<string, string>;

function index(files: Record<string, string>) {
  const out: Record<string, string> = {};
  for (const [path, url] of Object.entries(files)) {
    const name = path.split("/").pop()!.replace(/\.(svg|jpg|png)$/, "");
    out[name.toUpperCase()] = url;
  }
  return out;
}

const TOKENS = index(tokenFiles);
const NETWORKS = index(networkFiles);

/**
 * Registry-key overrides. Wrapped/bridged/derivative assets keep their own
 * identity here so e.g. WBTC never renders the Bitcoin logo.
 */
const BY_ASSET_KEY: Record<string, string> = {
  "ethereum:WBTC": "WBTC",
  "polygon:POL": "POL",
  "solana:JUP": "JUP",
  "solana:BONK": "BONK",
  "arbitrum:ARB": "ARB",
};

export function resolveAssetLogo({
  assetKey,
  symbol,
  chainKey,
}: {
  assetKey?: string | null | undefined;
  symbol: string;
  chainKey?: string | null | undefined;
}): string | null {
  if (assetKey) {
    const override = BY_ASSET_KEY[assetKey];
    if (override && TOKENS[override]) return TOKENS[override] ?? null;
    const [, keySymbol] = assetKey.split(":");
    if (keySymbol && TOKENS[keySymbol.toUpperCase()]) return TOKENS[keySymbol.toUpperCase()] ?? null;
  }
  const clean = symbol.replace(/^\$/, "").toUpperCase();
  if (TOKENS[clean]) return TOKENS[clean] ?? null;
  // Native chain assets can be named by their chain (e.g. "solana" → SOL).
  if (chainKey && NETWORKS[chainKey.toUpperCase()] && !clean) {
    return NETWORKS[chainKey.toUpperCase()] ?? null;
  }
  return null;
}

export function networkLogo(chainKey: string): string | null {
  return NETWORKS[chainKey.toUpperCase()] ?? null;
}

export function hasAssetLogo(symbol: string): boolean {
  return Boolean(TOKENS[symbol.replace(/^\$/, "").toUpperCase()]);
}
