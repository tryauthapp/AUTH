/**
 * Launch audit timeline — SERVER ONLY.
 *
 * Every launch (and every admin smoke test) writes an append-only row per
 * stage: configuration validation, transaction construction, signing,
 * submission, on-chain confirmation, and failure.
 *
 * SECURITY: nothing written here may contain a secret. Every string and every
 * detail value is passed through `redact()` first, which:
 *  - drops values whose key looks like a credential (key/secret/token/auth...)
 *  - replaces any literal occurrence of a configured server secret
 *  - never receives a private key in the first place — callers pass public
 *    addresses, amounts and status text only.
 */

export type LaunchStage =
  | "config_validation"
  | "transaction_construction"
  | "signing"
  | "submission"
  | "confirmation"
  | "failure";

export type LaunchEventStatus = "pass" | "fail" | "warn" | "skipped" | "info";

const SECRET_ENV_NAMES = [
  "LAUNCHER_PRIVATE_KEY",
  "PUMPPORTAL_API_KEY",
  "HELIUS_API_KEY",
  "TURNKEY_API_PRIVATE_KEY",
  "TURNKEY_API_PUBLIC_KEY",
  "SUPABASE_SERVICE_ROLE_KEY",
  "LOVABLE_API_KEY",
];

const SENSITIVE_KEY_RE = /(secret|private|password|api[_-]?key|authorization|bearer|seed|mnemonic)/i;

function scrubString(value: string): string {
  let out = value;
  for (const name of SECRET_ENV_NAMES) {
    const secret = process.env[name];
    if (secret && secret.length >= 8) out = out.split(secret).join("[redacted]");
  }
  // Defensive: anything that looks like a 64-byte base58 secret key.
  out = out.replace(/[1-9A-HJ-NP-Za-km-z]{80,}/g, "[redacted]");
  return out.slice(0, 1000);
}

export function redact(value: unknown, depth = 0): unknown {
  if (value === null || value === undefined) return null;
  if (typeof value === "string") return scrubString(value);
  if (typeof value === "number" || typeof value === "boolean") return value;
  if (depth > 3) return "[omitted]";
  if (Array.isArray(value)) return value.slice(0, 20).map((v) => redact(v, depth + 1));
  if (typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      out[k] = SENSITIVE_KEY_RE.test(k) ? "[redacted]" : redact(v, depth + 1);
    }
    return out;
  }
  return "[omitted]";
}

export interface LaunchEventInput {
  userId: string | null;
  launchKey: string;
  kind?: "launch" | "smoke_test" | undefined;
  stage: LaunchStage;
  status: LaunchEventStatus;
  message?: string | null | undefined;
  detail?: Record<string, unknown> | undefined;
}

/** Appends one redacted audit row. Never throws into the launch path. */
export async function recordLaunchEvent(input: LaunchEventInput): Promise<void> {
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("launch_audit_events").insert({
      user_id: input.userId,
      launch_key: input.launchKey.slice(0, 120),
      kind: input.kind ?? "launch",
      stage: input.stage,
      status: input.status,
      message: input.message ? scrubString(input.message) : null,
      // Redacted plain JSON; the column is jsonb.
      detail: JSON.parse(JSON.stringify(redact(input.detail ?? {}) ?? {})),
    });
  } catch {
    // Auditing must never break or block a launch.
  }
}

/** Convenience recorder bound to one launch attempt. */
export function launchAuditRecorder(userId: string | null, launchKey: string, kind: "launch" | "smoke_test" = "launch") {
  return (
    stage: LaunchStage,
    status: LaunchEventStatus,
    message?: string | null,
    detail?: Record<string, unknown>,
  ) => recordLaunchEvent({ userId, launchKey, kind, stage, status, message, detail });
}
