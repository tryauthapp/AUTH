import { createServerFn } from "@tanstack/react-start";
import { isSocialProvider, normalizeSocialHandle } from "@/lib/social/providers";
import type { SocialProvider } from "@/lib/social/providers";

/**
 * Public identity page data for any of the five platforms.
 *
 * Everything returned is a real AUTH record or a real platform API response.
 * Nothing is seeded, and a balance of zero is reported as zero rather than
 * hidden behind a placeholder.
 */

export interface PublicPlatformProfile {
  provider: SocialProvider;
  handle: string;
  displayName: string | null;
  avatarUrl: string | null;
  bio: string | null;
  profileUrl: string | null;
  followerCount: number | null;
  platformVerified: boolean | null;
  profileFetchedAt: string | null;
  /** Why the platform profile is absent, when it is. */
  lookupMessage: string | null;
  /** AUTH state. */
  onAuth: boolean;
  claimed: boolean;
  verification: string;
  payoutWallet: string | null;
  claimableSol: number;
  claimableUsdc: number;
  claimableUsd: number;
  totalFeesUsd: number;
  paidOutUsd: number;
  paymentCount: number;
  launchCount: number;
  activity: {
    id: string;
    kind: "payment" | "payout";
    asset: string;
    amount: number | null;
    amountUsd: number | null;
    status: string;
    signature: string | null;
    at: string;
  }[];
}

export const publicPlatformProfile = createServerFn({ method: "GET" })
  .inputValidator((input: { provider: string; handle: string }) => {
    if (!isSocialProvider(input.provider)) throw new Error("Unsupported platform.");
    const handle = normalizeSocialHandle(input.provider, input.handle);
    if (!handle) throw new Error("Enter a username.");
    return { provider: input.provider, handle };
  })
  .handler(async ({ data }): Promise<PublicPlatformProfile> => {
    const { enforceRateLimit } = await import("@/lib/rate-limit.server");
    enforceRateLimit("public-profile", 90, 60_000);
    const { cached } = await import("@/lib/server-cache.server");
    return cached(
      `public-profile:${data.provider}:${data.handle.toLowerCase()}`,
      30_000,
      () => loadPublicPlatformProfile(data),
    );
  });

async function loadPublicPlatformProfile(data: {
  provider: SocialProvider;
  handle: string;
}): Promise<PublicPlatformProfile> {
  {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { lookupPlatformProfile } = await import("@/lib/social/lookup.server");

    const lookup = await lookupPlatformProfile(data.provider, data.handle);
    const handle = lookup.profile?.handle ?? data.handle;

    const { data: recipient } = await supabaseAdmin
      .from("recipients")
      .select("id,handle,display_name,avatar_url,bio,verification,claimed_by,follower_count,profile_url,platform_verified,profile_synced_at")
      .eq("provider", data.provider)
      .ilike("handle", handle)
      .maybeSingle();

    const base: PublicPlatformProfile = {
      provider: data.provider,
      handle,
      displayName: lookup.profile?.displayName ?? recipient?.display_name ?? null,
      avatarUrl: lookup.profile?.avatarUrl ?? recipient?.avatar_url ?? null,
      bio: lookup.profile?.bio ?? recipient?.bio ?? null,
      profileUrl: lookup.profile?.profileUrl ?? recipient?.profile_url ?? null,
      followerCount: lookup.profile?.followerCount ?? recipient?.follower_count ?? null,
      platformVerified: lookup.profile?.platformVerified ?? recipient?.platform_verified ?? null,
      profileFetchedAt: lookup.profile?.fetchedAt ?? recipient?.profile_synced_at ?? null,
      lookupMessage: lookup.profile ? null : (lookup.message ?? null),
      onAuth: Boolean(recipient),
      claimed: Boolean(recipient?.claimed_by),
      verification: recipient?.verification ?? "unverified",
      payoutWallet: null,
      claimableSol: 0,
      claimableUsdc: 0,
      claimableUsd: 0,
      totalFeesUsd: 0,
      paidOutUsd: 0,
      paymentCount: 0,
      launchCount: 0,
      activity: [],
    };

    if (!recipient) return base;

    const [wallet, payouts, fees, payments, launches] = await Promise.all([
      supabaseAdmin
        .from("wallets")
        .select("address,verified_at,is_default")
        .eq("recipient_id", recipient.id)
        .not("verified_at", "is", null)
        .order("is_default", { ascending: false })
        .limit(1)
        .maybeSingle(),
      supabaseAdmin
        .from("payouts")
        .select("id,status,asset,asset_amount,amount_usd,tx_signature,created_at")
        .eq("recipient_id", recipient.id)
        .eq("is_demo", false)
        .order("created_at", { ascending: false })
        .limit(50),
      supabaseAdmin
        .from("fee_events")
        .select("net_usd")
        .eq("recipient_id", recipient.id)
        .eq("is_demo", false),
      supabaseAdmin
        .from("payments")
        .select("id,asset,amount,amount_usd,status,tx_signature,created_at")
        .eq("recipient_id", recipient.id)
        .eq("is_demo", false)
        .order("created_at", { ascending: false })
        .limit(50),
      supabaseAdmin
        .from("token_recipients")
        .select("id", { count: "exact", head: true })
        .eq("recipient_id", recipient.id),
    ]);

    const payoutRows = payouts.data ?? [];
    const claimable = payoutRows.filter((p) => p.status === "claimable");
    const paymentRows = payments.data ?? [];

    base.payoutWallet = wallet.data?.address ?? null;
    base.claimableSol = claimable
      .filter((p) => p.asset === "SOL")
      .reduce((sum, p) => sum + Number(p.asset_amount ?? 0), 0);
    base.claimableUsdc = claimable
      .filter((p) => p.asset === "USDC")
      .reduce((sum, p) => sum + Number(p.asset_amount ?? 0), 0);
    base.claimableUsd = claimable.reduce((sum, p) => sum + Number(p.amount_usd ?? 0), 0);
    base.totalFeesUsd = (fees.data ?? []).reduce((sum, f) => sum + Number(f.net_usd ?? 0), 0);
    base.paidOutUsd = payoutRows
      .filter((p) => p.status === "paid")
      .reduce((sum, p) => sum + Number(p.amount_usd ?? 0), 0);
    base.paymentCount = paymentRows.length;
    base.launchCount = launches.count ?? 0;
    base.activity = [
      ...paymentRows.map((p) => ({
        id: p.id,
        kind: "payment" as const,
        asset: p.asset,
        amount: p.amount === null ? null : Number(p.amount),
        amountUsd: p.amount_usd === null ? null : Number(p.amount_usd),
        status: p.status,
        signature: p.tx_signature,
        at: p.created_at,
      })),
      ...payoutRows.map((p) => ({
        id: p.id,
        kind: "payout" as const,
        asset: p.asset ?? "",
        amount: p.asset_amount === null ? null : Number(p.asset_amount),
        amountUsd: p.amount_usd === null ? null : Number(p.amount_usd),
        status: p.status,
        signature: p.tx_signature,
        at: p.created_at,
      })),
    ]
      .sort((a, b) => (a.at < b.at ? 1 : -1))
      .slice(0, 25);

    return base;
  }
}
