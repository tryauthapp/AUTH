import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Dev-buy custody and delivery.
 *
 * A dev buy belongs to the launcher who funded it — never to the social
 * recipient, and never to AUTH. The pump.fun launch is signed by a
 * provider-hosted execution wallet, which is infrastructure only: holding the
 * tokens there confers no ownership.
 *
 * AUTH reports the true delivery state and never claims the launcher has
 * received tokens that are still sitting in the execution wallet.
 */

export interface DevBuyCapability {
  /** True only if the provider API can move dev-buy tokens to the launcher. */
  autoDelivery: boolean;
  provider: string;
  note: string;
}

export const devBuyDeliveryCapability = createServerFn({ method: "GET" }).handler(
  async (): Promise<DevBuyCapability> => {
    const {
      pumpfunDevBuyAutoDelivery,
      PUMPFUN_DEV_BUY_CUSTODY_NOTE,
      PUMPFUN_DEV_BUY_PENDING_NOTE,
    } = await import("@/integrations/adapters/pumpfun.server");
    const autoDelivery = pumpfunDevBuyAutoDelivery();
    return {
      autoDelivery,
      provider: "pumpportal",
      note: autoDelivery ? PUMPFUN_DEV_BUY_PENDING_NOTE : PUMPFUN_DEV_BUY_CUSTODY_NOTE,
    };
  },
);

export interface DevBuyPosition {
  mint: string;
  symbol: string;
  name: string;
  devBuySol: number;
  /** "none" | "pending_manual_settlement" | "delivered" */
  deliveryStatus: string;
  executionProvider: string | null;
  executionWallet: string | null;
  launchedAt: string;
}

/** Every dev buy the signed-in launcher owns, with its real delivery state. */
export const myDevBuyPositions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<DevBuyPosition[]> => {
    const { data } = await context.supabase
      .from("tokens")
      .select(
        "mint,symbol,name,dev_buy_sol,dev_buy_delivery_status,execution_provider,launch_wallet,created_at",
      )
      .eq("dev_buy_owner_user_id", context.userId)
      .eq("is_demo", false)
      .order("created_at", { ascending: false })
      .limit(100);

    return (data ?? [])
      .filter((row) => Number(row.dev_buy_sol ?? 0) > 0)
      .map((row) => ({
        mint: row.mint,
        symbol: row.symbol,
        name: row.name,
        devBuySol: Number(row.dev_buy_sol ?? 0),
        deliveryStatus: row.dev_buy_delivery_status ?? "none",
        executionProvider: row.execution_provider,
        executionWallet: row.launch_wallet,
        launchedAt: row.created_at,
      }));
  });

export interface CreatorFeeEntitlement {
  recipientId: string;
  provider: string;
  handle: string;
  displayName: string | null;
  avatarUrl: string | null;
  mints: string[];
  /** True once the identity's owner has verified it and linked it to an account. */
  claimed: boolean;
}

/**
 * Creator-fee entitlement for one canonical social identity, independent of
 * who launched the token. Public and read-only: an unclaimed identity still
 * has a visible, attributable entitlement.
 */
export const creatorFeeEntitlement = createServerFn({ method: "GET" })
  .inputValidator((input: { provider: string; handle: string }) => ({
    provider: String(input?.provider ?? "x").toLowerCase().slice(0, 20),
    handle: String(input?.handle ?? "")
      .replace(/^@+/, "")
      .replace(/[^A-Za-z0-9_.-]/g, "")
      .slice(0, 40),
  }))
  .handler(async ({ data }): Promise<CreatorFeeEntitlement | null> => {
    if (!data.handle) return null;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: recipient } = await supabaseAdmin
      .from("recipients")
      .select("id,provider,handle,display_name,avatar_url,claimed_by")
      .eq("provider", data.provider)
      .ilike("handle", data.handle)
      .eq("is_demo", false)
      .maybeSingle();
    if (!recipient) return null;

    const { data: tokens } = await supabaseAdmin
      .from("tokens")
      .select("mint")
      .eq("creator_fee_recipient_id", recipient.id)
      .eq("is_demo", false)
      .limit(100);

    return {
      recipientId: recipient.id,
      provider: recipient.provider,
      handle: recipient.handle,
      displayName: recipient.display_name,
      avatarUrl: recipient.avatar_url,
      mints: (tokens ?? []).map((t) => t.mint),
      claimed: Boolean(recipient.claimed_by),
    };
  });

export interface LaunchWalletStatus {
  /** "configured" | "missing" | "invalid" — never includes the secret itself. */
  state: string;
  message: string | null;
  /** Public address only. */
  address: string | null;
  solBalance: number | null;
  /** "external_wallet" | "provider_hosted" | null */
  signerMode: string | null;
  provider: string;
  providerRole: string;
  rpcConfigured: boolean;
}

/**
 * Launch wallet configuration for admin/integration status.
 *
 * Returns the derived PUBLIC address and balance only. The private key is read
 * server-side inside the signing step and is never returned, logged, or
 * included in any response.
 */
export const launchWalletStatus = createServerFn({ method: "GET" }).handler(
  async (): Promise<LaunchWalletStatus> => {
    const { launcherWalletStatus } = await import("@/lib/launcher-wallet.server");
    const { pumpfunSignerMode } = await import("@/integrations/adapters/pumpfun.server");
    const { getSolBalance, rpcEndpoint } = await import("@/integrations/adapters/helius.server");

    const status = launcherWalletStatus();
    const address = status.state === "configured" ? status.address : null;
    const signerMode = pumpfunSignerMode();

    let solBalance: number | null = null;
    if (address) {
      const balance = await getSolBalance(address);
      if (balance.ok) solBalance = balance.data;
    }

    return {
      state: status.state,
      message: status.state === "configured" ? null : status.message,
      address,
      solBalance,
      signerMode,
      provider: "pumpportal",
      providerRole:
        signerMode === "external_wallet"
          ? "Transaction construction only — AUTH signs and broadcasts with its own launch wallet."
          : "Provider-hosted execution wallet signs the launch. It is infrastructure, never an owner.",
      rpcConfigured: Boolean(rpcEndpoint()),
    };
  },
);
