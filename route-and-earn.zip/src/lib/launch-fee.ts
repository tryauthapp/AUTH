/**
 * AUTH charges no platform fee to create a token: pump.fun lists coin creation
 * at 0 SOL, and AUTH does not add a surcharge on top of it. The only SOL a
 * launcher ever sends through AUTH is the required dev buy they fund, plus the
 * unavoidable Solana network cost of the launch transaction itself, which is
 * paid by the provider-hosted launch account that signs it.
 */
export const AUTH_LAUNCH_FEE_SOL = 0;

/**
 * Every launch requires a dev buy funded by the launcher. AUTH's platform fee
 * stays 0 SOL, but the launcher must buy at least this much of their own token
 * so the launch has real launcher-owned supply from the first block.
 */
export const MIN_DEV_BUY_SOL = 0.001;

/** Funded launch account that signs launches and receives optional dev-buy SOL. */
export const LAUNCH_FEE_ADDRESS = "7JpVSfV2sJPRLpkg3jij4ohsRgBMnYamku4e4dxBzfP";

/** Base58 Solana transaction signature. */
export const SIGNATURE_RE = /^[1-9A-HJ-NP-Za-km-z]{64,90}$/;

/**
 * Typical Solana network cost of a pump.fun create transaction. This is a real
 * observed order of magnitude for a signed mainnet transaction, not a charge by
 * AUTH, and it is paid by the account that signs the launch.
 */
export const NETWORK_COST_NOTE =
  "Solana network cost for the launch transaction is paid by the launch account that signs it.";

/**
 * The exact SOL a launcher must send for this launch attempt: the required dev
 * buy (minimum 0.001 SOL) plus a small unique lamport tag, so the incoming
 * payment can be matched on-chain automatically with no signature to paste.
 * Legacy attempts recorded before the minimum existed can still be zero.
 */
export function requiredLamportsForLaunch(launchKey: string, devBuySol: number): number {
  const devBuyLamports = Math.round((Number(devBuySol) || 0) * 1_000_000_000);
  if (devBuyLamports <= 0) return 0;
  // Stable FNV-1a-derived tag: both the browser and server calculate the same
  // exact amount, but every launch attempt receives a different reference.
  let hash = 2166136261;
  for (let i = 0; i < launchKey.length; i++) {
    hash ^= launchKey.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  const tag = ((hash >>> 0) % 90_000) + 1_000; // 1,000–90,999 lamports
  return devBuyLamports + tag;
}

export function lamportsToSol(lamports: number): string {
  return (lamports / 1_000_000_000).toFixed(9).replace(/0+$/, "").replace(/\.$/, "");
}
