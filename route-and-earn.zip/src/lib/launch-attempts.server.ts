/**
 * Launch attempt ledger (SERVER ONLY).
 *
 * Every pump.fun launch through AUTH moves through an explicit state machine:
 *
 *   draft -> funded -> submitted -> confirmed
 *                              \-> failed -> (refundable | reconciling | not_applicable)
 *
 * Funding architecture, stated honestly:
 * - The launch fee is paid by the launcher directly to the PumpPortal-hosted
 *   launch account. AUTH holds only the PumpPortal API key, which can create
 *   and trade pump.fun tokens - it cannot sign an arbitrary SOL transfer out
 *   of that account. AUTH holds no private key for it and takes no custody it
 *   can unilaterally reverse.
 * - Therefore AUTH cannot execute an automated on-chain refund today. Instead
 *   it records the exact lamports received, what was irreversibly spent, and
 *   the provably unspent remainder, and flags the attempt for settlement.
 *   No refund receipt, signature or amount is ever fabricated.
 */

export type LaunchAttemptStatus =
  | "draft"
  | "funded"
  | "submitted"
  | "confirmed"
  | "failed";

export type RefundStatus =
  | "none"
  | "not_applicable"
  | "reconciling"
  | "manual_settlement"
  | "refund_pending"
  | "refunded";

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

async function upsertAttempt(
  userId: string,
  launchKey: string,
  patch: Record<string, unknown>,
) {
  const db = await admin();
  const { data: existing } = await db
    .from("launch_attempts")
    .select("id")
    .eq("user_id", userId)
    .eq("launch_key", launchKey)
    .maybeSingle();

  if (existing) {
    await db
      .from("launch_attempts")
      .update({ ...patch, updated_at: new Date().toISOString() })
      .eq("id", existing.id);
    return existing.id;
  }

  const { data: created } = await db
    .from("launch_attempts")
    .insert({ user_id: userId, launch_key: launchKey, ...patch })
    .select("id")
    .maybeSingle();
  return created?.id ?? null;
}

/** The launcher's fee payment is confirmed on mainnet and reserved to them. */
export async function recordFunded(args: {
  userId: string;
  launchKey: string;
  signature: string;
  payer: string | null;
  lamports: number;
}) {
  await upsertAttempt(args.userId, args.launchKey, {
    status: "funded",
    fee_signature: args.signature,
    fee_payer: args.payer,
    fee_lamports_received: args.lamports,
    refundable_lamports: args.lamports,
    refund_status: "none",
    funded_at: new Date().toISOString(),
  });
}

/** The pump.fun create transaction is about to be submitted. */
export async function recordSubmitted(args: {
  userId: string;
  launchKey: string;
  symbol: string;
}) {
  await upsertAttempt(args.userId, args.launchKey, {
    status: "submitted",
    symbol: args.symbol,
    submitted_at: new Date().toISOString(),
  });
}

/**
 * Launch confirmed on mainnet with a verified mint: the fee was consumed.
 *
 * This is also where ownership is pinned, and the three roles stay separate:
 * - `user_id` / `dev_buy_owner_user_id` — the launcher, who owns the dev-buy
 *   token allocation they paid for
 * - `execution_wallet` — provider infrastructure that signed the transaction;
 *   it owns nothing
 * - `creator_fee_recipient_id` — the canonical social identity that owns the
 *   creator-fee entitlement, whether or not it has ever been claimed
 */
export async function recordConfirmed(args: {
  userId: string;
  launchKey: string;
  mint: string;
  launchSignature: string;
  spentLamports: number;
  recipientId?: string | null;
  executionProvider?: string | null;
  executionWallet?: string | null;
  devBuySol?: number;
  devBuyDeliveryStatus?: string;
  devBuyDeliveryNote?: string | null;
  signerMode?: string | null;
  launchWalletAddress?: string | null;
  devBuyOwnerWallet?: string | null;
  /** Confirmed transfer of the dev-buy tokens to the launcher's own wallet. */
  devBuyDeliverySignature?: string | null;
  devBuyDestinationWallet?: string | null;
  /** Launcher wallet + payment that funded the dev buy. AUTH never funds it. */
  devBuyFundingWallet?: string | null;
  devBuyFundingSignature?: string | null;
  devBuyFundingLamports?: number;
  /** Network/provider cost of the launch, paid by AUTH launch infrastructure. */
  infrastructureCostLamports?: number;
}) {
  const devBuySol = args.devBuySol ?? 0;
  await upsertAttempt(args.userId, args.launchKey, {
    status: "confirmed",
    mint: args.mint,
    launch_signature: args.launchSignature,
    spent_lamports: args.spentLamports,
    refundable_lamports: 0,
    refund_status: "not_applicable",
    confirmed_at: new Date().toISOString(),
    recipient_id: args.recipientId ?? null,
    creator_fee_recipient_id: args.recipientId ?? null,
    execution_provider: args.executionProvider ?? null,
    execution_wallet: args.executionWallet ?? null,
    dev_buy_sol: devBuySol,
    dev_buy_owner_user_id: devBuySol > 0 ? args.userId : null,
    dev_buy_delivery_status: args.devBuyDeliveryStatus ?? (devBuySol > 0 ? "pending_manual_settlement" : "none"),
    dev_buy_delivery_note: args.devBuyDeliveryNote ?? null,
    signer_mode: args.signerMode ?? null,
    launch_wallet_address: args.launchWalletAddress ?? null,
    dev_buy_owner_wallet: args.devBuyOwnerWallet ?? null,
    dev_buy_delivery_signature: args.devBuyDeliverySignature ?? null,
    dev_buy_delivered_at: args.devBuyDeliverySignature ? new Date().toISOString() : null,
    dev_buy_destination_wallet: args.devBuyDestinationWallet ?? null,
    dev_buy_funding_wallet: args.devBuyFundingWallet ?? null,
    dev_buy_funding_signature: args.devBuyFundingSignature ?? null,
    dev_buy_funding_lamports: args.devBuyFundingLamports ?? 0,
    launch_infrastructure_cost_lamports: args.infrastructureCostLamports ?? 0,
  });
}

/**
 * Launch failed. Refundability is derived only from what AUTH can prove:
 * - no fee received  -> nothing was charged, nothing to refund
 * - fee received, nothing submitted on-chain -> the full fee is unspent
 * - a launch transaction exists but could not be verified -> ambiguous, must be
 *   reconciled against Solana before anything is treated as refundable
 */
export async function recordFailed(args: {
  userId: string;
  launchKey: string;
  reason: string;
  launchSignature?: string | null;
}) {
  const db = await admin();
  const { data: row } = await db
    .from("launch_attempts")
    .select("id,fee_lamports_received,spent_lamports")
    .eq("user_id", args.userId)
    .eq("launch_key", args.launchKey)
    .maybeSingle();

  const received = Number(row?.fee_lamports_received ?? 0);
  const ambiguous = Boolean(args.launchSignature);
  const unspent = ambiguous ? 0 : Math.max(0, received - Number(row?.spent_lamports ?? 0));

  let refundStatus: RefundStatus = "not_applicable";
  if (ambiguous) refundStatus = "reconciling";
  else if (unspent > 0) refundStatus = "manual_settlement";

  await upsertAttempt(args.userId, args.launchKey, {
    status: "failed",
    failure_reason: args.reason.slice(0, 500),
    launch_signature: args.launchSignature ?? null,
    refundable_lamports: unspent,
    refund_status: refundStatus,
    failed_at: new Date().toISOString(),
  });
}
