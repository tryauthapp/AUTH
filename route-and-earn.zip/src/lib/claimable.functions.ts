import { createServerFn } from "@tanstack/react-start";
import { SOCIAL_PROVIDERS, type SocialProvider } from "@/lib/social/providers";

/**
 * Public claimable-balance accounting for a social identity.
 *
 * Every number here is derived from real AUTH accounting rows:
 *  - `payouts`        — creator-fee routing owed to the recipient
 *  - `escrow_deposits`— payments sent to a handle before it was claimed
 *
 * Nothing is invented. When an identity has no rows, the totals are 0 and the
 * caller renders an accurate empty state. USD is an approximation derived from
 * stored `amount_usd` plus a live SOL spot price; it is always labelled as
 * approximate and is null when no price source answered.
 */

export type ClaimableAsset = "SOL" | "USDC";

export interface ClaimableBucket {
  /** Native units of the asset, not USD. */
  SOL: number;
  USDC: number;
  /** USD recorded on the accounting rows themselves, when present. */
  recordedUsd: number;
}

export interface PublicClaimable {
  handle: string;
  provider: SocialProvider;
  profileUrl: string | null;
  identity: {
    displayName: string | null;
    avatarUrl: string | null;
    /** AUTH's own verification state — never a claim about the platform's badge. */
    verification: string;
    isClaimed: boolean;
  } | null;
  available: ClaimableBucket;
  claimed: ClaimableBucket;
  /** Approximate USD for the available bucket; null when no price was available. */
  approxUsd: number | null;
  priceSource: string | null;
  solPriceUsd: number | null;
  asOf: string;
}

const AVAILABLE_PAYOUT_LIST = ["pending", "processing", "claimable", "failed"] as const;
const AVAILABLE_PAYOUT: Set<string> = new Set(AVAILABLE_PAYOUT_LIST);
const CLAIMED_PAYOUT: Set<string> = new Set(["paid", "claimed"]);
const AVAILABLE_ESCROW_LIST = ["pending", "deposited", "held", "claimable"] as const;
const AVAILABLE_ESCROW: Set<string> = new Set(AVAILABLE_ESCROW_LIST);
const CLAIMED_ESCROW: Set<string> = new Set(["released", "claimed"]);

function emptyBucket(): ClaimableBucket {
  return { SOL: 0, USDC: 0, recordedUsd: 0 };
}

function assetOf(value: string | null | undefined): ClaimableAsset | null {
  if (!value) return null;
  const symbol = value.includes(":") ? value.split(":")[1] : value;
  const upper = (symbol ?? "").toUpperCase();
  if (upper === "SOL") return "SOL";
  if (upper === "USDC") return "USDC";
  return null;
}

function add(bucket: ClaimableBucket, asset: ClaimableAsset | null, amount: unknown, usd: unknown) {
  const n = Number(amount);
  if (asset && Number.isFinite(n) && n > 0) bucket[asset] += n;
  const u = Number(usd);
  if (Number.isFinite(u) && u > 0) bucket.recordedUsd += u;
}

function cleanHandle(value: unknown): string {
  return String(value ?? "")
    .replace(/^@+/, "")
    .replace(/[^A-Za-z0-9_.-]/g, "")
    .slice(0, 40);
}

function cleanProvider(value: unknown): SocialProvider {
  const id = String(value ?? "x").toLowerCase();
  return (SOCIAL_PROVIDERS.find((p) => p.id === id)?.id ?? "x") as SocialProvider;
}

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

/** Approximate USD for a bucket: stored USD wins, SOL uses live spot, USDC is 1:1. */
function approximate(bucket: ClaimableBucket, solPriceUsd: number | null): number | null {
  const solUsd = solPriceUsd === null ? null : bucket.SOL * solPriceUsd;
  if (bucket.SOL > 0 && solUsd === null) return null;
  const total = (solUsd ?? 0) + bucket.USDC;
  if (total > 0) return Number(total.toFixed(2));
  return bucket.recordedUsd > 0 ? Number(bucket.recordedUsd.toFixed(2)) : 0;
}

export const getPublicClaimable = createServerFn({ method: "GET" })
  .inputValidator((input: { handle: string; provider?: string }) => ({
    handle: cleanHandle(input.handle),
    provider: cleanProvider(input.provider),
  }))
  .handler(async ({ data }): Promise<PublicClaimable> => {
    const { cached } = await import("@/lib/server-cache.server");
    return cached(`claimable:${data.provider}:${data.handle.toLowerCase()}`, 20_000, () =>
      loadPublicClaimable(data),
    );
  });

async function loadPublicClaimable(data: {
  handle: string;
  provider: SocialProvider;
}): Promise<PublicClaimable> {
  {
    const asOf = new Date().toISOString();
    const base: PublicClaimable = {
      handle: data.handle,
      provider: data.provider,
      profileUrl: null,
      identity: null,
      available: emptyBucket(),
      claimed: emptyBucket(),
      approxUsd: 0,
      priceSource: null,
      solPriceUsd: null,
      asOf,
    };
    if (!data.handle) return base;

    const db = await admin();
    const { data: recipient, error } = await db
      .from("recipients")
      .select("id,handle,display_name,avatar_url,verification,claimed_by,provider")
      .eq("is_demo", false)
      .eq("provider", data.provider)
      .ilike("handle", data.handle)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!recipient) return base;

    base.handle = recipient.handle;
    base.identity = {
      displayName: recipient.display_name,
      avatarUrl: recipient.avatar_url,
      verification: recipient.verification,
      isClaimed: Boolean(recipient.claimed_by),
    };

    const [{ data: payouts }, { data: escrow }] = await Promise.all([
      db
        .from("payouts")
        .select("status,asset,asset_amount,amount_usd")
        .eq("recipient_id", recipient.id)
        .eq("is_demo", false),
      db
        .from("escrow_deposits")
        .select("status,asset_key,amount,amount_usd")
        .eq("recipient_id", recipient.id),
    ]);

    for (const row of payouts ?? []) {
      const asset = assetOf(row.asset);
      if (AVAILABLE_PAYOUT.has(row.status)) add(base.available, asset, row.asset_amount, row.amount_usd);
      else if (CLAIMED_PAYOUT.has(row.status)) add(base.claimed, asset, row.asset_amount, row.amount_usd);
    }
    for (const row of escrow ?? []) {
      const asset = assetOf(row.asset_key);
      if (AVAILABLE_ESCROW.has(row.status)) add(base.available, asset, row.amount, row.amount_usd);
      else if (CLAIMED_ESCROW.has(row.status)) add(base.claimed, asset, row.amount, row.amount_usd);
    }

    if (base.available.SOL > 0 || base.claimed.SOL > 0) {
      const { getSolUsdPrice } = await import("@/integrations/adapters/price.server");
      const price = await getSolUsdPrice();
      if (price.ok) {
        base.solPriceUsd = price.usd;
        base.priceSource = price.source;
      }
    }
    base.approxUsd = approximate(base.available, base.solPriceUsd);
    return base;
  }
}

export interface ClaimableSummary {
  handle: string;
  provider: SocialProvider;
  displayName: string | null;
  avatarUrl: string | null;
  isClaimed: boolean;
  SOL: number;
  USDC: number;
  /** Approximate USD for this identity's available balance; null when unpriced. */
  approxUsd: number | null;
}

/**
 * Discovery list: identities that currently have something waiting.
 * Only public identity fields and public entitlement totals are returned.
 */
export const listPublicClaimable = createServerFn({ method: "GET" }).handler(
  async (): Promise<ClaimableSummary[]> => {
    const { cached } = await import("@/lib/server-cache.server");
    return cached("claimable:list", 30_000, loadPublicClaimableList);
  },
);

async function loadPublicClaimableList(): Promise<ClaimableSummary[]> {
  {
    const db = await admin();
    const [{ data: payouts }, { data: escrow }] = await Promise.all([
      db
        .from("payouts")
        .select("recipient_id,status,asset,asset_amount")
        .eq("is_demo", false)
        .in("status", [...AVAILABLE_PAYOUT_LIST]),
      db
        .from("escrow_deposits")
        .select("recipient_id,status,asset_key,amount")
        .in("status", [...AVAILABLE_ESCROW_LIST]),
    ]);

    const totals = new Map<string, { SOL: number; USDC: number }>();
    const bump = (id: string | null, asset: ClaimableAsset | null, amount: unknown) => {
      const n = Number(amount);
      if (!id || !asset || !Number.isFinite(n) || n <= 0) return;
      const entry = totals.get(id) ?? { SOL: 0, USDC: 0 };
      entry[asset] += n;
      totals.set(id, entry);
    };
    for (const row of payouts ?? []) bump(row.recipient_id, assetOf(row.asset), row.asset_amount);
    for (const row of escrow ?? []) bump(row.recipient_id, assetOf(row.asset_key), row.amount);
    if (totals.size === 0) return [];

    let solPriceUsd: number | null = null;
    const anySol = [...totals.values()].some((t) => t.SOL > 0);
    if (anySol) {
      const { getSolUsdPrice } = await import("@/integrations/adapters/price.server");
      const price = await getSolUsdPrice();
      if (price.ok) solPriceUsd = price.usd;
    }

    const { data: recipients } = await db
      .from("recipients")
      .select("id,handle,display_name,avatar_url,claimed_by,provider")
      .eq("is_demo", false)
      .in("id", [...totals.keys()]);

    return (recipients ?? [])
      .map((r) => {
        const t = totals.get(r.id) ?? { SOL: 0, USDC: 0 };
        return {
          handle: r.handle,
          provider: cleanProvider(r.provider),
          displayName: r.display_name,
          avatarUrl: r.avatar_url,
          isClaimed: Boolean(r.claimed_by),
          SOL: t.SOL,
          USDC: t.USDC,
          approxUsd:
            t.SOL > 0 && solPriceUsd === null
              ? null
              : Number((t.SOL * (solPriceUsd ?? 0) + t.USDC).toFixed(2)),
        };
      })
      .sort((a, b) => b.SOL + b.USDC - (a.SOL + a.USDC))
      .slice(0, 24);
  }
}
