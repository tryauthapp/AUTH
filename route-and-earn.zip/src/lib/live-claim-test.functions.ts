import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Live claim-path test — admin only, real money, deliberately tiny.
 *
 * Proves the full "send now, claim later" pipeline end to end:
 *   1. canonical identity → Turnkey deposit wallet provisioning
 *   2. launcher wallet funds a real mainnet SOL transfer into it
 *   3. on-chain verification turns the transfer into a claimable ledger row
 *   4. the recipient's own Claim (Claim All → Turnkey signing → on-chain
 *      verification) completes the loop
 *
 * This function only performs steps 1–3. Step 4 runs through the normal
 * claim flow so the tested path is exactly what users use.
 */

const DEFAULT_TEST_SOL = 0.05;
const MAX_TEST_SOL = 0.2;

export interface LiveDepositTestResult {
  ok: boolean;
  message: string;
  signature?: string;
  depositAddress?: string;
  amountSol?: number;
  explorerUrl?: string;
}

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

export const runLiveDepositTest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { recipientId: string; amountSol?: number } | undefined) => ({
    recipientId: String(input?.recipientId ?? ""),
    amountSol: Math.min(
      Math.max(Number(input?.amountSol) || DEFAULT_TEST_SOL, 0.005),
      MAX_TEST_SOL,
    ),
  }))
  .handler(async ({ data, context }): Promise<LiveDepositTestResult> => {
    const { userId } = context;
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Admin access is required to run the live deposit test.");

    const { enforceRateLimit } = await import("@/lib/rate-limit.server");
    enforceRateLimit("live-deposit-test", 3, 60_000);

    const db = await admin();

    // The identity must already be claimed by this account — the test never
    // touches an identity the caller does not own.
    const { data: recipient } = await db
      .from("recipients")
      .select("id,handle,provider,provider_user_id,claimed_by")
      .eq("id", data.recipientId)
      .maybeSingle();
    if (!recipient || recipient.claimed_by !== userId) {
      return {
        ok: false,
        message: "Pick one of your own verified identities to fund.",
      };
    }
    if (!recipient.provider_user_id) {
      return {
        ok: false,
        message: "This identity has no permanent platform ID, so there is no safe deposit address.",
      };
    }

    // Step 1 — provisioning (reuses the production path; creates the Turnkey
    // deposit wallet on first use and proves that path works).
    const { ensureIdentityDepositWallet } = await import("@/lib/deposits/deposit-wallet.server");
    const deposit = await ensureIdentityDepositWallet({
      provider: recipient.provider,
      providerUserId: recipient.provider_user_id,
      recipientId: recipient.id,
      handle: recipient.handle,
    });
    if (!deposit.ok) {
      return { ok: false, message: deposit.message };
    }

    // Step 2 — real mainnet transfer from the launcher wallet.
    const { sendSolFromLauncher } = await import("@/lib/launcher-send.server");
    const sent = await sendSolFromLauncher({
      to: deposit.wallet.address,
      amountSol: data.amountSol,
    });
    if (!sent.ok) {
      return { ok: false, message: sent.message };
    }

    // Step 3 — on-chain confirmation + verification before the ledger row
    // exists. A broadcast alone never creates claimable value.
    const { getSignatureStatus, verifyTransfer } = await import(
      "@/integrations/adapters/helius.server"
    );
    let confirmed = false;
    for (let i = 0; i < 12; i++) {
      const status = await getSignatureStatus(sent.signature);
      if (status.ok && status.data) {
        if (status.data.err) break;
        if (
          status.data.confirmationStatus === "confirmed" ||
          status.data.confirmationStatus === "finalized"
        ) {
          confirmed = true;
          break;
        }
      }
      await new Promise((r) => setTimeout(r, 2000));
    }
    if (!confirmed) {
      return {
        ok: false,
        message:
          "The test transfer was not confirmed on-chain, so nothing was added to the ledger.",
        signature: sent.signature,
      };
    }
    const check = await verifyTransfer(sent.signature, {
      from: sent.from,
      to: deposit.wallet.address,
      mint: null,
      amount: data.amountSol,
      decimals: 9,
    });
    if (!check.ok || !check.data.found || !check.data.succeeded) {
      return {
        ok: false,
        message: "On-chain verification did not match the intended transfer.",
        signature: sent.signature,
      };
    }

    // Claimable ledger row, idempotent on the tx signature.
    const { error: ledgerError } = await db.from("identity_ledger").insert({
      recipient_id: recipient.id,
      provider: recipient.provider,
      provider_user_id: recipient.provider_user_id,
      source: "payment",
      source_event_id: `live_test:${sent.signature}`,
      asset: "SOL",
      amount: data.amountSol,
      deposit_address: deposit.wallet.address,
      tx_signature: sent.signature,
      status: "deposited",
    });
    if (ledgerError) {
      return {
        ok: false,
        message: `The transfer landed on-chain but the ledger write failed: ${ledgerError.message}`,
        signature: sent.signature,
        depositAddress: deposit.wallet.address,
      };
    }

    await db.from("audit_log").insert({
      actor_id: userId,
      action: "claim.live_deposit_test",
      entity: "identity_ledger",
      entity_id: recipient.id,
      metadata: {
        provider: recipient.provider,
        handle: recipient.handle,
        deposit_address: deposit.wallet.address,
        amount: data.amountSol,
        signature: sent.signature,
      },
    });

    return {
      ok: true,
      message: `Funded @${recipient.handle}'s deposit wallet with ${data.amountSol} SOL. Open Claim and claim it to finish the test.`,
      signature: sent.signature,
      depositAddress: deposit.wallet.address,
      amountSol: data.amountSol,
      explorerUrl: `https://solscan.io/tx/${sent.signature}`,
    };
  });
