import { createServerFn } from "@tanstack/react-start";

/**
 * Public, read-only proof that AUTH's embedded wallets really run on Turnkey.
 *
 * Calls Turnkey's `getWhoami` live and reports only non-sensitive facts:
 * the organization name, a masked organization ID, the API host and how many
 * Solana wallets have been provisioned. API keys are never read client-side,
 * never returned and never logged.
 */

export interface TurnkeyProof {
  configured: boolean;
  reachable: boolean;
  apiHost: string;
  organizationName: string | null;
  /** Masked: first and last 4 characters only. */
  organizationIdMasked: string | null;
  walletsProvisioned: number | null;
  checkedAt: string;
  message?: string;
}

function mask(id: string): string {
  if (id.length <= 10) return "••••";
  return `${id.slice(0, 4)}…${id.slice(-4)}`;
}

export const turnkeyProof = createServerFn({ method: "GET" }).handler(
  async (): Promise<TurnkeyProof> => {
    const apiHost = "api.turnkey.com";
    const checkedAt = new Date().toISOString();

    const organizationId = process.env["TURNKEY_ORGANIZATION_ID"];
    const apiPublicKey = process.env["TURNKEY_API_PUBLIC_KEY"];
    const apiPrivateKey = process.env["TURNKEY_API_PRIVATE_KEY"];

    if (!organizationId || !apiPublicKey || !apiPrivateKey) {
      return {
        configured: false,
        reachable: false,
        apiHost,
        organizationName: null,
        organizationIdMasked: null,
        walletsProvisioned: null,
        checkedAt,
        message: "Turnkey credentials are not configured on this deployment.",
      };
    }

    let organizationName: string | null = null;
    let reachable = false;
    let message: string | undefined;
    try {
      const { Turnkey } = await import("@turnkey/sdk-server");
      const client = new Turnkey({
        apiBaseUrl: `https://${apiHost}`,
        apiPublicKey,
        apiPrivateKey,
        defaultOrganizationId: organizationId,
      }).apiClient();
      const who = await client.getWhoami({ organizationId });
      organizationName = who.organizationName ?? null;
      reachable = true;
    } catch {
      // Never surface provider error details — they can echo credentials.
      message = "Turnkey did not respond to the verification call.";
    }

    let walletsProvisioned: number | null = null;
    try {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const { count } = await supabaseAdmin
        .from("embedded_wallets")
        .select("id", { count: "exact", head: true })
        .eq("provider", "turnkey");
      walletsProvisioned = count ?? 0;
    } catch {
      walletsProvisioned = null;
    }

    return {
      configured: true,
      reachable,
      apiHost,
      organizationName,
      organizationIdMasked: mask(organizationId),
      walletsProvisioned,
      checkedAt,
      ...(message ? { message } : {}),
    };
  },
);
