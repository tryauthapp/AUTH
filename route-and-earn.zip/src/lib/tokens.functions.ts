import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { ADDRESS_RE } from "@/lib/solana";
import { normalizeUrl } from "@/lib/links";
import {
  type SocialProvider,
  isSocialProvider,
  normalizeSocialHandle,
  providerMeta,
} from "@/lib/social/providers";
import {
  LAUNCH_FEE_ADDRESS,
  MIN_DEV_BUY_SOL,
  requiredLamportsForLaunch,
  SIGNATURE_RE,
} from "@/lib/launch-fee";

/**
 * Records a confirmed, reserved launch-fee payment against the launch attempt
 * ledger so a later failure can be accounted for honestly.
 */
/**
 * Where a launcher's optional dev-buy SOL must be sent: always the account that
 * actually executes the buy. AUTH's launch-wallet balance is infrastructure
 * funding for network/provider costs and is never spent on a user's dev buy.
 */
async function devBuyFundingAddress(): Promise<string> {
  const { pumpfunDevBuyFundingAddress } = await import(
    "@/integrations/adapters/pumpfun.server"
  );
  return pumpfunDevBuyFundingAddress() ?? LAUNCH_FEE_ADDRESS;
}

async function recordFundedAttempt(
  userId: string,
  launchKey: string,
  signature: string,
  payer: string | null,
  lamports: number,
) {
  const { recordFunded } = await import("@/lib/launch-attempts.server");
  await recordFunded({ userId, launchKey, signature, payer, lamports });
}



/**
 * Token registration and real on-chain reads for tokens registered through
 * AUTH. A mint is only accepted once it is confirmed to exist on mainnet, so
 * registered tokens are never fabricated.
 */

export const verifyMint = createServerFn({ method: "POST" })
  .inputValidator((input: { mint: string }) => {
    if (!ADDRESS_RE.test(input.mint.trim())) throw new Error("That is not a Solana address.");
    return { mint: input.mint.trim() };
  })
  .handler(async ({ data }) => {
    const { getMintInfo, heliusConfigured } = await import(
      "@/integrations/adapters/helius.server"
    );
    if (!heliusConfigured()) {
      return { ok: false as const, message: "On-chain verification is unavailable right now." };
    }
    const info = await getMintInfo(data.mint);
    if (!info.ok) return { ok: false as const, message: info.message };
    if (!info.data) {
      return { ok: false as const, message: "No SPL token mint exists at that address on mainnet." };
    }
    return {
      ok: true as const,
      mint: info.data.mint,
      decimals: info.data.decimals,
      supply: info.data.supply,
    };
  });

/** Public: real mainnet activity for a registered mint. */
export const getMintOverview = createServerFn({ method: "POST" })
  .inputValidator((input: { mint: string }) => {
    if (!ADDRESS_RE.test(input.mint.trim())) throw new Error("Invalid mint address.");
    return { mint: input.mint.trim() };
  })
  .handler(async ({ data }) => {
    const { getMintInfo, getRecentSignatures, heliusConfigured } = await import(
      "@/integrations/adapters/helius.server"
    );
    if (!heliusConfigured()) {
      return { ok: false as const, message: "On-chain reads are not configured.", supply: null, decimals: null, signatures: [] };
    }
    const [info, sigs] = await Promise.all([
      getMintInfo(data.mint),
      getRecentSignatures(data.mint, 12),
    ]);
    return {
      ok: true as const,
      message: null,
      supply: info.ok ? (info.data?.supply ?? null) : null,
      decimals: info.ok ? (info.data?.decimals ?? null) : null,
      signatures: sigs.ok
        ? sigs.data.map((s) => ({
            signature: s.signature,
            blockTime: s.blockTime,
            succeeded: !s.err,
          }))
        : [],
    };
  });

export interface LaunchTokenInput {
  handle: string;
  /** Platform the creator-fee recipient lives on. Defaults to X. */
  provider?: string;
  /** Immutable platform-side ID from the server-side profile lookup. */
  platformUserId?: string | null;
  displayName?: string | null;
  avatarUrl?: string | null;
  bio?: string | null;
  /** Canonical X user ID from the server-side profile lookup, when resolved. */
  xUserId?: string | null;
  xDisplayName?: string | null;
  xAvatarUrl?: string | null;
  xBio?: string | null;
  symbol: string;
  name: string;
  description: string;
  imageUrl: string | null;
  imagePath: string | null;
  /** Optional extra SOL the dev supplies to buy their own new token. */
  devBuySol: string;
  /**
   * The launcher's OWN Solana wallet, where the dev-buy tokens must end up.
   * Required whenever a dev buy is chosen: AUTH's execution wallet is never
   * the beneficial owner of that supply.
   */
  devBuyDestination?: string;
  /** Client-generated key so a double submit cannot launch twice. */
  launchKey: string;
  /** The previous (failed) attempt this launch is a retry of, for audit history. */
  retryOfLaunchKey?: string;
  websiteUrl: string;
  xUrl: string;
  telegramUrl: string;
  communityUrl: string;
  /** Mainnet signature of the confirmed dev-buy payment, when a dev buy was chosen. */
  feeSignature: string;
  /**
   * Creator-fee asset for this launch: the pump.fun pair the recipient's
   * rewards are collected and paid in. AUTH supports SOL and USDC only.
   */
  rewardAsset: string;
}

/**
 * Creates a brand-new token through pump.fun on Solana mainnet and indexes the
 * mint the launch actually produced. The caller never supplies a mint: it comes
 * back from the launch transaction and is verified on-chain before it is saved.
 */
export const launchToken = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: LaunchTokenInput) => {
    const provider = isSocialProvider(input.provider ?? "x")
      ? (input.provider as SocialProvider) ?? "x"
      : "x";
    const providerRow = providerMeta(provider)!;
    const handle = normalizeSocialHandle(provider, input.handle).toLowerCase();
    if (!providerRow.handlePattern.test(handle)) {
      throw new Error(`Enter a valid ${providerRow.label} username. ${providerRow.handleHint}`);
    }
    if (!input.symbol.trim()) throw new Error("Enter a token symbol.");
    const rewardAsset = (input.rewardAsset ?? "").trim().toLowerCase();
    if (rewardAsset !== "sol" && rewardAsset !== "usdc") {
      throw new Error("Choose SOL or USDC for creator rewards.");
    }
    return {
      ...input,
      provider,
      rewardAsset: rewardAsset as "sol" | "usdc",
      handle,
      symbol: input.symbol.trim().toUpperCase().slice(0, 12),
      name: (input.name.trim() || input.symbol.trim().toUpperCase()).slice(0, 60),
      description: input.description.trim().slice(0, 600),
      websiteUrl: normalizeUrl(input.websiteUrl, "Website URL"),
      xUrl: normalizeUrl(input.xUrl, "X URL"),
      telegramUrl: normalizeUrl(input.telegramUrl, "Telegram URL"),
      communityUrl: normalizeUrl(input.communityUrl, "Community URL"),
      devBuySol: (() => {
        const raw = (input.devBuySol ?? "").toString().trim();
        // Every new launch requires a launcher-funded dev buy. This is enforced
        // here, server-side, and never trusted from the browser alone.
        if (!raw || raw === ".") {
          throw new Error(`A dev buy of at least ${MIN_DEV_BUY_SOL} SOL is required to launch.`);
        }
        // Lamport precision: at most 9 decimals, sane upper bound.
        if (!/^\d{1,4}(\.\d{1,9})?$/.test(raw)) {
          throw new Error("Enter a dev buy amount in SOL with up to 9 decimal places.");
        }
        const value = Number(raw);
        if (!Number.isFinite(value) || value < MIN_DEV_BUY_SOL) {
          throw new Error(`The minimum dev buy is ${MIN_DEV_BUY_SOL} SOL.`);
        }
        if (value > 100) throw new Error("Dev buy is capped at 100 SOL.");
        return value;
      })(),
      launchKey: (() => {
        const key = (input.launchKey ?? "").trim().slice(0, 64);
        if (!key) throw new Error("This launch attempt is missing its secure reference. Refresh and try again.");
        return key;
      })(),
      feeSignature: (input.feeSignature ?? "").trim(),
      retryOfLaunchKey: (input.retryOfLaunchKey ?? "").trim().slice(0, 64),
      devBuyDestination: (() => {
        const raw = (input.devBuyDestination ?? "").trim();
        if (!raw) return "";
        if (!ADDRESS_RE.test(raw)) {
          throw new Error("Enter a valid Solana address for your dev-buy tokens.");
        }
        return raw;
      })(),
    };
  })
  .handler(async ({ data, context }) => {
    const { enforceRateLimit } = await import("@/lib/rate-limit.server");
    enforceRateLimit("launch-token", 6, 300_000);
    const { userId } = context;

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const attempts = await import("@/lib/launch-attempts.server");
    // AUTH charges no launch fee. SOL is only required when the launcher chose
    // the required dev buy, and it is exactly that dev-buy amount.
    const expectedFeeLamports = requiredLamportsForLaunch(data.launchKey, data.devBuySol);
    const requiresPayment = expectedFeeLamports > 0;

    if (requiresPayment) {
      if (!SIGNATURE_RE.test(data.feeSignature)) {
        // Nothing has been charged at this point: no payment was ever matched.
        return {
          ok: false as const,
          message: "The dev buy has not been paid yet.",
          launchKey: data.launchKey,
          funded: false,
        };
      }
      // The payment must have been reserved to this launcher, so a signature
      // copied from someone else's transaction cannot unlock a launch.
      const { data: reservation } = await supabaseAdmin
        .from("processed_events")
        .select("id")
        .eq("source", "launch_fee")
        .eq("external_id", `${data.feeSignature}:${userId}:${data.launchKey}`)
        .maybeSingle();
      if (!reservation) {
        return {
          ok: false as const,
          message: "The dev buy has not been paid yet.",
          launchKey: data.launchKey,
          funded: false,
        };
      }

      const { verifySolCredit } = await import("@/integrations/adapters/helius.server");
      const paid = await verifySolCredit(
        data.feeSignature,
        await devBuyFundingAddress(),
        expectedFeeLamports,
      );
      if (!paid.ok) {
        return { ok: false as const, message: paid.message, launchKey: data.launchKey, funded: false };
      }
      if (!paid.data.found || !paid.data.succeeded || paid.data.creditedLamports !== expectedFeeLamports) {
        return {
          ok: false as const,
          message: "That dev-buy payment could not be confirmed on mainnet.",
          launchKey: data.launchKey,
          funded: false,
        };
      }

      // Spend the payment exactly once, globally. A second launch on the same
      // payment (retry, refresh, replay) is rejected before any SOL moves.
      const { error: spendError } = await supabaseAdmin
        .from("processed_events")
        .insert({ source: "launch_fee_spent", external_id: data.feeSignature });
      if (spendError) {
        return {
          ok: false as const,
          message: "That dev-buy payment was already used for a launch. Send a new payment to launch again.",
          launchKey: data.launchKey,
          funded: false,
        };
      }

      // From here on AUTH has a confirmed, reserved payment for this exact
      // launch attempt. Every later outcome is recorded against it.
      await attempts.recordFunded({
        userId,
        launchKey: data.launchKey,
        signature: data.feeSignature,
        payer: null,
        lamports: expectedFeeLamports,
      });
    }

    // Append-only audit timeline for this attempt. Redacted server-side.
    const { launchAuditRecorder } = await import("@/lib/launch-audit.server");
    const audit = launchAuditRecorder(userId, data.launchKey, "launch");

    const fail = async (message: string, launchSignature?: string | null) => {
      await attempts.recordFailed({
        userId,
        launchKey: data.launchKey,
        reason: message,
        launchSignature: launchSignature ?? null,
      });
      await audit("failure", "fail", message, { launchSignature: launchSignature ?? null });
      return { ok: false as const, message, launchKey: data.launchKey, funded: requiresPayment };
    };




    // Dev-buy destination: the launcher's OWN wallet, proven before anything is
    // broadcast. AUTH's execution wallet only ever holds that supply in transit,
    // and a dev buy is refused outright when it cannot be forwarded out.
    let devBuyDestination: string | null = null;
    if (data.devBuySol > 0) {
      const { pumpfunDevBuyAutoDelivery } = await import(
        "@/integrations/adapters/pumpfun.server"
      );
      if (!pumpfunDevBuyAutoDelivery()) {
        return {
          ok: false as const,
          message:
            "Dev buys are unavailable right now: AUTH cannot forward the purchased tokens to your own wallet on the current provider path, and it will not hold them for you. Launch with a dev buy of 0 instead.",
          launchKey: data.launchKey,
          funded: requiresPayment,
        };
      }
      const requested = data.devBuyDestination;
      if (!requested) {
        return {
          ok: false as const,
          message: "Add your own Solana wallet address to receive the dev-buy tokens.",
          launchKey: data.launchKey,
          funded: requiresPayment,
        };
      }
      // Ownership proof: either a wallet this user has verified with a signature,
      // or the exact wallet that funded this dev buy on-chain.
      const { data: attemptRow } = await supabaseAdmin
        .from("launch_attempts")
        .select("fee_payer")
        .eq("user_id", userId)
        .eq("launch_key", data.launchKey)
        .maybeSingle();
      const { data: ownedWallet } = await supabaseAdmin
        .from("wallets")
        .select("address")
        .eq("user_id", userId)
        .eq("address", requested)
        .not("verified_at", "is", null)
        .maybeSingle();
      const provenByFunding = Boolean(attemptRow?.fee_payer) && attemptRow?.fee_payer === requested;
      if (!ownedWallet && !provenByFunding) {
        return {
          ok: false as const,
          message:
            "That dev-buy wallet is not proven to be yours. Use a wallet you have verified in your profile, or the same wallet you sent the dev-buy SOL from.",
          launchKey: data.launchKey,
          funded: requiresPayment,
        };
      }
      devBuyDestination = requested;
    }

    // One launch per submit: claim the key before spending any SOL. A repeat
    // submit (double click, refresh) must never launch and dev-buy twice — but
    // a historical failed attempt must never block a retry forever either, so a
    // collision is resolved against Solana instead of dead-ending.
    if (data.launchKey) {
      const claimId = `${userId}:${data.launchKey}`;
      const { error: claimError } = await supabaseAdmin
        .from("processed_events")
        .insert({ source: "token_launch", external_id: claimId });
      if (claimError) {
        const { reconcileLaunchAttempt } = await import("@/lib/launch-reconcile.server");
        const prior = await reconcileLaunchAttempt(userId, data.launchKey);
        if (prior.state === "confirmed" || prior.state === "in_flight") {
          return {
            ok: false as const,
            message:
              prior.state === "confirmed"
                ? "That launch already went through. Open the token instead of launching again."
                : "Launch already in progress. Give it a moment before trying again.",
            launchKey: data.launchKey,
            funded: requiresPayment,
            state: prior.state,
            retryable: false,
            priorMint: prior.mint,
            priorSignature: prior.launchSignature,
          };
        }
        // Nothing survived on-chain: release the stale claim and retry cleanly.
        await supabaseAdmin
          .from("processed_events")
          .delete()
          .eq("source", "token_launch")
          .eq("external_id", claimId);
        const { error: reclaimError } = await supabaseAdmin
          .from("processed_events")
          .insert({ source: "token_launch", external_id: claimId });
        if (reclaimError) {
          return {
            ok: false as const,
            message: "Launch already in progress. Give it a moment before trying again.",
            launchKey: data.launchKey,
            funded: requiresPayment,
            state: "in_flight" as const,
            retryable: false,
            priorMint: null,
            priorSignature: null,
          };
        }
      }
    }

    // Fresh signed URL so the provider can pin the image to IPFS.
    let imageForMetadata = data.imageUrl;
    if (data.imagePath) {
      const { data: signed } = await supabaseAdmin.storage
        .from("token-images")
        .createSignedUrl(data.imagePath, 600);
      if (signed?.signedUrl) imageForMetadata = signed.signedUrl;
    }

    // Real pump.fun mainnet launch. If it is not genuinely available, stop here.
    await attempts.recordSubmitted({ userId, launchKey: data.launchKey, symbol: data.symbol });
    // Link the retry to the attempt it replaces. The old row is never touched:
    // it stays exactly as it was for audit history.
    if (data.retryOfLaunchKey && data.retryOfLaunchKey !== data.launchKey) {
      const { data: priorRow } = await supabaseAdmin
        .from("launch_attempts")
        .select("id")
        .eq("user_id", userId)
        .eq("launch_key", data.retryOfLaunchKey)
        .maybeSingle();
      await supabaseAdmin
        .from("launch_attempts")
        .update({
          retry_of_attempt_id: priorRow?.id ?? null,
          retry_of_launch_key: data.retryOfLaunchKey,
        })
        .eq("user_id", userId)
        .eq("launch_key", data.launchKey);
    }
    const {
      createPumpfunLaunch,
      pumpfunSupportsQuoteAsset,
      pumpfunQuoteAssetBlocker,
      PUMPFUN_DEV_BUY_CUSTODY_NOTE,
    } = await import("@/integrations/adapters/pumpfun.server");
    // Block before submitting anything if the provider cannot create this pair.
    if (!pumpfunSupportsQuoteAsset(data.rewardAsset)) {
      return await fail(pumpfunQuoteAssetBlocker(data.rewardAsset));
    }
    {
      const { launcherWalletStatus } = await import("@/lib/launcher-wallet.server");
      const { pumpfunSignerMode } = await import("@/integrations/adapters/pumpfun.server");
      const walletStatus = launcherWalletStatus();
      await audit(
        "config_validation",
        walletStatus.state === "configured" ? "pass" : "warn",
        walletStatus.state === "configured"
          ? "Launch wallet configured; signing server-side."
          : "No launch wallet secret available; using the provider-hosted execution path.",
        {
          signerMode: pumpfunSignerMode(),
          launchWallet: walletStatus.state === "configured" ? walletStatus.address : null,
          symbol: data.symbol,
          devBuySol: data.devBuySol,
          rewardAsset: data.rewardAsset,
        },
      );
    }
    const launch = await createPumpfunLaunch({
      name: data.name,
      symbol: data.symbol,
      description: data.description || null,
      imageUrl: imageForMetadata,
      website: data.websiteUrl,
      twitter: data.xUrl,
      telegram: data.telegramUrl,
      devBuySol: data.devBuySol,
      quoteAsset: data.rewardAsset,
      onStage: (stage, status, message, detail) => audit(stage, status, message, detail),
    });
    if (!launch.ok) return await fail(launch.message);

    // Verify the mint the launch produced actually exists on mainnet.
    const { getMintInfo } = await import("@/integrations/adapters/helius.server");
    let mintInfo: Awaited<ReturnType<typeof getMintInfo>> | null = null;
    for (let attempt = 0; attempt < 5; attempt++) {
      mintInfo = await getMintInfo(launch.mint);
      if (mintInfo.ok && mintInfo.data) break;
      await new Promise((r) => setTimeout(r, 2000));
    }
    if (!mintInfo || !mintInfo.ok || !mintInfo.data) {
      return await fail(
        `The launch transaction was submitted (${launch.signature}) but the mint is not yet visible on mainnet. Check the signature on Solscan before retrying.`,
        launch.signature,
      );
    }
    const chainMint = mintInfo.data;
    const mint = chainMint.mint;


    const { data: existingToken } = await supabaseAdmin
      .from("tokens")
      .select("id,mint")
      .eq("mint", mint)
      .maybeSingle();
    if (existingToken) {
      return await fail("That mint is already indexed on AUTH.", launch.signature);
    }




    const provider = data.provider;
    const platformUserId =
      (data.platformUserId ?? data.xUserId ?? "").trim() || null;
    const profileFields = {
      display_name: (data.displayName ?? data.xDisplayName)?.trim() || `@${data.handle}`,
      avatar_url: (data.avatarUrl ?? data.xAvatarUrl)?.trim() || null,
      bio: (data.bio ?? data.xBio)?.trim() || null,
    };

    let recipientId: string;
    // The immutable platform ID is the canonical identity; handles are mutable.
    const { data: byPlatformId } = platformUserId
      ? await supabaseAdmin
          .from("recipients")
          .select("id")
          .eq("provider", provider)
          .eq("provider_user_id", platformUserId)
          .maybeSingle()
      : { data: null };
    const { data: recipient } = byPlatformId
      ? { data: byPlatformId }
      : await supabaseAdmin
          .from("recipients")
          .select("id")
          .eq("provider", provider)
          .ilike("handle", data.handle)
          .maybeSingle();
    if (recipient) {
      recipientId = recipient.id;
      await supabaseAdmin
        .from("recipients")
        .update({
          handle: data.handle,
          ...(platformUserId
            ? {
                provider_user_id: platformUserId,
                ...(provider === "x" ? { x_user_id: platformUserId } : {}),
                ...profileFields,
              }
            : {}),
        })
        .eq("id", recipientId);
    } else {
      const { data: created, error } = await supabaseAdmin
        .from("recipients")
        .insert({
          handle: data.handle,
          provider,
          is_demo: false,
          provider_user_id: platformUserId,
          ...(provider === "x" ? { x_user_id: platformUserId } : {}),
          ...profileFields,
        })
        .select("id")
        .single();
      if (error) return await fail(error.message, launch.signature);
      recipientId = created.id;
    }

    // Ownership split, recorded explicitly so no later read has to guess:
    //  - dev-buy SOL     -> funded by the launcher, never by AUTH
    //  - dev-buy tokens  -> the launcher (this user), delivered to their wallet
    //  - creator fees    -> the canonical social identity (recipientId)
    //  - execution wallet-> infrastructure that pays network cost, owns nothing
    const { data: fundingAttempt } = await supabaseAdmin
      .from("launch_attempts")
      .select("fee_payer,fee_signature,fee_lamports_received")
      .eq("user_id", userId)
      .eq("launch_key", data.launchKey)
      .maybeSingle();
    const launcherWallet = fundingAttempt?.fee_payer ?? null;
    const devBuyFundingSignature = fundingAttempt?.fee_signature ?? null;
    const devBuyFundingLamports = Number(fundingAttempt?.fee_lamports_received ?? 0);
    const { LAUNCH_INFRASTRUCTURE_COST_LAMPORTS, PUMPFUN_DEV_BUY_PENDING_NOTE } = await import(
      "@/integrations/adapters/pumpfun.server"
    );

    // Deliver the dev-buy allocation to the launcher's own wallet. The AUTH
    // launch wallet must never end up the beneficial owner of those tokens.
    let devBuyDeliveryStatus = data.devBuySol > 0 ? "pending_delivery" : "none";
    let devBuyDeliverySignature: string | null = null;
    let devBuyDeliveryNote: string | null = null;

    if (data.devBuySol > 0) {
      if (launch.signerMode === "external_wallet" && devBuyDestination) {
        const { deliverDevBuyTokens } = await import("@/lib/dev-buy-delivery.server");
        const delivery = await deliverDevBuyTokens({ mint, destination: devBuyDestination });
        if (delivery.ok) {
          devBuyDeliveryStatus = "delivered";
          devBuyDeliverySignature = delivery.signature;
          await audit("confirmation", "pass", "Dev-buy tokens forwarded to the launcher's wallet.", {
            mint,
            destination: devBuyDestination,
            signature: delivery.signature,
          });
        } else {
          devBuyDeliveryStatus = "pending_delivery";
          devBuyDeliveryNote = delivery.message;
          await audit("confirmation", "warn", "Dev-buy tokens are not delivered yet.", {
            mint,
            destination: devBuyDestination,
            reason: delivery.message,
          });
        }
      } else if (!devBuyDestination) {
        devBuyDeliveryStatus = "blocked_no_destination";
        devBuyDeliveryNote =
          "AUTH has no launcher wallet address on record for this dev buy, so the purchased tokens could not be delivered automatically. They belong to you and are held pending settlement.";
      } else {
        devBuyDeliveryStatus = "pending_manual_settlement";
        devBuyDeliveryNote = PUMPFUN_DEV_BUY_CUSTODY_NOTE;
      }
      if (devBuyDeliveryStatus === "pending_delivery" && !devBuyDeliveryNote) {
        devBuyDeliveryNote = PUMPFUN_DEV_BUY_PENDING_NOTE;
      }
    }

    const { data: token, error: tokenError } = await supabaseAdmin
      .from("tokens")
      .insert({
        mint,
        symbol: data.symbol,
        name: data.name,
        description: data.description || null,
        image_url: data.imageUrl,
        website_url: data.websiteUrl,
        x_url: data.xUrl,
        telegram_url: data.telegramUrl,
        community_url: data.communityUrl,
        launch_signature: launch.signature,
        source: "pumpfun",
        created_by: userId,
        is_demo: false,
        // Provider infrastructure that signed the transaction. Holding the
        // execution wallet is not an ownership claim by AUTH or the provider.
        launch_wallet: launch.launchWallet,
        execution_provider: "pumpportal",
        signer_mode: launch.signerMode,
        // The launcher: owns the dev-buy allocation they funded, and nothing else.
        launcher_user_id: userId,
        launcher_wallet: launcherWallet,
        dev_buy_owner_wallet: devBuyDestination ?? launch.devBuyOwnerWallet,
        dev_buy_sol: data.devBuySol,
        dev_buy_owner_user_id: data.devBuySol > 0 ? userId : null,
        dev_buy_delivery_status: devBuyDeliveryStatus,
        dev_buy_delivery_signature: devBuyDeliverySignature,
        dev_buy_delivered_at: devBuyDeliverySignature ? new Date().toISOString() : null,
        dev_buy_delivery_note: devBuyDeliveryNote,
        dev_buy_destination_wallet: devBuyDestination,
        dev_buy_funding_wallet: data.devBuySol > 0 ? launcherWallet : null,
        dev_buy_funding_signature: data.devBuySol > 0 ? devBuyFundingSignature : null,
        dev_buy_funding_lamports: data.devBuySol > 0 ? devBuyFundingLamports : 0,
        // AUTH infrastructure funds the network cost only — never the dev buy.
        launch_infrastructure_cost_lamports: LAUNCH_INFRASTRUCTURE_COST_LAMPORTS,
        // The canonical social identity: owns creator-fee entitlement only.
        creator_fee_recipient_id: recipientId,
        verified_on_chain_at: new Date().toISOString(),
        decimals: chainMint.decimals,
        supply: chainMint.supply,
      })
      .select("id,mint")
      .single();
    if (tokenError) return await fail(tokenError.message, launch.signature);


    await supabaseAdmin
      .from("token_recipients")
      .insert({ token_id: token.id, recipient_id: recipientId, share_percent: 100 });

    // Routing config for the recipient (replaces any existing active config).
    await supabaseAdmin
      .from("routing_configs")
      .update({ is_active: false })
      .eq("recipient_id", recipientId);

    const { data: config, error: configError } = await supabaseAdmin
      .from("routing_configs")
      .insert({ recipient_id: recipientId, name: `${data.symbol} routing`, is_active: true })
      .select("id")
      .single();
    if (configError) return await fail(configError.message, launch.signature);

    // One destination only: the creator-fee asset the launch pair pays out in.
    await supabaseAdmin.from("routing_splits").insert({
      config_id: config.id,
      destination: data.rewardAsset as never,
      label: data.rewardAsset === "usdc" ? "Creator rewards in USDC" : "Creator rewards in SOL",
      percent: 100,
      address: null,
      sort_order: 0,
    });

    await supabaseAdmin.from("audit_log").insert({
      actor_id: userId,
      action: "token.launched",
      entity: "tokens",
      entity_id: token.id,
      metadata: {
        mint,
        handle: data.handle,
        provider,
        execution_wallet: launch.launchWallet,
        execution_provider: "pumpportal",
        signer_mode: launch.signerMode,
        dev_buy_owner_wallet: devBuyDestination ?? launch.devBuyOwnerWallet,
        launcher_user_id: userId,
        dev_buy_sol: data.devBuySol,
        dev_buy_owner_user_id: data.devBuySol > 0 ? userId : null,
        dev_buy_delivery_status: devBuyDeliveryStatus,
        dev_buy_delivery_signature: devBuyDeliverySignature,
        dev_buy_funding_wallet: data.devBuySol > 0 ? launcherWallet : null,
        dev_buy_funding_signature: data.devBuySol > 0 ? devBuyFundingSignature : null,
        launch_infrastructure_cost_lamports: LAUNCH_INFRASTRUCTURE_COST_LAMPORTS,
        creator_fee_recipient_id: recipientId,
        source: "pumpfun",
        signature: launch.signature,
        network: "mainnet-beta",
      },
    });


    await attempts.recordConfirmed({
      userId,
      launchKey: data.launchKey,
      mint: token.mint,
      launchSignature: launch.signature,
      spentLamports: expectedFeeLamports,
      recipientId,
      executionProvider: "pumpportal",
      executionWallet: launch.launchWallet,
      devBuySol: data.devBuySol,
      devBuyDeliveryStatus,
      devBuyDeliveryNote,
      signerMode: launch.signerMode,
      launchWalletAddress: launch.launchWallet,
      devBuyOwnerWallet: devBuyDestination ?? launch.devBuyOwnerWallet,
      devBuyDeliverySignature,
      devBuyDestinationWallet: devBuyDestination,
      devBuyFundingWallet: data.devBuySol > 0 ? launcherWallet : null,
      devBuyFundingSignature: data.devBuySol > 0 ? devBuyFundingSignature : null,
      devBuyFundingLamports: data.devBuySol > 0 ? devBuyFundingLamports : 0,
      infrastructureCostLamports: LAUNCH_INFRASTRUCTURE_COST_LAMPORTS,
    });

    await audit("confirmation", "pass", "Mint verified on Solana mainnet and recorded.", {
      mint: token.mint,
      signature: launch.signature,
      signerMode: launch.signerMode,
      executionWallet: launch.launchWallet,
      devBuySol: data.devBuySol,
      devBuyDeliveryStatus,
      creatorFeeRecipientId: recipientId,
    });

    return {
      ok: true as const,
      mint: token.mint,
      recipientId,
      launchKey: data.launchKey,
      funded: requiresPayment,
      signature: launch.signature,
      devBuySol: data.devBuySol,
      devBuyDeliveryStatus,
      devBuyDeliveryNote,
      devBuyDeliverySignature,
      devBuyDestinationWallet: devBuyDestination,
      signerMode: launch.signerMode,
      launchWallet: launch.launchWallet,
    };
  });

/**
 * Watches the launch account on mainnet for the exact optional dev-buy amount
 * and claims that payment so it can only ever unlock one launch. AUTH charges
 * no launch fee, so this only runs when a dev buy was chosen.
 */
export const awaitLaunchFee = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { payer: string; launchKey: string; devBuySol: number }) => {
    const payer = String(input.payer ?? "").trim();
    if (payer && !/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(payer)) {
      throw new Error("Enter the Solana address you are paying from.");
    }
    const launchKey = String(input.launchKey ?? "").trim().slice(0, 64);
    if (!launchKey) throw new Error("This launch attempt is missing its secure reference. Refresh and try again.");
    const devBuySol = Number(input.devBuySol ?? 0);
    if (!Number.isFinite(devBuySol) || devBuySol < MIN_DEV_BUY_SOL) {
      throw new Error(`The minimum dev buy is ${MIN_DEV_BUY_SOL} SOL.`);
    }
    return { payer, launchKey, devBuySol };
  })
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Create a server-timestamped intent for this exact launch attempt. Credits
    // from before this point cannot be recycled to unlock a new launch.
    const intentId = `${context.userId}:${data.launchKey}`;
    let { data: intent } = await supabaseAdmin
      .from("processed_events")
      .select("processed_at")
      .eq("source", "launch_fee_intent")
      .eq("external_id", intentId)
      .maybeSingle();
    if (!intent) {
      await supabaseAdmin
        .from("processed_events")
        .insert({ source: "launch_fee_intent", external_id: intentId });
      const intentResult = await supabaseAdmin
        .from("processed_events")
        .select("processed_at")
        .eq("source", "launch_fee_intent")
        .eq("external_id", intentId)
        .maybeSingle();
      intent = intentResult.data;
    }
    if (!intent) {
      return { ok: false as const, paid: false, signature: null, message: "Could not start this launch payment check. Refresh and try again." };
    }
    const intentStartedAt = new Date(intent.processed_at).getTime();
    const expectedFeeLamports = requiredLamportsForLaunch(data.launchKey, data.devBuySol);

    // Restore only the payment reserved to this exact launch attempt. A spare
    // payment from another form/session/attempt must never unlock this one.
    const reservationSuffix = `:${context.userId}:${data.launchKey}`;
    const { data: reservedRows } = await supabaseAdmin
      .from("processed_events")
      .select("external_id")
      .eq("source", "launch_fee")
      .like("external_id", `%${reservationSuffix}`)
      .order("processed_at", { ascending: false })
      .limit(1);
    for (const row of reservedRows ?? []) {
      const signature = row.external_id.split(":")[0] ?? "";
      if (!SIGNATURE_RE.test(signature)) continue;
      const { data: spent } = await supabaseAdmin
        .from("processed_events")
        .select("id")
        .eq("source", "launch_fee_spent")
        .eq("external_id", signature)
        .maybeSingle();
      if (spent) continue;
      await recordFundedAttempt(context.userId, data.launchKey, signature, data.payer || null, expectedFeeLamports);
      return { ok: true as const, paid: true, signature, message: null };
    }

    if (!data.payer) {
      return { ok: true as const, paid: false, signature: null, message: null };
    }
    const { listRecentSolCredits, heliusConfigured } = await import(
      "@/integrations/adapters/helius.server"
    );
    if (!heliusConfigured()) {
      return { ok: false as const, paid: false, signature: null, message: "On-chain payment checks are unavailable right now." };
    }
    const credits = await listRecentSolCredits(await devBuyFundingAddress(), 15);
    if (!credits.ok) {
      return { ok: false as const, paid: false, signature: null, message: credits.message };
    }
    let sawOtherPayer = false;
    for (const c of credits.data) {
      // Only a payment sent from the address this launcher declared counts, so
      // every launch is tied to the wallet that paid for it. Each signature can
      // only ever unlock one launch.
      if (c.credited !== expectedFeeLamports) continue;
      // Allow a small clock/indexing margin, but reject old deposits made before
      // this launch attempt existed.
      if (!c.blockTime || c.blockTime * 1000 < intentStartedAt - 30_000) continue;
      const fromDeclared = c.payer === data.payer || c.senders.includes(data.payer);
      if (!fromDeclared) {
        sawOtherPayer = true;
        continue;
      }
      const { data: alreadySpent } = await supabaseAdmin
        .from("processed_events")
        .select("id")
        .eq("source", "launch_fee_spent")
        .eq("external_id", c.signature)
        .maybeSingle();
      if (alreadySpent) continue;
      const ownedEventId = `${c.signature}:${context.userId}:${data.launchKey}`;

      const { data: existing } = await supabaseAdmin
        .from("processed_events")
        .select("id")
        .eq("source", "launch_fee")
        .eq("external_id", ownedEventId)
        .maybeSingle();
      if (existing) {
        await recordFundedAttempt(context.userId, data.launchKey, c.signature, data.payer, expectedFeeLamports);
        return { ok: true as const, paid: true, signature: c.signature, message: null };
      }
      const { data: claimedByAnother } = await supabaseAdmin
        .from("processed_events")
        .select("external_id")
        .eq("source", "launch_fee")
        .like("external_id", `${c.signature}:%`)
        .maybeSingle();
      if (claimedByAnother) continue;
      const { error } = await supabaseAdmin
        .from("processed_events")
        .insert({ source: "launch_fee", external_id: ownedEventId });
      if (error) continue;
      await recordFundedAttempt(context.userId, data.launchKey, c.signature, data.payer, expectedFeeLamports);
      return { ok: true as const, paid: true, signature: c.signature, message: null };
    }
    return {
      ok: true as const,
      paid: false,
      signature: null,
      message: sawOtherPayer
        ? "We can see recent payments, but none from the address you entered. Check the address matches the wallet you paid from."
        : null,
    };
  });

/** Real availability of the pump.fun launch path. */
export const launchAvailability = createServerFn({ method: "GET" }).handler(async () => {
  const {
    pumpfunConfigured,
    pumpfunMissing,
    PUMPFUN_BLOCKER,
    PUMPFUN_SUPPORTED_QUOTE_ASSETS,
    pumpfunDevBuyFundingAddress,
    pumpfunSignerMode,
    pumpfunDevBuyAutoDelivery,
    LAUNCH_INFRASTRUCTURE_COST_LAMPORTS,
  } = await import("@/integrations/adapters/pumpfun.server");
  const ready = pumpfunConfigured();
  return {
    ready,
    supportedRewardAssets: [...PUMPFUN_SUPPORTED_QUOTE_ASSETS],
    missing: ready ? [] : pumpfunMissing(),
    message: ready ? null : PUMPFUN_BLOCKER,
    /** Where the launcher's optional dev-buy SOL is sent. Never AUTH's balance. */
    devBuyFundingAddress: pumpfunDevBuyFundingAddress(),
    signerMode: pumpfunSignerMode(),
    /** True when AUTH can forward the dev-buy tokens to the launcher itself. */
    devBuyAutoDelivery: pumpfunDevBuyAutoDelivery(),
    infrastructureCostLamports: LAUNCH_INFRASTRUCTURE_COST_LAMPORTS,
  };
});
