/**
 * Dev-buy token delivery (SERVER ONLY).
 *
 * A dev buy is funded by the launcher, so the purchased tokens belong to the
 * launcher. When AUTH's own launch wallet signs the pump.fun create transaction
 * (external-wallet signer mode), the newly bought tokens land in that wallet
 * first as a pure execution artefact. This module moves them out to the
 * launcher's own wallet immediately after the launch confirms, so the AUTH
 * launch wallet never becomes the beneficial owner.
 *
 * The launch wallet secret is read inside the signing step only and is never
 * logged or returned. Nothing here fabricates a signature: if the transfer does
 * not broadcast, the caller is told the delivery is still pending.
 */

import {
  ComputeBudgetProgram,
  Keypair,
  PublicKey,
  TransactionMessage,
  VersionedTransaction,
} from "@solana/web3.js";
import {
  TOKEN_PROGRAM_ID,
  TOKEN_2022_PROGRAM_ID,
  createAssociatedTokenAccountIdempotentInstruction,
  createTransferCheckedInstruction,
  getAssociatedTokenAddressSync,
} from "@solana/spl-token";
import { ADDRESS_RE } from "@/lib/solana";
import { loadLauncherKeypair } from "@/lib/launcher-wallet.server";
import {
  getLatestBlockhash,
  rpcEndpoint,
  sendRawTransactionBase64,
  getSignatureStatus,
} from "@/integrations/adapters/helius.server";

export type DevBuyDelivery =
  | {
      ok: true;
      signature: string;
      amountRaw: string;
      decimals: number;
      from: string;
      to: string;
    }
  | { ok: false; message: string; retryable: boolean };

interface OwnedTokenAccount {
  address: string;
  amountRaw: string;
  decimals: number;
  programId: PublicKey;
}

async function rpc<T>(method: string, params: unknown[]): Promise<T | null> {
  const endpoint = rpcEndpoint();
  if (!endpoint) return null;
  try {
    const res = await fetch(endpoint, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }),
    });
    if (!res.ok) return null;
    const json = (await res.json()) as { result?: T };
    return json.result ?? null;
  } catch {
    return null;
  }
}

/** The launch wallet's token account for this mint, with its real balance. */
async function findTokenAccount(
  owner: string,
  mint: string,
): Promise<OwnedTokenAccount | null> {
  for (const programId of [TOKEN_PROGRAM_ID, TOKEN_2022_PROGRAM_ID]) {
    const result = await rpc<{
      value: Array<{
        pubkey: string;
        account: {
          data: {
            parsed?: {
              info?: { tokenAmount?: { amount?: string; decimals?: number } };
            };
          };
        };
      }>;
    }>("getTokenAccountsByOwner", [
      owner,
      { mint, programId: programId.toBase58() },
      { encoding: "jsonParsed" },
    ]);
    const row = result?.value?.[0];
    const amount = row?.account?.data?.parsed?.info?.tokenAmount;
    if (row && amount?.amount && Number(amount.amount) > 0) {
      return {
        address: row.pubkey,
        amountRaw: amount.amount,
        decimals: Number(amount.decimals ?? 6),
        programId,
      };
    }
  }
  return null;
}

/**
 * Sends the whole dev-buy allocation from the launch (execution) wallet to the
 * launcher's own wallet. Only ever called for a launch where the launcher
 * funded the dev buy.
 */
export async function deliverDevBuyTokens(params: {
  mint: string;
  destination: string;
}): Promise<DevBuyDelivery> {
  const mint = params.mint.trim();
  const destination = params.destination.trim();
  if (!ADDRESS_RE.test(mint) || !ADDRESS_RE.test(destination)) {
    return {
      ok: false,
      message: "The dev-buy delivery destination is not a valid Solana address.",
      retryable: false,
    };
  }

  const launcher: Keypair | null = loadLauncherKeypair();
  if (!launcher) {
    return {
      ok: false,
      message:
        "Dev-buy tokens were bought by the execution wallet, but AUTH cannot sign a transfer out of it, so delivery is still pending.",
      retryable: true,
    };
  }
  const from = launcher.publicKey.toBase58();
  if (from === destination) {
    return {
      ok: false,
      message: "The delivery destination matches the execution wallet.",
      retryable: false,
    };
  }

  // Give the pump.fun buy a moment to settle before reading the balance.
  let source: OwnedTokenAccount | null = null;
  for (let attempt = 0; attempt < 6; attempt++) {
    source = await findTokenAccount(from, mint);
    if (source) break;
    await new Promise((r) => setTimeout(r, 2500));
  }
  if (!source) {
    return {
      ok: false,
      message:
        "The dev-buy tokens are not visible in the execution wallet yet, so nothing was transferred. Delivery stays pending until they are.",
      retryable: true,
    };
  }

  const mintKey = new PublicKey(mint);
  const destKey = new PublicKey(destination);
  const destAta = getAssociatedTokenAddressSync(
    mintKey,
    destKey,
    true,
    source.programId,
  );

  const blockhash = await getLatestBlockhash();
  if (!blockhash.ok) {
    return {
      ok: false,
      message: "Solana could not be reached to deliver the dev-buy tokens. Delivery stays pending.",
      retryable: true,
    };
  }

  const message = new TransactionMessage({
    payerKey: launcher.publicKey,
    recentBlockhash: blockhash.data.blockhash,
    instructions: [
      ComputeBudgetProgram.setComputeUnitPrice({ microLamports: 10_000 }),
      createAssociatedTokenAccountIdempotentInstruction(
        launcher.publicKey,
        destAta,
        destKey,
        mintKey,
        source.programId,
      ),
      createTransferCheckedInstruction(
        new PublicKey(source.address),
        mintKey,
        destAta,
        launcher.publicKey,
        BigInt(source.amountRaw),
        source.decimals,
        [],
        source.programId,
      ),
    ],
  }).compileToV0Message();

  const tx = new VersionedTransaction(message);
  tx.sign([launcher]);
  const sent = await sendRawTransactionBase64(
    Buffer.from(tx.serialize()).toString("base64"),
  );
  if (!sent.ok) {
    return {
      ok: false,
      message: `The dev-buy token transfer was rejected by Solana: ${sent.message}. Delivery stays pending.`,
      retryable: true,
    };
  }

  // Never report delivery from a broadcast alone: wait for Solana to confirm.
  let confirmed = false;
  for (let attempt = 0; attempt < 20; attempt++) {
    const status = await getSignatureStatus(sent.data);
    const value = status.ok ? status.data : null;
    if (value?.err) {
      return {
        ok: false,
        message:
          "The dev-buy token transfer failed on Solana, so nothing was delivered. Delivery stays pending.",
        retryable: true,
      };
    }
    if (value && (value.confirmationStatus === "confirmed" || value.confirmationStatus === "finalized")) {
      confirmed = true;
      break;
    }
    await new Promise((r) => setTimeout(r, 2000));
  }
  if (!confirmed) {
    return {
      ok: false,
      message:
        "The dev-buy token transfer was submitted but has not confirmed on Solana yet, so AUTH is not marking it delivered.",
      retryable: true,
    };
  }

  // Independent proof: the tokens are readable in the launcher's own wallet.
  const landed = await findTokenAccount(destination, mint);
  if (!landed || BigInt(landed.amountRaw) < BigInt(source.amountRaw)) {
    return {
      ok: false,
      message:
        "The dev-buy tokens are not yet readable in your wallet on-chain, so AUTH is not marking delivery complete.",
      retryable: true,
    };
  }

  return {
    ok: true,
    signature: sent.data,
    amountRaw: source.amountRaw,
    decimals: source.decimals,
    from,
    to: destination,
  };
}
