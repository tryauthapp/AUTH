import { SignerError, type SignedMessage, type TransactionSigner, type TransferPlan } from "./signer";

/**
 * Embedded (passkey / MPC) authorization adapter — AUTH's only signing path.
 *
 * A key is created and held by a non-custodial embedded-wallet provider and
 * unlocked by a device passkey. There is no browser extension to install and no
 * seed phrase to write down, and every transfer is still cryptographically
 * authorized by the person.
 *
 * AUTH never runs custody itself, never accepts or stores a private key or
 * seed phrase, and never signs on a user's behalf. Until a real provider is
 * configured this adapter stays inert and reports honestly as unavailable — it
 * never pretends a transfer was authorized.
 *
 * To enable: set VITE_EMBEDDED_WALLET_PROVIDER to the configured provider key
 * and implement the provider calls below against its SDK. Transaction building
 * already lives in ./transfer-tx and is provider-agnostic.
 */

export function embeddedProviderKey(): string | null {
  const value = import.meta.env["VITE_EMBEDDED_WALLET_PROVIDER"];
  return typeof value === "string" && value.trim() ? value.trim() : null;
}

export function embeddedWalletConfigured(): boolean {
  return embeddedProviderKey() !== null;
}

export const AUTHORIZATION_UNAVAILABLE_MESSAGE =
  "Secure authorization isn't switched on yet. AUTH will never sign for you, so real transfers stay blocked until the embedded signing provider is live.";

function notConfiguredError(): SignerError {
  return new SignerError(AUTHORIZATION_UNAVAILABLE_MESSAGE, "unavailable");
}

export const embeddedSigner: TransactionSigner = {
  key: "passkey",
  name: "Passkey account",
  kind: "browser_wallet",
  isAvailable() {
    // Requires both a configured provider and platform passkey support.
    return (
      embeddedWalletConfigured() &&
      typeof window !== "undefined" &&
      typeof window.PublicKeyCredential !== "undefined"
    );
  },
  connect(): Promise<string> {
    return Promise.reject(notConfiguredError());
  },
  disconnect(): Promise<void> {
    return Promise.resolve();
  },
  getAddress(): string | null {
    return null;
  },
  signMessage(_message: string): Promise<SignedMessage> {
    return Promise.reject(notConfiguredError());
  },
  signAndSendTransfer(_plan: TransferPlan): Promise<string> {
    return Promise.reject(notConfiguredError());
  },
};
