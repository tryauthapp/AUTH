import { SignerError, type TransferPlan } from "./signer";

/**
 * Chain-side transaction construction, independent of who authorizes it.
 *
 * The transfer plan is produced server-side (destination, mint, token program,
 * decimals, blockhash) so the browser cannot substitute a different token or
 * recipient. Whichever signer is active only ever authorizes this object.
 */

/**
 * Exact human-units → base-units conversion. Floating point multiplication
 * (`amount * 10 ** decimals`) loses precision on 8- and 9-decimal assets, so the
 * amount is converted through its decimal string instead.
 */
export function toBaseUnits(amount: number, decimals: number): bigint {
  if (!Number.isFinite(amount) || amount < 0) throw new SignerError("Invalid amount.");
  const fixed = amount.toFixed(decimals);
  const [whole, fraction = ""] = fixed.split(".");
  const digits = `${whole}${fraction.padEnd(decimals, "0")}`.replace(/^0+(?=\d)/, "");
  return BigInt(digits);
}

/** Builds the unsigned Solana transaction for a server-issued transfer plan. */
export async function buildTransferTransaction(from: string, plan: TransferPlan) {
  const isNative = !plan.mint;
  const [{ PublicKey, Transaction, SystemProgram }, splToken] = await Promise.all([
    import("@solana/web3.js"),
    isNative ? Promise.resolve(null) : import("@solana/spl-token"),
  ]);

  const payer = new PublicKey(from);
  const destination = new PublicKey(plan.to);
  const tx = new Transaction({
    feePayer: payer,
    blockhash: plan.blockhash,
    lastValidBlockHeight: plan.lastValidBlockHeight,
  });

  if (isNative) {
    tx.add(
      SystemProgram.transfer({
        fromPubkey: payer,
        toPubkey: destination,
        lamports: toBaseUnits(plan.amount, 9),
      }),
    );
    return tx;
  }

  if (!splToken) throw new SignerError("Token transfer support failed to load.");
  const {
    TOKEN_PROGRAM_ID,
    getAssociatedTokenAddressSync,
    createAssociatedTokenAccountInstruction,
    createTransferCheckedInstruction,
  } = splToken;

  const mint = new PublicKey(plan.mint!);
  const programId = new PublicKey(plan.tokenProgram ?? TOKEN_PROGRAM_ID.toBase58());
  if (!programId.equals(TOKEN_PROGRAM_ID)) {
    throw new SignerError(`${plan.asset} uses a token program this transfer path does not support.`);
  }
  const source = getAssociatedTokenAddressSync(mint, payer, false, programId);
  const dest = getAssociatedTokenAddressSync(mint, destination, true, programId);

  if (!plan.destinationTokenAccountExists) {
    tx.add(createAssociatedTokenAccountInstruction(payer, dest, destination, mint, programId));
  }
  tx.add(
    createTransferCheckedInstruction(
      source,
      mint,
      dest,
      payer,
      toBaseUnits(plan.amount, plan.decimals),
      plan.decimals,
      [],
      programId,
    ),
  );
  return tx;
}
