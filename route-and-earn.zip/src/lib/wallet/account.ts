import {
  embeddedSigner,
  embeddedProviderKey,
  embeddedWalletConfigured,
  AUTHORIZATION_UNAVAILABLE_MESSAGE,
} from "./embedded-signer";
import type { TransactionSigner } from "./signer";

/**
 * Payment account abstraction.
 *
 * AUTH is walletless: a person authorizes a transfer with a device passkey
 * through a non-custodial embedded-wallet provider. There is no browser
 * extension, no seed phrase, no AUTH login, and no key ever held by AUTH.
 *
 * The signer interface stays modular so a different audited provider (passkey,
 * MPC, session keys) can be swapped in without touching product code. Until one
 * is configured the walletless path reports honestly as "planned" — AUTH
 * never pretends a transaction was authorized.
 */

export type AccountKind = "walletless";
export type WalletlessStatus = "live" | "planned";

export function walletlessStatus(): WalletlessStatus {
  return embeddedWalletConfigured() && embeddedSigner.isAvailable() ? "live" : "planned";
}

export function walletlessProvider(): string | null {
  return embeddedProviderKey();
}

/** Resolves a signer key to an implementation. */
export function resolveSigner(key: string): TransactionSigner | null {
  return key === embeddedSigner.key ? embeddedSigner : null;
}

export const WALLETLESS_PLANNED_MESSAGE = AUTHORIZATION_UNAVAILABLE_MESSAGE;
