import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { embeddedSigner } from "./embedded-signer";
import { walletlessStatus, type AccountKind, type WalletlessStatus } from "./account";
import type { TransactionSigner } from "./signer";

const STORAGE_KEY = "crypto-account";

interface WalletState {
  /** Authorized address of the walletless account, when one exists. */
  address: string | null;
  signer: TransactionSigner | null;
  kind: AccountKind | null;
  /** True while the passkey prompt is open. */
  connecting: boolean;
  /** Honest status of the walletless (passkey) authorization path. */
  walletless: WalletlessStatus;
  /** Creates or unlocks the passkey account. */
  authorize: () => Promise<string>;
  /** Forgets the account on this device. No funds move, nothing is deleted on-chain. */
  forget: () => Promise<void>;
}

const WalletContext = createContext<WalletState | null>(null);

export function WalletProvider({ children }: { children: React.ReactNode }) {
  const [address, setAddress] = useState<string | null>(null);
  const [connecting, setConnecting] = useState(false);
  const [walletless, setWalletless] = useState<WalletlessStatus>("planned");

  useEffect(() => {
    setWalletless(walletlessStatus());
    if (!window.localStorage.getItem(STORAGE_KEY)) return;
    if (!embeddedSigner.isAvailable()) return;
    embeddedSigner
      .connect()
      .then(setAddress)
      .catch(() => window.localStorage.removeItem(STORAGE_KEY));
  }, []);

  const authorize = useCallback(async () => {
    setConnecting(true);
    try {
      const addr = await embeddedSigner.connect();
      setAddress(addr);
      window.localStorage.setItem(STORAGE_KEY, embeddedSigner.key);
      return addr;
    } finally {
      setConnecting(false);
    }
  }, []);

  const forget = useCallback(async () => {
    await embeddedSigner.disconnect();
    setAddress(null);
    window.localStorage.removeItem(STORAGE_KEY);
  }, []);

  const value = useMemo<WalletState>(
    () => ({
      address,
      signer: address ? embeddedSigner : null,
      kind: address ? "walletless" : null,
      connecting,
      walletless,
      authorize,
      forget,
    }),
    [address, connecting, walletless, authorize, forget],
  );

  return <WalletContext.Provider value={value}>{children}</WalletContext.Provider>;
}

export function useWallet(): WalletState {
  const ctx = useContext(WalletContext);
  if (!ctx) throw new Error("useWallet must be used inside WalletProvider");
  return ctx;
}
