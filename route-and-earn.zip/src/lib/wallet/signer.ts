import type { PayoutAsset } from "@/lib/solana";

/**
 * Modular signing layer.
 *
 * The only implementation is the walletless embedded/passkey adapter, where the
 * human authorizes every transaction. Another audited provider (MPC, session
 * keys) can be added later by implementing this same interface — product code
 * only ever talks to `TransactionSigner`.
 *
 * No implementation may accept, request, store or transmit a private key or
 * seed phrase.
 */

export type SignerKind = "browser_wallet" | "custody";

export interface TransferPlan {
  /** Destination address, resolved and verified server-side. */
  to: string;
  /** Asset symbol, e.g. SOL, USDC, USDT, JUP, BONK. */
  asset: string;
  /**
   * SPL mint address for token transfers. Null/omitted means the chain's native
   * asset (SOL). Resolved server-side from the asset registry — never from the
   * browser — so a client cannot substitute a different token.
   */
  mint?: string | null;
  /**
   * SPL program that owns the mint, resolved server-side from the registry.
   * Null for native SOL.
   */
  tokenProgram?: string | null;
  /** Human-unit amount. */
  amount: number;
  decimals: number;

  blockhash: string;
  lastValidBlockHeight: number;
  /** For SPL transfers: whether the destination token account already exists. */
  destinationTokenAccountExists: boolean;
  memo: string;
}

export interface SignedMessage {
  address: string;
  signature: string;
  message: string;
}

export interface TransactionSigner {
  key: string;
  name: string;
  kind: SignerKind;
  icon?: string;
  /** True when this signer can be used right now in this environment. */
  isAvailable(): boolean;
  connect(): Promise<string>;
  disconnect(): Promise<void>;
  getAddress(): string | null;
  signMessage(message: string): Promise<SignedMessage>;
  /** Signs and submits. Returns the transaction signature — confirmation is verified server-side. */
  signAndSendTransfer(plan: TransferPlan): Promise<string>;
}

export class SignerError extends Error {
  constructor(
    message: string,
    public code: "unavailable" | "rejected" | "failed" = "failed",
  ) {
    super(message);
    this.name = "SignerError";
  }
}
