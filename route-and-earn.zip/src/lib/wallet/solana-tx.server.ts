/**
 * Server-side Solana transfer construction, signing and broadcast — SERVER ONLY.
 *
 * Used for one job: moving funds out of a Turnkey-held identity deposit wallet
 * into the verified owner's payout destination when they claim.
 *
 * Key custody never leaves Turnkey. AUTH builds an unsigned transaction, asks
 * Turnkey to sign it inside its enclave, and broadcasts the result. No private
 * key is ever read, stored, logged or returned here.
 *
 * `@solana/spl-token` cannot be bundled for the Worker runtime, so the two
 * token instructions we need are encoded by hand.
 */

import { TOKEN_PROGRAM_ID, ASSOCIATED_TOKEN_PROGRAM_ID } from "@/lib/wallet/ata.server";

const SYSTEM_PROGRAM_ID = "11111111111111111111111111111111";

/** Exact human-units -> base-units, via the decimal string (no float drift). */
export function toBaseUnits(amount: number, decimals: number): bigint {
  const fixed = amount.toFixed(decimals);
  const [whole, fraction = ""] = fixed.split(".");
  const digits = `${whole}${fraction.padEnd(decimals, "0")}`.replace(/^0+(?=\d)/, "");
  return BigInt(digits);
}

function u64le(value: bigint): Uint8Array {
  const buf = new Uint8Array(8);
  let v = value;
  for (let i = 0; i < 8; i++) {
    buf[i] = Number(v & 0xffn);
    v >>= 8n;
  }
  return buf;
}

export interface TransferRequest {
  /** Turnkey-held wallet that pays fees and sends the funds. */
  from: string;
  to: string;
  /** null = native SOL. */
  mint: string | null;
  amount: number;
  decimals: number;
}

/** Builds the unsigned transaction. Returns hex, which is what Turnkey signs. */
export async function buildUnsignedTransfer(
  req: TransferRequest,
  blockhash: string,
): Promise<{ hex: string }> {
  const { PublicKey, Transaction, SystemProgram, TransactionInstruction } = await import(
    "@solana/web3.js"
  );
  const { deriveAssociatedTokenAddress } = await import("@/lib/wallet/ata.server");
  const { accountExists } = await import("@/integrations/adapters/helius.server");

  const payer = new PublicKey(req.from);
  const tx = new Transaction({ feePayer: payer, blockhash, lastValidBlockHeight: 0 });

  if (!req.mint) {
    tx.add(
      SystemProgram.transfer({
        fromPubkey: payer,
        toPubkey: new PublicKey(req.to),
        lamports: toBaseUnits(req.amount, 9),
      }),
    );
  } else {
    const mint = new PublicKey(req.mint);
    const source = await deriveAssociatedTokenAddress(req.from, req.mint, TOKEN_PROGRAM_ID);
    const dest = await deriveAssociatedTokenAddress(req.to, req.mint, TOKEN_PROGRAM_ID);

    const destExists = await accountExists(dest);
    if (!(destExists.ok && destExists.data)) {
      // Create the recipient's token account (idempotent variant, index 1) so a
      // claim never fails just because they've never held USDC before.
      tx.add(
        new TransactionInstruction({
          programId: new PublicKey(ASSOCIATED_TOKEN_PROGRAM_ID),
          keys: [
            { pubkey: payer, isSigner: true, isWritable: true },
            { pubkey: new PublicKey(dest), isSigner: false, isWritable: true },
            { pubkey: new PublicKey(req.to), isSigner: false, isWritable: false },
            { pubkey: mint, isSigner: false, isWritable: false },
            { pubkey: new PublicKey(SYSTEM_PROGRAM_ID), isSigner: false, isWritable: false },
            { pubkey: new PublicKey(TOKEN_PROGRAM_ID), isSigner: false, isWritable: false },
          ],
          data: Buffer.from([1]),
        }),
      );
    }

    // TransferChecked (SPL Token instruction 12).
    const data = Buffer.concat([
      Buffer.from([12]),
      Buffer.from(u64le(toBaseUnits(req.amount, req.decimals))),
      Buffer.from([req.decimals]),
    ]);
    tx.add(
      new TransactionInstruction({
        programId: new PublicKey(TOKEN_PROGRAM_ID),
        keys: [
          { pubkey: new PublicKey(source), isSigner: false, isWritable: true },
          { pubkey: mint, isSigner: false, isWritable: false },
          { pubkey: new PublicKey(dest), isSigner: false, isWritable: true },
          { pubkey: payer, isSigner: true, isWritable: false },
        ],
        data,
      }),
    );
  }

  const serialized = tx.serialize({ requireAllSignatures: false, verifySignatures: false });
  return { hex: Buffer.from(serialized).toString("hex") };
}

/** Signs the built transaction inside Turnkey and broadcasts it. */
export async function signAndSendWithTurnkey(args: {
  subOrganizationId: string;
  signWith: string;
  unsignedHex: string;
}): Promise<{ ok: true; signature: string } | { ok: false; message: string }> {
  const { turnkeyApiClient } = await import("@/lib/turnkey.server");
  const { sendRawTransactionBase64 } = await import("@/integrations/adapters/helius.server");

  let signedHex: string;
  try {
    const client = await turnkeyApiClient();
    const result = await client.signTransaction({
      organizationId: args.subOrganizationId,
      signWith: args.signWith,
      unsignedTransaction: args.unsignedHex,
      type: "TRANSACTION_TYPE_SOLANA",
    });
    signedHex = result.signedTransaction;
  } catch {
    // Never surface provider internals: they can contain request context.
    return { ok: false, message: "The custody service could not sign this claim." };
  }
  if (!signedHex) return { ok: false, message: "The custody service returned no signed transaction." };

  const base64 = Buffer.from(signedHex, "hex").toString("base64");
  const sent = await sendRawTransactionBase64(base64);
  if (!sent.ok) return { ok: false, message: sent.message };
  return { ok: true, signature: sent.data };
}
