/**
 * Safe outbound links.
 *
 * Every external URL the UI can open is built here from a fixed allow-list of
 * official hostnames. Handles coming back from a provider lookup are validated
 * against that provider's own handle rules and percent-encoded before they are
 * placed in a path, so no API or user supplied string can ever become an
 * arbitrary clickable URL.
 */

import { providerMeta, type SocialProvider } from "@/lib/social/providers";

/** Official AUTH social and developer surfaces. */
export const AUTH_X_URL = "https://x.com/TryAuthApp";
export const AUTH_GITHUB_URL = "https://github.com/tryauthapp";

/** The AUTH token's on-chain mint (contract address) on Solana mainnet. */
export const AUTH_TOKEN_MINT = "JAkpyrkcJAvKs1j6wXUtJcQ2uiGphPPfXevV2wb3AUTH";

export function solscanTokenUrl(mint: string): string {
  return `https://solscan.io/token/${mint}`;
}

/** Turnkey's official surfaces — the only Turnkey URLs the UI links to. */
/** In-app public proof page for AUTH's Turnkey integration. */
export const TURNKEY_PROOF_PATH = "/turnkey-proof";

export const TURNKEY_SITE_URL = "https://www.turnkey.com";
export const TURNKEY_DOCS_URL = "https://docs.turnkey.com";

/**
 * A public, verifiable URL to THIS project's Turnkey integration source.
 *
 * Intentionally null: no public repository of this project's code has been
 * confirmed. Nothing is invented here — while this is null the UI links the
 * Turnkey brand to Turnkey's own site and shows no "view integration code"
 * link. Set this to the real public source URL once one exists.
 */
export const TURNKEY_INTEGRATION_SOURCE_URL: string | null = null;

/** Official platform home pages. */
const PLATFORM_HOME: Record<SocialProvider, string> = {
  x: "https://x.com",
  tiktok: "https://www.tiktok.com",
  youtube: "https://www.youtube.com",
  twitch: "https://www.twitch.tv",
  instagram: "https://www.instagram.com",
};

export function platformHomeUrl(provider: SocialProvider): string {
  return PLATFORM_HOME[provider];
}

/** How each platform addresses a profile, relative to its home page. */
const PROFILE_PATH: Record<SocialProvider, (encoded: string) => string> = {
  x: (h) => `/${h}`,
  tiktok: (h) => `/@${h}`,
  youtube: (h) => `/@${h}`,
  twitch: (h) => `/${h}`,
  instagram: (h) => `/${h}`,
};

/**
 * Canonical profile URL for a resolved handle, or null when the handle does
 * not match the provider's documented handle shape.
 */
export function socialProfileUrl(
  provider: SocialProvider,
  handle: string | null | undefined,
): string | null {
  const meta = providerMeta(provider);
  if (!meta) return null;
  const clean = String(handle ?? "")
    .trim()
    .replace(/^@+/, "");
  if (!clean || !meta.handlePattern.test(clean)) return null;
  return `${PLATFORM_HOME[provider]}${PROFILE_PATH[provider](encodeURIComponent(clean))}`;
}
