import { createServerFn } from "@tanstack/react-start";
import {
  normalizeHandle,
  toXIdentity,
  X_HANDLE_RE,
  X_USER_FIELDS,
  X_USER_FIELDS_MINIMAL,
  type XApiUser,
  type XIdentity,
} from "@/lib/x-identity";

/**
 * Server-side X profile lookup (X API v2 `users/by/username`).
 *
 * Auth, in order of preference:
 *   1. X_BEARER_TOKEN — app-only bearer from the X developer portal.
 *   2. X_API_KEY / X_API_SECRET — consumer key pair, exchanged for an app-only
 *      bearer via OAuth2 client credentials.
 * X_CLIENT_ID / X_CLIENT_SECRET are the OAuth 2.0 user-auth pair used by the
 * PKCE identity flow; X rejects them for app-only lookups, so they are not used
 * here.
 *
 * Credentials never reach the browser, nothing is scraped, and when auth is
 * missing or rejected the function reports `unconfigured` rather than inventing
 * a profile, avatar, follower count or verification badge.
 */

export type XProfileStatus =
  | "ok"
  | "not_found"
  | "unconfigured"
  | "unauthorized"
  | "rate_limited"
  | "error";

export type XProfile = XIdentity;

export interface XProfileResult {
  status: XProfileStatus;
  profile?: XProfile;
  message?: string;
  /** Advisory: profile metadata (followers, bio) is a point-in-time snapshot. */
  cachedAt?: string;
}

// Short-lived cache: follower counts and bios move, so never treat as current.
const CACHE_MS = 5 * 60 * 1000;
const cache = new Map<string, { expires: number; result: XProfileResult }>();

let bearerCache: { token: string; expires: number } | null = null;

async function appBearer(): Promise<string | null> {
  const direct = process.env["X_BEARER_TOKEN"];
  if (direct) return direct.trim();

  const key = process.env["X_API_KEY"];
  const secret = process.env["X_API_SECRET"];
  if (!key || !secret) return null;
  if (bearerCache && bearerCache.expires > Date.now()) return bearerCache.token;

  const basic = btoa(`${encodeURIComponent(key)}:${encodeURIComponent(secret)}`);
  const res = await fetch("https://api.x.com/oauth2/token", {
    method: "POST",
    headers: {
      Authorization: `Basic ${basic}`,
      "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
    },
    body: "grant_type=client_credentials",
  });
  if (!res.ok) return null;
  const json = (await res.json()) as { access_token?: string };
  if (!json.access_token) return null;
  bearerCache = { token: json.access_token, expires: Date.now() + 30 * 60 * 1000 };
  return json.access_token;
}

async function requestUser(handle: string, bearer: string, fields: readonly string[]) {
  const url = new URL(`https://api.x.com/2/users/by/username/${handle}`);
  url.searchParams.set("user.fields", fields.join(","));
  return fetch(url, { headers: { Authorization: `Bearer ${bearer}` } });
}

export const lookupXProfile = createServerFn({ method: "GET" })
  .inputValidator((input: { handle: string }) => {
    const handle = normalizeHandle(input.handle);
    if (!X_HANDLE_RE.test(handle)) {
      throw new Error("Enter a valid X username (letters, numbers, underscore).");
    }
    return { handle };
  })
  .handler(async ({ data }): Promise<XProfileResult> => {
    const key = data.handle.toLowerCase();
    const hit = cache.get(key);
    if (hit && hit.expires > Date.now()) return hit.result;

    const bearer = await appBearer();
    if (!bearer) {
      return {
        status: "unconfigured",
        message: "X profile lookup isn't configured yet — an X API token is missing.",
      };
    }

    let res: Response;
    try {
      res = await requestUser(data.handle, bearer, X_USER_FIELDS);
      // Some access tiers reject specific fields; retry with the minimal set.
      if (res.status === 400) res = await requestUser(data.handle, bearer, X_USER_FIELDS_MINIMAL);
    } catch {
      return { status: "error", message: "Could not reach the X API. Try again." };
    }

    if (res.status === 429) {
      return { status: "rate_limited", message: "X API rate limit reached. Try again shortly." };
    }
    if (res.status === 402) {
      return {
        status: "unauthorized",
        message:
          "The X API plan has no request credits left — profile lookup is unavailable until the plan is topped up.",
      };
    }
    if (res.status === 401) {
      return {
        status: "unauthorized",
        message: "The X API token was rejected — profile lookup is unavailable.",
      };
    }
    if (res.status === 403) {
      return {
        status: "unauthorized",
        message: "This X API plan does not allow user lookup — profile lookup is unavailable.",
      };
    }
    if (!res.ok && res.status !== 404) {
      return { status: "error", message: `X API error (${res.status}). Try again.` };
    }

    const json = (await res.json().catch(() => null)) as { data?: XApiUser } | null;
    if (!json?.data) {
      const miss: XProfileResult = { status: "not_found", message: "No X account found." };
      cache.set(key, { expires: Date.now() + 60_000, result: miss });
      return miss;
    }

    const profile = toXIdentity(json.data);
    const result: XProfileResult = { status: "ok", profile, cachedAt: profile.fetchedAt };
    cache.set(key, { expires: Date.now() + CACHE_MS, result });
    return result;
  });

/** Whether X profile lookup has server credentials configured. */
export const xLookupStatus = createServerFn({ method: "GET" }).handler(async () => ({
  configured: Boolean(
    process.env["X_BEARER_TOKEN"] ||
      (process.env["X_API_KEY"] && process.env["X_API_SECRET"]),
  ),
}));
