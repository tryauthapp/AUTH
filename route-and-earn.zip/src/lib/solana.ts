/** Shared Solana constants and helpers. Browser-safe: no key material, no RPC secrets. */

export const SOLANA_NETWORK = "mainnet-beta" as const;

/** Circle USDC on Solana mainnet. */
export const USDC_MINT = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
export const USDC_DECIMALS = 6;
export const LAMPORTS_PER_SOL = 1_000_000_000;

export const ADDRESS_RE = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
export const SIGNATURE_RE = /^[1-9A-HJ-NP-Za-km-z]{64,90}$/;

export function isSolanaAddress(value: string): boolean {
  return ADDRESS_RE.test(value.trim());
}

export function explorerTx(signature: string): string {
  return `https://solscan.io/tx/${signature}`;
}

export function explorerAddress(address: string): string {
  return `https://solscan.io/account/${address}`;
}

export function explorerToken(mint: string): string {
  return `https://solscan.io/token/${mint}`;
}

export type PayoutAsset = "SOL" | "USDC";

export function formatAsset(amount: number, asset: PayoutAsset): string {
  const digits = asset === "SOL" ? 6 : 2;
  return `${amount.toLocaleString(undefined, { maximumFractionDigits: digits })} ${asset}`;
}
