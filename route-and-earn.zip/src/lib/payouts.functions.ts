import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { ADDRESS_RE, SIGNATURE_RE, USDC_DECIMALS, USDC_MINT } from "@/lib/solana";

/**
 * Real Solana payouts, authorized by the recipient's own non-custodial account.
 *
 * The server never holds keys. It only: resolves and verifies the destination,
 * prices the payout, hands back an unsigned transfer plan, then verifies the
 * resulting signature on-chain before marking anything as paid.
 */

export interface TransferPlanResponse {
  ok: boolean;
  message?: string;
  plan?: {
    payoutId: string;
    to: string;
    asset: "SOL" | "USDC";
    amount: number;
    amountUsd: number;
    decimals: number;
    blockhash: string;
    lastValidBlockHeight: number;
    destinationTokenAccountExists: boolean;
    memo: string;
    solPriceUsd: number | null;
    priceSource: string | null;
    network: "mainnet-beta";
    idempotencyKey: string;
  };
}

const SUPPORTED: Record<string, "SOL" | "USDC"> = {
  sol: "SOL",
  wallet_withdrawal: "SOL",
  charity: "SOL",
  split_recipient: "SOL",
  usdc: "USDC",
};

export const preparePayoutTransfer = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { payoutId: string; signerAddress: string }) => {
    if (!input.payoutId) throw new Error("Missing payout.");
    if (!ADDRESS_RE.test(input.signerAddress.trim())) throw new Error("Invalid wallet address.");
    return { payoutId: input.payoutId, signerAddress: input.signerAddress.trim() };
  })
  .handler(async ({ data, context }): Promise<TransferPlanResponse> => {
    const { supabase, userId } = context;

    const { data: payout, error } = await supabase
      .from("payouts")
      .select(
        "id,recipient_id,destination,label,amount_usd,status,tx_signature,is_demo,idempotency_key",
      )
      .eq("id", data.payoutId)
      .maybeSingle();
    if (error) return { ok: false, message: error.message };
    if (!payout) return { ok: false, message: "Payout not found." };
    if (payout.tx_signature) return { ok: false, message: "This payout is already settled on-chain." };
    if (payout.status === "paid") return { ok: false, message: "This payout is already paid." };

    const owner = await assertOwnsRecipient(supabase, payout.recipient_id, userId);
    if (!owner.ok) return { ok: false, message: owner.message };

    const asset = SUPPORTED[payout.destination];
    if (!asset) {
      return {
        ok: false,
        message:
          payout.destination === "x_money"
            ? "X Money payouts are disabled: there is no legitimate third-party payout API today. Use a wallet destination or a claim."
            : `On-chain settlement is not available for the ${payout.destination} destination yet.`,
      };
    }

    const destination = await resolveDestination(supabase, payout.recipient_id, payout.destination);
    if (!destination.ok) return { ok: false, message: destination.message };

    const amountUsd = Number(payout.amount_usd);
    if (!(amountUsd > 0)) return { ok: false, message: "This payout has no amount." };

    let amount = amountUsd;
    let solPriceUsd: number | null = null;
    let priceSource: string | null = null;
    if (asset === "SOL") {
      const { getSolUsdPrice } = await import("@/integrations/adapters/price.server");
      const price = await getSolUsdPrice();
      if (!price.ok) {
        return { ok: false, message: `Could not price this payout in SOL: ${price.message}` };
      }
      solPriceUsd = price.usd;
      priceSource = price.source;
      amount = Number((amountUsd / price.usd).toFixed(6));
    } else {
      amount = Number(amountUsd.toFixed(USDC_DECIMALS));
    }
    if (!(amount > 0)) return { ok: false, message: "Amount rounds to zero." };

    const { getLatestBlockhash, accountExists } = await import(
      "@/integrations/adapters/helius.server"
    );
    const blockhash = await getLatestBlockhash();
    if (!blockhash.ok) return { ok: false, message: blockhash.message };

    let destinationTokenAccountExists = true;
    if (asset === "USDC") {
      const ata = await deriveAta(destination.address, USDC_MINT);
      const exists = await accountExists(ata);
      destinationTokenAccountExists = exists.ok ? exists.data : false;
    }

    return {
      ok: true,
      plan: {
        payoutId: payout.id,
        to: destination.address,
        asset,
        amount,
        amountUsd,
        decimals: asset === "SOL" ? 9 : USDC_DECIMALS,
        blockhash: blockhash.data.blockhash,
        lastValidBlockHeight: blockhash.data.lastValidBlockHeight,
        destinationTokenAccountExists,
        memo: `AUTH payout ${payout.id}`,
        solPriceUsd,
        priceSource,
        network: "mainnet-beta",
        idempotencyKey: `${payout.id}:${data.signerAddress}`,
      },
    };
  });

export interface SettlementResponse {
  ok: boolean;
  status?: "paid" | "processing" | "failed";
  message?: string;
  signature?: string;
}

/** Records a submitted signature, then verifies it on-chain before marking paid. */
export const settlePayoutSignature = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (input: {
      payoutId: string;
      signature: string;
      signerAddress: string;
      asset: "SOL" | "USDC";
      amount: number;
      destination: string;
      idempotencyKey: string;
    }) => {
      if (!SIGNATURE_RE.test(input.signature.trim())) throw new Error("Invalid transaction signature.");
      if (!ADDRESS_RE.test(input.signerAddress.trim())) throw new Error("Invalid wallet address.");
      if (!ADDRESS_RE.test(input.destination.trim())) throw new Error("Invalid destination address.");
      if (!(input.amount > 0)) throw new Error("Invalid amount.");
      return {
        ...input,
        signature: input.signature.trim(),
        signerAddress: input.signerAddress.trim(),
        destination: input.destination.trim(),
      };
    },
  )
  .handler(async ({ data, context }): Promise<SettlementResponse> => {
    const { supabase, userId } = context;

    const { data: payout, error } = await supabase
      .from("payouts")
      .select("id,recipient_id,amount_usd,status,tx_signature")
      .eq("id", data.payoutId)
      .maybeSingle();
    if (error) return { ok: false, message: error.message };
    if (!payout) return { ok: false, message: "Payout not found." };

    const owner = await assertOwnsRecipient(supabase, payout.recipient_id, userId);
    if (!owner.ok) return { ok: false, message: owner.message };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Idempotency: one attempt row per payout+signer, one signature per payout.
    await supabaseAdmin
      .from("payout_attempts")
      .upsert(
        {
          payout_id: payout.id,
          recipient_id: payout.recipient_id,
          signer_address: data.signerAddress,
          asset: data.asset,
          asset_amount: data.amount,
          destination_address: data.destination,
          tx_signature: data.signature,
          status: "submitted",
          idempotency_key: data.idempotencyKey,
        },
        { onConflict: "idempotency_key" },
      );

    const { getSignatureStatus, getTransactionSummary } = await import(
      "@/integrations/adapters/helius.server"
    );

    let confirmed = false;
    let failedOnChain = false;
    for (let i = 0; i < 12; i++) {
      const status = await getSignatureStatus(data.signature);
      if (status.ok && status.data) {
        if (status.data.err) {
          failedOnChain = true;
          break;
        }
        if (status.data.confirmationStatus === "confirmed" || status.data.confirmationStatus === "finalized") {
          confirmed = true;
          break;
        }
      }
      await new Promise((r) => setTimeout(r, 2000));
    }

    if (!confirmed && !failedOnChain) {
      const tx = await getTransactionSummary(data.signature);
      if (tx.ok && tx.data) {
        confirmed = tx.data.succeeded;
        failedOnChain = !tx.data.succeeded;
      }
    }

    const now = new Date().toISOString();

    if (failedOnChain) {
      await supabaseAdmin
        .from("payout_attempts")
        .update({ status: "failed", failure_reason: "Transaction failed on-chain." })
        .eq("idempotency_key", data.idempotencyKey);
      await supabaseAdmin
        .from("payouts")
        .update({
          status: "claimable",
          failure_reason: "The signed transaction failed on-chain. The balance is still yours.",
          signer_address: data.signerAddress,
          attempted_at: now,
        })
        .eq("id", payout.id);
      return { ok: false, status: "failed", signature: data.signature, message: "The transaction failed on-chain. Nothing was lost — the balance stays claimable." };
    }

    if (!confirmed) {
      await supabaseAdmin
        .from("payouts")
        .update({
          status: "processing",
          tx_signature: data.signature,
          signer_address: data.signerAddress,
          asset: data.asset,
          asset_amount: data.amount,
          attempted_at: now,
          is_demo: false,
        })
        .eq("id", payout.id);
      return {
        ok: true,
        status: "processing",
        signature: data.signature,
        message: "Submitted. Waiting for network confirmation — refresh in a moment.",
      };
    }

    await supabaseAdmin
      .from("payout_attempts")
      .update({ status: "confirmed", confirmed_at: now })
      .eq("idempotency_key", data.idempotencyKey);

    const { error: updateError } = await supabaseAdmin
      .from("payouts")
      .update({
        status: "paid",
        tx_signature: data.signature,
        signer_address: data.signerAddress,
        asset: data.asset,
        asset_amount: data.amount,
        failure_reason: null,
        attempted_at: now,
        settled_at: now,
        confirmed_at: now,
        is_demo: false,
      })
      .eq("id", payout.id);
    if (updateError) return { ok: false, message: updateError.message };

    await supabaseAdmin.from("audit_log").insert({
      actor_id: userId,
      action: "payout.settled_on_chain",
      entity: "payouts",
      entity_id: payout.id,
      metadata: {
        signature: data.signature,
        asset: data.asset,
        amount: data.amount,
        destination: data.destination,
        signer: data.signerAddress,
        network: "mainnet-beta",
      },
    });

    return { ok: true, status: "paid", signature: data.signature, message: "Confirmed on-chain." };
  });

/** Re-checks a submitted-but-unconfirmed payout. */
export const refreshPayoutConfirmation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { payoutId: string }) => input)
  .handler(async ({ data, context }): Promise<SettlementResponse> => {
    const { supabase, userId } = context;
    const { data: payout } = await supabase
      .from("payouts")
      .select("id,recipient_id,tx_signature,status")
      .eq("id", data.payoutId)
      .maybeSingle();
    if (!payout?.tx_signature) return { ok: false, message: "No transaction to check." };
    const owner = await assertOwnsRecipient(supabase, payout.recipient_id, userId);
    if (!owner.ok) return { ok: false, message: owner.message };

    const { getTransactionSummary } = await import("@/integrations/adapters/helius.server");
    const tx = await getTransactionSummary(payout.tx_signature);
    if (!tx.ok) return { ok: false, message: tx.message };
    if (!tx.data) return { ok: true, status: "processing", message: "Still not visible on-chain." };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const now = new Date().toISOString();
    if (tx.data.succeeded) {
      await supabaseAdmin
        .from("payouts")
        .update({ status: "paid", settled_at: now, confirmed_at: now, failure_reason: null })
        .eq("id", payout.id);
      return { ok: true, status: "paid", signature: payout.tx_signature, message: "Confirmed on-chain." };
    }
    await supabaseAdmin
      .from("payouts")
      .update({
        status: "claimable",
        failure_reason: "The signed transaction failed on-chain. The balance is still yours.",
        tx_signature: null,
      })
      .eq("id", payout.id);
    return { ok: false, status: "failed", message: "That transaction failed on-chain." };
  });

/* ------------------------------ helpers ------------------------------ */

type Client = { from: (t: string) => any };

async function assertOwnsRecipient(
  supabase: Client,
  recipientId: string,
  userId: string,
): Promise<{ ok: true } | { ok: false; message: string }> {
  const { data } = await supabase
    .from("recipients")
    .select("id,claimed_by")
    .eq("id", recipientId)
    .maybeSingle();
  if (!data) return { ok: false, message: "Recipient not found." };
  if (data.claimed_by !== userId) {
    return { ok: false, message: "This payout belongs to another recipient." };
  }
  return { ok: true };
}

async function resolveDestination(
  supabase: Client,
  recipientId: string,
  destination: string,
): Promise<{ ok: true; address: string } | { ok: false; message: string }> {
  if (destination === "charity") {
    const { data } = await supabase
      .from("routing_splits")
      .select("address,charity:charities(wallet_address)")
      .eq("destination", "charity")
      .limit(1)
      .maybeSingle();
    const address = data?.address ?? data?.charity?.wallet_address;
    if (!address || !ADDRESS_RE.test(address)) {
      return { ok: false, message: "That charity has no verified Solana wallet configured." };
    }
    return { ok: true, address };
  }

  // Wallet-based destinations settle to the claimed account's payout wallet.
  //
  // Order of preference, so one AUTH account keeps one destination across all
  // of its verified social identities:
  //   1. an external payout wallet the user explicitly verified
  //   2. the account's primary Turnkey embedded wallet
  const { data: wallet } = await supabase
    .from("wallets")
    .select("address,verified_at")
    .eq("recipient_id", recipientId)
    .not("verified_at", "is", null)
    .order("verified_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (wallet?.address && ADDRESS_RE.test(wallet.address)) {
    return { ok: true, address: wallet.address };
  }

  // Fall back to the primary embedded wallet of the account that claimed this
  // identity. Identity-scoped legacy wallets are only used if no primary exists.
  const { data: owner } = await supabase
    .from("recipients")
    .select("claimed_by")
    .eq("id", recipientId)
    .maybeSingle();

  if (owner?.claimed_by) {
    const { data: embedded } = await supabase
      .from("embedded_wallets")
      .select("address,is_primary,created_at")
      .eq("user_id", owner.claimed_by)
      .order("is_primary", { ascending: false })
      .order("created_at", { ascending: true })
      .limit(1)
      .maybeSingle();
    if (embedded?.address && ADDRESS_RE.test(embedded.address)) {
      return { ok: true, address: embedded.address };
    }
  }
  return {
    ok: false,
    message: "Add and verify a payout wallet first — AUTH will not guess a destination.",
  };
}

/** Associated token account derivation (server-side, no keys involved). */
async function deriveAta(owner: string, mint: string): Promise<string> {
  const { deriveAssociatedTokenAddress } = await import("@/lib/wallet/ata.server");
  return deriveAssociatedTokenAddress(owner, mint);
}
