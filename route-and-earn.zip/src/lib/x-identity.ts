/**
 * Shared X identity model.
 *
 * Both the launch recipient lookup and the X OAuth (PKCE) identity flow map the
 * X API v2 user object through here, so a resolved identity always has the same
 * shape and the immutable X user ID is always the canonical identifier.
 * Nothing here fabricates values: missing fields stay null.
 */

export interface XIdentity {
  /** Immutable X user ID — the canonical recipient identity. */
  id: string;
  /** Mutable handle: display and routing metadata only. */
  username: string;
  name: string;
  avatarUrl: string | null;
  description: string | null;
  followers: number | null;
  /** Only set when the API plan actually returns a verification field. */
  verified: boolean | null;
  verifiedType: string | null;
  location: string | null;
  website: string | null;
  fetchedAt: string;
}

/** Fields AUTH requests from X API v2. Trimmed by the server on plan errors. */
export const X_USER_FIELDS = [
  "profile_image_url",
  "description",
  "public_metrics",
  "verified",
  "verified_type",
  "location",
  "url",
  "entities",
] as const;

/** Minimal field set that every X API access tier supports. */
export const X_USER_FIELDS_MINIMAL = ["profile_image_url", "description"] as const;

export interface XApiUser {
  id: string;
  username: string;
  name: string;
  profile_image_url?: string;
  description?: string;
  public_metrics?: { followers_count?: number };
  verified?: boolean;
  verified_type?: string;
  location?: string;
  url?: string;
  entities?: { url?: { urls?: { expanded_url?: string }[] } };
}

/** Maps an X API v2 user object to AUTH's sanitized identity model. */
export function toXIdentity(u: XApiUser): XIdentity {
  const expanded = u.entities?.url?.urls?.[0]?.expanded_url;
  return {
    id: u.id,
    username: u.username,
    name: u.name,
    // Request the full-size avatar rather than the 48px thumbnail.
    avatarUrl: u.profile_image_url ? u.profile_image_url.replace("_normal", "_400x400") : null,
    description: u.description?.trim() || null,
    followers:
      typeof u.public_metrics?.followers_count === "number"
        ? u.public_metrics.followers_count
        : null,
    verified: typeof u.verified === "boolean" ? u.verified : null,
    verifiedType: u.verified_type ?? null,
    location: u.location?.trim() || null,
    website: expanded ?? u.url ?? null,
    fetchedAt: new Date().toISOString(),
  };
}

/** Normalizes user input (@handle, x.com URL, raw handle) to a bare username. */
export function normalizeHandle(raw: string): string {
  return String(raw ?? "")
    .trim()
    .replace(/^@+/, "")
    .replace(/^(?:https?:\/\/)?(?:www\.)?(?:x|twitter)\.com\//i, "")
    .split(/[/?#]/)[0]!
    .trim();
}

export const X_HANDLE_RE = /^[A-Za-z0-9_]{1,15}$/;
