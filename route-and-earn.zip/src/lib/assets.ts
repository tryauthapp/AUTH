import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/**
 * Asset + chain registry reads.
 *
 * The registry is deliberately broad (it lists major assets for discovery) but
 * only rows with status "live" AND is_payable = true are ever selectable in the
 * Pay flow. Everything else renders as Planned.
 */

export type AssetRow = {
  key: string;
  symbol: string;
  name: string;
  chain_key: string;
  kind: string;
  contract_address: string | null;
  decimals: number;
  status: string;
  is_payable: boolean;
  market_rank: number | null;
  logo_url: string | null;
  /** SPL program owning the mint; null for native assets. */
  token_program: string | null;
  issuer: string | null;
  category: string | null;
  notes: string | null;
};

export type ChainRow = {
  key: string;
  name: string;
  native_symbol: string;
  status: string;
  signer_kind: string;
  sort_order: number;
  notes: string | null;
};

const ASSET_SELECT =
  "key,symbol,name,chain_key,kind,contract_address,decimals,status,is_payable,market_rank,logo_url,token_program,issuer,category,notes";


export const assetsQuery = () =>
  queryOptions({
    queryKey: ["assets"],
    staleTime: 5 * 60 * 1000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("assets")
        .select(ASSET_SELECT)
        .order("market_rank", { ascending: true, nullsFirst: false });
      if (error) throw new Error(error.message);
      return (data ?? []) as unknown as AssetRow[];
    },
  });

export const chainsQuery = () =>
  queryOptions({
    queryKey: ["chains"],
    staleTime: 5 * 60 * 1000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("chains")
        .select("key,name,native_symbol,status,signer_kind,sort_order,notes")
        .order("sort_order");
      if (error) throw new Error(error.message);
      return (data ?? []) as unknown as ChainRow[];
    },
  });

export function payableAssets(assets: AssetRow[]): AssetRow[] {
  return assets.filter((a) => a.status === "live" && a.is_payable);
}

export function plannedAssets(assets: AssetRow[]): AssetRow[] {
  return assets.filter((a) => !(a.status === "live" && a.is_payable));
}
