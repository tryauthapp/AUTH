import { createServerFn } from "@tanstack/react-start";
import {
  SOCIAL_PROVIDERS,
  type LookupKind,
  type SocialProvider,
  callbackUrl,
  isSocialProvider,
  normalizeSocialHandle,
  providerMeta,
} from "@/lib/social/providers";

/**
 * Platform-agnostic identity surface shared by Pay, Launch, Explore, Profile
 * and the public identity pages.
 *
 * Two distinct things are reported and never conflated:
 *  - the *platform profile*, read live from the platform's own API;
 *  - the *AUTH identity record*, which is what money is actually routed to.
 *
 * A platform is only described as live when its credentials are present and
 * its official API path is real. Missing credentials and platform restrictions
 * are reported verbatim instead of being papered over.
 */

export interface ResolvedIdentity {
  provider: SocialProvider;
  handle: string;
  /** Platform-side profile, present only when the platform returned one. */
  profile: {
    platformUserId: string;
    handle: string;
    displayName: string | null;
    avatarUrl: string | null;
    profileUrl: string | null;
    followerCount: number | null;
    platformVerified: boolean | null;
    bio: string | null;
    fetchedAt: string;
  } | null;
  /** Status of the lookup attempt. */
  lookupStatus:
    | "ok"
    | "not_found"
    | "unconfigured"
    | "unsupported"
    | "unauthorized"
    | "rate_limited"
    | "error";
  lookupMessage: string | null;
  /** AUTH-side record, present once anything has been routed to the identity. */
  record: {
    recipientId: string;
    handle: string;
    displayName: string | null;
    avatarUrl: string | null;
    verification: string;
    claimed: boolean;
    payable: boolean;
    destinationWallet: string | null;
  } | null;
}

/** Resolve a handle on any platform: live profile plus AUTH record. */
export const resolvePlatformIdentity = createServerFn({ method: "GET" })
  .inputValidator((input: { provider: string; handle: string }) => {
    if (!isSocialProvider(input.provider)) throw new Error("Unsupported platform.");
    const handle = normalizeSocialHandle(input.provider, input.handle);
    if (!handle) throw new Error("Enter a username.");
    return { provider: input.provider, handle };
  })
  .handler(async ({ data }): Promise<ResolvedIdentity> => {
    const { enforceRateLimit } = await import("@/lib/rate-limit.server");
    enforceRateLimit("identity-resolve", 30, 60_000);
    const { lookupPlatformProfile } = await import("@/lib/social/lookup.server");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const lookup = await lookupPlatformProfile(data.provider, data.handle);
    const handle = lookup.profile?.handle ?? data.handle;

    // AUTH record is matched on the immutable platform ID when known, so a
    // renamed account still resolves to the same balance.
    let query = supabaseAdmin
      .from("recipients")
      .select("id,handle,display_name,avatar_url,verification,claimed_by,provider,provider_user_id")
      .eq("provider", data.provider);
    query = lookup.profile
      ? query.or(
          `provider_user_id.eq.${lookup.profile.platformUserId},handle.ilike.${handle}`,
        )
      : query.ilike("handle", handle);

    const { data: rows } = await query.limit(1);
    const recipient = rows?.[0] ?? null;

    let record: ResolvedIdentity["record"] = null;
    if (recipient) {
      const { data: wallet } = await supabaseAdmin
        .from("wallets")
        .select("address,verified_at,is_default")
        .eq("recipient_id", recipient.id)
        .not("verified_at", "is", null)
        .order("is_default", { ascending: false })
        .order("verified_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      const destination = wallet?.address ?? null;
      record = {
        recipientId: recipient.id,
        handle: recipient.handle,
        displayName: recipient.display_name,
        avatarUrl: recipient.avatar_url,
        verification: recipient.verification ?? "unverified",
        claimed: Boolean(recipient.claimed_by),
        payable: Boolean(destination),
        destinationWallet: destination,
      };

      // Keep the cached snapshot fresh when the platform gave us a real one.
      if (lookup.profile) {
        await supabaseAdmin
          .from("recipients")
          .update({
            handle: lookup.profile.handle,
            display_name: lookup.profile.displayName,
            avatar_url: lookup.profile.avatarUrl,
            bio: lookup.profile.bio,
            provider_user_id: lookup.profile.platformUserId,
            follower_count: lookup.profile.followerCount,
            profile_url: lookup.profile.profileUrl,
            platform_verified: lookup.profile.platformVerified,
            profile_synced_at: lookup.profile.fetchedAt,
          })
          .eq("id", recipient.id);
      }
    }

    return {
      provider: data.provider,
      handle,
      profile: lookup.profile
        ? {
            platformUserId: lookup.profile.platformUserId,
            handle: lookup.profile.handle,
            displayName: lookup.profile.displayName,
            avatarUrl: lookup.profile.avatarUrl,
            profileUrl: lookup.profile.profileUrl,
            followerCount: lookup.profile.followerCount,
            platformVerified: lookup.profile.platformVerified,
            bio: lookup.profile.bio,
            fetchedAt: lookup.profile.fetchedAt,
          }
        : null,
      lookupStatus: lookup.status,
      lookupMessage: lookup.message ?? null,
      record,
    };
  });

/**
 * Operational lifecycle of an integration, derived from real configuration —
 * never hand-set marketing state.
 *
 * live      lookup (or owner-only claiming) and ownership OAuth both work.
 * sandbox   partially wired: usable for read-only testing, not for claiming.
 * planned   no credentials present yet; nothing is callable.
 * disabled  deliberately switched off via DISABLED_SOCIAL_PROVIDERS.
 */
export type IntegrationLifecycle = "live" | "sandbox" | "planned" | "disabled";

export interface PlatformIntegrationStatus {
  id: SocialProvider;
  label: string;
  identityNoun: string;
  handlePrefix: string;
  handleHint: string;
  lifecycle: IntegrationLifecycle;
  /** Plain-language reason for the lifecycle state. */
  lifecycleReason: string;
  /** A real public handle used by the read-only test control. */
  sampleHandle: string;
  /** Can AUTH read a public profile from a handle right now? */
  lookupAvailable: boolean;
  lookupKind: LookupKind;
  lookupSecretNames: string[];
  missingLookupSecrets: string[];
  /** Can an owner prove they control the account right now? */
  oauthAvailable: boolean;
  oauthSecretNames: string[];
  missingOauthSecrets: string[];
  /** Honest statement of what the platform itself does not permit. */
  limitation: string | null;
  reviewRequired: boolean;
  callbackUrl: string;
  consoleUrl: string;
  lastError: { message: string; at: string } | null;
}

/** Real, public, stable accounts used only for read-only connectivity tests. */
const SAMPLE_HANDLES: Record<SocialProvider, string> = {
  x: "elonmusk",
  youtube: "mrbeast",
  twitch: "ninja",
  instagram: "instagram",
  tiktok: "tiktok",
};

function disabledProviders(): Set<string> {
  return new Set(
    (process.env["DISABLED_SOCIAL_PROVIDERS"] ?? "")
      .split(",")
      .map((s) => s.trim().toLowerCase())
      .filter(Boolean),
  );
}


/**
 * Configuration truth for all five platforms. Reports what is wired, what is
 * missing by exact env var name, and the last real API failure seen.
 */
export const platformIntegrationStatus = createServerFn({ method: "GET" }).handler(
  async (): Promise<PlatformIntegrationStatus[]> => {
    const { cached } = await import("@/lib/server-cache.server");
    return cached("platform:status", 30_000, loadPlatformIntegrationStatus);
  },
);

async function loadPlatformIntegrationStatus(): Promise<PlatformIntegrationStatus[]> {
  {
    const { lookupConfigured, lastLookupError } = await import("@/lib/social/lookup.server");
    const off = disabledProviders();

    return SOCIAL_PROVIDERS.map((p) => {
      const missingOauth = p.secretNames.filter((n) => !process.env[n]);
      const missingLookup = p.lookupSecretNames.filter((n) => !process.env[n]);
      // owner_only platforms can never offer lookup, however well configured.
      const lookupAvailable = p.lookupKind !== "owner_only" && lookupConfigured(p.id);
      const oauthAvailable = missingOauth.length === 0;

      let lifecycle: IntegrationLifecycle;
      let lifecycleReason: string;
      if (off.has(p.id)) {
        lifecycle = "disabled";
        lifecycleReason = `${p.label} is switched off for this deployment.`;
      } else if (oauthAvailable && (lookupAvailable || p.lookupKind === "owner_only")) {
        lifecycle = "live";
        lifecycleReason =
          p.lookupKind === "owner_only"
            ? `${p.label} sign-in claiming is live. This platform publishes no public lookup.`
            : `${p.label} profile lookup and sign-in claiming are both live.`;
      } else if (lookupAvailable || oauthAvailable) {
        lifecycle = "sandbox";
        lifecycleReason = lookupAvailable
          ? `Read-only: profile lookup works, sign-in claiming still needs ${missingOauth.join(", ")}.`
          : `Sign-in works, profile lookup still needs ${missingLookup.join(", ")}.`;
      } else {
        lifecycle = "planned";
        lifecycleReason = p.reviewRequired
          ? `${p.label} needs platform app review before credentials can be issued.`
          : `No ${p.label} credentials are configured yet.`;
      }

      return {
        id: p.id,
        label: p.label,
        identityNoun: p.identityNoun,
        handlePrefix: p.handlePrefix,
        handleHint: p.handleHint,
        lifecycle,
        lifecycleReason,
        sampleHandle: SAMPLE_HANDLES[p.id],
        lookupAvailable,
        lookupKind: p.lookupKind,
        lookupSecretNames: [...p.lookupSecretNames],
        missingLookupSecrets: missingLookup,
        oauthAvailable,
        oauthSecretNames: [...p.secretNames],
        missingOauthSecrets: missingOauth,
        limitation: p.limitation,
        reviewRequired: p.reviewRequired,
        callbackUrl: callbackUrl(p),
        consoleUrl: p.consoleUrl,
        lastError: lastLookupError(p.id),
      };
    });
  }
}

export interface IntegrationTestResult {
  provider: SocialProvider;
  handle: string;
  status: string;
  ok: boolean;
  message: string;
  latencyMs: number;
  ranAt: string;
  profile: {
    platformUserId: string;
    handle: string;
    displayName: string | null;
    avatarUrl: string | null;
    followerCount: number | null;
    profileUrl: string | null;
  } | null;
}

/**
 * Safe test control: a read-only public profile lookup against the platform's
 * own API. It writes nothing, moves no funds, touches no AUTH records, and is
 * rate limited. Disabled platforms refuse to run.
 */
export const testPlatformIntegration = createServerFn({ method: "POST" })
  .inputValidator((input: { provider: string; handle?: string }) => {
    if (!isSocialProvider(input.provider)) throw new Error("Unsupported platform.");
    return { provider: input.provider, handle: (input.handle ?? "").trim() };
  })
  .handler(async ({ data }): Promise<IntegrationTestResult> => {
    const { enforceRateLimit } = await import("@/lib/rate-limit.server");
    enforceRateLimit("integration-test", 10, 60_000);

    const handle =
      normalizeSocialHandle(data.provider, data.handle) || SAMPLE_HANDLES[data.provider];
    const ranAt = new Date().toISOString();

    if (disabledProviders().has(data.provider)) {
      return {
        provider: data.provider,
        handle,
        status: "disabled",
        ok: false,
        message: "This integration is switched off for this deployment.",
        latencyMs: 0,
        ranAt,
        profile: null,
      };
    }

    const { lookupPlatformProfile } = await import("@/lib/social/lookup.server");
    const started = Date.now();
    const result = await lookupPlatformProfile(data.provider, handle);
    const latencyMs = Date.now() - started;

    return {
      provider: data.provider,
      handle: result.handle || handle,
      status: result.status,
      ok: result.status === "ok",
      message:
        result.message ??
        (result.status === "ok"
          ? "Live profile returned by the platform API."
          : "The platform returned no profile."),
      latencyMs,
      ranAt,
      profile: result.profile
        ? {
            platformUserId: result.profile.platformUserId,
            handle: result.profile.handle,
            displayName: result.profile.displayName,
            avatarUrl: result.profile.avatarUrl,
            followerCount: result.profile.followerCount,
            profileUrl: result.profile.profileUrl,
          }
        : null,
    };
  });


/** Client-safe list used by selectors; no secrets, no server round trip needed. */
export function platformOptions() {
  return SOCIAL_PROVIDERS.map((p) => ({
    id: p.id,
    label: p.label,
    identityNoun: p.identityNoun,
    handlePrefix: p.handlePrefix,
    handleHint: p.handleHint,
    limitation: p.limitation,
  }));
}

export { providerMeta, normalizeSocialHandle, isSocialProvider };
export type { SocialProvider };
