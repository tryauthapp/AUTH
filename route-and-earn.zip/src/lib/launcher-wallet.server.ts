/**
 * Launch/dev wallet — SERVER ONLY.
 *
 * AUTH signs pump.fun launches with a normal Solana wallet whose secret key is
 * held as a server-side secret: `LAUNCHER_PRIVATE_KEY`.
 *
 * SECURITY RULES (do not relax):
 * - This module is server-only (`*.server.ts` is blocked from client bundles).
 * - The secret is read inside functions, never at module scope, never cached
 *   in a global, never returned, never logged, never put in an error message.
 * - Only the derived PUBLIC address ever leaves this module.
 *
 * ACCEPTED FORMAT for `LAUNCHER_PRIVATE_KEY` (64-byte Solana secret key):
 *   1. base58 string — the format Phantom/Solflare "export private key" gives
 *      you. This is the canonical format.
 *   2. JSON byte array — `[12,34,...]`, 64 numbers, the format
 *      `solana-keygen` writes to an id.json file.
 * Nothing else is accepted: no seed phrases, no hex, no base64, no
 * passphrase-derived keys.
 *
 * Optional `LAUNCHER_PUBLIC_KEY` is a sanity check only. When set, it must
 * match the address derived from the secret or the wallet is treated as
 * misconfigured and no launch is attempted.
 */

import { Keypair } from "@solana/web3.js";
import bs58 from "bs58";

export type LauncherWalletStatus =
  | { state: "missing"; message: string }
  | { state: "invalid"; message: string }
  | { state: "configured"; address: string };

function parseSecretKey(raw: string): Uint8Array | null {
  const value = raw.trim();
  if (!value) return null;

  // JSON byte array (solana-keygen id.json)
  if (value.startsWith("[")) {
    try {
      const parsed = JSON.parse(value) as unknown;
      if (!Array.isArray(parsed) || parsed.length !== 64) return null;
      const bytes = Uint8Array.from(
        parsed.map((n) => {
          const v = Number(n);
          if (!Number.isInteger(v) || v < 0 || v > 255) throw new Error("byte out of range");
          return v;
        }),
      );
      return bytes;
    } catch {
      return null;
    }
  }

  // base58 secret key (wallet export)
  try {
    const bytes = bs58.decode(value);
    return bytes.length === 64 ? Uint8Array.from(bytes) : null;
  } catch {
    return null;
  }
}

/**
 * The launch wallet keypair. Callers must keep it inside a single server-side
 * signing step and never return it, serialize it, or log it.
 */
export function loadLauncherKeypair(): Keypair | null {
  const raw = process.env["LAUNCHER_PRIVATE_KEY"];
  if (!raw) return null;
  const secret = parseSecretKey(raw);
  if (!secret) return null;
  try {
    const kp = Keypair.fromSecretKey(secret);
    const expected = process.env["LAUNCHER_PUBLIC_KEY"]?.trim();
    if (expected && expected !== kp.publicKey.toBase58()) return null;
    return kp;
  } catch {
    return null;
  }
}

/** Configuration status, safe to surface in admin UI. Never includes the key. */
export function launcherWalletStatus(): LauncherWalletStatus {
  const raw = process.env["LAUNCHER_PRIVATE_KEY"];
  if (!raw?.trim()) {
    return {
      state: "missing",
      message:
        "No launch wallet is configured. Add LAUNCHER_PRIVATE_KEY as a server secret (base58 secret key, or a 64-number JSON array) to launch from your own Solana wallet.",
    };
  }
  const secret = parseSecretKey(raw);
  if (!secret) {
    return {
      state: "invalid",
      message:
        "LAUNCHER_PRIVATE_KEY could not be read as a Solana secret key. It must be a base58 secret key or a JSON array of 64 numbers.",
    };
  }
  try {
    const kp = Keypair.fromSecretKey(secret);
    const expected = process.env["LAUNCHER_PUBLIC_KEY"]?.trim();
    if (expected && expected !== kp.publicKey.toBase58()) {
      return {
        state: "invalid",
        message:
          "LAUNCHER_PRIVATE_KEY does not match LAUNCHER_PUBLIC_KEY. Fix one of them before launching.",
      };
    }
    return { state: "configured", address: kp.publicKey.toBase58() };
  } catch {
    return { state: "invalid", message: "LAUNCHER_PRIVATE_KEY is not a valid Solana secret key." };
  }
}

/** Public address only — safe to show anywhere. */
export function launcherWalletAddress(): string | null {
  const status = launcherWalletStatus();
  return status.state === "configured" ? status.address : null;
}
