/**
 * Launch smoke test — SERVER ONLY.
 *
 * Runs the whole launch path as a dry run: configuration validation, launch
 * wallet balance, real transaction construction through PumpPortal, real
 * server-side signing, and a Solana `simulateTransaction` dry run, plus a
 * read-only confirmation check against the most recent real launch.
 *
 * NOTHING IS BROADCAST. No mint is created, no SOL moves, no dev buy happens.
 * The private key never leaves `loadLauncherKeypair()`; only public addresses,
 * byte counts and statuses are reported.
 */

import { Keypair, VersionedTransaction } from "@solana/web3.js";
import { loadLauncherKeypair, launcherWalletStatus } from "@/lib/launcher-wallet.server";
import {
  getLatestBlockhash,
  getSignatureStatus,
  getSolBalance,
  rpcEndpoint,
  simulateTransactionBase64,
} from "@/integrations/adapters/helius.server";
import { recordLaunchEvent, type LaunchEventStatus, type LaunchStage } from "@/lib/launch-audit.server";
import { MIN_DEV_BUY_SOL } from "@/lib/launch-fee";

const TRADE_LOCAL_URL = "https://pumpportal.fun/api/trade-local";
/** Creation plus network costs. Dev-buy SOL is funded separately by the launcher. */
const MIN_LAUNCH_SOL = 0.03;

export interface SmokeCheck {
  id: string;
  label: string;
  stage: LaunchStage;
  status: LaunchEventStatus;
  message: string;
  /** Pretty-printed, already-redacted JSON detail, or null. */
  detailJson: string | null;
}

type SmokeCheckInput = Omit<SmokeCheck, "detailJson"> & { detail?: Record<string, unknown> | undefined };

export interface SmokeTestReport {
  runKey: string;
  ranAt: string;
  broadcast: false;
  checks: SmokeCheck[];
  passed: number;
  failed: number;
  warned: number;
  readyToLaunch: boolean;
}

async function timedFetch(url: string, init: RequestInit, ms = 15_000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

export async function runSmokeTest(userId: string): Promise<SmokeTestReport> {
  const ranAt = new Date().toISOString();
  const runKey = `smoke:${Date.now()}`;
  const checks: SmokeCheck[] = [];

  const add = async (input: SmokeCheckInput) => {
    const { detail, ...rest } = input;
    const check: SmokeCheck = { ...rest, detailJson: detail ? JSON.stringify(detail, null, 2) : null };
    checks.push(check);
    await recordLaunchEvent({
      userId,
      launchKey: runKey,
      kind: "smoke_test",
      stage: check.stage,
      status: check.status,
      message: `${check.label}: ${check.message}`,
      detail,
    });
  };

  // 1. Launch wallet configuration.
  const wallet = launcherWalletStatus();
  await add({
    id: "wallet_config",
    label: "Launch wallet configuration",
    stage: "config_validation",
    status: wallet.state === "configured" ? "pass" : wallet.state === "missing" ? "warn" : "fail",
    message:
      wallet.state === "configured"
        ? `Secret key read and validated. Public address ${wallet.address}.`
        : wallet.message,
    detail: { address: wallet.state === "configured" ? wallet.address : null, state: wallet.state },
  });

  // 2. RPC configuration + reachability.
  const rpcUrl = rpcEndpoint();
  if (!rpcUrl) {
    await add({
      id: "rpc",
      label: "Solana RPC",
      stage: "config_validation",
      status: "fail",
      message: "No Solana RPC is configured, so AUTH cannot build, simulate or broadcast anything.",
    });
  } else {
    const bh = await getLatestBlockhash();
    await add({
      id: "rpc",
      label: "Solana RPC",
      stage: "config_validation",
      status: bh.ok ? "pass" : "fail",
      message: bh.ok
        ? `Mainnet reachable at block height ${bh.data.lastValidBlockHeight}.`
        : `RPC did not return a blockhash: ${bh.message}`,
    });
  }

  // 3. Launch wallet SOL balance.
  const address = wallet.state === "configured" ? wallet.address : null;
  if (!address) {
    await add({
      id: "balance",
      label: "Launch wallet SOL balance",
      stage: "config_validation",
      status: "skipped",
      message: "No launch wallet address to check.",
    });
  } else {
    const balance = await getSolBalance(address);
    await add({
      id: "balance",
      label: "Launch wallet SOL balance",
      stage: "config_validation",
      status: !balance.ok ? "fail" : balance.data >= MIN_LAUNCH_SOL ? "pass" : "warn",
      message: !balance.ok
        ? `Balance could not be read: ${balance.message}`
        : balance.data >= MIN_LAUNCH_SOL
          ? `${balance.data.toFixed(4)} SOL — enough for a launch with no dev buy (needs about ${MIN_LAUNCH_SOL} SOL).`
          : `${balance.data.toFixed(4)} SOL — below the roughly ${MIN_LAUNCH_SOL} SOL a launch costs. Fund the wallet before launching.`,
      detail: { address, solBalance: balance.ok ? balance.data : null, minimumSol: MIN_LAUNCH_SOL },
    });
  }

  // 4. Transaction construction (real, never sent).
  const launcher = loadLauncherKeypair();
  let signedBase64: string | null = null;
  if (!launcher) {
    await add({
      id: "construction",
      label: "Transaction construction",
      stage: "transaction_construction",
      status: "skipped",
      message: "No usable launch wallet, so no transaction was built.",
    });
    await add({
      id: "signing",
      label: "Signing",
      stage: "signing",
      status: "skipped",
      message: "Nothing to sign.",
    });
  } else {
    const mintKeypair = Keypair.generate();
    const mint = mintKeypair.publicKey.toBase58();
    let serialized: Uint8Array | null = null;
    try {
      const res = await timedFetch(TRADE_LOCAL_URL, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          publicKey: launcher.publicKey.toBase58(),
          action: "create",
          tokenMetadata: {
            name: "AUTH smoke test",
            symbol: "AUTHTEST",
            uri: "https://route-and-earn.lovable.app/docs",
          },
          mint,
          denominatedInSol: "true",
          // Mirrors the real rule: every launch carries the minimum dev buy.
          amount: MIN_DEV_BUY_SOL,
          slippage: 10,
          priorityFee: 0.0005,
          pool: "pump",
        }),
      });
      if (!res.ok) {
        const text = await res.text();
        await add({
          id: "construction",
          label: "Transaction construction",
          stage: "transaction_construction",
          status: "fail",
          message: `pump.fun would not build a create transaction (${res.status}): ${text.slice(0, 160)}`,
        });
      } else {
        const bytes = new Uint8Array(await res.arrayBuffer());
        if (bytes.byteLength === 0) {
          await add({
            id: "construction",
            label: "Transaction construction",
            stage: "transaction_construction",
            status: "fail",
            message: "pump.fun returned an empty transaction.",
          });
        } else {
          serialized = bytes;
          await add({
            id: "construction",
            label: "Transaction construction",
            stage: "transaction_construction",
            status: "pass",
            message: `pump.fun built a ${bytes.byteLength}-byte unsigned create transaction. It was not sent.`,
            detail: {
              transactionBytes: bytes.byteLength,
              throwawayMint: mint,
              devBuySol: MIN_DEV_BUY_SOL,
            },
          });
        }
      }
    } catch (e) {
      await add({
        id: "construction",
        label: "Transaction construction",
        stage: "transaction_construction",
        status: "fail",
        message: e instanceof Error ? `Construction failed: ${e.message}` : "Construction failed.",
      });
    }

    // 5. Signing (local only).
    if (!serialized) {
      await add({
        id: "signing",
        label: "Signing",
        stage: "signing",
        status: "skipped",
        message: "No transaction was built, so nothing was signed.",
      });
    } else {
      try {
        const tx = VersionedTransaction.deserialize(serialized);
        tx.sign([mintKeypair, launcher]);
        signedBase64 = Buffer.from(tx.serialize()).toString("base64");
        await add({
          id: "signing",
          label: "Signing",
          stage: "signing",
          status: "pass",
          message: "Signed server-side by the launch wallet and the throwaway mint. Signature kept local.",
          detail: { signers: 2, signedBytes: signedBase64.length },
        });
      } catch (e) {
        await add({
          id: "signing",
          label: "Signing",
          stage: "signing",
          status: "fail",
          message: e instanceof Error ? `Signing failed: ${e.message}` : "Signing failed.",
        });
      }
    }
  }

  // 6. Submission dry run — simulate, never broadcast.
  if (!signedBase64) {
    await add({
      id: "submission",
      label: "Submission dry run",
      stage: "submission",
      status: "skipped",
      message: "No signed transaction to simulate.",
    });
  } else {
    const sim = await simulateTransactionBase64(signedBase64, true);
    await add({
      id: "submission",
      label: "Submission dry run",
      stage: "submission",
      status: !sim.ok ? "fail" : sim.data.err ? "warn" : "pass",
      message: !sim.ok
        ? `Solana could not simulate the transaction: ${sim.message}`
        : sim.data.err
          ? `Solana accepted the signatures but the simulated run would fail: ${JSON.stringify(sim.data.err).slice(0, 160)}`
          : `Signatures verified and the transaction simulated cleanly${sim.data.unitsConsumed ? ` (${sim.data.unitsConsumed} compute units)` : ""}. Nothing was broadcast.`,
      detail: sim.ok ? { unitsConsumed: sim.data.unitsConsumed, logs: sim.data.logs } : undefined,
    });
  }

  // 7. On-chain confirmation path — read-only against the last real launch.
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: last } = await supabaseAdmin
      .from("launch_attempts")
      .select("launch_signature,mint,confirmed_at")
      .not("launch_signature", "is", null)
      .order("confirmed_at", { ascending: false, nullsFirst: false })
      .limit(1)
      .maybeSingle();
    if (!last?.launch_signature) {
      await add({
        id: "confirmation",
        label: "On-chain confirmation check",
        stage: "confirmation",
        status: "skipped",
        message: "No previous launch signature to re-check. The confirmation path will be exercised by the first real launch.",
      });
    } else {
      const status = await getSignatureStatus(last.launch_signature);
      await add({
        id: "confirmation",
        label: "On-chain confirmation check",
        stage: "confirmation",
        status: !status.ok ? "fail" : status.data?.confirmationStatus ? "pass" : "warn",
        message: !status.ok
          ? `Signature status could not be read: ${status.message}`
          : status.data?.confirmationStatus
            ? `Last launch signature reads back as ${status.data.confirmationStatus} on mainnet.`
            : "Last launch signature was not found on mainnet.",
        detail: { signature: last.launch_signature, mint: last.mint },
      });
    }
  } catch (e) {
    await add({
      id: "confirmation",
      label: "On-chain confirmation check",
      stage: "confirmation",
      status: "fail",
      message: e instanceof Error ? e.message : "Confirmation check failed.",
    });
  }

  // Dev-buy ownership: AUTH must be able to forward the purchased supply to the
  // launcher's own wallet, and must never be left holding it.
  try {
    const { pumpfunDevBuyAutoDelivery } = await import(
      "@/integrations/adapters/pumpfun.server"
    );
    const canForward = pumpfunDevBuyAutoDelivery();
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: stuck } = await supabaseAdmin
      .from("tokens")
      .select("mint,dev_buy_delivery_status,dev_buy_destination_wallet")
      .gt("dev_buy_sol", 0)
      .neq("dev_buy_delivery_status", "delivered")
      .limit(5);
    const undelivered = stuck?.length ?? 0;
    await add({
      id: "dev-buy-ownership",
      label: "Dev-buy ownership and delivery",
      stage: "config_validation",
      status: !canForward ? "warn" : undelivered > 0 ? "warn" : "pass",
      message: !canForward
        ? "Dev buys are blocked: AUTH cannot forward purchased tokens to a launcher wallet on the current provider path."
        : undelivered > 0
          ? `${undelivered} dev buy(s) are not confirmed delivered to the launcher's wallet yet.`
          : "Dev-buy tokens are forwarded to the launcher's own wallet and only marked delivered after on-chain confirmation.",
      detail: { autoDelivery: canForward, undelivered },
    });
  } catch (e) {
    await add({
      id: "dev-buy-ownership",
      label: "Dev-buy ownership and delivery",
      stage: "config_validation",
      status: "fail",
      message: e instanceof Error ? e.message : "Dev-buy ownership check failed.",
    });
  }

  const passed = checks.filter((c) => c.status === "pass").length;
  const failed = checks.filter((c) => c.status === "fail").length;
  const warned = checks.filter((c) => c.status === "warn").length;

  return {
    runKey,
    ranAt,
    broadcast: false,
    checks,
    passed,
    failed,
    warned,
    readyToLaunch: failed === 0 && checks.some((c) => c.id === "submission" && c.status === "pass"),
  };
}
