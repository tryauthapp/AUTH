/**
 * Server-side OAuth for social identity verification.
 *
 * Client secrets, authorization codes, access tokens and refresh tokens never
 * leave this module: the access token is used once to read the authenticated
 * identity and then discarded. Nothing here is ever a wallet key.
 */

import {
  type ProviderMeta,
  type SocialProvider,
  callbackUrl,
  providerMeta,
} from "./providers";

export interface ProviderIdentity {
  providerUserId: string;
  handle: string;
  displayName: string | null;
  avatarUrl: string | null;
  profileUrl: string | null;
}

export type IdentityResult =
  | { ok: true; identity: ProviderIdentity }
  | { ok: false; code: "token_failed" | "profile_failed" | "no_channel" | "unconfigured" };

interface Credentials {
  clientId: string;
  clientSecret: string;
}

/** Reads the provider credentials from server env. Never logged or returned. */
export function providerCredentials(provider: SocialProvider): Credentials | null {
  const meta = providerMeta(provider);
  if (!meta) return null;
  const [idName, secretName] = meta.secretNames;
  const clientId = idName ? process.env[idName] : undefined;
  const clientSecret = secretName ? process.env[secretName] : undefined;
  if (!clientId || !clientSecret) return null;
  return { clientId, clientSecret };
}

export function providerConfigured(provider: SocialProvider): boolean {
  return providerCredentials(provider) !== null;
}

function base64url(bytes: Uint8Array): string {
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

export function randomToken(size = 32): string {
  const bytes = new Uint8Array(size);
  crypto.getRandomValues(bytes);
  return base64url(bytes);
}

export async function pkcePair(): Promise<{ verifier: string; challenge: string }> {
  const verifier = randomToken(48);
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier));
  return { verifier, challenge: base64url(new Uint8Array(digest)) };
}

/** Builds the provider's authorize URL. PKCE is used wherever it is supported. */
export function authorizeUrl(
  meta: ProviderMeta,
  args: { clientId: string; state: string; challenge: string; redirectUri: string },
): string {
  const { clientId, state, challenge, redirectUri } = args;
  const scope = meta.scopes.join(meta.id === "twitch" ? " " : meta.id === "tiktok" ? "," : " ");

  switch (meta.id) {
    case "x": {
      const url = new URL("https://x.com/i/oauth2/authorize");
      url.searchParams.set("response_type", "code");
      url.searchParams.set("client_id", clientId);
      url.searchParams.set("redirect_uri", redirectUri);
      url.searchParams.set("scope", scope);
      url.searchParams.set("state", state);
      url.searchParams.set("code_challenge", challenge);
      url.searchParams.set("code_challenge_method", "S256");
      return url.toString();
    }
    case "tiktok": {
      const url = new URL("https://www.tiktok.com/v2/auth/authorize/");
      url.searchParams.set("client_key", clientId);
      url.searchParams.set("response_type", "code");
      url.searchParams.set("scope", scope);
      url.searchParams.set("redirect_uri", redirectUri);
      url.searchParams.set("state", state);
      url.searchParams.set("code_challenge", challenge);
      url.searchParams.set("code_challenge_method", "S256");
      return url.toString();
    }
    case "youtube": {
      const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
      url.searchParams.set("client_id", clientId);
      url.searchParams.set("response_type", "code");
      url.searchParams.set("redirect_uri", redirectUri);
      url.searchParams.set("scope", scope);
      url.searchParams.set("state", state);
      url.searchParams.set("access_type", "online");
      url.searchParams.set("include_granted_scopes", "false");
      url.searchParams.set("prompt", "consent select_account");
      url.searchParams.set("code_challenge", challenge);
      url.searchParams.set("code_challenge_method", "S256");
      return url.toString();
    }
    case "instagram": {
      // Instagram API with Instagram Login. Meta's endpoint does not accept
      // PKCE, so state is the replay defence here (single-use, 15-min TTL).
      const url = new URL("https://www.instagram.com/oauth/authorize");
      url.searchParams.set("client_id", clientId);
      url.searchParams.set("response_type", "code");
      url.searchParams.set("redirect_uri", redirectUri);
      url.searchParams.set("scope", scope);
      url.searchParams.set("state", state);
      return url.toString();
    }
    case "twitch": {
      const url = new URL("https://id.twitch.tv/oauth2/authorize");
      url.searchParams.set("client_id", clientId);
      url.searchParams.set("response_type", "code");
      url.searchParams.set("redirect_uri", redirectUri);
      url.searchParams.set("scope", scope);
      url.searchParams.set("state", state);
      url.searchParams.set("force_verify", "true");
      return url.toString();
    }
  }
}

async function exchangeCode(
  meta: ProviderMeta,
  creds: Credentials,
  args: { code: string; redirectUri: string; verifier: string },
): Promise<string | null> {
  const { code, redirectUri, verifier } = args;

  const post = async (url: string, body: URLSearchParams, headers: Record<string, string> = {}) => {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded", ...headers },
      body,
    });
    if (!res.ok) return null;
    const json = (await res.json()) as { access_token?: string };
    return json.access_token ?? null;
  };

  switch (meta.id) {
    case "x":
      return post(
        "https://api.x.com/2/oauth2/token",
        new URLSearchParams({
          grant_type: "authorization_code",
          code,
          redirect_uri: redirectUri,
          code_verifier: verifier,
        }),
        { Authorization: `Basic ${btoa(`${creds.clientId}:${creds.clientSecret}`)}` },
      );
    case "tiktok":
      return post(
        "https://open.tiktokapis.com/v2/oauth/token/",
        new URLSearchParams({
          client_key: creds.clientId,
          client_secret: creds.clientSecret,
          code,
          grant_type: "authorization_code",
          redirect_uri: redirectUri,
          code_verifier: verifier,
        }),
      );
    case "youtube":
      return post(
        "https://oauth2.googleapis.com/token",
        new URLSearchParams({
          client_id: creds.clientId,
          client_secret: creds.clientSecret,
          code,
          grant_type: "authorization_code",
          redirect_uri: redirectUri,
          code_verifier: verifier,
        }),
      );
    case "instagram":
      return post(
        "https://api.instagram.com/oauth/access_token",
        new URLSearchParams({
          client_id: creds.clientId,
          client_secret: creds.clientSecret,
          code,
          grant_type: "authorization_code",
          redirect_uri: redirectUri,
        }),
      );
    case "twitch":
      return post(
        "https://id.twitch.tv/oauth2/token",
        new URLSearchParams({
          client_id: creds.clientId,
          client_secret: creds.clientSecret,
          code,
          grant_type: "authorization_code",
          redirect_uri: redirectUri,
        }),
      );
  }
}

async function readIdentity(
  meta: ProviderMeta,
  creds: Credentials,
  accessToken: string,
): Promise<IdentityResult> {
  const auth = { Authorization: `Bearer ${accessToken}` };

  if (meta.id === "x") {
    const { X_USER_FIELDS } = await import("@/lib/x-identity");
    const res = await fetch(
      `https://api.x.com/2/users/me?user.fields=${X_USER_FIELDS.join(",")}`,
      { headers: auth },
    );
    if (!res.ok) return { ok: false, code: "profile_failed" };
    const body = (await res.json()) as {
      data?: { id?: string; username?: string; name?: string; profile_image_url?: string };
    };
    const u = body.data;
    if (!u?.id || !u.username) return { ok: false, code: "profile_failed" };
    return {
      ok: true,
      identity: {
        providerUserId: u.id,
        handle: u.username,
        displayName: u.name ?? null,
        avatarUrl: u.profile_image_url?.replace("_normal", "_400x400") ?? null,
        profileUrl: `https://x.com/${u.username}`,
      },
    };
  }

  if (meta.id === "tiktok") {
    const res = await fetch(
      "https://open.tiktokapis.com/v2/user/info/?fields=open_id,union_id,display_name,avatar_url,username",
      { headers: auth },
    );
    if (!res.ok) return { ok: false, code: "profile_failed" };
    const body = (await res.json()) as {
      data?: {
        user?: {
          open_id?: string;
          union_id?: string;
          display_name?: string;
          avatar_url?: string;
          username?: string;
        };
      };
    };
    const u = body.data?.user;
    // union_id is stable across the developer's apps; open_id is the per-app
    // stable ID. Either is immutable — the username is not.
    const id = u?.union_id ?? u?.open_id;
    if (!id) return { ok: false, code: "profile_failed" };
    const handle = u?.username ?? u?.display_name ?? "";
    if (!handle) return { ok: false, code: "profile_failed" };
    return {
      ok: true,
      identity: {
        providerUserId: id,
        handle,
        displayName: u?.display_name ?? null,
        avatarUrl: u?.avatar_url ?? null,
        profileUrl: u?.username ? `https://www.tiktok.com/@${u.username}` : null,
      },
    };
  }

  if (meta.id === "youtube") {
    // Canonical identity is the YouTube channel, not the Google account.
    const res = await fetch(
      "https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true",
      { headers: auth },
    );
    if (!res.ok) return { ok: false, code: "profile_failed" };
    const body = (await res.json()) as {
      items?: {
        id?: string;
        snippet?: {
          title?: string;
          customUrl?: string;
          thumbnails?: { high?: { url?: string }; default?: { url?: string } };
        };
      }[];
    };
    const channel = body.items?.[0];
    if (!channel?.id) return { ok: false, code: "no_channel" };
    const custom = channel.snippet?.customUrl?.replace(/^@/, "") ?? "";
    return {
      ok: true,
      identity: {
        providerUserId: channel.id,
        handle: custom || channel.id,
        displayName: channel.snippet?.title ?? null,
        avatarUrl:
          channel.snippet?.thumbnails?.high?.url ??
          channel.snippet?.thumbnails?.default?.url ??
          null,
        profileUrl: custom
          ? `https://www.youtube.com/@${custom}`
          : `https://www.youtube.com/channel/${channel.id}`,
      },
    };
  }

  if (meta.id === "instagram") {
    const res = await fetch(
      "https://graph.instagram.com/v21.0/me?fields=id,username,name,profile_picture_url,account_type",
      { headers: auth },
    );
    if (!res.ok) return { ok: false, code: "profile_failed" };
    const body = (await res.json()) as {
      id?: string;
      username?: string;
      name?: string;
      profile_picture_url?: string;
    };
    if (!body.id || !body.username) return { ok: false, code: "profile_failed" };
    return {
      ok: true,
      identity: {
        providerUserId: body.id,
        handle: body.username,
        displayName: body.name ?? null,
        avatarUrl: body.profile_picture_url ?? null,
        profileUrl: `https://www.instagram.com/${body.username}`,
      },
    };
  }

  // Twitch requires the client ID alongside the user token.
  const res = await fetch("https://api.twitch.tv/helix/users", {
    headers: { ...auth, "Client-Id": creds.clientId },
  });
  if (!res.ok) return { ok: false, code: "profile_failed" };
  const body = (await res.json()) as {
    data?: {
      id?: string;
      login?: string;
      display_name?: string;
      profile_image_url?: string;
    }[];
  };
  const u = body.data?.[0];
  if (!u?.id || !u.login) return { ok: false, code: "profile_failed" };
  return {
    ok: true,
    identity: {
      providerUserId: u.id,
      handle: u.login,
      displayName: u.display_name ?? null,
      avatarUrl: u.profile_image_url ?? null,
      profileUrl: `https://www.twitch.tv/${u.login}`,
    },
  };
}

/** Full server-side code exchange + identity read for one provider. */
export async function resolveAuthorizedIdentity(args: {
  meta: ProviderMeta;
  code: string;
  verifier: string;
  redirectUri?: string;
}): Promise<IdentityResult> {
  const creds = providerCredentials(args.meta.id);
  if (!creds) return { ok: false, code: "unconfigured" };

  const redirectUri = args.redirectUri ?? callbackUrl(args.meta);
  const accessToken = await exchangeCode(args.meta, creds, {
    code: args.code,
    redirectUri,
    verifier: args.verifier,
  });
  if (!accessToken) return { ok: false, code: "token_failed" };

  return readIdentity(args.meta, creds, accessToken);
}
