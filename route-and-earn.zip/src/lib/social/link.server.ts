/**
 * Completes a social identity link after the provider proved ownership.
 *
 * Shared by every provider callback. The rules are identical across providers:
 *   - the state row is single-use (replay and duplicate callbacks are rejected)
 *   - the authorized identity must match the identity being claimed
 *   - a provider identity already held by another AUTH account is never
 *     silently reassigned
 *   - the immutable provider ID is the key; the handle is metadata
 *   - completing OAuth links the identity, it never moves funds
 */

import { type ProviderMeta, type SocialProvider } from "./providers";
import { resolveAuthorizedIdentity } from "./oauth.server";

export interface StateRow {
  state: string;
  provider: SocialProvider;
  user_id: string;
  code_verifier: string;
  redirect_uri: string;
  handle_hint: string | null;
  consumed_at: string | null;
  created_at: string;
}

export type LinkOutcome =
  | { status: "linked"; handle: string; wallet: "ready" | string }
  | {
      status:
        | "expired"
        | "invalid"
        | "unconfigured"
        | "token_failed"
        | "profile_failed"
        | "no_channel"
        | "claim_missing"
        | "taken";
      handle?: string;
    }
  | { status: "mismatch"; handle: string; actual: string };

const STATE_TTL_MS = 15 * 60 * 1000;

/** Loads and single-use-consumes the OAuth state row. */
export async function consumeState(state: string): Promise<StateRow | null> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("social_oauth_states")
    .select("state,provider,user_id,code_verifier,redirect_uri,handle_hint,consumed_at,created_at")
    .eq("state", state)
    .maybeSingle();

  if (!data || data.consumed_at) return null;
  if (Date.now() - new Date(data.created_at).getTime() > STATE_TTL_MS) return null;

  // Consume before any network call so a replayed callback cannot re-run this.
  const { data: claimed } = await supabaseAdmin
    .from("social_oauth_states")
    .update({ consumed_at: new Date().toISOString() })
    .eq("state", state)
    .is("consumed_at", null)
    .select("state")
    .maybeSingle();
  if (!claimed) return null;

  return data as StateRow;
}

export async function completeSocialLink(args: {
  meta: ProviderMeta;
  row: StateRow;
  code: string;
}): Promise<LinkOutcome> {
  const { meta, row, code } = args;
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const resolved = await resolveAuthorizedIdentity({
    meta,
    code,
    verifier: row.code_verifier,
    redirectUri: row.redirect_uri,
  });
  if (!resolved.ok) return { status: resolved.code };

  const identity = resolved.identity;
  const hint = (row.handle_hint ?? "").toLowerCase();

  // The authorized account must be the one being claimed — never bind whoever
  // happens to be signed into the provider.
  const matches =
    hint.length > 0 &&
    (hint === identity.handle.toLowerCase() || hint === identity.providerUserId.toLowerCase());
  if (!matches) {
    return { status: "mismatch", handle: row.handle_hint ?? "", actual: identity.handle };
  }

  // Is this provider identity already linked to a different AUTH account?
  const { data: existingIdentity } = await supabaseAdmin
    .from("social_identities")
    .select("id,user_id")
    .eq("provider", meta.id)
    .eq("provider_user_id", identity.providerUserId)
    .is("disconnected_at", null)
    .maybeSingle();
  if (existingIdentity && existingIdentity.user_id !== row.user_id) {
    return { status: "taken", handle: identity.handle };
  }

  // The recipient reserved when the claim started.
  const { data: recipient } = await supabaseAdmin
    .from("recipients")
    .select("id,claimed_by")
    .eq("provider", meta.id)
    .ilike("handle", row.handle_hint ?? identity.handle)
    .maybeSingle();

  if (!recipient) return { status: "claim_missing", handle: identity.handle };
  if (recipient.claimed_by && recipient.claimed_by !== row.user_id) {
    return { status: "taken", handle: identity.handle };
  }

  const now = new Date().toISOString();

  await supabaseAdmin
    .from("recipients")
    .update({
      claimed_by: row.user_id,
      verification: "verified",
      handle: identity.handle,
      provider_user_id: identity.providerUserId,
      display_name: identity.displayName,
      avatar_url: identity.avatarUrl,
      ...(meta.id === "x" ? { x_user_id: identity.providerUserId } : {}),
    })
    .eq("id", recipient.id);

  await supabaseAdmin.from("social_identities").upsert(
    {
      provider: meta.id,
      provider_user_id: identity.providerUserId,
      handle: identity.handle,
      display_name: identity.displayName,
      avatar_url: identity.avatarUrl,
      profile_url: identity.profileUrl,
      user_id: row.user_id,
      recipient_id: recipient.id,
      verified_at: now,
      disconnected_at: null,
      updated_at: now,
    },
    { onConflict: "provider,provider_user_id" },
  );

  if (meta.id === "x") {
    // Keep the original X table in sync for existing readers.
    await supabaseAdmin.from("x_identities").upsert(
      {
        x_user_id: identity.providerUserId,
        handle: identity.handle,
        display_name: identity.displayName,
        avatar_url: identity.avatarUrl,
        user_id: row.user_id,
        recipient_id: recipient.id,
        verified_at: now,
      },
      { onConflict: "x_user_id" },
    );
  }

  // Close any open manual proof claim for this identity.
  await supabaseAdmin
    .from("identity_claims")
    .update({ status: "approved", reviewed_at: now })
    .eq("user_id", row.user_id)
    .eq("recipient_id", recipient.id)
    .neq("status", "approved");

  await supabaseAdmin.from("audit_log").insert({
    actor_id: row.user_id,
    action: "identity.linked",
    entity: "social_identities",
    entity_id: `${meta.id}:${identity.providerUserId}`,
    metadata: { provider: meta.id, handle: identity.handle },
  });

  // Ownership is proven, so this AUTH account gets (or reuses) its single
  // primary Solana payout wallet. Additional verified identities on the same
  // account route into this same wallet instead of creating another one.
  // Turnkey holds the key material; AUTH stores only the address.
  const { ensurePrimaryPayoutWallet } = await import("@/lib/turnkey.server");
  const wallet = await ensurePrimaryPayoutWallet({
    provider: meta.id,
    providerUserId: identity.providerUserId,
    handle: identity.handle,
    userId: row.user_id,
    recipientId: recipient.id,
  });

  if ("address" in wallet) {
    await supabaseAdmin.from("audit_log").insert({
      actor_id: row.user_id,
      action: "wallet.embedded_provisioned",
      entity: "embedded_wallets",
      entity_id: wallet.address,
      metadata: {
        provider: meta.id,
        handle: identity.handle,
        custodian: "turnkey",
        scope: "account_primary_payout_wallet",
        created: wallet.created,
      },
    });
  }

  return {
    status: "linked",
    handle: identity.handle,
    wallet: "address" in wallet ? "ready" : wallet.error,
  };
}

/** Redirect back into the claim UI with a readable outcome. */
export function backToClaim(origin: string, provider: SocialProvider, outcome: LinkOutcome): Response {
  const url = new URL("/claim", origin);
  url.searchParams.set("provider", provider);
  url.searchParams.set("link", outcome.status === "linked" ? "verified" : outcome.status);
  if ("handle" in outcome && outcome.handle) url.searchParams.set("handle", outcome.handle);
  if (outcome.status === "mismatch") url.searchParams.set("actual", outcome.actual);
  if (outcome.status === "linked") url.searchParams.set("wallet", outcome.wallet);
  return new Response(null, { status: 302, headers: { Location: url.toString() } });
}
