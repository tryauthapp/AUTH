/**
 * Supported social identity providers.
 *
 * This module is client-safe: it contains no secrets, only the public shape of
 * each provider (labels, handle rules, which server-side secret names the
 * provider needs, and the callback URL its developer dashboard must register).
 *
 * The canonical ownership key for every provider is its immutable
 * provider_user_id — never the visible handle, which the owner can change.
 */

export type SocialProvider = "x" | "tiktok" | "youtube" | "twitch" | "instagram";

/**
 * How — and whether — a platform lets AUTH resolve a *public* profile from a
 * handle alone, with no involvement from its owner.
 *
 * `api`         the platform publishes a real lookup endpoint AUTH can call.
 * `restricted`  a lookup exists but only for a narrow class of accounts.
 * `owner_only`  the platform exposes no public lookup at all; the only way to
 *               resolve an identity is for its owner to authorize AUTH.
 */
export type LookupKind = "api" | "restricted" | "owner_only";

export interface ProviderMeta {
  id: SocialProvider;
  label: string;
  /** What the provider calls the thing being verified. */
  identityNoun: string;
  /** Prefix shown in front of the handle in the UI. */
  handlePrefix: string;
  /** What the platform itself calls the handle, e.g. "TikTok username". */
  handleLabel: string;
  /** Placeholder shown in the handle field. */
  handlePlaceholder: string;
  /** Server-side secret names required before the provider can go live. */
  secretNames: readonly string[];
  /** Path the provider redirects back to after authorization. */
  callbackPath: string;
  /** Scopes AUTH requests — kept to the minimum that proves ownership. */
  scopes: readonly string[];
  /** Where the developer app is configured. */
  consoleUrl: string;
  handlePattern: RegExp;
  handleHint: string;
  /** Public profile-lookup capability of the platform itself. */
  lookupKind: LookupKind;
  /**
   * Secrets the lookup path needs. Some platforms use different credentials
   * for app-only reads than for user authorization.
   */
  lookupSecretNames: readonly string[];
  /** Honest, user-facing statement of what the platform does not allow. */
  limitation: string | null;
  /** Whether the developer app needs platform review before public use. */
  reviewRequired: boolean;
}

/**
 * X keeps its original callback path so the already-registered developer app
 * keeps working. New providers use the unified path.
 */
export const SOCIAL_PROVIDERS: readonly ProviderMeta[] = [
  {
    id: "x",
    label: "X",
    identityNoun: "account",
    handlePrefix: "@",
    handleLabel: "X handle",
    handlePlaceholder: "username",
    secretNames: ["X_CLIENT_ID", "X_CLIENT_SECRET"],
    callbackPath: "/api/public/x/callback",
    scopes: ["tweet.read", "users.read"],
    consoleUrl: "https://developer.x.com/en/portal/dashboard",
    handlePattern: /^[A-Za-z0-9_]{1,15}$/,
    handleHint: "Letters, numbers and underscore, up to 15 characters.",
    lookupKind: "api",
    lookupSecretNames: ["X_BEARER_TOKEN"],
    limitation: null,
    reviewRequired: false,
  },
  {
    id: "tiktok",
    label: "TikTok",
    identityNoun: "account",
    handlePrefix: "@",
    handleLabel: "TikTok username",
    handlePlaceholder: "username",
    secretNames: ["TIKTOK_CLIENT_KEY", "TIKTOK_CLIENT_SECRET"],
    callbackPath: "/api/public/social/tiktok/callback",
    scopes: ["user.info.basic", "user.info.profile"],
    consoleUrl: "https://developers.tiktok.com/apps",
    handlePattern: /^[A-Za-z0-9_.]{2,24}$/,
    handleHint: "Letters, numbers, underscore and dot.",
    // TikTok's Display API only ever returns the *authorized* user. There is no
    // public username → profile endpoint, so AUTH cannot preview a TikTok
    // profile before its owner signs in.
    lookupKind: "owner_only",
    lookupSecretNames: [],
    limitation:
      "TikTok has no public profile lookup. A TikTok payment is addressed to the username and the profile only resolves once its owner signs in with TikTok to claim it.",
    reviewRequired: true,
  },
  {
    id: "youtube",
    label: "YouTube",
    identityNoun: "channel",
    handlePrefix: "@",
    handleLabel: "YouTube handle",
    handlePlaceholder: "channelhandle",
    secretNames: ["GOOGLE_OAUTH_CLIENT_ID", "GOOGLE_OAUTH_CLIENT_SECRET"],
    callbackPath: "/api/public/social/youtube/callback",
    scopes: ["https://www.googleapis.com/auth/youtube.readonly"],
    consoleUrl: "https://console.cloud.google.com/apis/credentials",
    handlePattern: /^[A-Za-z0-9_.-]{3,30}$/,
    handleHint: "Your channel handle, e.g. @mychannel.",
    lookupKind: "api",
    lookupSecretNames: ["GOOGLE_API_KEY"],
    limitation: null,
    reviewRequired: false,
  },
  {
    id: "twitch",
    label: "Twitch",
    identityNoun: "account",
    handlePrefix: "@",
    handleLabel: "Twitch username",
    handlePlaceholder: "username",
    secretNames: ["TWITCH_CLIENT_ID", "TWITCH_CLIENT_SECRET"],
    callbackPath: "/api/public/social/twitch/callback",
    scopes: ["user:read:email"],
    consoleUrl: "https://dev.twitch.tv/console/apps",
    handlePattern: /^[A-Za-z0-9_]{3,25}$/,
    handleHint: "Letters, numbers and underscore.",
    lookupKind: "api",
    lookupSecretNames: ["TWITCH_CLIENT_ID", "TWITCH_CLIENT_SECRET"],
    limitation: null,
    reviewRequired: false,
  },
  {
    id: "instagram",
    label: "Instagram",
    identityNoun: "account",
    handlePrefix: "@",
    handleLabel: "Instagram username",
    handlePlaceholder: "username",
    secretNames: ["INSTAGRAM_APP_ID", "INSTAGRAM_APP_SECRET"],
    callbackPath: "/api/public/social/instagram/callback",
    scopes: ["instagram_business_basic"],
    consoleUrl: "https://developers.facebook.com/apps",
    handlePattern: /^[A-Za-z0-9_.]{1,30}$/,
    handleHint: "Letters, numbers, underscore and dot.",
    // Meta only exposes lookup through Business Discovery, which requires AUTH
    // to own a linked Instagram professional account AND only resolves other
    // professional (business/creator) accounts. Personal accounts never resolve.
    lookupKind: "restricted",
    lookupSecretNames: ["META_IG_USER_ID", "META_IG_ACCESS_TOKEN"],
    limitation:
      "Meta only allows lookup of Instagram professional (business or creator) accounts, via Business Discovery. Personal accounts cannot be previewed and resolve only when their owner signs in with Instagram.",
    reviewRequired: true,
  },
] as const;

export function providerMeta(id: string): ProviderMeta | undefined {
  return SOCIAL_PROVIDERS.find((p) => p.id === id);
}

export function isSocialProvider(id: string): id is SocialProvider {
  return SOCIAL_PROVIDERS.some((p) => p.id === id);
}

/**
 * Providers only accept pre-registered callback URLs, and AUTH is reachable on
 * several surfaces (published, www, preview). Every OAuth round-trip goes
 * through this one canonical origin so a single registered callback covers all.
 */
export const SOCIAL_CALLBACK_ORIGIN = "https://route-and-earn.lovable.app";

export function callbackUrl(p: ProviderMeta): string {
  return `${SOCIAL_CALLBACK_ORIGIN}${p.callbackPath}`;
}

/** Strips @, URLs and stray whitespace from anything a user types. */
export function normalizeSocialHandle(provider: SocialProvider, raw: string): string {
  let value = String(raw ?? "").trim();
  value = value.replace(
    /^(?:https?:\/\/)?(?:www\.)?(?:x\.com|twitter\.com|tiktok\.com|youtube\.com|twitch\.tv|instagram\.com)\//i,
    "",
  );
  if (provider === "youtube") value = value.replace(/^(?:channel|c|user)\//i, "");
  value = value.replace(/^@+/, "").split(/[/?#]/)[0] ?? "";
  return value.trim();
}

export interface SocialIdentityRecord {
  id: string;
  provider: SocialProvider;
  providerUserId: string;
  handle: string;
  displayName: string | null;
  avatarUrl: string | null;
  profileUrl: string | null;
  verifiedAt: string;
}
