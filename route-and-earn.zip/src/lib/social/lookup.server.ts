/**
 * Public profile lookup, one adapter per platform.
 *
 * Every adapter calls the platform's own official API with server-side
 * credentials. Nothing here scrapes, guesses or fabricates: when credentials
 * are missing the result is `unconfigured`, when the platform publishes no
 * usable endpoint the result is `unsupported`, and when the platform answers
 * "no such account" the result is `not_found`. A profile is only ever returned
 * when the platform itself returned one.
 *
 * Secrets are read from process.env inside the adapters and never returned.
 */

import {
  type SocialProvider,
  providerMeta,
  normalizeSocialHandle,
} from "./providers";
import {
  X_USER_FIELDS,
  X_USER_FIELDS_MINIMAL,
  toXIdentity,
  type XApiUser,
} from "@/lib/x-identity";

/** Canonical internal profile shape shared by every platform. */
export interface PlatformProfile {
  provider: SocialProvider;
  /** Immutable platform-side ID. The durable half of the identity key. */
  platformUserId: string;
  /** Mutable handle — display and addressing metadata only. */
  handle: string;
  displayName: string | null;
  avatarUrl: string | null;
  profileUrl: string | null;
  followerCount: number | null;
  /** Platform-side verification badge, when the API exposes one. */
  platformVerified: boolean | null;
  bio: string | null;
  fetchedAt: string;
}

export type LookupStatus =
  | "ok"
  | "not_found"
  | "unconfigured"
  | "unsupported"
  | "unauthorized"
  | "rate_limited"
  | "error";

export interface LookupResult {
  provider: SocialProvider;
  handle: string;
  status: LookupStatus;
  profile?: PlatformProfile;
  message?: string;
  /** Profile metadata is a point-in-time snapshot, never "current". */
  fetchedAt?: string;
}

// ---------------------------------------------------------------------------
// Diagnostics: the admin integration view reports the last real failure per
// platform. Only status text is retained — never credentials or payloads.
// ---------------------------------------------------------------------------

const lastErrors = new Map<SocialProvider, { message: string; at: string }>();

function noteError(provider: SocialProvider, message: string) {
  lastErrors.set(provider, { message, at: new Date().toISOString() });
}

export function lastLookupError(provider: SocialProvider) {
  return lastErrors.get(provider) ?? null;
}

// Short-lived cache. Follower counts move, so results are explicitly stamped.
const CACHE_MS = 5 * 60 * 1000;
const cache = new Map<string, { expires: number; result: LookupResult }>();

// ---------------------------------------------------------------------------
// X
// ---------------------------------------------------------------------------

let xBearerCache: { token: string; expires: number } | null = null;

async function xAppBearer(): Promise<string | null> {
  const direct = process.env["X_BEARER_TOKEN"];
  if (direct) return direct.trim();

  const key = process.env["X_API_KEY"];
  const secret = process.env["X_API_SECRET"];
  if (!key || !secret) return null;
  if (xBearerCache && xBearerCache.expires > Date.now()) return xBearerCache.token;

  const basic = btoa(`${encodeURIComponent(key)}:${encodeURIComponent(secret)}`);
  const res = await fetch("https://api.x.com/oauth2/token", {
    method: "POST",
    headers: {
      Authorization: `Basic ${basic}`,
      "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
    },
    body: "grant_type=client_credentials",
  });
  if (!res.ok) return null;
  const json = (await res.json()) as { access_token?: string };
  if (!json.access_token) return null;
  xBearerCache = { token: json.access_token, expires: Date.now() + 30 * 60 * 1000 };
  return json.access_token;
}

async function lookupX(handle: string): Promise<LookupResult> {
  const bearer = await xAppBearer();
  if (!bearer) {
    return {
      provider: "x",
      handle,
      status: "unconfigured",
      message: "X profile lookup needs X_BEARER_TOKEN (or X_API_KEY + X_API_SECRET).",
    };
  }

  const request = (fields: readonly string[]) => {
    const url = new URL(`https://api.x.com/2/users/by/username/${handle}`);
    url.searchParams.set("user.fields", fields.join(","));
    return fetch(url, { headers: { Authorization: `Bearer ${bearer}` } });
  };

  let res: Response;
  try {
    res = await request(X_USER_FIELDS);
    // Some access tiers reject specific fields; retry with the minimal set.
    if (res.status === 400) res = await request(X_USER_FIELDS_MINIMAL);
  } catch {
    noteError("x", "Could not reach the X API.");
    return { provider: "x", handle, status: "error", message: "Could not reach the X API." };
  }

  if (res.status === 429) {
    noteError("x", "Rate limited by the X API.");
    return { provider: "x", handle, status: "rate_limited", message: "X API rate limit reached." };
  }
  if (res.status === 401 || res.status === 402 || res.status === 403) {
    const message =
      res.status === 402
        ? "The X API plan has no request credits left."
        : "The X API token was rejected or the plan does not allow user lookup.";
    noteError("x", message);
    return { provider: "x", handle, status: "unauthorized", message };
  }
  if (!res.ok && res.status !== 404) {
    noteError("x", `X API error ${res.status}.`);
    return { provider: "x", handle, status: "error", message: `X API error (${res.status}).` };
  }

  const json = (await res.json().catch(() => null)) as { data?: XApiUser } | null;
  if (!json?.data) {
    return { provider: "x", handle, status: "not_found", message: "No X account found." };
  }

  const x = toXIdentity(json.data);
  return {
    provider: "x",
    handle: x.username,
    status: "ok",
    fetchedAt: x.fetchedAt,
    profile: {
      provider: "x",
      platformUserId: x.id,
      handle: x.username,
      displayName: x.name,
      avatarUrl: x.avatarUrl,
      profileUrl: `https://x.com/${x.username}`,
      followerCount: x.followers,
      platformVerified: x.verified,
      bio: x.description,
      fetchedAt: x.fetchedAt,
    },
  };
}

// ---------------------------------------------------------------------------
// YouTube (Data API v3)
// ---------------------------------------------------------------------------

async function lookupYouTube(handle: string): Promise<LookupResult> {
  const apiKey = process.env["YOUTUBE_API_KEY"] || process.env["GOOGLE_API_KEY"];
  if (!apiKey) {
    return {
      provider: "youtube",
      handle,
      status: "unconfigured",
      message: "YouTube channel lookup needs YOUTUBE_API_KEY (or GOOGLE_API_KEY).",
    };
  }

  const base = "https://www.googleapis.com/youtube/v3/channels";
  const params = (extra: Record<string, string>) =>
    new URLSearchParams({ part: "snippet,statistics", key: apiKey, ...extra });

  // A channel can be addressed by handle, by legacy username or by raw ID.
  const attempts = [
    params({ forHandle: `@${handle}` }),
    params({ forUsername: handle }),
    ...(handle.startsWith("UC") ? [params({ id: handle })] : []),
  ];

  for (const query of attempts) {
    let res: Response;
    try {
      res = await fetch(`${base}?${query.toString()}`);
    } catch {
      noteError("youtube", "Could not reach the YouTube Data API.");
      return { provider: "youtube", handle, status: "error", message: "Could not reach YouTube." };
    }
    if (res.status === 403) {
      const message = "The YouTube API key was rejected or its quota is exhausted.";
      noteError("youtube", message);
      return { provider: "youtube", handle, status: "unauthorized", message };
    }
    if (!res.ok) continue;

    const body = (await res.json().catch(() => null)) as {
      items?: {
        id?: string;
        snippet?: {
          title?: string;
          description?: string;
          customUrl?: string;
          thumbnails?: { high?: { url?: string }; default?: { url?: string } };
        };
        statistics?: { subscriberCount?: string; hiddenSubscriberCount?: boolean };
      }[];
    } | null;

    const channel = body?.items?.[0];
    if (!channel?.id) continue;

    const custom = channel.snippet?.customUrl?.replace(/^@/, "") || channel.id;
    const subs = channel.statistics?.subscriberCount;
    const fetchedAt = new Date().toISOString();
    return {
      provider: "youtube",
      handle: custom,
      status: "ok",
      fetchedAt,
      profile: {
        provider: "youtube",
        platformUserId: channel.id,
        handle: custom,
        displayName: channel.snippet?.title ?? null,
        avatarUrl:
          channel.snippet?.thumbnails?.high?.url ??
          channel.snippet?.thumbnails?.default?.url ??
          null,
        profileUrl: channel.snippet?.customUrl
          ? `https://www.youtube.com/@${custom}`
          : `https://www.youtube.com/channel/${channel.id}`,
        // Hidden subscriber counts are reported as null, never as zero.
        followerCount:
          channel.statistics?.hiddenSubscriberCount || !subs ? null : Number(subs),
        platformVerified: null,
        bio: channel.snippet?.description?.trim() || null,
        fetchedAt,
      },
    };
  }

  return { provider: "youtube", handle, status: "not_found", message: "No YouTube channel found." };
}

// ---------------------------------------------------------------------------
// Twitch (Helix)
// ---------------------------------------------------------------------------

let twitchTokenCache: { token: string; expires: number } | null = null;

async function twitchAppToken(id: string, secret: string): Promise<string | null> {
  if (twitchTokenCache && twitchTokenCache.expires > Date.now()) return twitchTokenCache.token;
  const res = await fetch("https://id.twitch.tv/oauth2/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: id,
      client_secret: secret,
      grant_type: "client_credentials",
    }),
  });
  if (!res.ok) return null;
  const json = (await res.json()) as { access_token?: string; expires_in?: number };
  if (!json.access_token) return null;
  twitchTokenCache = {
    token: json.access_token,
    expires: Date.now() + Math.max(60, (json.expires_in ?? 3600) - 60) * 1000,
  };
  return json.access_token;
}

async function lookupTwitch(handle: string): Promise<LookupResult> {
  const clientId = process.env["TWITCH_CLIENT_ID"];
  const clientSecret = process.env["TWITCH_CLIENT_SECRET"];
  if (!clientId || !clientSecret) {
    return {
      provider: "twitch",
      handle,
      status: "unconfigured",
      message: "Twitch lookup needs TWITCH_CLIENT_ID and TWITCH_CLIENT_SECRET.",
    };
  }

  const token = await twitchAppToken(clientId, clientSecret);
  if (!token) {
    const message = "Twitch rejected the app credentials.";
    noteError("twitch", message);
    return { provider: "twitch", handle, status: "unauthorized", message };
  }

  let res: Response;
  try {
    res = await fetch(`https://api.twitch.tv/helix/users?login=${encodeURIComponent(handle)}`, {
      headers: { "Client-Id": clientId, Authorization: `Bearer ${token}` },
    });
  } catch {
    noteError("twitch", "Could not reach the Twitch API.");
    return { provider: "twitch", handle, status: "error", message: "Could not reach Twitch." };
  }

  if (res.status === 401) {
    twitchTokenCache = null;
    const message = "The Twitch app token was rejected.";
    noteError("twitch", message);
    return { provider: "twitch", handle, status: "unauthorized", message };
  }
  if (res.status === 429) {
    return { provider: "twitch", handle, status: "rate_limited", message: "Twitch rate limit reached." };
  }
  if (!res.ok) {
    noteError("twitch", `Twitch API error ${res.status}.`);
    return { provider: "twitch", handle, status: "error", message: `Twitch API error (${res.status}).` };
  }

  const body = (await res.json().catch(() => null)) as {
    data?: {
      id?: string;
      login?: string;
      display_name?: string;
      description?: string;
      profile_image_url?: string;
      broadcaster_type?: string;
    }[];
  } | null;

  const user = body?.data?.[0];
  if (!user?.id || !user.login) {
    return { provider: "twitch", handle, status: "not_found", message: "No Twitch account found." };
  }

  const fetchedAt = new Date().toISOString();
  return {
    provider: "twitch",
    handle: user.login,
    status: "ok",
    fetchedAt,
    profile: {
      provider: "twitch",
      platformUserId: user.id,
      handle: user.login,
      displayName: user.display_name ?? null,
      avatarUrl: user.profile_image_url ?? null,
      profileUrl: `https://twitch.tv/${user.login}`,
      // Helix /users carries no follower total; it needs a separate scoped
      // endpoint, so AUTH reports null rather than a guess.
      followerCount: null,
      platformVerified: user.broadcaster_type === "partner" ? true : null,
      bio: user.description?.trim() || null,
      fetchedAt,
    },
  };
}

// ---------------------------------------------------------------------------
// Instagram (Graph API Business Discovery)
// ---------------------------------------------------------------------------

async function lookupInstagram(handle: string): Promise<LookupResult> {
  const igUserId = process.env["META_IG_USER_ID"];
  const token = process.env["META_IG_ACCESS_TOKEN"];
  if (!igUserId || !token) {
    return {
      provider: "instagram",
      handle,
      status: "unconfigured",
      message:
        "Instagram lookup needs META_IG_USER_ID and META_IG_ACCESS_TOKEN (a linked Instagram professional account). Personal accounts can never be looked up.",
    };
  }

  const fields = `business_discovery.username(${handle}){id,username,name,biography,profile_picture_url,followers_count}`;
  const url = new URL(`https://graph.facebook.com/v21.0/${igUserId}`);
  url.searchParams.set("fields", fields);
  url.searchParams.set("access_token", token);

  let res: Response;
  try {
    res = await fetch(url);
  } catch {
    noteError("instagram", "Could not reach the Meta Graph API.");
    return { provider: "instagram", handle, status: "error", message: "Could not reach Instagram." };
  }

  const body = (await res.json().catch(() => null)) as {
    business_discovery?: {
      id?: string;
      username?: string;
      name?: string;
      biography?: string;
      profile_picture_url?: string;
      followers_count?: number;
    };
    error?: { message?: string; code?: number };
  } | null;

  if (!res.ok || !body?.business_discovery) {
    const code = body?.error?.code;
    // 110 / 24 are Meta's "cannot resolve this user" family — most often a
    // personal account, which Business Discovery is not permitted to return.
    if (code === 110 || code === 24 || res.status === 400) {
      return {
        provider: "instagram",
        handle,
        status: "unsupported",
        message:
          "Instagram did not return this account. Business Discovery only resolves professional (business or creator) accounts.",
      };
    }
    const message = body?.error?.message ?? `Instagram API error (${res.status}).`;
    noteError("instagram", message);
    return { provider: "instagram", handle, status: "unauthorized", message };
  }

  const u = body.business_discovery;
  if (!u.id || !u.username) {
    return { provider: "instagram", handle, status: "not_found", message: "No Instagram account found." };
  }

  const fetchedAt = new Date().toISOString();
  return {
    provider: "instagram",
    handle: u.username,
    status: "ok",
    fetchedAt,
    profile: {
      provider: "instagram",
      platformUserId: u.id,
      handle: u.username,
      displayName: u.name ?? null,
      avatarUrl: u.profile_picture_url ?? null,
      profileUrl: `https://instagram.com/${u.username}`,
      followerCount: typeof u.followers_count === "number" ? u.followers_count : null,
      platformVerified: null,
      bio: u.biography?.trim() || null,
      fetchedAt,
    },
  };
}

// ---------------------------------------------------------------------------
// TikTok
// ---------------------------------------------------------------------------

function lookupTikTok(handle: string): LookupResult {
  // TikTok's Display API resolves the authorized user only; there is no public
  // username endpoint at any access tier. Saying so is the honest answer.
  return {
    provider: "tiktok",
    handle,
    status: "unsupported",
    message:
      "TikTok publishes no public profile lookup. The account resolves when its owner signs in with TikTok to claim it.",
  };
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------

/** Whether the lookup path for a platform has its credentials configured. */
export function lookupConfigured(provider: SocialProvider): boolean {
  switch (provider) {
    case "x":
      return Boolean(
        process.env["X_BEARER_TOKEN"] ||
          (process.env["X_API_KEY"] && process.env["X_API_SECRET"]),
      );
    case "youtube":
      return Boolean(process.env["YOUTUBE_API_KEY"] || process.env["GOOGLE_API_KEY"]);
    case "twitch":
      return Boolean(process.env["TWITCH_CLIENT_ID"] && process.env["TWITCH_CLIENT_SECRET"]);
    case "instagram":
      return Boolean(process.env["META_IG_USER_ID"] && process.env["META_IG_ACCESS_TOKEN"]);
    case "tiktok":
      return false;
  }
}

export async function lookupPlatformProfile(
  provider: SocialProvider,
  rawHandle: string,
): Promise<LookupResult> {
  const meta = providerMeta(provider);
  const handle = normalizeSocialHandle(provider, rawHandle);
  if (!meta || !handle || !meta.handlePattern.test(handle)) {
    return {
      provider,
      handle,
      status: "not_found",
      message: meta ? `Enter a valid ${meta.label} ${meta.identityNoun}. ${meta.handleHint}` : "Unsupported platform.",
    };
  }

  const key = `${provider}:${handle.toLowerCase()}`;
  const hit = cache.get(key);
  if (hit && hit.expires > Date.now()) return hit.result;

  let result: LookupResult;
  switch (provider) {
    case "x":
      result = await lookupX(handle);
      break;
    case "youtube":
      result = await lookupYouTube(handle);
      break;
    case "twitch":
      result = await lookupTwitch(handle);
      break;
    case "instagram":
      result = await lookupInstagram(handle);
      break;
    case "tiktok":
      result = lookupTikTok(handle);
      break;
  }

  // Only cache settled answers; transient failures must be retried.
  if (result.status === "ok" || result.status === "not_found") {
    cache.set(key, { expires: Date.now() + (result.status === "ok" ? CACHE_MS : 60_000), result });
  }
  return result;
}
