import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const AUTH_ERA_START = "2026-09-21T12:50:00.000Z";

const InputSchema = z.object({
  cachedCount: z.number().int().nonnegative(),
  cachedNewestAt: z.string().nullable(),
  cacheUpdatedAt: z.string(),
});

export const checkLaunchDataHealth = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => InputSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { data: isAdmin, error: roleError } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (roleError || !isAdmin) throw new Error("Admins only.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const [{ count, error: countError }, { data: newest, error: newestError }] = await Promise.all([
      supabaseAdmin
        .from("tokens")
        .select("id", { count: "exact", head: true })
        .eq("is_demo", false)
        .gte("created_at", AUTH_ERA_START),
      supabaseAdmin
        .from("tokens")
        .select("created_at")
        .eq("is_demo", false)
        .gte("created_at", AUTH_ERA_START)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle(),
    ]);
    if (countError || newestError) throw new Error("Could not read authoritative launch records.");

    const databaseCount = count ?? 0;
    const databaseNewestAt = newest?.created_at ?? null;
    const cacheAgeMs = Date.now() - new Date(data.cacheUpdatedAt).getTime();
    const countMatches = data.cachedCount === databaseCount;
    const newestMatches = data.cachedNewestAt === databaseNewestAt;
    const stale = !Number.isFinite(cacheAgeMs) || cacheAgeMs > 5 * 60 * 1000;

    return {
      status: countMatches && newestMatches && !stale ? "healthy" as const : "attention" as const,
      cachedCount: data.cachedCount,
      databaseCount,
      cachedNewestAt: data.cachedNewestAt,
      databaseNewestAt,
      cacheUpdatedAt: data.cacheUpdatedAt,
      checkedAt: new Date().toISOString(),
      countMatches,
      newestMatches,
      stale,
    };
  });