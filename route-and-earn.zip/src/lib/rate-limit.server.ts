/**
 * SERVER ONLY. Fixed-window rate limiting for endpoints that cost real money
 * or real upstream quota: platform profile lookups, payment creation, launches.
 *
 * Per worker instance, so the effective global limit is this multiplied by the
 * number of live instances. That is deliberate: the goal is to stop one client
 * from burning an API quota or hammering the chain, not to meter billing.
 */

import { getRequestHeader } from "@tanstack/react-start/server";

type Window = { count: number; resetAt: number };

const windows = new Map<string, Window>();
const MAX_KEYS = 20_000;

/** Best-effort caller identity: the real client IP behind the edge proxy. */
export function callerKey(suffix = ""): string {
  let ip = "unknown";
  try {
    ip =
      getRequestHeader("cf-connecting-ip") ??
      getRequestHeader("x-real-ip") ??
      (getRequestHeader("x-forwarded-for") ?? "").split(",")[0]?.trim() ??
      "unknown";
  } catch {
    ip = "unknown";
  }
  return `${ip || "unknown"}:${suffix}`;
}

export class RateLimitError extends Error {
  readonly retryAfterSeconds: number;
  constructor(retryAfterSeconds: number) {
    super(
      `Too many requests. Please wait ${retryAfterSeconds} second${
        retryAfterSeconds === 1 ? "" : "s"
      } and try again.`,
    );
    this.name = "RateLimitError";
    this.retryAfterSeconds = retryAfterSeconds;
  }
}

/**
 * Consumes one unit against `bucket`. Throws RateLimitError when the caller has
 * exceeded `limit` requests inside `windowMs`.
 */
export function enforceRateLimit(bucket: string, limit: number, windowMs: number) {
  const key = callerKey(bucket);
  const now = Date.now();

  if (windows.size > MAX_KEYS) {
    for (const [k, w] of windows) if (w.resetAt <= now) windows.delete(k);
    if (windows.size > MAX_KEYS) windows.clear();
  }

  const current = windows.get(key);
  if (!current || current.resetAt <= now) {
    windows.set(key, { count: 1, resetAt: now + windowMs });
    return;
  }
  current.count += 1;
  if (current.count > limit) {
    throw new RateLimitError(Math.max(1, Math.ceil((current.resetAt - now) / 1000)));
  }
}
