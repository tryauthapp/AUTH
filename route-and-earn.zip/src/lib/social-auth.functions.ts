import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  SOCIAL_PROVIDERS,
  type SocialProvider,
  callbackUrl,
  isSocialProvider,
  normalizeSocialHandle,
  providerMeta,
} from "@/lib/social/providers";

/**
 * Social identity verification (OAuth 2.0, PKCE where supported).
 *
 * This is a claim-security mechanism, not an AUTH login: it proves a person
 * controls the account behind a handle or channel. Client secrets and tokens
 * stay server-side. Completing OAuth links an identity — releasing funds still
 * requires the authenticated AUTH session and an explicit authorization step.
 */

export interface ProviderStatus {
  id: SocialProvider;
  label: string;
  identityNoun: string;
  handlePrefix: string;
  handleHint: string;
  /** True only when real credentials are present on the server. */
  configured: boolean;
  secretNames: string[];
  missingSecrets: string[];
  callbackUrl: string;
  consoleUrl: string;
  scopes: string[];
}

/** Which providers are actually live, and what is missing for the rest. */
export const socialProviderStatus = createServerFn({ method: "GET" }).handler(
  async (): Promise<ProviderStatus[]> =>
    SOCIAL_PROVIDERS.map((p) => {
      const missing = p.secretNames.filter((name) => !process.env[name]);
      return {
        id: p.id,
        label: p.label,
        identityNoun: p.identityNoun,
        handlePrefix: p.handlePrefix,
        handleHint: p.handleHint,
        configured: missing.length === 0,
        secretNames: [...p.secretNames],
        missingSecrets: missing,
        callbackUrl: callbackUrl(p),
        consoleUrl: p.consoleUrl,
        scopes: [...p.scopes],
      };
    }),
);

export interface StartLinkResult {
  ok: boolean;
  url?: string;
  message?: string;
}

/** Starts provider authorization for the identity the caller is claiming. */
export const startSocialLink = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { provider: string; handle: string }) => {
    if (!isSocialProvider(input.provider)) throw new Error("Unsupported provider.");
    const meta = providerMeta(input.provider)!;
    const handle = normalizeSocialHandle(input.provider, input.handle);
    if (!meta.handlePattern.test(handle)) {
      throw new Error(`Enter a valid ${meta.label} ${meta.identityNoun}. ${meta.handleHint}`);
    }
    return { provider: input.provider, handle };
  })
  .handler(async ({ data, context }): Promise<StartLinkResult> => {
    const meta = providerMeta(data.provider)!;
    const { providerCredentials, pkcePair, randomToken, authorizeUrl } = await import(
      "@/lib/social/oauth.server"
    );

    const creds = providerCredentials(data.provider);
    if (!creds) {
      return {
        ok: false,
        message: `${meta.label} verification isn't configured yet.`,
      };
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: claim } = await supabaseAdmin
      .from("identity_claims")
      .select("id")
      .eq("user_id", context.userId)
      .ilike("handle", data.handle)
      .in("status", ["pending", "submitted"])
      .gt("proof_code_expires_at", new Date().toISOString())
      .maybeSingle();
    if (!claim) {
      return { ok: false, message: "Start the identity claim before verifying ownership." };
    }

    const { verifier, challenge } = await pkcePair();
    const state = randomToken(24);
    const redirectUri = callbackUrl(meta);

    const { error } = await supabaseAdmin.from("social_oauth_states").insert({
      state,
      provider: data.provider,
      user_id: context.userId,
      code_verifier: verifier,
      redirect_uri: redirectUri,
      handle_hint: data.handle,
    });
    if (error) return { ok: false, message: "Could not start verification. Try again." };

    return {
      ok: true,
      url: authorizeUrl(meta, { clientId: creds.clientId, state, challenge, redirectUri }),
    };
  });

export interface ConnectedIdentity {
  id: string;
  provider: SocialProvider;
  providerUserId: string;
  handle: string;
  displayName: string | null;
  avatarUrl: string | null;
  profileUrl: string | null;
  verifiedAt: string;
  recipientId: string | null;
}

/** Identities linked to the caller's AUTH account. */
export const myConnectedIdentities = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<ConnectedIdentity[]> => {
    const { data } = await context.supabase
      .from("social_identities")
      .select(
        "id,provider,provider_user_id,handle,display_name,avatar_url,profile_url,verified_at,recipient_id",
      )
      .eq("user_id", context.userId)
      .is("disconnected_at", null)
      .order("verified_at", { ascending: false });

    return (data ?? []).map((row) => ({
      id: row.id,
      provider: row.provider as SocialProvider,
      providerUserId: row.provider_user_id,
      handle: row.handle,
      displayName: row.display_name,
      avatarUrl: row.avatar_url,
      profileUrl: row.profile_url,
      verifiedAt: row.verified_at,
      recipientId: row.recipient_id,
    }));
  });

/**
 * Unlinks an identity from the caller's account.
 *
 * The embedded wallet stays bound to the provider identity — disconnecting is
 * not a transfer of ownership and never moves funds. Re-verifying with the same
 * provider account restores the link.
 */
export const disconnectSocialIdentity = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { identityId: string }) => {
    if (!input.identityId) throw new Error("Missing identity.");
    return input;
  })
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: identity } = await supabaseAdmin
      .from("social_identities")
      .select("id,user_id,provider,provider_user_id,handle,recipient_id")
      .eq("id", data.identityId)
      .maybeSingle();

    if (!identity || identity.user_id !== context.userId) {
      return { ok: false as const, message: "That identity is not linked to your account." };
    }

    const now = new Date().toISOString();
    await supabaseAdmin
      .from("social_identities")
      .update({ disconnected_at: now, updated_at: now })
      .eq("id", identity.id);

    if (identity.recipient_id) {
      await supabaseAdmin
        .from("recipients")
        .update({ claimed_by: null, verification: "unverified" })
        .eq("id", identity.recipient_id);
    }

    await supabaseAdmin.from("audit_log").insert({
      actor_id: context.userId,
      action: "identity.unlinked",
      entity: "social_identities",
      entity_id: `${identity.provider}:${identity.provider_user_id}`,
      metadata: { provider: identity.provider, handle: identity.handle },
    });

    return { ok: true as const, message: `${identity.handle} disconnected.` };
  });

/**
 * Publicly visible verified identities for one AUTH payment identity.
 *
 * Runs server-side with an explicit safe-column projection: immutable provider
 * IDs and the owning AUTH user id are never selected, so nothing here can be
 * used to impersonate an identity. Anonymous Data API reads of
 * `social_identities` are revoked, so this must not use the browser client.
 */
export const publicIdentitiesForRecipient = createServerFn({ method: "GET" })
  .inputValidator((input: { recipientId: string }) => input)
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: rows } = await supabaseAdmin
      .from("social_identities")
      .select("id,provider,handle,display_name,avatar_url,profile_url,verified_at")
      .eq("recipient_id", data.recipientId)
      .is("disconnected_at", null);
    return rows ?? [];
  });
