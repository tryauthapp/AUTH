import { ComputeBudgetProgram, Keypair, PublicKey, SystemProgram, TransactionMessage, VersionedTransaction } from "@solana/web3.js";
import { ADDRESS_RE } from "@/lib/solana";
import { loadLauncherKeypair } from "@/lib/launcher-wallet.server";
import {
  getLatestBlockhash,
  getSolBalance,
  LAMPORTS_PER_SOL,
  sendRawTransactionBase64,
} from "@/integrations/adapters/helius.server";

/**
 * Launcher-wallet outbound SOL transfers — SERVER ONLY.
 *
 * Signs with the launcher key held in server secrets (`LAUNCHER_PRIVATE_KEY`)
 * and broadcasts through the configured RPC. Used for tiny live deposit tests:
 * the private key never leaves the server runtime and is never logged.
 */

/** Hard cap per transfer so a bug can never drain the launch wallet. */
const MAX_TRANSFER_SOL = 0.5;
/** Kept behind per transfer so the wallet can still pay network fees. */
const MIN_RESERVE_SOL = 0.01;

export type LauncherSendResult =
  | { ok: true; signature: string; from: string; amountSol: number }
  | { ok: false; message: string };

export async function sendSolFromLauncher(params: {
  to: string;
  amountSol: number;
}): Promise<LauncherSendResult> {
  const keypair: Keypair | null = loadLauncherKeypair();
  if (!keypair) {
    return { ok: false, message: "The launch wallet is not configured on the server." };
  }
  const to = params.to.trim();
  if (!ADDRESS_RE.test(to)) {
    return { ok: false, message: "The destination address is not a valid Solana address." };
  }
  let toPubkey: PublicKey;
  try {
    toPubkey = new PublicKey(to);
  } catch {
    return { ok: false, message: "The destination address is not a valid Solana address." };
  }

  const amount = Number(params.amountSol);
  if (!Number.isFinite(amount) || amount <= 0 || amount > MAX_TRANSFER_SOL) {
    return { ok: false, message: `Amount must be between 0 and ${MAX_TRANSFER_SOL} SOL.` };
  }

  const balance = await getSolBalance(keypair.publicKey.toBase58());
  if (!balance.ok) {
    return { ok: false, message: "Could not read the launch wallet balance." };
  }
  if (balance.data < amount + MIN_RESERVE_SOL) {
    return {
      ok: false,
      message: `The launch wallet only holds ${balance.data.toFixed(4)} SOL — top it up first.`,
    };
  }

  const blockhash = await getLatestBlockhash();
  if (!blockhash.ok) {
    return { ok: false, message: "Could not reach Solana to fetch a blockhash." };
  }

  const message = new TransactionMessage({
    payerKey: keypair.publicKey,
    recentBlockhash: blockhash.data.blockhash,
    instructions: [
      ComputeBudgetProgram.setComputeUnitPrice({ microLamports: 10_000 }),
      SystemProgram.transfer({
        fromPubkey: keypair.publicKey,
        toPubkey,
        lamports: BigInt(Math.round(amount * LAMPORTS_PER_SOL)),
      }),
    ],
  }).compileToV0Message();

  const tx = new VersionedTransaction(message);
  tx.sign([keypair]);
  const encoded = Buffer.from(tx.serialize()).toString("base64");

  const sent = await sendRawTransactionBase64(encoded);
  if (!sent.ok) {
    return { ok: false, message: sent.message };
  }
  return {
    ok: true,
    signature: sent.data,
    from: keypair.publicKey.toBase58(),
    amountSol: amount,
  };
}
