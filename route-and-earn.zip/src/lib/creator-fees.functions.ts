import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Admin visibility and manual trigger for the creator-fee automation.
 * Detection itself is automatic (event-driven plus a 5-minute cron fallback);
 * this only reports state and lets an admin force a pass.
 */

export interface CreatorFeeMintState {
  mint: string;
  recipientHandle: string | null;
  provider: string | null;
  creatorVault: string | null;
  lastSyncedAt: string | null;
  lastError: string | null;
  eventsProcessed: number;
  creditsCreated: number;
  solCredited: number;
}

export interface CreatorFeeStatus {
  isAdmin: boolean;
  cronIntervalMinutes: number;
  lastRunAt: string | null;
  lastSuccessAt: string | null;
  lastError: string | null;
  nextRunEstimate: string | null;
  totals: { runs: number; eventsProcessed: number; creditsCreated: number; solCredited: number };
  accrued: { rows: number; sol: number };
  mints: CreatorFeeMintState[];
}

const CRON_INTERVAL_MINUTES = 5;

export const getCreatorFeeStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<CreatorFeeStatus> => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });

    const empty: CreatorFeeStatus = {
      isAdmin: Boolean(isAdmin),
      cronIntervalMinutes: CRON_INTERVAL_MINUTES,
      lastRunAt: null,
      lastSuccessAt: null,
      lastError: null,
      nextRunEstimate: null,
      totals: { runs: 0, eventsProcessed: 0, creditsCreated: 0, solCredited: 0 },
      accrued: { rows: 0, sol: 0 },
      mints: [],
    };
    if (!isAdmin) return empty;

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: runs } = await supabaseAdmin
      .from("creator_fee_sync_runs")
      .select("status,started_at,finished_at,error,events_processed,credits_created,lamports_credited")
      .order("started_at", { ascending: false })
      .limit(100);

    const runRows = runs ?? [];
    const lastRun = runRows[0] ?? null;
    const lastSuccess = runRows.find((r) => r.status === "ok") ?? null;
    const lastFailed = runRows.find((r) => r.error) ?? null;

    const totals = runRows.reduce(
      (acc, r) => ({
        runs: acc.runs + 1,
        eventsProcessed: acc.eventsProcessed + (r.events_processed ?? 0),
        creditsCreated: acc.creditsCreated + (r.credits_created ?? 0),
        solCredited: acc.solCredited + Number(r.lamports_credited ?? 0) / 1_000_000_000,
      }),
      { runs: 0, eventsProcessed: 0, creditsCreated: 0, solCredited: 0 },
    );

    const { data: states } = await supabaseAdmin
      .from("creator_fee_mint_state")
      .select("mint,recipient_id,provider,creator_vault,last_synced_at,last_error,events_processed,credits_created,lamports_credited")
      .order("last_synced_at", { ascending: false })
      .limit(25);

    const recipientIds = [...new Set((states ?? []).map((s) => s.recipient_id).filter(Boolean))] as string[];
    const handles = new Map<string, string>();
    if (recipientIds.length > 0) {
      const { data: recipients } = await supabaseAdmin
        .from("recipients")
        .select("id,handle")
        .in("id", recipientIds);
      for (const r of recipients ?? []) handles.set(r.id, r.handle);
    }

    const { data: accruedRows } = await supabaseAdmin
      .from("identity_ledger")
      .select("amount")
      .eq("source", "creator_fee")
      .eq("status", "accrued")
      .limit(1000);
    const accruedSol = (accruedRows ?? []).reduce((acc, r) => acc + Number(r.amount ?? 0), 0);

    const nextRun = lastRun?.started_at
      ? new Date(new Date(lastRun.started_at).getTime() + CRON_INTERVAL_MINUTES * 60_000).toISOString()
      : null;

    return {
      isAdmin: true,
      cronIntervalMinutes: CRON_INTERVAL_MINUTES,
      lastRunAt: lastRun?.started_at ?? null,
      lastSuccessAt: lastSuccess?.finished_at ?? lastSuccess?.started_at ?? null,
      lastError: lastFailed?.error ?? null,
      nextRunEstimate: nextRun,
      totals,
      accrued: { rows: accruedRows?.length ?? 0, sol: accruedSol },
      mints: (states ?? []).map((s) => ({
        mint: s.mint,
        recipientHandle: s.recipient_id ? handles.get(s.recipient_id) ?? null : null,
        provider: s.provider,
        creatorVault: s.creator_vault,
        lastSyncedAt: s.last_synced_at,
        lastError: s.last_error,
        eventsProcessed: s.events_processed ?? 0,
        creditsCreated: s.credits_created ?? 0,
        solCredited: Number(s.lamports_credited ?? 0) / 1_000_000_000,
      })),
    };
  });

export const runCreatorFeeSyncNow = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<{ ok: boolean; message: string }> => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Admin access is required.");

    const { enforceRateLimit } = await import("@/lib/rate-limit.server");
    enforceRateLimit("creator-fee-sync-manual", 5, 60_000);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { reconcileCreatorFees } = await import("@/lib/fees/creator-fee-indexer.server");
    const { settleCreatorFees } = await import("@/lib/fees/creator-fee-settlement.server");

    const { data: run } = await supabaseAdmin
      .from("creator_fee_sync_runs")
      .insert({ trigger: "admin", status: "running" })
      .select("id")
      .single();

    const reconciled = await reconcileCreatorFees();
    const settled = await settleCreatorFees();
    const errors = [...reconciled.errors, ...settled.errors];

    if (run) {
      await supabaseAdmin
        .from("creator_fee_sync_runs")
        .update({
          status: errors.length > 0 ? "partial" : "ok",
          mints_scanned: reconciled.mintsScanned,
          events_processed: reconciled.eventsProcessed,
          credits_created: reconciled.creditsCreated,
          lamports_credited: reconciled.lamportsCredited,
          settlements: settled.settlements,
          settlement_note: settled.note,
          error: errors.length > 0 ? errors.slice(0, 5).join(" | ").slice(0, 900) : null,
          finished_at: new Date().toISOString(),
        })
        .eq("id", run.id);
    }

    return {
      ok: errors.length === 0,
      message:
        errors.length === 0
          ? `Scanned ${reconciled.mintsScanned} coins, added ${reconciled.creditsCreated} new fee credits.`
          : errors.slice(0, 2).join(" | "),
    };
  });
