/**
 * Creator-fee settlement — SERVER ONLY.
 *
 * Detection (creator-fee-indexer.server.ts) records what an identity has earned.
 * Settlement moves that money into the identity's protected Turnkey deposit
 * wallet so the normal Claim / Claim All path can pay it out.
 *
 * On pump.fun, fees accrue in a creator-vault PDA owned by the wallet that
 * created the coin (AUTH's launch wallet — infrastructure, never the owner).
 * Two real on-chain steps are needed:
 *
 *   1. collect: pump.fun's `collectCreatorFee` moves vault SOL to the launch
 *      wallet. AUTH builds it through PumpPortal's local (unsigned) transaction
 *      API and signs it server-side with LAUNCHER_PRIVATE_KEY.
 *   2. sweep: the collected SOL is transferred from the launch wallet to each
 *      identity's deposit wallet, in the exact amount detected for it.
 *
 * Ledger rows stay `accrued` (earned, detected, not yet in identity custody)
 * until their sweep confirms, then become `available` and claimable. Nothing is
 * marked available on an unverified or failed transfer.
 */

import { Keypair, VersionedTransaction } from "@solana/web3.js";
import { loadLauncherKeypair } from "@/lib/launcher-wallet.server";
import { sendSolFromLauncher } from "@/lib/launcher-send.server";
import { getSignatureStatus, sendRawTransactionBase64 } from "@/integrations/adapters/helius.server";

const PUMPPORTAL_TRADE_LOCAL_URL = "https://pumpportal.fun/api/trade-local";

/** Never sweep dust: the network fee would exceed it. */
const MIN_SWEEP_SOL = 0.002;
/** Bounded work per run. */
const MAX_RECIPIENTS_PER_RUN = 5;

export interface SettlementSummary {
  settlements: number;
  note: string | null;
  errors: string[];
}

type AccruedRow = {
  id: string;
  recipient_id: string;
  amount: number | string;
  asset: string;
};

/**
 * Collects pump.fun creator fees into the launch wallet.
 * Returns a note instead of throwing when the provider cannot build the
 * transaction — the fees stay on-chain and settlement simply retries later.
 */
async function collectCreatorFees(): Promise<{ ok: boolean; signature?: string; message: string }> {
  const keypair: Keypair | null = loadLauncherKeypair();
  if (!keypair) {
    return { ok: false, message: "The launch wallet is not configured, so fees cannot be collected." };
  }
  let response: Response;
  try {
    response = await fetch(PUMPPORTAL_TRADE_LOCAL_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        publicKey: keypair.publicKey.toBase58(),
        action: "collectCreatorFee",
        priorityFee: 0.000005,
      }),
    });
  } catch (e) {
    return { ok: false, message: e instanceof Error ? e.message : "Fee collection request failed." };
  }
  if (!response.ok) {
    const text = await response.text().catch(() => "");
    return {
      ok: false,
      message: `pump.fun did not return a fee-collection transaction (${response.status}): ${text.slice(0, 160)}`,
    };
  }
  const buffer = new Uint8Array(await response.arrayBuffer());
  if (buffer.byteLength === 0) {
    return { ok: false, message: "pump.fun returned an empty fee-collection transaction." };
  }
  let tx: VersionedTransaction;
  try {
    tx = VersionedTransaction.deserialize(buffer);
  } catch {
    return { ok: false, message: "The fee-collection transaction could not be read." };
  }
  tx.sign([keypair]);
  const sent = await sendRawTransactionBase64(Buffer.from(tx.serialize()).toString("base64"));
  if (!sent.ok) return { ok: false, message: sent.message };

  // Wait briefly for confirmation so the sweep sees the balance.
  for (let i = 0; i < 10; i += 1) {
    const status = await getSignatureStatus(sent.data);
    if (status.ok && status.data) {
      if (status.data.err) return { ok: false, message: "The fee-collection transaction failed on-chain." };
      if (status.data.confirmationStatus === "confirmed" || status.data.confirmationStatus === "finalized") {
        return { ok: true, signature: sent.data, message: "Creator fees collected." };
      }
    }
    await new Promise((r) => setTimeout(r, 1500));
  }
  return { ok: true, signature: sent.data, message: "Fee collection submitted; confirmation still pending." };
}

/**
 * Sweeps detected-but-unsettled creator fees into identity deposit wallets and
 * promotes the matching ledger rows to `available`.
 */
export async function settleCreatorFees(): Promise<SettlementSummary> {
  const summary: SettlementSummary = { settlements: 0, note: null, errors: [] };
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const { data: accrued, error } = await supabaseAdmin
    .from("identity_ledger")
    .select("id,recipient_id,amount,asset")
    .eq("source", "creator_fee")
    .eq("status", "accrued")
    .limit(500);

  if (error) {
    summary.errors.push(`Could not read accrued creator fees: ${error.message}`);
    return summary;
  }
  const rows = (accrued ?? []) as AccruedRow[];
  if (rows.length === 0) return summary;

  const byRecipient = new Map<string, { total: number; ids: string[] }>();
  for (const row of rows) {
    if (row.asset !== "SOL") continue;
    const amount = Number(row.amount);
    if (!Number.isFinite(amount) || amount <= 0) continue;
    const entry = byRecipient.get(row.recipient_id) ?? { total: 0, ids: [] };
    entry.total += amount;
    entry.ids.push(row.id);
    byRecipient.set(row.recipient_id, entry);
  }

  const payable = [...byRecipient.entries()]
    .filter(([, v]) => v.total >= MIN_SWEEP_SOL)
    .slice(0, MAX_RECIPIENTS_PER_RUN);
  if (payable.length === 0) {
    summary.note = "Creator fees detected but still below the minimum sweep amount.";
    return summary;
  }

  const collected = await collectCreatorFees();
  if (!collected.ok) {
    summary.note = collected.message;
    summary.errors.push(collected.message);
    return summary;
  }
  summary.note = collected.message;

  const { ensureIdentityDepositWallet } = await import("@/lib/deposits/deposit-wallet.server");

  for (const [recipientId, entry] of payable) {
    const { data: recipient } = await supabaseAdmin
      .from("recipients")
      .select("id,handle,provider,provider_user_id")
      .eq("id", recipientId)
      .maybeSingle();
    if (!recipient) continue;

    const wallet = await ensureIdentityDepositWallet({
      provider: recipient.provider,
      providerUserId: recipient.provider_user_id,
      recipientId: recipient.id,
      handle: recipient.handle,
    });
    if (!wallet.ok) {
      summary.errors.push(`${recipient.handle}: ${wallet.message}`);
      continue;
    }

    const sent = await sendSolFromLauncher({ to: wallet.wallet.address, amountSol: entry.total });
    if (!sent.ok) {
      summary.errors.push(`${recipient.handle}: ${sent.message}`);
      continue;
    }

    const now = new Date().toISOString();
    await supabaseAdmin
      .from("identity_ledger")
      .update({
        status: "available",
        deposit_address: wallet.wallet.address,
        settlement_signature: sent.signature,
        settled_at: now,
      })
      .in("id", entry.ids)
      .eq("status", "accrued");

    summary.settlements += 1;
  }

  return summary;
}
