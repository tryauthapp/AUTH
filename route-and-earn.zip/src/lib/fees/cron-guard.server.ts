/**
 * Auth for the creator-fee reconciliation endpoints — SERVER ONLY.
 *
 * Accepts either the platform cron secret (LOVABLE_CRON_SECRET) or the
 * dedicated scheduler secret (CREATOR_FEE_CRON_SECRET) as a bearer token.
 * Both are compared with a constant-time digest. There is no unauthenticated
 * way to trigger reconciliation.
 */
export async function authenticateFeeSyncRequest(request: Request): Promise<Response | null> {
  const match = /^Bearer ([^\s,]+)$/.exec(request.headers.get("authorization") ?? "");
  const token = match?.[1];
  if (!token) return new Response("Unauthorized", { status: 401 });

  const candidates = [
    process.env["CREATOR_FEE_CRON_SECRET"],
    process.env["LOVABLE_CRON_SECRET"],
    process.env["LOVABLE_CRON_SECRET_PREVIOUS"],
  ].filter((v): v is string => Boolean(v));
  if (candidates.length === 0) return new Response("Server configuration error", { status: 500 });

  const { createHash, timingSafeEqual } = await import("node:crypto");
  const digest = (value: string) => createHash("sha256").update(value, "utf8").digest();
  const provided = digest(token);
  const allowed = candidates.some((secret) => timingSafeEqual(provided, digest(secret)));

  return allowed ? null : new Response("Unauthorized", { status: 401 });
}
