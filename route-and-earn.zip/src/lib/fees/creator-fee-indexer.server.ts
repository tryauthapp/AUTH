/**
 * Creator-fee detection and reconciliation — SERVER ONLY.
 *
 * SOURCE OF TRUTH: Solana mainnet, read through the configured RPC (Helius).
 * pump.fun does not publish a per-mint creator-fee webhook or REST feed, so
 * AUTH derives fees from the chain itself:
 *
 *   - every pump.fun trade on a mint moves the creator's share of the trade fee
 *     into the creator-vault PDA  seeds ["creator-vault", creator_wallet]
 *     under the pump.fun program
 *   - AUTH walks the mint's transaction history forward from a stored cursor,
 *     reads the vault's pre/post lamport delta for each transaction, and credits
 *     exactly that delta
 *
 * Nothing is credited from frontend input, provider-reported totals, or
 * estimates. If the chain read fails, the run records the error and retries on
 * the next pass — it never guesses.
 *
 * Ownership: the credit goes to `tokens.creator_fee_recipient_id`, the canonical
 * social identity recorded at launch time (provider + immutable
 * provider_user_id). The launch/dev wallet is execution infrastructure only and
 * is never the beneficial owner of a creator fee.
 */

import { PublicKey } from "@solana/web3.js";
import {
  LAMPORTS_PER_SOL,
  getRecentSignatures,
  heliusConfigured,
  verifySolCredit,
} from "@/integrations/adapters/helius.server";
import { creditIdentity } from "@/lib/deposits/ledger.server";

/** pump.fun bonding-curve program. */
const PUMP_PROGRAM_ID = new PublicKey("6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P");

/** Creator fees for every coin a wallet created accrue in this PDA. */
export function creatorVaultFor(creatorWallet: string): string | null {
  try {
    const [pda] = PublicKey.findProgramAddressSync(
      [Buffer.from("creator-vault"), new PublicKey(creatorWallet).toBuffer()],
      PUMP_PROGRAM_ID,
    );
    return pda.toBase58();
  } catch {
    return null;
  }
}

export interface ReconcileSummary {
  mintsScanned: number;
  eventsProcessed: number;
  creditsCreated: number;
  lamportsCredited: number;
  errors: string[];
}

type TokenRow = {
  id: string;
  mint: string;
  creator_fee_recipient_id: string | null;
  launcher_wallet: string | null;
  launch_wallet: string | null;
  source: string;
  is_demo: boolean;
};

/**
 * Reconciles creator fees for a bounded slice of launched mints.
 * Bounded on purpose: the cron runs every 5 minutes, so each pass does a small
 * amount of work and the least-recently-synced mints are always picked first.
 */
export async function reconcileCreatorFees(options?: {
  maxMints?: number;
  maxSignaturesPerMint?: number;
}): Promise<ReconcileSummary> {
  const maxMints = Math.min(Math.max(options?.maxMints ?? 15, 1), 50);
  const maxSignatures = Math.min(Math.max(options?.maxSignaturesPerMint ?? 25, 1), 100);

  const summary: ReconcileSummary = {
    mintsScanned: 0,
    eventsProcessed: 0,
    creditsCreated: 0,
    lamportsCredited: 0,
    errors: [],
  };

  if (!heliusConfigured()) {
    summary.errors.push("No Solana RPC is configured, so no fee data could be read.");
    return summary;
  }

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const { data: tokens, error } = await supabaseAdmin
    .from("tokens")
    .select("id,mint,creator_fee_recipient_id,launcher_wallet,launch_wallet,source,is_demo")
    .eq("is_demo", false)
    .not("creator_fee_recipient_id", "is", null)
    .not("mint", "is", null)
    .limit(500);

  if (error) {
    summary.errors.push(`Could not load launched tokens: ${error.message}`);
    return summary;
  }

  const rows = (tokens ?? []) as TokenRow[];
  if (rows.length === 0) return summary;

  const { data: states } = await supabaseAdmin
    .from("creator_fee_mint_state")
    .select("mint,last_signature,last_synced_at")
    .in("mint", rows.map((t) => t.mint));

  const stateByMint = new Map(
    (states ?? []).map((s) => [s.mint, s as { mint: string; last_signature: string | null; last_synced_at: string | null }]),
  );

  // Least-recently-synced first; never-synced mints lead.
  const queue = [...rows].sort((a, b) => {
    const at = stateByMint.get(a.mint)?.last_synced_at ?? "";
    const bt = stateByMint.get(b.mint)?.last_synced_at ?? "";
    return at.localeCompare(bt);
  }).slice(0, maxMints);

  for (const token of queue) {
    summary.mintsScanned += 1;
    try {
      const result = await reconcileMint(token, stateByMint.get(token.mint)?.last_signature ?? null, maxSignatures);
      summary.eventsProcessed += result.eventsProcessed;
      summary.creditsCreated += result.creditsCreated;
      summary.lamportsCredited += result.lamportsCredited;
      if (result.error) summary.errors.push(`${token.mint}: ${result.error}`);
    } catch (e) {
      const message = e instanceof Error ? e.message : "Unknown failure";
      summary.errors.push(`${token.mint}: ${message}`);
      await writeState(token, { lastError: message });
    }
  }

  return summary;
}

async function reconcileMint(
  token: TokenRow,
  cursor: string | null,
  maxSignatures: number,
): Promise<{ eventsProcessed: number; creditsCreated: number; lamportsCredited: number; error?: string }> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  const creatorWallet = token.launcher_wallet ?? token.launch_wallet;
  if (!creatorWallet) {
    await writeState(token, { lastError: "No launch wallet recorded for this mint." });
    return { eventsProcessed: 0, creditsCreated: 0, lamportsCredited: 0, error: "No launch wallet recorded." };
  }
  const vault = creatorVaultFor(creatorWallet);
  if (!vault) {
    await writeState(token, { creatorWallet, lastError: "Creator vault could not be derived." });
    return { eventsProcessed: 0, creditsCreated: 0, lamportsCredited: 0, error: "Creator vault could not be derived." };
  }

  // Recipient identity recorded at launch — ownership is never inferred from
  // handle text here.
  const { data: recipient } = await supabaseAdmin
    .from("recipients")
    .select("id,provider,provider_user_id")
    .eq("id", token.creator_fee_recipient_id!)
    .maybeSingle();
  if (!recipient) {
    await writeState(token, { creatorWallet, creatorVault: vault, lastError: "Creator-fee recipient row is missing." });
    return { eventsProcessed: 0, creditsCreated: 0, lamportsCredited: 0, error: "Creator-fee recipient missing." };
  }

  const sigs = await getRecentSignatures(token.mint, maxSignatures);
  if (!sigs.ok) {
    await writeState(token, { creatorWallet, creatorVault: vault, lastError: sigs.message });
    return { eventsProcessed: 0, creditsCreated: 0, lamportsCredited: 0, error: sigs.message };
  }

  // Newest-first from the RPC. Stop at the cursor, then process oldest-first so
  // the stored cursor only ever advances over fully processed history.
  const fresh: typeof sigs.data = [];
  for (const s of sigs.data) {
    if (cursor && s.signature === cursor) break;
    fresh.push(s);
  }
  const ordered = fresh.reverse();

  let eventsProcessed = 0;
  let creditsCreated = 0;
  let lamportsCredited = 0;
  let newestProcessed: string | null = null;

  for (const s of ordered) {
    if (s.err) {
      newestProcessed = s.signature;
      continue;
    }
    const tx = await verifySolCredit(s.signature, vault, 0);
    if (!tx.ok) {
      // Transient read failure: keep the cursor where it is and retry next run.
      await writeState(token, {
        creatorWallet,
        creatorVault: vault,
        lastSignature: newestProcessed ?? cursor,
        eventsDelta: eventsProcessed,
        creditsDelta: creditsCreated,
        lamportsDelta: lamportsCredited,
        lastError: tx.message,
      });
      return { eventsProcessed, creditsCreated, lamportsCredited, error: tx.message };
    }
    eventsProcessed += 1;
    newestProcessed = s.signature;

    const credited = tx.data.found && tx.data.succeeded ? tx.data.creditedLamports : 0;
    if (credited <= 0) continue;

    // One credit per (mint, transaction). The unique index on
    // (source, source_event_id) makes retries, restarts and duplicate provider
    // deliveries impossible to double-count.
    const result = await creditIdentity({
      recipientId: recipient.id,
      provider: recipient.provider,
      providerUserId: recipient.provider_user_id,
      source: "creator_fee",
      sourceEventId: `pumpfun:${token.mint}:${s.signature}`,
      asset: "SOL",
      assetKey: "solana:sol",
      amount: credited / LAMPORTS_PER_SOL,
      amountUsd: null,
      depositAddress: null,
      txSignature: null,
      status: "accrued",
    });
    if (result.ok && !result.duplicate) {
      creditsCreated += 1;
      lamportsCredited += credited;
    }
  }

  await writeState(token, {
    creatorWallet,
    creatorVault: vault,
    lastSignature: newestProcessed ?? cursor,
    eventsDelta: eventsProcessed,
    creditsDelta: creditsCreated,
    lamportsDelta: lamportsCredited,
    lastError: null,
    recipientId: recipient.id,
    provider: recipient.provider,
    providerUserId: recipient.provider_user_id,
  });

  return { eventsProcessed, creditsCreated, lamportsCredited };
}

async function writeState(
  token: TokenRow,
  patch: {
    creatorWallet?: string | null;
    creatorVault?: string | null;
    lastSignature?: string | null;
    eventsDelta?: number;
    creditsDelta?: number;
    lamportsDelta?: number;
    lastError?: string | null;
    recipientId?: string | null;
    provider?: string | null;
    providerUserId?: string | null;
  },
): Promise<void> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: existing } = await supabaseAdmin
    .from("creator_fee_mint_state")
    .select("events_processed,credits_created,lamports_credited,last_signature")
    .eq("mint", token.mint)
    .maybeSingle();

  await supabaseAdmin.from("creator_fee_mint_state").upsert(
    {
      mint: token.mint,
      token_id: token.id,
      recipient_id: patch.recipientId ?? token.creator_fee_recipient_id,
      provider: patch.provider ?? null,
      provider_user_id: patch.providerUserId ?? null,
      creator_wallet: patch.creatorWallet ?? null,
      creator_vault: patch.creatorVault ?? null,
      last_signature: patch.lastSignature ?? existing?.last_signature ?? null,
      last_synced_at: new Date().toISOString(),
      last_error: patch.lastError ?? null,
      events_processed: (existing?.events_processed ?? 0) + (patch.eventsDelta ?? 0),
      credits_created: (existing?.credits_created ?? 0) + (patch.creditsDelta ?? 0),
      lamports_credited: Number(existing?.lamports_credited ?? 0) + (patch.lamportsDelta ?? 0),
      updated_at: new Date().toISOString(),
    },
    { onConflict: "mint" },
  );
}
