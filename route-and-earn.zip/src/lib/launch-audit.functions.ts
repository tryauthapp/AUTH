import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Launch audit timeline + admin smoke test.
 *
 * The timeline is append-only and already redacted at write time; these
 * functions only read it. The smoke test never broadcasts a transaction.
 */

export interface AuditEvent {
  id: string;
  launchKey: string;
  kind: string;
  stage: string;
  status: string;
  message: string | null;
  detailJson: string | null;
  createdAt: string;
}

function mapRow(row: {
  id: string;
  launch_key: string;
  kind: string;
  stage: string;
  status: string;
  message: string | null;
  detail: unknown;
  created_at: string;
}): AuditEvent {
  return {
    id: row.id,
    launchKey: row.launch_key,
    kind: row.kind,
    stage: row.stage,
    status: row.status,
    message: row.message,
    detailJson: row.detail == null ? null : JSON.stringify(row.detail, null, 2),
    createdAt: row.created_at,
  };
}

/** Every recorded stage for one launch key. RLS scopes this to the owner or an admin. */
export const launchAuditTimeline = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { launchKey: string }) => ({
    launchKey: String(input?.launchKey ?? "").slice(0, 120),
  }))
  .handler(async ({ data, context }): Promise<AuditEvent[]> => {
    if (!data.launchKey) return [];
    const { data: rows } = await context.supabase
      .from("launch_audit_events")
      .select("id,launch_key,kind,stage,status,message,detail,created_at")
      .eq("launch_key", data.launchKey)
      .order("created_at", { ascending: true })
      .limit(200);
    return (rows ?? []).map(mapRow);
  });

/** Most recent audit events across launches and smoke tests, newest first. */
export const recentLaunchAudit = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<AuditEvent[]> => {
    const { data: rows } = await context.supabase
      .from("launch_audit_events")
      .select("id,launch_key,kind,stage,status,message,detail,created_at")
      .order("created_at", { ascending: false })
      .limit(120);
    return (rows ?? []).map(mapRow);
  });

export type { SmokeTestReport, SmokeCheck } from "@/lib/launch-smoke-test.server";

/**
 * Admin-only preflight. Validates config, balance, transaction construction,
 * signing and signature submission via simulation, plus the on-chain
 * confirmation read — without broadcasting a real launch.
 */
export const runLaunchSmokeTest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Admin access is required to run the launch smoke test.");

    const { runSmokeTest } = await import("@/lib/launch-smoke-test.server");
    return await runSmokeTest(context.userId);
  });
