/** Safe, shared normalization for user-supplied project links. */

const ALLOWED_PROTOCOLS = new Set(["http:", "https:"]);

/**
 * Returns a normalized https(s) URL, or null when empty.
 * Throws when the value is not a safe absolute web URL.
 */
export function normalizeUrl(raw: string | null | undefined, field: string): string | null {
  const value = (raw ?? "").trim();
  if (!value) return null;
  const withScheme = /^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(value) ? value : `https://${value}`;
  let url: URL;
  try {
    url = new URL(withScheme);
  } catch {
    throw new Error(`${field} is not a valid URL.`);
  }
  if (!ALLOWED_PROTOCOLS.has(url.protocol)) {
    throw new Error(`${field} must start with https://`);
  }
  if (!url.hostname.includes(".")) throw new Error(`${field} is not a valid URL.`);
  url.hash = "";
  url.username = "";
  url.password = "";
  return url.toString();
}

/** Non-throwing check used for inline form validation. */
export function urlError(raw: string, field: string): string | null {
  try {
    normalizeUrl(raw, field);
    return null;
  } catch (e) {
    return e instanceof Error ? e.message : "Invalid URL.";
  }
}

/** Safe href for rendering a stored link; null when unsafe. */
export function safeHref(raw: string | null | undefined): string | null {
  try {
    return normalizeUrl(raw, "Link");
  } catch {
    return null;
  }
}
