import { createServerFn } from "@tanstack/react-start";
import { optionalSupabaseAuth } from "@/lib/auth/optional-auth";
import { ADDRESS_RE, SIGNATURE_RE } from "@/lib/solana";

/**
 * Person-to-person payments addressed by a social identity.
 *
 * Send now, claim later. The sender signs once and the money leaves their
 * wallet immediately, even when the recipient has never joined AUTH:
 *
 *  - recipient already claimed, with a verified payout wallet
 *        -> straight to that wallet
 *  - recipient not on AUTH yet
 *        -> into the Turnkey-held deposit wallet bound to their canonical
 *           identity (provider + immutable provider_user_id), credited to the
 *           identity ledger, claimable only after that exact account proves
 *           ownership through provider OAuth
 *
 * Every payment is recorded against the canonical identity, never the handle
 * text. AUTH holds no keys itself; deposit custody is Turnkey's.
 */

import {
  type SocialProvider,
  isSocialProvider,
  normalizeSocialHandle,
  providerMeta,
} from "@/lib/social/providers";

/** Validates a handle against the platform's own username rules. */
function parseIdentity(rawProvider: string | undefined, rawHandle: string) {
  const provider: SocialProvider = isSocialProvider(rawProvider ?? "x")
    ? (rawProvider as SocialProvider)
    : "x";
  const meta = providerMeta(provider)!;
  const handle = normalizeSocialHandle(provider, rawHandle);
  if (!meta.handlePattern.test(handle)) {
    throw new Error(`Enter a valid ${meta.label} username. ${meta.handleHint}`);
  }
  return { provider, handle };
}

export interface PayeeLookup {
  found: boolean;
  provider: SocialProvider;
  handle: string;
  recipientId?: string;
  displayName?: string | null;
  bio?: string | null;
  avatarUrl?: string | null;
  verification?: string;
  claimed?: boolean;
  payable?: boolean;
  destinationWallet?: string | null;
  isDemo?: boolean;
}

/** Public: resolve a platform handle into a payee card. */
export const lookupPayee = createServerFn({ method: "GET" })
  .inputValidator((input: { handle: string; provider?: string }) =>
    parseIdentity(input.provider, input.handle),
  )
  .handler(async ({ data }): Promise<PayeeLookup> => {
    const { enforceRateLimit } = await import("@/lib/rate-limit.server");
    enforceRateLimit("payee-lookup", 60, 60_000);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: recipient } = await supabaseAdmin
      .from("recipients")
      .select("id,handle,display_name,bio,avatar_url,verification,claimed_by,is_demo")
      .eq("provider", data.provider)
      .ilike("handle", data.handle)
      .maybeSingle();

    if (!recipient) return { found: false, provider: data.provider, handle: data.handle };

    const { data: wallet } = await supabaseAdmin
      .from("wallets")
      .select("address,verified_at")
      .eq("recipient_id", recipient.id)
      .not("verified_at", "is", null)
      .order("verified_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    const destinationWallet =
      wallet?.address && ADDRESS_RE.test(wallet.address) ? wallet.address : null;

    return {
      found: true,
      provider: data.provider,
      handle: recipient.handle,
      recipientId: recipient.id,
      displayName: recipient.display_name,
      bio: recipient.bio,
      avatarUrl: recipient.avatar_url ?? null,
      verification: recipient.verification ?? "unverified",
      claimed: Boolean(recipient.claimed_by),
      payable: Boolean(destinationWallet),
      destinationWallet,
      isDemo: recipient.is_demo ?? false,
    };
  });

export interface PaymentPlanResponse {
  ok: boolean;
  message?: string;
  paymentId?: string;
  status?: "awaiting_recipient" | "ready";
  /** Where the money is actually going, so the UI can say so plainly. */
  destinationKind?: "payout_wallet" | "identity_deposit";
  plan?: {
    paymentId: string;
    to: string;
    asset: string;
    mint: string | null;
    /** SPL program that owns the mint. Native SOL carries null. */
    tokenProgram: string | null;
    amount: number;
    amountUsd: number | null;
    decimals: number;
    blockhash: string;
    lastValidBlockHeight: number;
    destinationTokenAccountExists: boolean;
    memo: string;
    network: "mainnet-beta";
    idempotencyKey: string;
  };
}

/**
 * Whether the recipient already holds a token account for this mint. When it
 * doesn't exist the sender's transaction creates it (a small rent cost shown in
 * the review step).
 */
async function tokenAccountReady(
  mint: string | null,
  destination: string,
  tokenProgram: string,
): Promise<boolean> {
  if (!mint) return true;
  const { accountExists } = await import("@/integrations/adapters/helius.server");
  const { deriveAssociatedTokenAddress } = await import("@/lib/wallet/ata.server");
  const ata = await deriveAssociatedTokenAddress(destination, mint, tokenProgram);
  const exists = await accountExists(ata);
  return exists.ok ? exists.data : false;
}


/**
 * Creates the payment record and — when the handle has a verified wallet —
 * returns an unsigned transfer plan for the sender's own non-custodial account.
 *
 * The asset is resolved from the registry: a row must be status = live AND
 * is_payable, on a chain with a working adapter. Everything else is rejected
 * server-side, so a Planned asset can never be sent even if the UI is bypassed.
 */
export const createPayment = createServerFn({ method: "POST" })
  .middleware([optionalSupabaseAuth])
  .inputValidator(
    (input: {
      handle: string;
      provider?: string;
      assetKey?: string;
      asset?: "SOL" | "USDC";
      amount: number;
      note?: string;
      senderWallet: string;
    }) => {
      const { provider, handle } = parseIdentity(input.provider, input.handle);
      const assetKey = (input.assetKey ?? `solana:${input.asset ?? "SOL"}`).trim();
      if (!/^[a-z0-9_-]+:[A-Za-z0-9]{1,12}$/.test(assetKey)) throw new Error("Unsupported asset.");
      if (!(input.amount > 0)) throw new Error("Enter an amount greater than zero.");
      if (!ADDRESS_RE.test(input.senderWallet.trim())) throw new Error("Connect a Solana wallet first.");
      return {
        provider,
        handle,
        assetKey,
        amount: Number(input.amount),
        note: (input.note ?? "").slice(0, 140),
        senderWallet: input.senderWallet.trim(),
      };
    },
  )
  .handler(async ({ data, context }): Promise<PaymentPlanResponse> => {
    const { enforceRateLimit } = await import("@/lib/rate-limit.server");
    enforceRateLimit("create-payment", 12, 60_000);
    // No AUTH account required: a payment is authorized by the sender's own
    // wallet signature, verified on-chain at settlement. A session, when one
    // exists, only attaches the receipt to that account.
    const { userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Registry gate: only a live, payable asset on a chain with a working
    // adapter may be sent, and identity is the mint — never the ticker.
    const { data: assetRow } = await supabaseAdmin
      .from("assets")
      .select(
        "key,symbol,chain_key,kind,status,is_payable,decimals,contract_address,token_program,category,mint_verified_at",
      )
      .eq("key", data.assetKey)
      .maybeSingle();

    if (!assetRow) return { ok: false, message: "That asset is not in the AUTH registry." };
    if (assetRow.status !== "live" || !assetRow.is_payable) {
      return {
        ok: false,
        message: `${assetRow.symbol} can't be sent from AUTH yet.`,
      };
    }
    const { getChainAdapter } = await import("@/integrations/chains/registry");
    const chain = getChainAdapter(assetRow.chain_key);
    if (!chain?.canSendPayments) {
      return { ok: false, message: `${assetRow.chain_key} payments are not enabled yet.` };
    }
    const asset = assetRow.symbol;
    const isNative = assetRow.kind === "native";
    const decimals = assetRow.decimals;
    if (!Number.isInteger(decimals) || decimals < 0 || decimals > 18) {
      return { ok: false, message: `${asset} has no verified decimals in the registry.` };
    }
    // Native SOL has no mint; every other live asset is an SPL token whose mint
    // and owning token program come from the registry, never from the client.
    const mint = isNative ? null : (assetRow.contract_address ?? null);
    const { TOKEN_PROGRAM_ID } = await import("@/lib/wallet/ata.server");
    const tokenProgram = isNative ? null : (assetRow.token_program ?? null);
    if (!isNative) {
      if (!mint || !ADDRESS_RE.test(mint)) {
        return { ok: false, message: `${asset} has no verified mint address configured.` };
      }
      if (!assetRow.mint_verified_at) {
        return { ok: false, message: `${asset} has not been verified against Solana mainnet yet.` };
      }
      // Only the classic SPL Token program is supported by the generic transfer
      // path. Token-2022 mints can carry transfer hooks, transfer fees or other
      // extensions the plain transfer cannot honour, so they are refused here
      // rather than silently mis-sent.
      if (tokenProgram !== TOKEN_PROGRAM_ID) {
        return {
          ok: false,
          message: `${asset} uses a token program AUTH does not support for transfers yet.`,
        };
      }
    }


    let { data: recipient } = await supabaseAdmin
      .from("recipients")
      .select("id,handle,claimed_by,provider_user_id")
      .eq("provider", data.provider)
      .ilike("handle", data.handle)
      .maybeSingle();

    if (!recipient) {
      const { data: created, error } = await supabaseAdmin
        .from("recipients")
        .insert({
          handle: data.handle,
          provider: data.provider,
          verification: "unverified",
          is_demo: false,
        })
        .select("id,handle,claimed_by,provider_user_id")
        .single();
      if (error) return { ok: false, message: error.message };
      recipient = created;
    }

    const { data: wallet } = await supabaseAdmin
      .from("wallets")
      .select("address,verified_at,is_default")
      .eq("recipient_id", recipient.id)
      .not("verified_at", "is", null)
      .order("is_default", { ascending: false })
      .order("verified_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    const payoutWallet =
      wallet?.address && ADDRESS_RE.test(wallet.address) ? wallet.address : null;

    // No verified payout wallet yet: settle into the protected deposit wallet
    // for this canonical identity so the sender never has to come back.
    let destination = payoutWallet;
    let destinationKind: "payout_wallet" | "identity_deposit" = "payout_wallet";
    let depositBlocker: string | null = null;

    if (!destination) {
      // Ownership is keyed to the immutable platform ID. When we don't have it
      // yet, resolve the live profile once and store it.
      let providerUserId = recipient.provider_user_id ?? null;
      if (!providerUserId) {
        const { lookupPlatformProfile } = await import("@/lib/social/lookup.server");
        const lookup = await lookupPlatformProfile(data.provider, recipient.handle);
        if (lookup.profile?.platformUserId) {
          providerUserId = lookup.profile.platformUserId;
          await supabaseAdmin
            .from("recipients")
            .update({
              provider_user_id: providerUserId,
              handle: lookup.profile.handle,
              display_name: lookup.profile.displayName,
              avatar_url: lookup.profile.avatarUrl,
              profile_url: lookup.profile.profileUrl,
              profile_synced_at: new Date().toISOString(),
            })
            .eq("id", recipient.id);
        }
      }

      const { ensureIdentityDepositWallet } = await import(
        "@/lib/deposits/deposit-wallet.server"
      );
      const deposit = await ensureIdentityDepositWallet({
        provider: data.provider,
        providerUserId,
        recipientId: recipient.id,
        handle: recipient.handle,
      });
      if (deposit.ok) {
        destination = deposit.wallet.address;
        destinationKind = "identity_deposit";
      } else {
        depositBlocker = deposit.message;
      }
    }

    // USD value: registry stablecoins are 1:1, SOL uses the live price feed, and
    // other tokens have no price source yet — left null rather than guessed.
    let amountUsd: number | null = null;
    if (assetRow.category === "stablecoin") amountUsd = Number(data.amount.toFixed(2));
    else if (isNative) {
      const { getSolUsdPrice } = await import("@/integrations/adapters/price.server");
      const price = await getSolUsdPrice();
      if (price.ok) amountUsd = Number((data.amount * price.usd).toFixed(2));
    }


    // Double-click / retry guard: reuse an identical unfunded reservation from
    // the last 5 minutes instead of creating a second receipt for one intent.
    const since = new Date(Date.now() - 5 * 60 * 1000).toISOString();
    const { data: duplicate } = await supabaseAdmin
      .from("payments")
      .select("id")
      .eq("sender_wallet", data.senderWallet)
      .eq("recipient_id", recipient.id)
      .eq("asset_key", assetRow.key)
      .eq("amount", data.amount)
      .is("tx_signature", null)
      .in("status", ["ready", "awaiting_recipient"])
      .gte("created_at", since)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    const { data: payment, error: insertError } = duplicate
      ? { data: duplicate, error: null }
      : await supabaseAdmin

      .from("payments")
      .insert({
        sender_id: userId ?? null,
        sender_wallet: data.senderWallet,
        recipient_id: recipient.id,
        recipient_handle: recipient.handle,
        recipient_provider: data.provider,
        destination_wallet: destination,
        destination_kind: destination ? destinationKind : "legacy_reservation",
        asset,
        asset_key: assetRow.key,
        chain_key: assetRow.chain_key,
        amount: data.amount,
        amount_usd: amountUsd,
        note: data.note || null,
        status: destination ? "ready" : "awaiting_recipient",
        network: "mainnet-beta",
        is_demo: false,
      })
      .select("id")
      .single();
    if (insertError) return { ok: false, message: insertError.message };

    if (!destination) {
      return {
        ok: true,
        paymentId: payment.id,
        status: "awaiting_recipient",
        message:
          depositBlocker ??
          `AUTH can't hold funds for @${recipient.handle} yet. The payment is reserved and unfunded — nothing left your wallet.`,
      };
    }

    const { getLatestBlockhash } = await import("@/integrations/adapters/helius.server");
    const blockhash = await getLatestBlockhash();
    if (!blockhash.ok) return { ok: false, message: blockhash.message, paymentId: payment.id };

    const destinationTokenAccountExists = await tokenAccountReady(
      mint,
      destination,
      tokenProgram ?? TOKEN_PROGRAM_ID,
    );

    return {
      ok: true,
      paymentId: payment.id,
      status: "ready",
      destinationKind,
      plan: {
        paymentId: payment.id,
        to: destination,
        asset,
        mint,
        tokenProgram,
        amount: Number(data.amount.toFixed(decimals)),
        amountUsd,
        decimals,

        blockhash: blockhash.data.blockhash,
        lastValidBlockHeight: blockhash.data.lastValidBlockHeight,
        destinationTokenAccountExists,
        memo: `AUTH payment to @${recipient.handle}`,
        network: "mainnet-beta",
        idempotencyKey: `${payment.id}:${data.senderWallet}`,
      },
    };
  });

export interface PaymentSettlement {
  ok: boolean;
  status?: "sent" | "processing" | "failed";
  message?: string;
  signature?: string;
}

/** Verifies the submitted signature on-chain before marking the payment sent. */
export const settlePaymentSignature = createServerFn({ method: "POST" })
  .middleware([optionalSupabaseAuth])
  .inputValidator((input: { paymentId: string; signature: string }) => {
    if (!input.paymentId) throw new Error("Missing payment.");
    if (!SIGNATURE_RE.test(input.signature.trim())) throw new Error("Invalid transaction signature.");
    return { paymentId: input.paymentId, signature: input.signature.trim() };
  })
  .handler(async ({ data, context }): Promise<PaymentSettlement> => {
    const { userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: payment } = await supabaseAdmin
      .from("payments")
      .select(
        "id,sender_id,sender_wallet,destination_wallet,destination_kind,recipient_id,recipient_provider,asset,asset_key,amount,amount_usd,status,tx_signature",
      )
      .eq("id", data.paymentId)
      .maybeSingle();
    if (!payment) return { ok: false, message: "Payment not found." };
    if (payment.sender_id && userId && payment.sender_id !== userId) {
      return { ok: false, message: "This payment belongs to someone else." };
    }
    if (payment.tx_signature && payment.tx_signature !== data.signature) {
      return { ok: false, message: "This payment already has a transaction." };
    }
    if (!payment.sender_wallet || !payment.destination_wallet) {
      return { ok: false, message: "This payment has no sender or destination wallet." };
    }

    const { getSignatureStatus, verifyTransfer } = await import(
      "@/integrations/adapters/helius.server"
    );

    let confirmed = false;
    let failed = false;
    for (let i = 0; i < 10; i++) {
      const status = await getSignatureStatus(data.signature);
      if (status.ok && status.data) {
        if (status.data.err) {
          failed = true;
          break;
        }
        if (
          status.data.confirmationStatus === "confirmed" ||
          status.data.confirmationStatus === "finalized"
        ) {
          confirmed = true;
          break;
        }
      }
      await new Promise((r) => setTimeout(r, 2000));
    }

    // Authorization without an account: the transaction itself must prove the
    // sender signed it and the destination received the expected asset/amount.
    if (confirmed) {
      const { data: assetRow } = await supabaseAdmin
        .from("assets")
        .select("symbol,decimals,contract_address")
        .eq("key", payment.asset_key ?? `solana:${payment.asset}`)
        .maybeSingle();
      const decimals = assetRow?.decimals ?? (payment.asset === "SOL" ? 9 : 6);
      const mint = payment.asset === "SOL" ? null : (assetRow?.contract_address ?? null);
      const check = await verifyTransfer(data.signature, {
        from: payment.sender_wallet,
        to: payment.destination_wallet,
        mint,
        amount: Number(payment.amount),
        decimals,
      });
      if (check.ok && check.data.found) {
        if (!check.data.succeeded) {
          failed = true;
          confirmed = false;
        } else if (!check.data.senderSigned || !check.data.amountMatched) {
          return {
            ok: false,
            message:
              "That transaction doesn't match this payment — it wasn't signed by the sending wallet or didn't deliver the expected amount.",
          };
        }
      } else if (check.ok && !check.data.found) {
        confirmed = false;
      }
    }

    const now = new Date().toISOString();

    if (failed) {
      await supabaseAdmin
        .from("payments")
        .update({ status: "failed", failure_reason: "The transaction failed on-chain." })
        .eq("id", payment.id);
      return { ok: false, status: "failed", message: "The transaction failed on-chain. Nothing was sent." };
    }

    if (!confirmed) {
      await supabaseAdmin
        .from("payments")
        .update({ status: "processing", tx_signature: data.signature })
        .eq("id", payment.id);
      return {
        ok: true,
        status: "processing",
        signature: data.signature,
        message: "Submitted. Waiting for network confirmation.",
      };
    }

    await supabaseAdmin
      .from("payments")
      .update({
        status: "sent",
        tx_signature: data.signature,
        settled_at: now,
        confirmed_at: now,
        failure_reason: null,
      })
      .eq("id", payment.id);

    // Money has actually landed. When it went to the identity's protected
    // deposit wallet, credit the identity ledger — idempotently, so a retry of
    // this confirmation can never create a second credit.
    let ledgerEntryId: string | null = null;
    if (payment.destination_kind === "identity_deposit" && payment.recipient_id) {
      const { creditIdentity } = await import("@/lib/deposits/ledger.server");
      const { data: recipientRow } = await supabaseAdmin
        .from("recipients")
        .select("provider,provider_user_id")
        .eq("id", payment.recipient_id)
        .maybeSingle();
      const asset = payment.asset === "USDC" ? "USDC" : "SOL";
      const credit = await creditIdentity({
        recipientId: payment.recipient_id,
        provider: recipientRow?.provider ?? payment.recipient_provider ?? "x",
        providerUserId: recipientRow?.provider_user_id ?? null,
        source: "payment",
        sourceEventId: payment.id,
        asset,
        assetKey: payment.asset_key ?? null,
        amount: Number(payment.amount),
        amountUsd: payment.amount_usd === null ? null : Number(payment.amount_usd),
        depositAddress: payment.destination_wallet,
        txSignature: data.signature,
        // Verified above against the chain before we got here.
        status: "available",
      });
      ledgerEntryId = credit.id ?? null;
      if (ledgerEntryId) {
        await supabaseAdmin
          .from("payments")
          .update({ ledger_entry_id: ledgerEntryId })
          .eq("id", payment.id);
      }
    }

    await supabaseAdmin.from("audit_log").insert({
      actor_id: userId,
      action: "payment.settled_on_chain",
      entity: "payments",
      entity_id: payment.id,
      metadata: {
        signature: data.signature,
        network: "mainnet-beta",
        destination_kind: payment.destination_kind,
        ledger_entry_id: ledgerEntryId,
      },
    });

    return { ok: true, status: "sent", signature: data.signature, message: "Payment confirmed on-chain." };
  });

/** Sends a previously reserved payment once the recipient has a verified wallet. */
export const preparePendingPayment = createServerFn({ method: "POST" })
  .middleware([optionalSupabaseAuth])
  .inputValidator((input: { paymentId: string; senderWallet: string }) => {
    if (!ADDRESS_RE.test(input.senderWallet.trim())) throw new Error("Connect a Solana wallet first.");
    return { paymentId: input.paymentId, senderWallet: input.senderWallet.trim() };
  })
  .handler(async ({ data, context }): Promise<PaymentPlanResponse> => {
    const { userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: payment } = await supabaseAdmin
      .from("payments")
      .select(
        "id,sender_id,sender_wallet,recipient_id,recipient_handle,asset,asset_key,amount,amount_usd,status,tx_signature",
      )
      .eq("id", data.paymentId)
      .maybeSingle();
    if (!payment) return { ok: false, message: "Payment not found." };
    // Either the signed-in owner of the receipt, or the wallet that reserved it.
    const ownedBySession = Boolean(payment.sender_id) && payment.sender_id === userId;
    const ownedByWallet = payment.sender_wallet === data.senderWallet;
    if (!ownedBySession && !ownedByWallet) {
      return { ok: false, message: "This payment belongs to another sender." };
    }
    if (payment.tx_signature) return { ok: false, message: "This payment is already on-chain." };
    const { data: wallet } = await supabaseAdmin
      .from("wallets")
      .select("address,verified_at")
      .eq("recipient_id", payment.recipient_id)
      .not("verified_at", "is", null)
      .order("verified_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    const destination = wallet?.address && ADDRESS_RE.test(wallet.address) ? wallet.address : null;
    if (!destination) {
      return {
        ok: false,
        message: `@${payment.recipient_handle} still has no verified payout wallet. The payment stays reserved and unfunded.`,
      };
    }

    const asset = payment.asset;
    const { data: assetRow } = await supabaseAdmin
      .from("assets")
      .select("symbol,kind,decimals,contract_address,status,is_payable,token_program,mint_verified_at")
      .eq("key", payment.asset_key ?? `solana:${asset}`)
      .maybeSingle();
    if (!assetRow || assetRow.status !== "live" || !assetRow.is_payable) {
      return { ok: false, message: `${asset} can't be sent right now.` };
    }
    const isNative = assetRow.kind === "native";
    const decimals = assetRow.decimals;
    if (!Number.isInteger(decimals)) {
      return { ok: false, message: `${asset} has no verified decimals in the registry.` };
    }
    const mint = isNative ? null : (assetRow.contract_address ?? null);
    const { TOKEN_PROGRAM_ID } = await import("@/lib/wallet/ata.server");
    const tokenProgram = isNative ? null : (assetRow.token_program ?? null);
    if (!isNative) {
      if (!mint || !ADDRESS_RE.test(mint) || !assetRow.mint_verified_at) {
        return { ok: false, message: `${asset} has no verified mint address configured.` };
      }
      if (tokenProgram !== TOKEN_PROGRAM_ID) {
        return {
          ok: false,
          message: `${asset} uses a token program AUTH does not support for transfers yet.`,
        };
      }
    }

    const { getLatestBlockhash } = await import("@/integrations/adapters/helius.server");
    const blockhash = await getLatestBlockhash();
    if (!blockhash.ok) return { ok: false, message: blockhash.message };

    const destinationTokenAccountExists = await tokenAccountReady(
      mint,
      destination,
      tokenProgram ?? TOKEN_PROGRAM_ID,
    );

    await supabaseAdmin
      .from("payments")
      .update({ destination_wallet: destination, sender_wallet: data.senderWallet, status: "ready" })
      .eq("id", payment.id);

    return {
      ok: true,
      paymentId: payment.id,
      status: "ready",
      plan: {
        paymentId: payment.id,
        to: destination,
        asset,
        mint,
        tokenProgram,

        amount: Number(payment.amount),
        amountUsd: payment.amount_usd === null ? null : Number(payment.amount_usd),
        decimals,
        blockhash: blockhash.data.blockhash,
        lastValidBlockHeight: blockhash.data.lastValidBlockHeight,
        destinationTokenAccountExists,
        memo: `AUTH payment to @${payment.recipient_handle}`,
        network: "mainnet-beta",
        idempotencyKey: `${payment.id}:${data.senderWallet}`,
      },
    };
  });
