import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { ADDRESS_RE } from "@/lib/solana";
import type { SocialProvider } from "@/lib/social/providers";

/**
 * Unified claim system.
 *
 * Direct payments and creator fees are one balance, summed from immutable
 * `identity_ledger` rows against the canonical social identity. A claim sweeps
 * the identity's Turnkey deposit wallet into the owner's payout destination.
 *
 * Authorization: only an AUTH account that has proved ownership of the exact
 * immutable provider_user_id through provider OAuth (recorded as
 * `recipients.claimed_by`) can claim. Handle text alone never authorizes
 * anything.
 *
 * Every payout is verified on-chain before anything is marked claimed.
 */

/** SOL held back per deposit wallet for the network fee and token-account rent. */
const FEE_RESERVE_SOL = 0.006;

export interface ClaimableIdentity {
  recipientId: string;
  provider: SocialProvider;
  handle: string;
  displayName: string | null;
  avatarUrl: string | null;
  providerUserId: string | null;
  depositAddress: string | null;
  SOL: number;
  USDC: number;
  sources: { payments: { SOL: number; USDC: number }; creatorFees: { SOL: number; USDC: number } };
}

export interface MyClaimable {
  identities: ClaimableIdentity[];
  total: { SOL: number; USDC: number };
  claiming: { SOL: number; USDC: number };
  claimed: { SOL: number; USDC: number };
  approxUsd: number | null;
  solPriceUsd: number | null;
  /** Destination the claim would pay out to. */
  destination: { address: string; kind: "external_wallet" | "auth_wallet" } | null;
  /** Rough network cost of the claim, in SOL. */
  estimatedNetworkFeeSol: number;
  asOf: string;
}

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

/** The claimer's payout destination: their own verified wallet, else their AUTH wallet. */
async function resolveDestination(
  userId: string,
): Promise<{ address: string; kind: "external_wallet" | "auth_wallet" } | null> {
  const db = await admin();
  const { data: external } = await db
    .from("wallets")
    .select("address,is_default,verified_at")
    .eq("user_id", userId)
    .not("verified_at", "is", null)
    .order("is_default", { ascending: false })
    .order("verified_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (external?.address && ADDRESS_RE.test(external.address)) {
    return { address: external.address, kind: "external_wallet" };
  }
  const { data: embedded } = await db
    .from("embedded_wallets")
    .select("address,is_primary,created_at")
    .eq("user_id", userId)
    .order("is_primary", { ascending: false })
    .order("created_at", { ascending: true })
    .limit(1)
    .maybeSingle();
  if (embedded?.address && ADDRESS_RE.test(embedded.address)) {
    return { address: embedded.address, kind: "auth_wallet" };
  }
  return null;
}

/** Everything the signed-in user can claim, across every identity they own. */
export const myClaimable = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<MyClaimable> => {
    const { userId } = context;
    const db = await admin();
    const asOf = new Date().toISOString();

    const empty: MyClaimable = {
      identities: [],
      total: { SOL: 0, USDC: 0 },
      claiming: { SOL: 0, USDC: 0 },
      claimed: { SOL: 0, USDC: 0 },
      approxUsd: 0,
      solPriceUsd: null,
      destination: await resolveDestination(userId),
      estimatedNetworkFeeSol: 0,
      asOf,
    };

    // Verified ownership: identities this AUTH account has actually claimed.
    const { data: recipients } = await db
      .from("recipients")
      .select("id,handle,display_name,avatar_url,provider,provider_user_id")
      .eq("claimed_by", userId);
    if (!recipients?.length) return empty;

    const ids = recipients.map((r) => r.id);
    const [{ data: rows }, { data: deposits }] = await Promise.all([
      db
        .from("identity_ledger")
        .select("recipient_id,status,asset,amount,amount_usd,source")
        .in("recipient_id", ids),
      db
        .from("identity_deposit_wallets")
        .select("recipient_id,address")
        .in("recipient_id", ids),
    ]);

    const { totalsFromRows } = await import("@/lib/deposits/ledger.server");
    const identities: ClaimableIdentity[] = [];
    const total = { SOL: 0, USDC: 0 };
    const claiming = { SOL: 0, USDC: 0 };
    const claimed = { SOL: 0, USDC: 0 };

    for (const r of recipients) {
      const mine = (rows ?? []).filter((row) => row.recipient_id === r.id);
      const t = totalsFromRows(mine as never);
      total.SOL += t.available.SOL;
      total.USDC += t.available.USDC;
      claiming.SOL += t.claiming.SOL;
      claiming.USDC += t.claiming.USDC;
      claimed.SOL += t.claimed.SOL;
      claimed.USDC += t.claimed.USDC;
      identities.push({
        recipientId: r.id,
        provider: (r.provider ?? "x") as SocialProvider,
        handle: r.handle,
        displayName: r.display_name,
        avatarUrl: r.avatar_url,
        providerUserId: r.provider_user_id,
        depositAddress: deposits?.find((d) => d.recipient_id === r.id)?.address ?? null,
        SOL: t.available.SOL,
        USDC: t.available.USDC,
        sources: {
          payments: t.bySource.payment,
          creatorFees: t.bySource.creator_fee,
        },
      });
    }

    let solPriceUsd: number | null = null;
    if (total.SOL > 0) {
      const { getSolUsdPrice } = await import("@/integrations/adapters/price.server");
      const price = await getSolUsdPrice();
      if (price.ok) solPriceUsd = price.usd;
    }
    const approxUsd =
      total.SOL > 0 && solPriceUsd === null
        ? null
        : Number((total.SOL * (solPriceUsd ?? 0) + total.USDC).toFixed(2));

    const walletsInvolved = new Set(
      identities.filter((i) => i.SOL > 0 || i.USDC > 0).map((i) => i.depositAddress),
    );
    walletsInvolved.delete(null);

    return {
      ...empty,
      identities,
      total,
      claiming,
      claimed,
      approxUsd,
      solPriceUsd,
      estimatedNetworkFeeSol: Number((walletsInvolved.size * 0.000005).toFixed(6)),
      asOf,
    };
  });

export interface ClaimAllResult {
  ok: boolean;
  message: string;
  claimed: { asset: string; amount: number; signature: string }[];
  failed: { asset: string; amount: number; reason: string }[];
  destination?: string;
}

/**
 * Claim everything available across every verified identity this account owns,
 * in as few transactions as the chain allows: one per asset per deposit wallet.
 */
export const claimAll = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { destinationAddress?: string } | undefined) => ({
    destinationAddress: input?.destinationAddress?.trim() || null,
  }))
  .handler(async ({ data, context }): Promise<ClaimAllResult> => {
    const { userId } = context;
    const { enforceRateLimit } = await import("@/lib/rate-limit.server");
    enforceRateLimit("claim-all", 6, 60_000);
    const db = await admin();

    const claimedOut: ClaimAllResult["claimed"] = [];
    const failedOut: ClaimAllResult["failed"] = [];

    // Destination: an explicit address must already be a verified wallet of
    // this account — never an arbitrary address supplied by the browser.
    let destination = await resolveDestination(userId);
    if (data.destinationAddress) {
      if (!ADDRESS_RE.test(data.destinationAddress)) {
        return { ok: false, message: "That payout address isn't valid.", claimed: [], failed: [] };
      }
      const { data: owned } = await db
        .from("wallets")
        .select("address")
        .eq("user_id", userId)
        .eq("address", data.destinationAddress)
        .not("verified_at", "is", null)
        .maybeSingle();
      if (!owned) {
        return {
          ok: false,
          message: "Verify that wallet on your profile before claiming to it.",
          claimed: [],
          failed: [],
        };
      }
      destination = { address: owned.address, kind: "external_wallet" };
    }
    if (!destination) {
      return {
        ok: false,
        message: "You have no payout wallet yet. Verify a social account to get one.",
        claimed: [],
        failed: [],
      };
    }

    const { data: recipients } = await db
      .from("recipients")
      .select("id,handle,provider")
      .eq("claimed_by", userId);
    if (!recipients?.length) {
      return { ok: false, message: "Verify a social account first.", claimed: [], failed: [] };
    }

    const ids = recipients.map((r) => r.id);
    const { data: rows } = await db
      .from("identity_ledger")
      .select("id,recipient_id,asset,amount,deposit_address,status")
      .in("recipient_id", ids)
      .in("status", ["deposited", "available"]);
    if (!rows?.length) {
      return { ok: false, message: "There's nothing to claim yet.", claimed: [], failed: [] };
    }

    const { data: wallets } = await db
      .from("identity_deposit_wallets")
      .select("address,sub_organization_id,recipient_id")
      .in("recipient_id", ids);

    // Group into one transfer per (deposit wallet, asset).
    const groups = new Map<string, { address: string; asset: "SOL" | "USDC"; amount: number; ids: string[]; recipientId: string }>();
    for (const row of rows) {
      const address = row.deposit_address;
      const asset = row.asset === "USDC" ? "USDC" : row.asset === "SOL" ? "SOL" : null;
      if (!address || !asset) continue;
      const key = `${address}:${asset}`;
      const entry = groups.get(key) ?? {
        address,
        asset,
        amount: 0,
        ids: [],
        recipientId: row.recipient_id,
      };
      entry.amount += Number(row.amount);
      entry.ids.push(row.id);
      groups.set(key, entry);
    }
    if (groups.size === 0) {
      return { ok: false, message: "There's nothing to claim yet.", claimed: [], failed: [] };
    }

    const { getSolBalance, getLatestBlockhash, getSignatureStatus, verifyTransfer } = await import(
      "@/integrations/adapters/helius.server"
    );
    const { buildUnsignedTransfer, signAndSendWithTurnkey } = await import(
      "@/lib/wallet/solana-tx.server"
    );
    const { USDC_MINT, USDC_DECIMALS } = await import("@/lib/solana");

    for (const group of groups.values()) {
      const wallet = wallets?.find((w) => w.address === group.address);
      if (!wallet?.sub_organization_id) {
        failedOut.push({
          asset: group.asset,
          amount: group.amount,
          reason: "This deposit wallet has no custody record, so AUTH can't move it.",
        });
        continue;
      }

      // Never try to send more than the wallet actually holds, and always keep
      // enough SOL behind for the network fee and token-account rent.
      let amount = group.amount;
      if (group.asset === "SOL") {
        const balance = await getSolBalance(group.address);
        if (!balance.ok) {
          failedOut.push({ asset: "SOL", amount, reason: "Could not read the deposit balance." });
          continue;
        }
        amount = Math.min(amount, Number((balance.data - FEE_RESERVE_SOL).toFixed(9)));
        if (!(amount > 0)) {
          failedOut.push({
            asset: "SOL",
            amount: group.amount,
            reason: "Balance is too small to cover the network fee.",
          });
          continue;
        }
      }

      const idempotencyKey = `claim:${userId}:${group.address}:${group.asset}:${group.ids
        .slice()
        .sort()
        .join(",")}`;

      const { data: batch, error: batchError } = await db
        .from("claim_batches")
        .insert({
          recipient_id: group.recipientId,
          user_id: userId,
          asset: group.asset,
          amount,
          source_address: group.address,
          destination_address: destination.address,
          status: "claiming",
          idempotency_key: idempotencyKey,
        })
        .select("id")
        .single();
      if (batchError || !batch) {
        // Unique idempotency key: this exact claim is already in flight.
        failedOut.push({
          asset: group.asset,
          amount,
          reason: "This claim is already being processed.",
        });
        continue;
      }

      // Lock the rows: only rows still unclaimed move to "claiming", so a
      // concurrent claim can never pay the same credit twice.
      const { data: locked } = await db
        .from("identity_ledger")
        .update({ status: "claiming", claim_batch_id: batch.id, claimed_by: userId })
        .in("id", group.ids)
        .in("status", ["deposited", "available"])
        .select("id");
      if (!locked?.length) {
        await db
          .from("claim_batches")
          .update({ status: "failed", failure_reason: "Already claimed." })
          .eq("id", batch.id);
        continue;
      }

      const blockhash = await getLatestBlockhash();
      if (!blockhash.ok) {
        await releaseLock(db, group.ids, batch.id, "Could not reach Solana.");
        failedOut.push({ asset: group.asset, amount, reason: "Could not reach Solana." });
        continue;
      }

      const unsigned = await buildUnsignedTransfer(
        {
          from: group.address,
          to: destination.address,
          mint: group.asset === "USDC" ? USDC_MINT : null,
          amount,
          decimals: group.asset === "USDC" ? USDC_DECIMALS : 9,
        },
        blockhash.data.blockhash,
      );

      const sent = await signAndSendWithTurnkey({
        subOrganizationId: wallet.sub_organization_id,
        signWith: group.address,
        unsignedHex: unsigned.hex,
      });
      if (!sent.ok) {
        await releaseLock(db, group.ids, batch.id, sent.message);
        failedOut.push({ asset: group.asset, amount, reason: sent.message });
        continue;
      }

      // Nothing is marked claimed on the strength of a broadcast alone: the
      // transfer has to be confirmed and match on-chain.
      let confirmed = false;
      for (let i = 0; i < 12; i++) {
        const status = await getSignatureStatus(sent.signature);
        if (status.ok && status.data) {
          if (status.data.err) break;
          if (
            status.data.confirmationStatus === "confirmed" ||
            status.data.confirmationStatus === "finalized"
          ) {
            confirmed = true;
            break;
          }
        }
        await new Promise((r) => setTimeout(r, 2000));
      }

      if (confirmed) {
        const check = await verifyTransfer(sent.signature, {
          from: group.address,
          to: destination.address,
          mint: group.asset === "USDC" ? USDC_MINT : null,
          amount,
          decimals: group.asset === "USDC" ? USDC_DECIMALS : 9,
        });
        if (check.ok && check.data.found && !check.data.succeeded) confirmed = false;
      }

      if (!confirmed) {
        await releaseLock(
          db,
          group.ids,
          batch.id,
          "The payout transaction was not confirmed on-chain.",
        );
        failedOut.push({
          asset: group.asset,
          amount,
          reason: "The payout was not confirmed on-chain. Nothing was marked as claimed.",
        });
        continue;
      }

      const now = new Date().toISOString();
      await db
        .from("claim_batches")
        .update({ status: "claimed", tx_signature: sent.signature, confirmed_at: now })
        .eq("id", batch.id);
      await db
        .from("identity_ledger")
        .update({
          status: "claimed",
          claim_signature: sent.signature,
          claimed_at: now,
          claimed_by: userId,
        })
        .eq("claim_batch_id", batch.id);

      await db.from("audit_log").insert({
        actor_id: userId,
        action: "claim.settled_on_chain",
        entity: "claim_batches",
        entity_id: batch.id,
        metadata: {
          asset: group.asset,
          amount,
          signature: sent.signature,
          destination: destination.address,
        },
      });

      claimedOut.push({ asset: group.asset, amount, signature: sent.signature });
    }

    const ok = claimedOut.length > 0;
    return {
      ok,
      destination: destination.address,
      claimed: claimedOut,
      failed: failedOut,
      message: ok
        ? `Claimed ${claimedOut
            .map((c) => `${c.amount} ${c.asset}`)
            .join(" and ")} to ${destination.address.slice(0, 4)}…${destination.address.slice(-4)}.`
        : (failedOut[0]?.reason ?? "Nothing could be claimed right now."),
    };
  });

/** Puts credits back to available when a payout didn't complete. */
async function releaseLock(
  db: Awaited<ReturnType<typeof admin>>,
  ids: string[],
  batchId: string,
  reason: string,
) {
  await db
    .from("identity_ledger")
    .update({ status: "available", claim_batch_id: null, claimed_by: null })
    .in("id", ids)
    .eq("status", "claiming");
  await db
    .from("claim_batches")
    .update({ status: "failed", failure_reason: reason })
    .eq("id", batchId);
}
