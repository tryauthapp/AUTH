import { createOpenAI } from "@ai-sdk/openai";
import { createServerFn } from "@tanstack/react-start";
import { Output, streamText } from "ai";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const InputSchema = z.object({
  goal: z.string().trim().min(12).max(1200),
});

const RecommendationSchema = z.object({
  summary: z.string(),
  splits: z.array(
    z.object({
      destination: z.enum(["sol", "usdc", "charity"]),
      percent: z.number(),
      label: z.string(),
      charitySlug: z.string().nullable(),
    }),
  ),
});

export type RoutingRecommendation = {
  summary: string;
  splits: Array<{
    destination: "sol" | "usdc" | "charity";
    percent: number;
    label: string;
    address: null;
    charity_id: string | null;
  }>;
};

export const recommendRouting = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => InputSchema.parse(input))
  .handler(async ({ data, context }): Promise<RoutingRecommendation> => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("AI recommendations are unavailable right now.");

    const { data: charities, error } = await context.supabase
      .from("charities")
      .select("id,slug,name")
      .eq("is_demo", false)
      .order("name");
    if (error) throw new Error("Could not load available routing destinations.");

    const lovable = createOpenAI({
      baseURL: "https://ai.gateway.lovable.dev/v1",
      apiKey,
      headers: {
        "Lovable-API-Key": apiKey,
        "X-Lovable-AIG-SDK": "vercel-ai-sdk",
      },
    });

    const charityList = (charities ?? []).map((charity) => `${charity.slug}: ${charity.name}`).join("\n") || "None available";
    const result = streamText({
      model: lovable.responses("openai/gpt-6-astra"),
      output: Output.object({ schema: RecommendationSchema }),
      prompt: `Recommend a conservative creator-fee routing split from this goal:\n\n${data.goal}\n\nAllowed destinations are SOL, USDC, and listed charities only. Use one to three positive whole-number percentages totaling exactly 100. Use charity only when the goal explicitly requests giving and select only a listed charity slug. Never invent an address or destination. Keep the explanation concise.\n\nAvailable charities:\n${charityList}`,
      providerOptions: {
        openai: {
          forceReasoning: true,
          reasoningEffort: "low",
          reasoningSummary: "auto",
          store: false,
          include: ["reasoning.encrypted_content"],
        },
      },
    });

    const output = await result.output;
    if (!output) throw new Error("AI did not return a routing recommendation.");
    const parsed = RecommendationSchema.parse(output);
    if (parsed.splits.length < 1 || parsed.splits.length > 3) {
      throw new Error("AI returned an invalid number of routing destinations.");
    }

    const charityBySlug = new Map((charities ?? []).map((charity) => [charity.slug, charity.id]));
    const splits = parsed.splits.map((split) => {
      const percent = Math.round(split.percent);
      if (!Number.isFinite(percent) || percent <= 0 || percent > 100) {
        throw new Error("AI returned an invalid routing percentage.");
      }
      const charityId = split.destination === "charity" && split.charitySlug
        ? charityBySlug.get(split.charitySlug) ?? null
        : null;
      if (split.destination === "charity" && !charityId) {
        throw new Error("AI selected an unavailable charity.");
      }
      return {
        destination: split.destination,
        percent,
        label: split.label.trim().slice(0, 80) || split.destination.toUpperCase(),
        address: null,
        charity_id: charityId,
      };
    });

    if (splits.reduce((sum, split) => sum + split.percent, 0) !== 100) {
      throw new Error("AI recommendation did not total exactly 100%.");
    }

    return { summary: parsed.summary.trim().slice(0, 320), splits };
  });