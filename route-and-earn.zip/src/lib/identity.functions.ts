import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Identity → wallet mapping.
 *
 * An X username is the payment identity. Anyone can be paid at a username; the
 * funds only become spendable once the real owner proves the account is theirs
 * and verifies a payout wallet they control.
 *
 * Ownership proof uses X OAuth when configured. The returned X account ID and
 * username must match the claim before the identity is bound. A one-time public
 * proof post remains available for manual review as a fallback.
 */

const HANDLE_RE = /^[A-Za-z0-9_]{1,15}$/;
const PROOF_URL_RE = /^https:\/\/(?:x|twitter)\.com\/([A-Za-z0-9_]{1,15})\/status\/(\d{5,25})/i;

function normalizeHandle(raw: string): string {
  const handle = raw.trim().replace(/^@/, "");
  if (!HANDLE_RE.test(handle)) throw new Error("Enter a valid X username (letters, numbers, underscore).");
  return handle;
}

function makeProofCode(): string {
  // 20 chars from a 31-symbol alphabet (~99 bits), drawn with rejection
  // sampling so every symbol is equally likely — no modulo bias.
  const alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  const limit = 256 - (256 % alphabet.length);
  let out = "";
  while (out.length < 20) {
    const bytes = crypto.getRandomValues(new Uint8Array(24));
    for (const b of bytes) {
      if (b >= limit || out.length >= 20) continue;
      out += alphabet[b % alphabet.length];
    }
  }
  return `AUTH-${out}`;
}

export interface ClaimState {
  claimId: string;
  handle: string;
  recipientId: string;
  status: string;
  proofCode: string;
  proofUrl: string | null;
  reviewNote: string | null;
  verification: string;
  claimedByMe: boolean;
  createdAt: string;
}

/** Everything the signed-in user has claimed or is claiming. */
export const myIdentityState = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;

    const [{ data: claims }, { data: recipients }] = await Promise.all([
      supabase
        .from("identity_claims")
        .select("id,handle,recipient_id,status,proof_code,proof_url,review_note,created_at")
        .eq("user_id", userId)
        .order("created_at", { ascending: false }),
      supabase
        .from("recipients")
        .select("id,handle,verification,claimed_by")
        .eq("claimed_by", userId),
    ]);

    const verificationById = new Map((recipients ?? []).map((r) => [r.id, r]));

    const rows: ClaimState[] = (claims ?? []).map((c) => {
      const recipient = verificationById.get(c.recipient_id);
      return {
        claimId: c.id,
        handle: c.handle,
        recipientId: c.recipient_id,
        status: c.status,
        proofCode: c.proof_code,
        proofUrl: c.proof_url,
        reviewNote: c.review_note,
        verification: recipient?.verification ?? "unverified",
        claimedByMe: Boolean(recipient),
        createdAt: c.created_at,
      };
    });

    const { data: wallets } = await supabase
      .from("wallets")
      .select("id,address,recipient_id,verified_at,is_default,label")
      .eq("user_id", userId)
      .order("created_at", { ascending: false });

    return {
      claims: rows,
      identities: (recipients ?? []).map((r) => ({
        id: r.id,
        handle: r.handle,
        verification: r.verification,
      })),
      wallets: (wallets ?? []).map((w) => ({
        id: w.id,
        address: w.address,
        recipientId: w.recipient_id,
        verifiedAt: w.verified_at,
        isDefault: Boolean(w.is_default),
        label: w.label,
      })),
    };
  });

export interface StartClaimResult {
  ok: boolean;
  message?: string;
  claimId?: string;
  handle?: string;
  proofCode?: string;
  postText?: string;
}

/** Step 1 — reserve the claim and issue a one-time proof code. */
export const startHandleClaim = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { handle: string }) => ({ handle: normalizeHandle(input.handle) }))
  .handler(async ({ data, context }): Promise<StartClaimResult> => {
    const { userId } = context;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    let { data: recipient } = await supabaseAdmin
      .from("recipients")
      .select("id,handle,claimed_by,verification")
      .ilike("handle", data.handle)
      .maybeSingle();

    if (recipient?.claimed_by && recipient.claimed_by !== userId) {
      return { ok: false, message: "That username is already claimed by another account." };
    }

    if (!recipient) {
      const { data: created, error } = await supabaseAdmin
        .from("recipients")
        .insert({ handle: data.handle, verification: "unverified", is_demo: false })
        .select("id,handle,claimed_by,verification")
        .single();
      if (error) return { ok: false, message: error.message };
      recipient = created;
    }

    const { data: open } = await supabaseAdmin
      .from("identity_claims")
      .select("id,proof_code,status")
      .eq("recipient_id", recipient.id)
      .eq("user_id", userId)
      .in("status", ["pending", "submitted"])
      .gt("proof_code_expires_at", new Date().toISOString())
      .maybeSingle();

    if (open) {
      return {
        ok: true,
        claimId: open.id,
        handle: recipient.handle,
        proofCode: open.proof_code,
        postText: `Verifying my @${recipient.handle} identity on AUTH: ${open.proof_code}`,
      };
    }

    const proofCode = makeProofCode();
    const { data: claim, error: claimError } = await supabaseAdmin
      .from("identity_claims")
      .insert({
        recipient_id: recipient.id,
        handle: recipient.handle,
        user_id: userId,
        method: "post_proof",
        proof_code: proofCode,
        status: "pending",
      })
      .select("id")
      .single();
    if (claimError) return { ok: false, message: claimError.message };

    await supabaseAdmin.from("audit_log").insert({
      actor_id: userId,
      action: "identity.claim_started",
      entity: "identity_claims",
      entity_id: claim.id,
      metadata: { handle: recipient.handle },
    });

    return {
      ok: true,
      claimId: claim.id,
      handle: recipient.handle,
      proofCode,
      postText: `Verifying my @${recipient.handle} identity on AUTH: ${proofCode}`,
    };
  });

/** Step 2 — submit the public post that contains the code. */
export const submitHandleProof = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { claimId: string; proofUrl: string }) => {
    const proofUrl = input.proofUrl.trim();
    if (!PROOF_URL_RE.test(proofUrl)) {
      throw new Error("Paste the full link to your post, e.g. https://x.com/username/status/123…");
    }
    if (!input.claimId) throw new Error("Missing claim.");
    return { claimId: input.claimId, proofUrl };
  })
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: claim } = await supabase
      .from("identity_claims")
      .select("id,handle,recipient_id,user_id,status,proof_code_expires_at")
      .eq("id", data.claimId)
      .maybeSingle();

    if (!claim) return { ok: false as const, message: "Claim not found." };
    if (claim.user_id !== userId) return { ok: false as const, message: "That claim belongs to another account." };
    if (claim.proof_code_expires_at && new Date(claim.proof_code_expires_at) < new Date()) {
      return { ok: false as const, message: "This verification code has expired. Start the claim again to get a new one." };
    }

    const match = PROOF_URL_RE.exec(data.proofUrl);
    const urlHandle = match?.[1] ?? "";
    if (urlHandle.toLowerCase() !== claim.handle.toLowerCase()) {
      return {
        ok: false as const,
        message: `That post is from @${urlHandle}, not @${claim.handle}. Post the code from the account you are claiming.`,
      };
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const now = new Date().toISOString();

    const { data: recipient } = await supabaseAdmin
      .from("recipients")
      .select("id,claimed_by")
      .eq("id", claim.recipient_id)
      .maybeSingle();

    if (recipient?.claimed_by && recipient.claimed_by !== userId) {
      return { ok: false as const, message: "That username is already claimed by another account." };
    }

    await supabaseAdmin
      .from("identity_claims")
      .update({ proof_url: data.proofUrl, status: "submitted", submitted_at: now })
      .eq("id", claim.id);

    // A pasted link is not proof on its own — anyone can link to a public post.
    // The identity stays unowned until a reviewer (or X verification) confirms
    // it, so a submitted claim can never redirect someone else's incoming
    // payments to a payout wallet.
    if (!recipient?.claimed_by) {
      await supabaseAdmin
        .from("recipients")
        .update({ verification: "pending" })
        .eq("id", claim.recipient_id);
    }

    await supabaseAdmin.from("audit_log").insert({
      actor_id: userId,
      action: "identity.proof_submitted",
      entity: "identity_claims",
      entity_id: claim.id,
      metadata: { handle: claim.handle, proof_url: data.proofUrl },
    });

    return {
      ok: true as const,
      message:
        "Proof submitted. Once the post is checked, the username is yours and you can set a payout wallet.",
    };
  });


/** Step 3 — point the identity at one of the caller's verified wallets. */
export const setPayoutWallet = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { recipientId: string; walletId: string }) => {
    if (!input.recipientId || !input.walletId) throw new Error("Missing wallet or identity.");
    return input;
  })
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const [{ data: recipient }, { data: wallet }] = await Promise.all([
      supabase
        .from("recipients")
        .select("id,handle,claimed_by,verification")
        .eq("id", data.recipientId)
        .maybeSingle(),
      supabase.from("wallets").select("id,user_id,address,verified_at").eq("id", data.walletId).maybeSingle(),
    ]);

    if (!recipient || recipient.claimed_by !== userId) {
      return { ok: false as const, message: "You have not claimed that username." };
    }
    // Ownership must be confirmed (reviewed proof or X verification) before the
    // payout destination for a username can be changed.
    if (recipient.verification !== "verified") {
      return {
        ok: false as const,
        message: "This username isn't verified yet. A payout wallet can only be set after verification.",
      };
    }

    if (!wallet || wallet.user_id !== userId) {
      return { ok: false as const, message: "That wallet is not yours." };
    }
    if (!wallet.verified_at) {
      return { ok: false as const, message: "Verify the wallet by signing the ownership message first." };
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin
      .from("wallets")
      .update({ is_default: false })
      .eq("user_id", userId)
      .eq("recipient_id", data.recipientId);
    await supabaseAdmin
      .from("wallets")
      .update({ recipient_id: data.recipientId, is_default: true })
      .eq("id", data.walletId);

    await supabaseAdmin.from("audit_log").insert({
      actor_id: userId,
      action: "identity.payout_wallet_set",
      entity: "recipients",
      entity_id: data.recipientId,
      metadata: { handle: recipient.handle, wallet: wallet.address },
    });

    return { ok: true as const, message: `Payments to @${recipient.handle} now resolve to this wallet.` };
  });

/** Admin review of a submitted proof. */
export const reviewHandleClaim = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { claimId: string; approve: boolean; note?: string }) => ({
    claimId: input.claimId,
    approve: Boolean(input.approve),
    note: (input.note ?? "").slice(0, 200),
  }))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
    if (!isAdmin) return { ok: false as const, message: "Admins only." };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: claim } = await supabaseAdmin
      .from("identity_claims")
      .select("id,recipient_id,handle,user_id")
      .eq("id", data.claimId)
      .maybeSingle();
    if (!claim) return { ok: false as const, message: "Claim not found." };

    const now = new Date().toISOString();
    await supabaseAdmin
      .from("identity_claims")
      .update({
        status: data.approve ? "approved" : "rejected",
        reviewer_id: userId,
        review_note: data.note || null,
        reviewed_at: now,
      })
      .eq("id", claim.id);

    await supabaseAdmin
      .from("recipients")
      .update(
        data.approve
          ? { verification: "verified", claimed_by: claim.user_id }
          : { verification: "rejected", claimed_by: null },
      )
      .eq("id", claim.recipient_id);

    await supabaseAdmin.from("audit_log").insert({
      actor_id: userId,
      action: data.approve ? "identity.claim_approved" : "identity.claim_rejected",
      entity: "identity_claims",
      entity_id: claim.id,
      metadata: { handle: claim.handle },
    });

    return { ok: true as const, message: data.approve ? "Identity verified." : "Claim rejected." };
  });

/** Admin queue of claims awaiting review. */
export const pendingHandleClaims = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: isAdmin } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
    if (!isAdmin) return { ok: false as const, claims: [] };

    const { data } = await supabase
      .from("identity_claims")
      .select("id,handle,status,proof_code,proof_url,created_at,submitted_at")
      .in("status", ["pending", "submitted"])
      .order("created_at", { ascending: false })
      .limit(100);

    return { ok: true as const, claims: data ?? [] };
  });
