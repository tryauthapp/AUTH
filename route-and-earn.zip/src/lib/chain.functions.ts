import { createServerFn } from "@tanstack/react-start";

/**
 * Public, read-only on-chain reads backed by Helius RPC.
 * Never accepts or returns key material — public addresses and signatures only.
 */

const ADDRESS_RE = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
const SIGNATURE_RE = /^[1-9A-HJ-NP-Za-km-z]{64,90}$/;

export interface ChainStatus {
  configured: boolean;
  treasuryAddress: string | null;
  treasurySol: number | null;
  error: string | null;
  recent: { signature: string; blockTime: number | null; succeeded: boolean }[];
}

export const getChainStatus = createServerFn({ method: "GET" }).handler(
  async (): Promise<ChainStatus> => {
    const { heliusConfigured, getSolBalance, getRecentSignatures } = await import(
      "@/integrations/adapters/helius.server"
    );

    const address = await readTreasuryAddress();
    if (!heliusConfigured()) {
      return {
        configured: false,
        treasuryAddress: address,
        treasurySol: null,
        error: "Helius RPC is not configured.",
        recent: [],
      };
    }
    if (!address) {
      return {
        configured: true,
        treasuryAddress: null,
        treasurySol: null,
        error: "No treasury wallet is configured in protocol settings.",
        recent: [],
      };
    }

    const [balance, sigs] = await Promise.all([
      getSolBalance(address),
      getRecentSignatures(address, 10),
    ]);

    return {
      configured: true,
      treasuryAddress: address,
      treasurySol: balance.ok ? balance.data : null,
      error: balance.ok ? null : balance.message,
      recent: sigs.ok
        ? sigs.data.map((s) => ({
            signature: s.signature,
            blockTime: s.blockTime,
            succeeded: !s.err,
          }))
        : [],
    };
  },
);

export const getAddressBalance = createServerFn({ method: "POST" })
  .inputValidator((input: { address: string }) => {
    if (!ADDRESS_RE.test(input.address.trim())) {
      throw new Error("That does not look like a Solana address.");
    }
    return { address: input.address.trim() };
  })
  .handler(async ({ data }) => {
    const { getSolBalance } = await import("@/integrations/adapters/helius.server");
    const r = await getSolBalance(data.address);
    if (!r.ok) return { ok: false as const, message: r.message };
    return { ok: true as const, sol: r.data };
  });

export const lookupTransaction = createServerFn({ method: "POST" })
  .inputValidator((input: { signature: string }) => {
    if (!SIGNATURE_RE.test(input.signature.trim())) {
      throw new Error("That does not look like a Solana transaction signature.");
    }
    return { signature: input.signature.trim() };
  })
  .handler(async ({ data }) => {
    const { getTransactionSummary } = await import("@/integrations/adapters/helius.server");
    const r = await getTransactionSummary(data.signature);
    if (!r.ok) return { ok: false as const, message: r.message };
    if (!r.data) {
      return { ok: false as const, message: "Not found on mainnet (it may be a demo record)." };
    }
    return { ok: true as const, tx: r.data };
  });

/** Admin-only: list real on-chain activity for a mint. Records nothing as revenue. */
export const previewMintActivity = createServerFn({ method: "POST" })
  .inputValidator((input: { mint: string }) => {
    if (!ADDRESS_RE.test(input.mint.trim())) throw new Error("Invalid mint address.");
    return { mint: input.mint.trim() };
  })
  .handler(async ({ data }) => {
    const { getRecentSignatures, getTokenSupply } = await import(
      "@/integrations/adapters/helius.server"
    );
    const [sigs, supply] = await Promise.all([
      getRecentSignatures(data.mint, 15),
      getTokenSupply(data.mint),
    ]);
    return {
      ok: sigs.ok,
      message: sigs.ok ? null : sigs.message,
      supply: supply.ok ? supply.data : null,
      signatures: sigs.ok
        ? sigs.data.map((s) => ({
            signature: s.signature,
            blockTime: s.blockTime,
            succeeded: !s.err,
          }))
        : [],
    };
  });

async function readTreasuryAddress(): Promise<string | null> {
  // protocol_settings is admin-only through the Data API, so this read happens
  // server-side with the service client and returns just the public address.
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("protocol_settings")
    .select("value")
    .eq("key", "treasury_wallet")
    .maybeSingle();
  const value = data?.value as { address?: string } | null | undefined;
  return value?.address ?? null;
}
