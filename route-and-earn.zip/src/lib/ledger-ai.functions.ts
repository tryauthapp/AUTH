import { createOpenAI } from "@ai-sdk/openai";
import { createServerFn } from "@tanstack/react-start";
import { streamText } from "ai";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Creator-fee ledger assistant.
 *
 * A verified recipient can ask questions about their own balances, payout
 * statuses and transaction history. The model only ever sees the signed-in
 * user's own rows, read through their RLS-scoped client, and is told to answer
 * strictly from that data — it never invents amounts or signatures.
 */

const InputSchema = z.object({
  question: z.string().trim().min(3).max(500),
});

export interface LedgerAnswer {
  answer: string;
  /** Snapshot the answer was based on, so the UI can show what the model saw. */
  context: {
    identities: number;
    availableSol: number;
    availableUsdc: number;
    claimedSol: number;
    claimedUsdc: number;
    ledgerRows: number;
    payoutRows: number;
    asOf: string;
  };
}

export const askLedgerQuestion = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => InputSchema.parse(input))
  .handler(async ({ data, context }): Promise<LedgerAnswer> => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("The ledger assistant is unavailable right now.");

    // Only identities this account has proved ownership of.
    const { data: recipients } = await context.supabase
      .from("recipients")
      .select("id,provider,handle,display_name")
      .eq("claimed_by", context.userId)
      .eq("is_demo", false)
      .limit(25);

    const ids = (recipients ?? []).map((r) => r.id);
    if (ids.length === 0) {
      throw new Error(
        "Verify ownership of a social account first — the assistant only answers about accounts you have claimed.",
      );
    }

    const [{ data: ledger }, { data: payouts }] = await Promise.all([
      context.supabase
        .from("identity_ledger")
        .select("provider,source,asset,amount,amount_usd,status,created_at,claimed_at,tx_signature,claim_signature,recipient_id")
        .in("recipient_id", ids)
        .order("created_at", { ascending: false })
        .limit(120),
      context.supabase
        .from("payouts")
        .select("asset,asset_amount,amount_usd,status,destination,created_at,confirmed_at,failure_reason,tx_signature,recipient_id")
        .in("recipient_id", ids)
        .eq("is_demo", false)
        .order("created_at", { ascending: false })
        .limit(60),
    ]);

    const rows = ledger ?? [];
    const sum = (status: string, asset: string) =>
      rows
        .filter((r) => r.status === status && r.asset === asset)
        .reduce((total, r) => total + Number(r.amount ?? 0), 0);

    const snapshot = {
      identities: (recipients ?? []).length,
      availableSol: sum("available", "SOL"),
      availableUsdc: sum("available", "USDC"),
      claimedSol: sum("claimed", "SOL"),
      claimedUsdc: sum("claimed", "USDC"),
      ledgerRows: rows.length,
      payoutRows: (payouts ?? []).length,
      asOf: new Date().toISOString(),
    };

    const handleById = new Map((recipients ?? []).map((r) => [r.id, `${r.provider}:@${r.handle}`]));

    const dataBlock = JSON.stringify(
      {
        asOf: snapshot.asOf,
        verifiedAccounts: (recipients ?? []).map((r) => `${r.provider}:@${r.handle}`),
        totals: {
          availableSOL: snapshot.availableSol,
          availableUSDC: snapshot.availableUsdc,
          claimedSOL: snapshot.claimedSol,
          claimedUSDC: snapshot.claimedUsdc,
        },
        ledger: rows.map((r) => ({
          account: handleById.get(r.recipient_id) ?? r.provider,
          source: r.source,
          asset: r.asset,
          amount: Number(r.amount ?? 0),
          usd: r.amount_usd === null ? null : Number(r.amount_usd),
          status: r.status,
          createdAt: r.created_at,
          claimedAt: r.claimed_at,
          depositTx: r.tx_signature,
          claimTx: r.claim_signature,
        })),
        payouts: (payouts ?? []).map((p) => ({
          account: handleById.get(p.recipient_id) ?? null,
          asset: p.asset,
          amount: p.asset_amount === null ? null : Number(p.asset_amount),
          usd: Number(p.amount_usd ?? 0),
          status: p.status,
          destination: p.destination,
          createdAt: p.created_at,
          confirmedAt: p.confirmed_at,
          failureReason: p.failure_reason,
          txSignature: p.tx_signature,
        })),
      },
      null,
      0,
    ).slice(0, 60_000);

    const lovable = createOpenAI({
      baseURL: "https://ai.gateway.lovable.dev/v1",
      apiKey,
      headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    });

    const result = streamText({
      model: lovable.responses("openai/gpt-6-astra"),
      system: [
        "You explain a creator's own crypto earnings ledger on AUTH, a Solana social payments product.",
        "Answer ONLY from the JSON data provided. Never invent amounts, dates, signatures or accounts.",
        "If the data does not answer the question, say exactly what is missing.",
        "Statuses mean: deposited = money arrived, on-chain check pending; available = verified and claimable; claiming = a payout is in flight; claimed = paid out and confirmed on-chain; failed = the payout did not go through.",
        "Sources: payment = someone sent money directly to the account; creator_fee = pump.fun creator fees routed to the account.",
        "Be concise and plain-spoken: short paragraphs or a short list, real numbers with their asset, no jargon and no financial advice.",
      ].join(" "),
      prompt: `Creator's question: ${data.question}\n\nTheir ledger data (JSON):\n${dataBlock}`,
      providerOptions: {
        openai: {
          forceReasoning: true,
          reasoningEffort: "low",
          reasoningSummary: "auto",
          store: false,
          include: ["reasoning.encrypted_content"],
        },
      },
    });

    const answer = (await result.text).trim();
    if (!answer) throw new Error("The assistant could not produce an answer. Try asking again.");

    return { answer: answer.slice(0, 4000), context: snapshot };
  });
