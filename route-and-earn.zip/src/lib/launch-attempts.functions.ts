import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { ADDRESS_RE } from "@/lib/solana";

/**
 * Reads for the post-launch success and failure screens. Everything returned
 * here comes from rows written only after a real, verified on-chain outcome.
 */

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

/** Public: the verified result of a confirmed launch, safe to show on refresh. */
export const launchResult = createServerFn({ method: "GET" })
  .inputValidator((input: { mint: string }) => {
    const mint = String(input?.mint ?? "").trim();
    if (!ADDRESS_RE.test(mint)) throw new Error("That is not a Solana address.");
    return { mint };
  })
  .handler(async ({ data }) => {
    const db = await admin();
    const { data: token } = await db
      .from("tokens")
      .select(
        "id,mint,symbol,name,description,image_url,website_url,x_url,telegram_url," +
          "community_url,launch_signature,source,created_at,verified_on_chain_at,decimals,supply," +
          "launch_wallet,execution_provider,dev_buy_sol,dev_buy_delivery_status,creator_fee_recipient_id",
      )
      .eq("mint", data.mint)
      .eq("is_demo", false)
      .maybeSingle();
    const tokenRow = (token ?? null) as {
      id: string;
      mint: string;
      symbol: string;
      name: string;
      description: string | null;
      image_url: string | null;
      website_url: string | null;
      x_url: string | null;
      telegram_url: string | null;
      community_url: string | null;
      launch_signature: string | null;
      source: string;
      created_at: string;
      verified_on_chain_at: string | null;
      decimals: number | null;
      supply: number | null;
      launch_wallet: string | null;
      execution_provider: string | null;
      dev_buy_sol: number | null;
      dev_buy_delivery_status: string | null;
      creator_fee_recipient_id: string | null;
    } | null;
    if (!tokenRow || !tokenRow.verified_on_chain_at) return { found: false as const };

    const { data: link } = await db
      .from("token_recipients")
      .select("recipient:recipients(id,handle,display_name,avatar_url,verification)")
      .eq("token_id", tokenRow.id)
      .maybeSingle();
    const recipient = (link?.recipient ?? null) as {
      id: string;
      handle: string;
      display_name: string | null;
      avatar_url: string | null;
      verification: string;
    } | null;

    let splits: { label: string; destination: string; percent: number }[] = [];
    if (recipient) {
      const { data: config } = await db
        .from("routing_configs")
        .select("id")
        .eq("recipient_id", recipient.id)
        .eq("is_active", true)
        .maybeSingle();
      if (config) {
        const { data: rows } = await db
          .from("routing_splits")
          .select("label,destination,percent,sort_order")
          .eq("config_id", config.id)
          .order("sort_order", { ascending: true });
        splits = (rows ?? []).map((r) => ({
          label: r.label,
          destination: String(r.destination),
          percent: Number(r.percent),
        }));
      }
    }

    // Who owns what, stated explicitly and never inferred by the caller.
    const devBuySol = Number(tokenRow.dev_buy_sol ?? 0);
    const ownership = {
      devBuySol,
      /** "none" | "pending_manual_settlement" | "delivered" */
      devBuyDeliveryStatus: tokenRow.dev_buy_delivery_status ?? "none",
      devBuyOwner: "launcher" as const,
      executionProvider: tokenRow.execution_provider,
      executionWallet: tokenRow.launch_wallet,
      creatorFeeRecipientId: tokenRow.creator_fee_recipient_id ?? recipient?.id ?? null,
    };

    return { found: true as const, token: tokenRow, recipient, splits, ownership };
  });

/** The launcher's own record of one launch attempt, including fee accounting. */
export const launchAttempt = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { launchKey: string }) => {
    const launchKey = String(input?.launchKey ?? "").trim().slice(0, 64);
    if (!launchKey) throw new Error("Missing launch reference.");
    return { launchKey };
  })
  .handler(async ({ data, context }) => {
    const db = await admin();
    const { data: row } = await db
      .from("launch_attempts")
      .select(
        "status,fee_signature,fee_payer,fee_lamports_received,spent_lamports," +
          "refundable_lamports,refund_status,refund_signature,refund_destination," +
          "launch_signature,mint,symbol,failure_reason,created_at,funded_at," +
          "submitted_at,confirmed_at,failed_at,dev_buy_sol,dev_buy_delivery_status," +
          "dev_buy_delivery_note,execution_provider,execution_wallet,creator_fee_recipient_id",
      )
      .eq("user_id", context.userId)
      .eq("launch_key", data.launchKey)
      .maybeSingle();
    const attempt = (row ?? null) as {
      status: string;
      fee_signature: string | null;
      fee_payer: string | null;
      fee_lamports_received: number;
      spent_lamports: number;
      refundable_lamports: number;
      refund_status: string;
      refund_signature: string | null;
      refund_destination: string | null;
      launch_signature: string | null;
      mint: string | null;
      symbol: string | null;
      failure_reason: string | null;
      created_at: string;
      funded_at: string | null;
      submitted_at: string | null;
      confirmed_at: string | null;
      failed_at: string | null;
      dev_buy_sol: number | null;
      dev_buy_delivery_status: string | null;
      dev_buy_delivery_note: string | null;
      execution_provider: string | null;
      execution_wallet: string | null;
      creator_fee_recipient_id: string | null;
    } | null;
    if (!attempt) return { found: false as const };
    return { found: true as const, attempt };
  });

/**
 * Resolves a previous launch attempt against Solana so the Launch page can show
 * an actionable state (confirmed / failed / still running) instead of a
 * dead-end error. Read-and-reconcile only; it never submits a launch.
 */
export const reconcileLaunch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { launchKey: string }) => {
    const launchKey = String(input?.launchKey ?? "").trim().slice(0, 64);
    if (!launchKey) throw new Error("Missing launch reference.");
    return { launchKey };
  })
  .handler(async ({ data, context }) => {
    const { reconcileLaunchAttempt } = await import("@/lib/launch-reconcile.server");
    return await reconcileLaunchAttempt(context.userId, data.launchKey);
  });
