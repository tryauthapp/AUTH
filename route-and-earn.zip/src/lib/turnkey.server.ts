/**
 * Turnkey embedded wallets.
 *
 * One primary Solana payout wallet per AUTH account — not one per social
 * platform. A single AUTH user can own many verified identities (X, TikTok,
 * YouTube, Twitch, Instagram) and they all settle into the same wallet.
 * Turnkey holds the key material in secure enclaves — AUTH never sees, stores
 * or displays a private key.
 *
 * The wallet is created only after provider OAuth proves ownership of at least
 * one identity. Until the owner registers their own authenticator, the AUTH
 * API key is the sub-organization's root user so the wallet can receive funds;
 * adding the owner's passkey as a root user hands control to them.
 */

const TURNKEY_BASE_URL = "https://api.turnkey.com";

const SOLANA_ACCOUNT = {
  curve: "CURVE_ED25519",
  pathFormat: "PATH_FORMAT_BIP32",
  path: "m/44'/501'/0'/0'",
  addressFormat: "ADDRESS_FORMAT_SOLANA",
} as const;

export function turnkeyConfigured(): boolean {
  return Boolean(
    process.env["TURNKEY_ORGANIZATION_ID"] &&
      process.env["TURNKEY_API_PUBLIC_KEY"] &&
      process.env["TURNKEY_API_PRIVATE_KEY"],
  );
}

export async function turnkeyApiClient() {
  const organizationId = process.env["TURNKEY_ORGANIZATION_ID"];
  const apiPublicKey = process.env["TURNKEY_API_PUBLIC_KEY"];
  const apiPrivateKey = process.env["TURNKEY_API_PRIVATE_KEY"];
  if (!organizationId || !apiPublicKey || !apiPrivateKey) {
    throw new Error("Turnkey is not configured.");
  }
  const { Turnkey } = await import("@turnkey/sdk-server");
  return new Turnkey({
    apiBaseUrl: TURNKEY_BASE_URL,
    apiPublicKey,
    apiPrivateKey,
    defaultOrganizationId: organizationId,
  }).apiClient();
}

export type EmbeddedWallet = {
  address: string;
  walletId: string;
  subOrganizationId: string;
};

/**
 * Creates the Turnkey sub-organization and Solana wallet for one social
 * identity. Callers must have already verified ownership with the provider.
 */
export async function createTurnkeyWallet(
  provider: string,
  handle: string,
): Promise<EmbeddedWallet> {
  const client = await turnkeyApiClient();
  const apiPublicKey = process.env["TURNKEY_API_PUBLIC_KEY"]!;

  const result = await client.createSubOrganization({
    subOrganizationName: `auth-${provider}-${handle}`.slice(0, 60),
    rootQuorumThreshold: 1,
    rootUsers: [
      {
        userName: `auth-service`,
        apiKeys: [
          {
            apiKeyName: "auth-service-key",
            publicKey: apiPublicKey,
            curveType: "API_KEY_CURVE_P256",
          },
        ],
        authenticators: [],
        oauthProviders: [],
      },
    ],
    wallet: {
      walletName: `${handle} payouts (${provider})`.slice(0, 60),
      accounts: [SOLANA_ACCOUNT],
    },
  });

  const address = result.wallet?.addresses?.[0];
  const walletId = result.wallet?.walletId;
  const subOrganizationId = result.subOrganizationId;
  if (!address || !walletId || !subOrganizationId) {
    throw new Error("Turnkey did not return a Solana wallet address.");
  }
  return { address, walletId, subOrganizationId };
}

/**
 * Returns the AUTH user's single primary embedded Solana payout wallet,
 * creating it on first verified claim.
 *
 * One AUTH account = one primary payout wallet. Every verified social identity
 * that account owns (X, TikTok, YouTube, Twitch, Instagram) routes into this
 * same wallet — AUTH does not mint a separate wallet per platform. Legacy
 * per-identity wallets are adopted as the user's primary instead of being
 * duplicated, so no funds are ever stranded.
 *
 * Never returns key material — only the public Solana address.
 */
export async function ensurePrimaryPayoutWallet(params: {
  provider: string;
  providerUserId: string;
  handle: string;
  userId: string;
  recipientId: string | null;
}): Promise<{ address: string; created: boolean } | { error: string }> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

  // 1. The user already has a primary payout wallet: always reuse it.
  const { data: primary } = await supabaseAdmin
    .from("embedded_wallets")
    .select("address")
    .eq("user_id", params.userId)
    .eq("is_primary", true)
    .maybeSingle();
  if (primary) return { address: primary.address, created: false };

  // 2. Legacy path: a wallet was created per social identity before this
  //    model. Adopt the oldest one as the user's primary rather than
  //    provisioning a second wallet.
  const { data: legacy } = await supabaseAdmin
    .from("embedded_wallets")
    .select("id,address,user_id")
    .or(
      `user_id.eq.${params.userId},and(identity_provider.eq.${params.provider},provider_user_id.eq.${params.providerUserId})`,
    )
    .order("created_at", { ascending: true })
    .limit(1)
    .maybeSingle();

  if (legacy && (!legacy.user_id || legacy.user_id === params.userId)) {
    await supabaseAdmin
      .from("embedded_wallets")
      .update({ user_id: params.userId, is_primary: true, purpose: "user_payout" })
      .eq("id", legacy.id);
    return { address: legacy.address, created: false };
  }
  if (legacy && legacy.user_id !== params.userId) {
    // That identity's wallet belongs to a different AUTH account. Never
    // reassign custody silently.
    return { error: "wallet_conflict" };
  }

  if (!turnkeyConfigured()) return { error: "wallet_unconfigured" };

  let wallet: EmbeddedWallet;
  try {
    wallet = await createTurnkeyWallet("auth", params.userId.slice(0, 8));
  } catch {
    return { error: "wallet_failed" };
  }

  // Legacy column kept populated: plain ID for X, namespaced for others.
  const legacyKey =
    params.provider === "x" ? params.providerUserId : `${params.provider}:${params.providerUserId}`;

  const { error } = await supabaseAdmin.from("embedded_wallets").insert({
    identity_provider: params.provider,
    provider_user_id: params.providerUserId,
    x_user_id: legacyKey,
    handle: params.handle,
    user_id: params.userId,
    recipient_id: params.recipientId,
    provider: "turnkey",
    is_primary: true,
    purpose: "user_payout",
    sub_organization_id: wallet.subOrganizationId,
    wallet_id: wallet.walletId,
    address: wallet.address,
  });
  if (error) return { error: "wallet_failed" };

  return { address: wallet.address, created: true };
}
