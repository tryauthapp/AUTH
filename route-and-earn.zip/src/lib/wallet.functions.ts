import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { ADDRESS_RE } from "@/lib/solana";

/**
 * Wallet ownership proof.
 *
 * The user authorizes a plain-text message with their own account. No transaction is
 * sent, no funds move, and no private key ever leaves the wallet. The server
 * verifies the ed25519 signature against the claimed public key.
 */

export function ownershipMessage(address: string, nonce: string): string {
  return [
    "AUTH wallet verification",
    "",
    `Wallet: ${address}`,
    `Nonce: ${nonce}`,
    "",
    "Signing this message proves you control this wallet.",
    "It does not move any funds and does not approve a transaction.",
  ].join("\n");
}

export const createWalletNonce = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: Record<string, never>) => input)
  .handler(async () => {
    const nonce = `${Date.now().toString(36)}-${crypto.randomUUID()}`;
    return { nonce };
  });

export const verifyWalletOwnership = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (input: {
      address: string;
      signature: string;
      nonce: string;
      provider: string;
      recipientId?: string | null;
    }) => {
      if (!ADDRESS_RE.test(input.address.trim())) throw new Error("Invalid Solana address.");
      if (!input.signature) throw new Error("Missing signature.");
      if (!input.nonce) throw new Error("Missing nonce.");
      return {
        address: input.address.trim(),
        signature: input.signature.trim(),
        nonce: input.nonce,
        provider: input.provider.slice(0, 40),
        recipientId: input.recipientId ?? null,
      };
    },
  )
  .handler(async ({ data, context }) => {
    const { userId } = context;

    const issuedAt = parseInt(data.nonce.split("-")[0] ?? "", 36);
    if (!Number.isFinite(issuedAt) || Date.now() - issuedAt > 10 * 60 * 1000) {
      return { ok: false as const, message: "That verification request expired. Try again." };
    }

    const message = ownershipMessage(data.address, data.nonce);

    const [{ default: nacl }, { default: bs58 }] = await Promise.all([
      import("tweetnacl"),
      import("bs58"),
    ]);

    let valid = false;
    try {
      valid = nacl.sign.detached.verify(
        new TextEncoder().encode(message),
        bs58.decode(data.signature),
        bs58.decode(data.address),
      );
    } catch {
      valid = false;
    }
    if (!valid) return { ok: false as const, message: "That signature does not match the wallet." };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const now = new Date().toISOString();

    // A wallet may only be attached to a username the caller has actually had
    // verified. Without this check a signed-in user could point someone else's
    // handle at their own wallet and intercept incoming payments.
    let recipientId: string | null = null;
    if (data.recipientId) {
      const { data: recipient } = await supabaseAdmin
        .from("recipients")
        .select("id,claimed_by,verification")
        .eq("id", data.recipientId)
        .maybeSingle();
      if (!recipient || recipient.claimed_by !== userId || recipient.verification !== "verified") {
        return {
          ok: false as const,
          message: "You can only link a wallet to a username you have verified.",
        };
      }
      recipientId = recipient.id;
    }


    const { data: existing } = await supabaseAdmin
      .from("wallets")
      .select("id,user_id")
      .eq("address", data.address)
      .maybeSingle();

    if (existing && existing.user_id !== userId) {
      return { ok: false as const, message: "That wallet is already verified by another account." };
    }

    if (existing) {
      await supabaseAdmin
        .from("wallets")
        .update({
          verified_at: now,
          proof_signature: data.signature,
          proof_message: message,
          provider: data.provider,
          ...(recipientId ? { recipient_id: recipientId } : {}),
        })
        .eq("id", existing.id);
    } else {
      await supabaseAdmin.from("wallets").insert({
        user_id: userId,
        recipient_id: recipientId,
        address: data.address,
        chain: "solana",
        provider: data.provider,
        proof_signature: data.signature,
        proof_message: message,
        verified_at: now,
      });
    }

    await supabaseAdmin.from("audit_log").insert({
      actor_id: userId,
      action: "wallet.verified",
      entity: "wallets",
      entity_id: data.address,
      metadata: { provider: data.provider },
    });

    return { ok: true as const, address: data.address, verifiedAt: now };
  });
