/**
 * Evidence shown on the public Turnkey proof page.
 *
 * Every excerpt below is copied verbatim from this project's real Turnkey
 * integration files. Nothing here is illustrative or invented. Only env var
 * NAMES appear — never a value, key, or credential.
 */

export interface TurnkeyEvidenceFile {
  path: string;
  role: string;
  excerpt: string;
}

/** Package declared in this project's package.json dependencies. */
export const TURNKEY_SDK_PACKAGE = "@turnkey/sdk-server";
export const TURNKEY_SDK_DECLARED_RANGE = "^8.5.0";
export const TURNKEY_SDK_NPM_URL = "https://www.npmjs.com/package/@turnkey/sdk-server";

/** Non-secret, public configuration the integration uses. */
export const TURNKEY_PUBLIC_CONFIG: { label: string; value: string; note?: string }[] = [
  { label: "API base URL", value: "https://api.turnkey.com" },
  { label: "Key curve", value: "CURVE_ED25519", note: "Solana signing curve" },
  { label: "Derivation path", value: "m/44'/501'/0'/0'", note: "BIP-32, Solana" },
  { label: "Address format", value: "ADDRESS_FORMAT_SOLANA" },
  { label: "API key curve", value: "API_KEY_CURVE_P256" },
  { label: "Root quorum threshold", value: "1" },
  {
    label: "Server-only credential names",
    value: "TURNKEY_ORGANIZATION_ID, TURNKEY_API_PUBLIC_KEY, TURNKEY_API_PRIVATE_KEY",
    note: "Names only. Values never leave the server and are never logged.",
  },
];

export const TURNKEY_EVIDENCE_FILES: TurnkeyEvidenceFile[] = [
  {
    path: "src/lib/turnkey.server.ts",
    role: "Creates one Turnkey sub-organization and Solana wallet per verified social identity.",
    excerpt: `const TURNKEY_BASE_URL = "https://api.turnkey.com";

const SOLANA_ACCOUNT = {
  curve: "CURVE_ED25519",
  pathFormat: "PATH_FORMAT_BIP32",
  path: "m/44'/501'/0'/0'",
  addressFormat: "ADDRESS_FORMAT_SOLANA",
} as const;

async function turnkeyClient() {
  const organizationId = process.env["TURNKEY_ORGANIZATION_ID"];
  const apiPublicKey = process.env["TURNKEY_API_PUBLIC_KEY"];
  const apiPrivateKey = process.env["TURNKEY_API_PRIVATE_KEY"];
  if (!organizationId || !apiPublicKey || !apiPrivateKey) {
    throw new Error("Turnkey is not configured.");
  }
  const { Turnkey } = await import("@turnkey/sdk-server");
  return new Turnkey({
    apiBaseUrl: TURNKEY_BASE_URL,
    apiPublicKey,
    apiPrivateKey,
    defaultOrganizationId: organizationId,
  }).apiClient();
}`,
  },
  {
    path: "src/lib/turnkey.server.ts",
    role: "Wallet creation. The returned address is public; key material stays inside Turnkey.",
    excerpt: `const result = await client.createSubOrganization({
  subOrganizationName: \`auth-\${provider}-\${handle}\`.slice(0, 60),
  rootQuorumThreshold: 1,
  rootUsers: [
    {
      userName: \`auth-service\`,
      apiKeys: [
        {
          apiKeyName: "auth-service-key",
          publicKey: apiPublicKey,
          curveType: "API_KEY_CURVE_P256",
        },
      ],
      authenticators: [],
      oauthProviders: [],
    },
  ],
  wallet: {
    walletName: \`\${handle} payouts (\${provider})\`.slice(0, 60),
    accounts: [SOLANA_ACCOUNT],
  },
});

const address = result.wallet?.addresses?.[0];
const walletId = result.wallet?.walletId;
const subOrganizationId = result.subOrganizationId;`,
  },
  {
    path: "src/lib/turnkey.server.ts",
    role: "Account binding. One AUTH account gets one primary payout wallet; every verified social identity that account owns routes into it.",
    excerpt: `const { data: primary } = await supabaseAdmin
  .from("embedded_wallets")
  .select("address")
  .eq("user_id", params.userId)
  .eq("is_primary", true)
  .maybeSingle();

if (primary) return { address: primary.address, created: false };

if (!turnkeyConfigured()) return { error: "wallet_unconfigured" };

wallet = await createTurnkeyWallet("auth", params.userId.slice(0, 8));`,
  },
  {
    path: "src/lib/turnkey.functions.ts",
    role: "The live verification call behind the status on this page. Reports non-sensitive facts only.",
    excerpt: `const { Turnkey } = await import("@turnkey/sdk-server");
const client = new Turnkey({
  apiBaseUrl: \`https://\${apiHost}\`,
  apiPublicKey,
  apiPrivateKey,
  defaultOrganizationId: organizationId,
}).apiClient();
const who = await client.getWhoami({ organizationId });
organizationName = who.organizationName ?? null;
reachable = true;`,
  },
];

/**
 * Public source URL for these exact files. Intentionally null: this project has
 * no confirmed public repository. When one exists, set it and the page links
 * each file to its source.
 */
export const PUBLIC_SOURCE_BASE_URL: string | null = null;
