import { createServerFn } from "@tanstack/react-start";

const AUTH_ERA_START = "2026-09-21T12:50:00.000Z";

/**
 * Public, read-only projections of financial tables.
 *
 * The underlying tables (fee_events, payouts, payments, routing_*) are no
 * longer readable by anon/authenticated roles through the Data API. Anything
 * the product shows publicly is served here, column by column, so wallet
 * addresses, signer addresses, sender identity and failure details never leave
 * the server.
 */

const FEE_SELECT =
  "id,tx_signature,gross_usd,protocol_fee_usd,net_usd,sol_amount,occurred_at,source," +
  "token:tokens(id,mint,symbol,name,source),recipient:recipients(id,handle,display_name,avatar_url,provider)";

const PAYOUT_SELECT =
  "id,fee_event_id,recipient_id,destination,label,adapter,amount_usd,status,failure_reason," +
  "created_at,settled_at,tx_signature,network,asset,asset_amount,confirmed_at";

const PAYMENT_SELECT =
  "id,recipient_id,recipient_handle,recipient_provider,asset,amount,amount_usd,note,status,network," +
  "tx_signature,created_at,settled_at";

async function cache() {
  const { cached } = await import("@/lib/server-cache.server");
  return cached;
}

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

export const listPublicFeeEvents = createServerFn({ method: "GET" })
  .inputValidator((input: { limit?: number } | undefined) => ({
    limit: Math.min(Math.max(input?.limit ?? 500, 1), 1000),
  }))
  .handler(async ({ data }) => {
    const cached = await cache();
    return cached(`public:fee-events:${data.limit}`, 20_000, async () => {
    const db = await admin();
    const { data: rows, error } = await db
      .from("fee_events")
      .select(FEE_SELECT)
      .eq("is_demo", false)
      .gte("occurred_at", AUTH_ERA_START)
      .order("occurred_at", { ascending: false })
      .limit(data.limit);
    if (error) throw new Error(error.message);
    return rows ?? [];
    });
  });

export const listPublicPayouts = createServerFn({ method: "GET" }).handler(async () => {
  const cached = await cache();
  return cached("public:payouts", 20_000, async () => {
  const db = await admin();
  const { data: rows, error } = await db
    .from("payouts")
    .select(PAYOUT_SELECT)
    .eq("is_demo", false)
      .gte("created_at", AUTH_ERA_START)
    .order("created_at", { ascending: false })
    .limit(1000);
  if (error) throw new Error(error.message);
  return rows ?? [];
  });
});

export const listPublicPayments = createServerFn({ method: "GET" })
  .inputValidator((input: { limit?: number; handle?: string } | undefined) => ({
    limit: Math.min(Math.max(input?.limit ?? 200, 1), 500),
    handle: typeof input?.handle === "string" ? input.handle.replace(/[^A-Za-z0-9_]/g, "").slice(0, 32) : undefined,
  }))
  .handler(async ({ data }) => {
    const cached = await cache();
    return cached(`public:payments:${data.limit}:${data.handle ?? ""}`, 15_000, async () => {
    const db = await admin();
    let q = db
      .from("payments")
      .select(PAYMENT_SELECT)
      .eq("is_demo", false)
      .gte("created_at", AUTH_ERA_START)
      .order("created_at", { ascending: false })
      .limit(data.limit);
    if (data.handle) q = q.ilike("recipient_handle", data.handle);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
    });
  });

/** Routing shown on public recipient/token pages: percentages only, no addresses. */
export const getPublicRouting = createServerFn({ method: "GET" })
  .inputValidator((input: { recipientId: string }) => ({ recipientId: String(input.recipientId) }))
  .handler(async ({ data }) => {
    const cached = await cache();
    return cached(`public:routing:${data.recipientId}`, 30_000, async () => {
    const db = await admin();
    const { data: row, error } = await db
      .from("routing_configs")
      .select(
        "id,recipient_id,name,is_active,updated_at," +
          "splits:routing_splits(id,config_id,destination,label,percent,charity_id,sort_order)",
      )
      .eq("recipient_id", data.recipientId)
      .eq("is_active", true)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return row ?? null;
    });
  });
