export function usd(value: number | null | undefined, opts?: { compact?: boolean }) {
  const n = Number(value ?? 0);
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    notation: opts?.compact && Math.abs(n) >= 10000 ? "compact" : "standard",
    maximumFractionDigits: Math.abs(n) >= 10000 && opts?.compact ? 1 : 2,
  }).format(n);
}

export function pct(value: number | null | undefined) {
  return `${Number(value ?? 0).toFixed(Number(value ?? 0) % 1 === 0 ? 0 : 2)}%`;
}

export function shortAddress(value: string | null | undefined, size = 4) {
  if (!value) return "—";
  if (value.length <= size * 2 + 3) return value;
  return `${value.slice(0, size)}…${value.slice(-size)}`;
}

export function timeAgo(iso: string | null | undefined) {
  if (!iso) return "—";
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.round(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  if (days < 30) return `${days}d ago`;
  return new Date(iso).toLocaleDateString();
}

export function explorerTx(signature: string) {
  return `https://solscan.io/tx/${signature}`;
}

export function explorerAddress(address: string) {
  return `https://solscan.io/account/${address}`;
}

export const DESTINATION_LABELS: Record<string, string> = {
  sol: "SOL",
  usdc: "USDC",
  wallet_withdrawal: "Wallet withdrawal",
  x_money: "X Money",
  buyback: "Token buyback",
  burn: "Burn",
  charity: "Charity",
  split_recipient: "Split recipient",
};
