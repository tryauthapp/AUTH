/**
 * Minimal client-side error reporting.
 *
 * Logs unexpected UI errors to the console. Swap the body of `reportError`
 * for your own monitoring provider (Sentry, Highlight, etc.) if you want
 * errors forwarded off-device.
 */
export function reportError(error: unknown, context: Record<string, unknown> = {}) {
  if (typeof window === "undefined") return;
  // eslint-disable-next-line no-console
  console.error("[crypto] unhandled error", error, {
    route: window.location.pathname,
    ...context,
  });
}
