import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Reads the caller's primary embedded Solana payout wallet.
 *
 * One AUTH account has exactly one primary payout wallet; every verified
 * social identity on that account settles into it. Only the public address is
 * ever returned — key material stays inside Turnkey and is never exposed.
 */
export const getMyEmbeddedWallet = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase
      .from("embedded_wallets")
      .select("address,handle,provider,created_at,is_primary")
      .eq("user_id", context.userId)
      .order("is_primary", { ascending: false })
      .order("created_at", { ascending: true })
      .limit(1)
      .maybeSingle();
    return data ?? null;
  });
