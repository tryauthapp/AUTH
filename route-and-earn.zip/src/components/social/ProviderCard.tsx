import { ArrowUpRight, Check } from "lucide-react";
import type { SocialProvider } from "@/lib/social/providers";
import { ProviderIcon, providerTint } from "@/components/social/ProviderIcon";
import { cn } from "@/lib/utils";

/**
 * Status pill. "Active" is the product-facing state for supported platforms.
 */
export function ProviderStatus({
  live,
  soon = false,
  className,
}: {
  live: boolean;
  /** Part of the product, not connected yet — shown as "Coming soon". */
  soon?: boolean;
  className?: string;
}) {
  if (!live && soon) {
    return (
      <span
        className={cn(
          "inline-flex max-w-full items-center rounded-full bg-muted px-1.5 py-0.5 text-center font-mono text-[9px] font-medium uppercase leading-tight tracking-[0.04em] text-muted-foreground",
          className,
        )}
      >
        Coming soon
      </span>
    );
  }
  if (live) {
    return (
      <span
        className={cn(
          "inline-flex items-center gap-1.5 rounded-full bg-success/12 px-2 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-[0.14em] text-success",
          className,
        )}
      >
        <span className="live-dot relative inline-block size-1.5 rounded-full bg-success" />
        Active
      </span>
    );
  }
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center whitespace-nowrap rounded-full bg-muted px-2 py-0.5 font-mono text-[10px] font-medium uppercase tracking-[0.12em] text-muted-foreground",
        className,
      )}
    >
      Inactive
    </span>
  );
}

/**
 * Polished platform card. Same size for every provider; platform colour comes
 * from the logo and a restrained tint, never from a loud fill.
 */
export function ProviderCard({
  provider,
  label,
  live,
  soon = false,
  selected = false,
  onSelect,
  href,
  className,
}: {
  provider: SocialProvider;
  label: string;
  live: boolean;
  /** Show "Coming soon" instead of "Inactive" when not live. */
  soon?: boolean;
  selected?: boolean;
  onSelect?: () => void;
  /** Official platform URL, used when the card isn't a selector. */
  href?: string;
  className?: string;
}) {
  const asButton = Boolean(onSelect);
  const asLink = !asButton && Boolean(href);
  const interactive = asButton || asLink;
  const Tag = asButton ? "button" : asLink ? "a" : "div";

  return (
    <Tag
      {...(asButton
        ? { type: "button" as const, onClick: onSelect, "aria-pressed": selected }
        : {})}
      {...(asLink
        ? {
            href,
            target: "_blank",
            rel: "noopener noreferrer external",
            "aria-label": `Open ${label} (opens in a new tab)`,
          }
        : {})}
      style={providerTint(provider)}
      className={cn(
        "group relative flex h-full min-h-[86px] w-full flex-col justify-between rounded-2xl border bg-card p-3.5 text-left transition-all duration-200",
        interactive && "press hover:-translate-y-0.5 hover:shadow-[0_18px_36px_-28px_rgb(0_0_0/0.55)]",
        selected
          ? "platform-tint border-2 shadow-[0_18px_36px_-30px_rgb(0_0_0/0.55)]"
          : "border-border hover:platform-tint",
        className,
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <span
          className="grid size-9 shrink-0 place-items-center rounded-xl border border-border/70 bg-background transition-colors group-hover:border-transparent"
          style={providerTint(provider)}
        >
          <ProviderIcon provider={provider} brand className="size-5" />
        </span>
        {asLink ? (
          <ArrowUpRight className="size-4 shrink-0 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
        ) : null}
        {selected ? (
          <span className="grid size-5 place-items-center rounded-full bg-success text-success-foreground">
            <Check className="size-3" />
          </span>
        ) : null}
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-x-2 gap-y-1">
        <span className="text-sm font-semibold tracking-tight">{label}</span>
        <ProviderStatus live={live} soon={soon} />
      </div>
    </Tag>
  );
}
