import { SOCIAL_PROVIDERS, type SocialProvider } from "@/lib/social/providers";
import { ProviderIcon, providerTint } from "@/components/social/ProviderIcon";
import { cn } from "@/lib/utils";

/**
 * The single platform selector used by Pay, Launch and Explore.
 *
 * Each chip carries the platform's real mark and its own brand colour. The
 * selected chip tints its surface and border with that colour so the active
 * platform is unmistakable; unselected chips stay quiet greyscale so the row
 * still reads as one clean control rather than five competing logos.
 */
export function PlatformChip({
  provider,
  active,
  onSelect,
  comingSoon = false,
  className,
}: {
  provider: SocialProvider;
  active?: boolean;
  onSelect?: (p: SocialProvider) => void;
  /** Renders a polished, non-interactive roadmap state. */
  comingSoon?: boolean;
  className?: string;
}) {
  const meta = SOCIAL_PROVIDERS.find((p) => p.id === provider)!;
  return (
    <button
      type="button"
      disabled={comingSoon}
      aria-pressed={active}
      onClick={() => onSelect?.(provider)}
      style={providerTint(provider)}
      className={cn(
        "press inline-flex shrink-0 items-center gap-2 rounded-full border px-3 py-1.5 text-sm font-medium transition-colors",
        active
          ? "platform-tint border-2 font-semibold text-foreground"
          : comingSoon
            ? "cursor-default border-dashed border-border bg-surface text-muted-foreground opacity-80"
            : "border-border text-muted-foreground hover:bg-secondary hover:text-foreground",
        className,
      )}
    >
      <ProviderIcon provider={provider} brand={active || comingSoon} className={cn(comingSoon && "opacity-70")} />
      {/* The X mark already reads as the word, so repeating the label would double it. */}
      <span className={cn(provider === "x" && "sr-only")}>{meta.label}</span>
      {comingSoon ? (
        <span className="rounded-full bg-secondary px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide">
          Soon
        </span>
      ) : null}
    </button>
  );
}

/** Row of all five platform chips. Scrolls horizontally on phones. */
export function PlatformChips({
  value,
  onChange,
  className,
}: {
  value: SocialProvider;
  onChange: (p: SocialProvider) => void;
  className?: string;
}) {
  return (
    <div className={cn("chip-row", className)} role="group" aria-label="Platform">
      {SOCIAL_PROVIDERS.map((p) => (
        <PlatformChip key={p.id} provider={p.id} active={p.id === value} onSelect={onChange} />
      ))}
    </div>
  );
}
