import { cn } from "@/lib/utils";
import { IdentityAvatar } from "@/components/Avatar";
import { ProviderIcon, providerTint } from "@/components/social/ProviderIcon";
import { SOCIAL_PROVIDERS, type SocialProvider } from "@/lib/social/providers";

const AVATAR_SIZES = { sm: "sm", md: "md", lg: "lg", xl: "xl" } as const;
const BADGE_SIZES = {
  sm: "size-3.5 -bottom-0.5 -right-0.5",
  md: "size-4 -bottom-0.5 -right-0.5",
  lg: "size-5 -bottom-1 -right-1",
  xl: "size-7 -bottom-1 -right-1",
} as const;

/**
 * Avatar with the platform mark pinned to its corner.
 *
 * Every identity in AUTH is a social account, so the avatar always carries the
 * platform it came from. When no profile picture is available the avatar falls
 * back to stable initials rather than a faceless icon.
 */
export function SocialAvatar({
  provider,
  handle,
  avatarUrl,
  size = "md",
  className,
}: {
  provider: SocialProvider;
  handle: string;
  avatarUrl?: string | null | undefined;
  size?: keyof typeof AVATAR_SIZES;
  className?: string;
}) {
  return (
    <span className={cn("relative inline-flex shrink-0", className)}>
      <IdentityAvatar handle={handle} src={avatarUrl ?? null} size={AVATAR_SIZES[size]} />
      <span
        style={providerTint(provider)}
        className={cn(
          "absolute grid place-items-center rounded-full border border-border bg-background p-[3px]",
          BADGE_SIZES[size],
        )}
      >
        <ProviderIcon provider={provider} brand className="size-full" />
      </span>
    </span>
  );
}

/**
 * Avatar + display name + handle + platform, the standard identity row used in
 * feeds, tables, selectors and search results.
 */
export function SocialIdentity({
  provider,
  handle,
  displayName,
  avatarUrl,
  size = "md",
  meta,
  className,
}: {
  provider: SocialProvider;
  handle: string;
  displayName?: string | null;
  avatarUrl?: string | null | undefined;
  size?: keyof typeof AVATAR_SIZES;
  /** Extra trailing detail, e.g. follower count or a timestamp. */
  meta?: React.ReactNode;
  className?: string;
}) {
  const label = SOCIAL_PROVIDERS.find((p) => p.id === provider)?.label ?? provider;
  return (
    <span className={cn("flex min-w-0 items-center gap-3", className)}>
      <SocialAvatar provider={provider} handle={handle} avatarUrl={avatarUrl ?? null} size={size} />
      <span className="min-w-0">
        <span className="block truncate font-semibold leading-tight">
          {displayName || `@${handle}`}
        </span>
        <span className="flex min-w-0 items-center gap-1.5 text-sm text-muted-foreground">
          <span className="truncate">@{handle}</span>
          <span aria-hidden>·</span>
          <span className="truncate">{label}</span>
          {meta ? (
            <>
              <span aria-hidden>·</span>
              <span className="truncate">{meta}</span>
            </>
          ) : null}
        </span>
      </span>
    </span>
  );
}
