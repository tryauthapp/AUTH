import { SOCIAL_PROVIDERS, type SocialProvider } from "@/lib/social/providers";
import { cn } from "@/lib/utils";

/**
 * Platform marks.
 *
 * Each mark is drawn as a real SVG path (never a text placeholder). By default
 * a mark inherits `currentColor`; pass `brand` to render it in the platform's
 * own colours, which are defined as design tokens so both themes stay legible.
 */

function XMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor" className={className}>
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231ZM17.083 19.77h1.833L7.084 4.126H5.117Z" />
    </svg>
  );
}

const TIKTOK_PATH =
  "M16.6 5.82A4.28 4.28 0 0 1 15.54 3h-3.1v12.4a2.59 2.59 0 1 1-1.84-2.48V9.74a5.74 5.74 0 1 0 4.94 5.68V9.01a7.35 7.35 0 0 0 4.3 1.38V7.29a4.3 4.3 0 0 1-3.24-1.47Z";

function TikTokMark({ className, brand }: { className?: string; brand?: boolean }) {
  if (!brand) {
    return (
      <svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor" className={className}>
        <path d={TIKTOK_PATH} />
      </svg>
    );
  }
  // The offset cyan/magenta ghosts are TikTok's own split-channel treatment.
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className={className}>
      <path d={TIKTOK_PATH} transform="translate(-0.9 0.7)" fill="var(--color-platform-tiktok)" />
      <path
        d={TIKTOK_PATH}
        transform="translate(0.9 -0.7)"
        fill="var(--color-platform-tiktok-alt)"
      />
      <path d={TIKTOK_PATH} fill="var(--color-platform-x)" />
    </svg>
  );
}

function YouTubeMark({ className, brand }: { className?: string; brand?: boolean }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className={className}>
      <path
        fill={brand ? "var(--color-platform-youtube)" : "currentColor"}
        d="M23.5 6.9a3.02 3.02 0 0 0-2.12-2.14C19.5 4.25 12 4.25 12 4.25s-7.5 0-9.38.51A3.02 3.02 0 0 0 .5 6.9C0 8.79 0 12 0 12s0 3.21.5 5.1a3.02 3.02 0 0 0 2.12 2.14c1.88.51 9.38.51 9.38.51s7.5 0 9.38-.51a3.02 3.02 0 0 0 2.12-2.14C24 15.21 24 12 24 12s0-3.21-.5-5.1Z"
      />
      <path fill={brand ? "#fff" : "var(--color-background)"} d="M9.6 15.57V8.43L15.82 12 9.6 15.57Z" />
    </svg>
  );
}

function TwitchMark({ className, brand }: { className?: string; brand?: boolean }) {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      fill={brand ? "var(--color-platform-twitch)" : "currentColor"}
      className={className}
    >
      <path d="M4.3 1.5 2 6.1V20h5v3h3l2.6-3h4.1l5.3-5.3V1.5H4.3Zm15.5 12.1L17 16.4H12l-2.6 2.6v-2.6H5.5V3.4h14.3v10.2Z" />
      <path d="M13.5 6.9h1.9v5.2h-1.9zM8.7 6.9h1.9v5.2H8.7z" />
    </svg>
  );
}

function InstagramMark({ className, brand }: { className?: string; brand?: boolean }) {
  // Instagram's identity is its gradient, so the branded mark strokes the glyph
  // with the real amber → magenta → violet ramp instead of one flat colour.
  const stroke = brand ? "url(#auth-ig-gradient)" : "currentColor";
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" strokeWidth="1.9" className={className}>
      {brand ? (
        <defs>
          <linearGradient id="auth-ig-gradient" x1="2" y1="22" x2="22" y2="2">
            <stop offset="0%" stopColor="#FEDA75" />
            <stop offset="35%" stopColor="#FA7E1E" />
            <stop offset="65%" stopColor="#D62976" />
            <stop offset="100%" stopColor="#962FBF" />
          </linearGradient>
        </defs>
      ) : null}
      <rect x="2.6" y="2.6" width="18.8" height="18.8" rx="5.4" stroke={stroke} />
      <circle cx="12" cy="12" r="4.4" stroke={stroke} />
      <circle cx="17.4" cy="6.6" r="1.1" fill={brand ? "#D62976" : "currentColor"} stroke="none" />
    </svg>
  );
}

export function ProviderIcon({
  provider,
  className,
  brand = false,
}: {
  provider: SocialProvider;
  className?: string;
  /** Render in the platform's own colours instead of inheriting currentColor. */
  brand?: boolean;
}) {
  const cls = cn("size-4", className);
  switch (provider) {
    case "x":
      return <XMark className={cn(cls, brand && "text-platform-x")} />;
    case "tiktok":
      return <TikTokMark className={cls} brand={brand} />;
    case "youtube":
      return <YouTubeMark className={cls} brand={brand} />;
    case "twitch":
      return <TwitchMark className={cls} brand={brand} />;
    case "instagram":
      return <InstagramMark className={cls} brand={brand} />;
  }
}

/** CSS custom property that drives platform-tinted surfaces. */
export function providerTint(provider: SocialProvider): React.CSSProperties {
  const map: Record<SocialProvider, string> = {
    x: "var(--color-platform-x)",
    tiktok: "var(--color-platform-tiktok-alt)",
    youtube: "var(--color-platform-youtube)",
    twitch: "var(--color-platform-twitch)",
    instagram: "var(--color-platform-instagram)",
  };
  return { ["--platform-color" as string]: map[provider] };
}

/**
 * Narrows a stored provider string to a known platform. Legacy rows predate
 * multi-platform identities, so an unknown or missing value means X.
 */
export function asProvider(value: string | null | undefined): SocialProvider {
  return SOCIAL_PROVIDERS.some((p) => p.id === value) ? (value as SocialProvider) : "x";
}
