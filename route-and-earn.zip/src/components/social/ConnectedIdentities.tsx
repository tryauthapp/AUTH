import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { BadgeCheck, ExternalLink } from "lucide-react";
import {
  disconnectSocialIdentity,
  myConnectedIdentities,
} from "@/lib/social-auth.functions";
import { providerMeta } from "@/lib/social/providers";
import { ProviderIcon, providerTint } from "@/components/social/ProviderIcon";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/primitives";
import { useSession } from "@/hooks/useSession";
import { socialProfileUrl } from "@/lib/external-links";

/** Connected identities on the AUTH profile/settings surface. */
export function ConnectedIdentities() {
  const { session } = useSession();
  const queryClient = useQueryClient();
  const load = useServerFn(myConnectedIdentities);
  const disconnect = useServerFn(disconnectSocialIdentity);

  const identities = useQuery({
    queryKey: ["connected-identities", session?.user.id],
    enabled: Boolean(session),
    queryFn: () => load(),
  });

  const rows = identities.data ?? [];

  async function remove(id: string) {
    try {
      const res = await disconnect({ data: { identityId: id } });
      if (!res.ok) {
        toast.error(res.message);
        return;
      }
      toast.success(res.message);
      void queryClient.invalidateQueries({ queryKey: ["connected-identities"] });
      void queryClient.invalidateQueries({ queryKey: ["identity-state"] });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not disconnect.");
    }
  }

  if (!session) return null;

  return (
    <section className="panel p-4 sm:p-5">
      <h2 className="text-base font-semibold">Connected identities</h2>
      <p className="mt-1 text-xs text-muted-foreground">
        Each verified identity is stored by the platform&apos;s permanent ID, so renaming your
        handle never breaks payments.
      </p>

      <div className="mt-4 space-y-2">
        {rows.length === 0 ? (
          <EmptyState
            title="No identities connected yet"
            description="Verify ownership of an account or channel to turn it into a payment identity."
          />
        ) : (
          rows.map((row) => {
            const meta = providerMeta(row.provider);
            // Only ever an official platform URL built from the verified handle.
            const safeUrl = socialProfileUrl(row.provider, row.handle);
            return (
              <div
                key={row.id}
                className="flex flex-wrap items-center gap-3 rounded-xl border border-success/30 bg-success/5 px-3 py-2.5"
              >
                <span
                  className="platform-tint grid size-9 shrink-0 place-items-center rounded-xl border"
                  style={providerTint(row.provider)}
                >
                  <ProviderIcon provider={row.provider} brand className="size-4.5" />
                </span>
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">
                    {safeUrl ? (
                      <a
                        href={safeUrl}
                        target="_blank"
                        rel="noopener noreferrer external"
                        className="hover:underline"
                      >
                        {meta?.handlePrefix ?? "@"}
                        {row.handle}
                      </a>
                    ) : (
                      <>
                        {meta?.handlePrefix ?? "@"}
                        {row.handle}
                      </>
                    )}
                  </p>
                  <p className="text-[11px] text-muted-foreground">
                    {meta?.label} · connected {new Date(row.verifiedAt).toLocaleDateString()}
                  </p>
                </div>
                <span className="inline-flex items-center gap-1 rounded-full bg-success/10 px-2 py-0.5 text-[11px] font-medium text-success">
                  <BadgeCheck className="size-3.5" /> Verified
                </span>
                <div className="ml-auto flex items-center gap-2">
                  {safeUrl ? (
                    <a
                      href={safeUrl}
                      target="_blank"
                      rel="noopener noreferrer external"
                      className="text-muted-foreground hover:text-foreground"
                      aria-label={`Open ${row.handle} on ${meta?.label}`}
                    >
                      <ExternalLink className="size-4" />
                    </a>
                  ) : null}
                  <Button
                    size="sm"
                    variant="outline"
                    className="press rounded-full"
                    onClick={() => void remove(row.id)}
                  >
                    Disconnect
                  </Button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </section>
  );
}
