import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { ExternalLink } from "lucide-react";
import { socialProviderStatus, startSocialLink } from "@/lib/social-auth.functions";
import { startHandleClaim } from "@/lib/identity.functions";
import type { SocialProvider } from "@/lib/social/providers";
import { ProviderCard } from "@/components/social/ProviderCard";
import { ProviderIcon, providerTint } from "@/components/social/ProviderIcon";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

/**
 * "Claim with" — pick a platform, enter the identity, prove ownership.
 *
 * Providers without server-side credentials are shown as not configured rather
 * than offering a button that cannot work. Nothing here fakes a login.
 */
export function ConnectIdentity({
  initialHandle = "",
  onClaimStarted,
}: {
  initialHandle?: string;
  onClaimStarted?: () => void;
}) {
  const statuses = useQuery({
    queryKey: ["social-provider-status"],
    queryFn: () => socialProviderStatus(),
  });
  const startClaim = useServerFn(startHandleClaim);
  const startLink = useServerFn(startSocialLink);

  const [provider, setProvider] = useState<SocialProvider>("x");
  const [handle, setHandle] = useState(initialHandle);
  const [busy, setBusy] = useState(false);

  const list = statuses.data ?? [];
  const active = list.find((p) => p.id === provider);

  async function verify() {
    if (!active?.configured) return;
    setBusy(true);
    try {
      // Reserve the payment identity, then hand off to the provider.
      const claim = await startClaim({ data: { handle } });
      if (!claim.ok || !claim.handle) {
        toast.error(claim.message ?? "Could not start that claim.");
        return;
      }
      onClaimStarted?.();
      const res = await startLink({ data: { provider, handle: claim.handle } });
      if (!res.ok || !res.url) {
        toast.error(res.message ?? `${active.label} verification is unavailable.`);
        return;
      }
      window.location.assign(res.url);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not start verification.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        {list.map((p) => (
          <ProviderCard
            key={p.id}
            provider={p.id}
            label={p.label}
            live={p.configured}
            selected={p.id === provider}
            onSelect={() => setProvider(p.id)}
          />
        ))}
      </div>

      <div className="mt-3 grid gap-2 sm:grid-cols-[minmax(0,1fr)_auto]">
        <div className="relative">
          <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
            {active?.handlePrefix ?? "@"}
          </span>
          <span
            className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2"
            style={active ? providerTint(active.id) : undefined}
            aria-hidden="true"
          >
            {active ? <ProviderIcon provider={active.id} brand className="size-4" /> : null}
          </span>
          <Input
            value={handle}
            onChange={(e) => setHandle(e.target.value)}
            placeholder={active?.identityNoun === "channel" ? "yourchannel" : "username"}
            autoCapitalize="none"
            spellCheck={false}
            className="h-11 rounded-md pl-7 pr-10"
          />
        </div>
        <Button
          className="press h-11 rounded-md"
          onClick={verify}
          disabled={busy || !handle.trim() || !active?.configured}
        >
          <ExternalLink className="size-4" />
          {busy ? "Opening…" : `Verify with ${active?.label ?? ""}`}
        </Button>
      </div>

      <p className="mt-2 text-xs text-muted-foreground">
        {active?.handleHint} AUTH checks the {active?.label} {active?.identityNoun} you authorize
        matches the one you entered, and stores the platform's permanent ID — not the handle.
      </p>

      {active && !active.configured ? (
        <p className="mt-2 text-xs text-warning">
          {active.label} verification isn&apos;t configured on this deployment yet.
        </p>
      ) : null}
    </div>
  );
}
