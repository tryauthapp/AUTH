import { useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { AtSign, CheckCircle2, Info, Loader2 } from "lucide-react";
import {
  resolvePlatformIdentity,
  type ResolvedIdentity,
} from "@/lib/platform-identity.functions";
import { SOCIAL_PROVIDERS, type SocialProvider } from "@/lib/social/providers";
import { ProviderIcon, providerTint } from "@/components/social/ProviderIcon";
import { SocialAvatar } from "@/components/social/SocialIdentity";
import { PlatformChips } from "@/components/social/PlatformChips";
import { Input } from "@/components/ui/input";
import { StatusPill } from "@/components/primitives";
import { cn } from "@/lib/utils";

/**
 * Platform + handle entry shared by Pay and Launch.
 *
 * The preview only ever shows what a platform API actually returned. When a
 * platform cannot resolve a handle — no credentials, no public lookup, or an
 * account type the platform refuses to disclose — the reason is stated and the
 * handle is still usable: AUTH routes to the canonical platform identity and
 * the profile fills in when its owner verifies ownership.
 */
export function PlatformIdentityPicker({
  provider,
  onProviderChange,
  handle,
  onHandleChange,
  onResolved,
  label = "Recipient",
}: {
  provider: SocialProvider;
  onProviderChange: (p: SocialProvider) => void;
  handle: string;
  onHandleChange: (h: string) => void;
  onResolved?: (r: ResolvedIdentity | null) => void;
  label?: string;
}) {
  const resolve = useServerFn(resolvePlatformIdentity);
  const [checking, setChecking] = useState(false);
  const [resolved, setResolved] = useState<ResolvedIdentity | null>(null);

  const meta = useMemo(
    () => SOCIAL_PROVIDERS.find((p) => p.id === provider)!,
    [provider],
  );
  const clean = handle.trim().replace(/^@/, "");
  const valid = meta.handlePattern.test(clean);

  useEffect(() => {
    if (!valid) {
      setResolved(null);
      onResolved?.(null);
      return;
    }
    let active = true;
    setChecking(true);
    const t = setTimeout(async () => {
      try {
        const res = await resolve({ data: { provider, handle: clean } });
        if (!active) return;
        setResolved(res);
        onResolved?.(res);
      } catch {
        if (!active) return;
        setResolved(null);
        onResolved?.(null);
      } finally {
        if (active) setChecking(false);
      }
    }, 400);
    return () => {
      active = false;
      clearTimeout(t);
      setChecking(false);
    };
    // onResolved is a render-stable callback in every call site.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [provider, clean, valid, resolve]);

  const profile = resolved?.profile ?? null;
  const record = resolved?.record ?? null;

  return (
    <div>
      <span className="mb-2 block text-sm font-semibold">{label}</span>

      <PlatformChips value={provider} onChange={onProviderChange} />

      <span className="mt-3 block text-xs font-semibold text-muted-foreground">
        {meta.handleLabel}
      </span>
      <div className="relative mt-1.5" style={providerTint(provider)}>
        <span className="pointer-events-none absolute left-3 top-1/2 flex -translate-y-1/2 items-center gap-1.5 text-muted-foreground">
          <ProviderIcon provider={provider} brand />
          <AtSign className="size-3.5" />
        </span>
        <Input
          value={handle}
          onChange={(e) => onHandleChange(e.target.value)}
          placeholder={meta.handlePlaceholder}
          autoCapitalize="none"
          autoCorrect="off"
          spellCheck={false}
          className="field h-11 rounded-md pl-[3.75rem] text-sm"
        />
      </div>

      <div className="mt-2 min-h-[20px] text-xs">
        {checking ? (
          <span className="inline-flex items-center gap-1.5 text-muted-foreground">
            <Loader2 className="size-3 animate-spin" /> Checking {meta.handlePrefix}
            {clean} on {meta.label}…
          </span>
        ) : !clean ? (
          <span className="text-muted-foreground">{meta.handleHint}</span>
        ) : !valid ? (
          <span className="text-muted-foreground">{meta.handleHint}</span>
        ) : null}
      </div>

      {profile ? (
        <div
          style={providerTint(provider)}
          className="platform-tint mt-2 flex items-start gap-3 rounded-xl border p-3"
        >
          <SocialAvatar
            provider={provider}
            handle={profile.handle}
            avatarUrl={profile.avatarUrl}
          />
          <span className="min-w-0 flex-1">
            <span className="flex flex-wrap items-center gap-2">
              <span className="font-semibold">{profile.displayName ?? profile.handle}</span>
              <CheckCircle2 className="size-4 text-success" />
            </span>
            <span className="block truncate text-xs text-muted-foreground">
              {meta.handlePrefix}
              {profile.handle} · {meta.label}
              {profile.followerCount !== null
                ? ` · ${profile.followerCount.toLocaleString()} followers`
                : ""}
            </span>
            <span className="mt-1 flex flex-wrap items-center gap-2">
              <StatusPill status={record?.payable ? "verified" : "pending"}>
                {record?.payable ? "Payable now" : "Not claimed yet"}
              </StatusPill>
            </span>
          </span>
        </div>
      ) : resolved && clean ? (
        <p className="mt-2 flex items-start gap-2 rounded-lg border border-border bg-secondary/50 p-3 text-xs text-muted-foreground">
          <Info className="mt-0.5 size-3.5 shrink-0" />
          <span>
            {resolved.lookupMessage ??
              `${meta.label} did not return a profile for this username.`}{" "}
            {record?.payable
              ? "AUTH already has a verified payout wallet for this identity."
              : `Funds are held against the ${meta.label} identity until its owner verifies ownership.`}
          </span>
        </p>
      ) : null}
    </div>
  );
}
