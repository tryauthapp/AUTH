import { SocialAvatar } from "@/components/social/SocialIdentity";
import { asProvider } from "@/components/social/ProviderIcon";
import { Link } from "@tanstack/react-router";
import { ExternalLink } from "lucide-react";
import type { FeeEventRow, PayoutRow } from "@/lib/queries";
import { explorerTx, shortAddress, timeAgo, usd, DESTINATION_LABELS } from "@/lib/format";
import { StatusPill } from "@/components/primitives";

function statusTone(status: string) {
  if (status === "paid" || status === "claimed") return "paid" as const;
  if (status === "claimable") return "claimable" as const;
  if (status === "failed" || status === "cancelled") return "failed" as const;
  return "pending" as const;
}

export function PayoutStatusPill({ status }: { status: string }) {
  return <StatusPill status={statusTone(status)}>{status}</StatusPill>;
}

export function LedgerTable({
  events,
  payouts,
  showRecipient = true,
  showToken = true,
}: {
  events: FeeEventRow[];
  payouts: PayoutRow[];
  showRecipient?: boolean;
  showToken?: boolean;
}) {
  const payoutsByEvent = new Map<string, PayoutRow[]>();
  for (const p of payouts) {
    const list = payoutsByEvent.get(p.fee_event_id) ?? [];
    list.push(p);
    payoutsByEvent.set(p.fee_event_id, list);
  }

  return (
    <div className="panel scroll-x overflow-x-auto">
      <table className="w-full min-w-[760px] text-xs">
        <thead>
          <tr className="border-b border-border text-left text-[11px] uppercase tracking-widest text-muted-foreground">
            <th className="px-3 py-2.5 font-medium">When</th>
            {showToken ? <th className="px-3 py-2.5 font-medium">Token</th> : null}
            {showRecipient ? <th className="px-3 py-2.5 font-medium">Recipient</th> : null}
            <th className="px-4 py-3 text-right font-medium">Gross</th>
            <th className="px-4 py-3 text-right font-medium">Protocol</th>
            <th className="px-4 py-3 text-right font-medium">Net</th>
            <th className="px-4 py-3 font-medium">Payouts</th>
            <th className="px-4 py-3 font-medium">Tx</th>
          </tr>
        </thead>
        <tbody>
          {events.map((e) => {
            const eventPayouts = payoutsByEvent.get(e.id) ?? [];
            return (
              <tr key={e.id} className="border-b border-border/60 last:border-0 hover:bg-secondary/40">
                <td className="whitespace-nowrap px-4 py-3 text-muted-foreground">
                  {timeAgo(e.occurred_at)}
                </td>
                {showToken ? (
                  <td className="px-4 py-3">
                    {e.token ? (
                      <Link
                        to="/t/$mint"
                        params={{ mint: e.token.mint }}
                        className="font-medium hover:text-foreground"
                      >
                        ${e.token.symbol}
                      </Link>
                    ) : (
                      "—"
                    )}
                  </td>
                ) : null}
                {showRecipient ? (
                  <td className="px-4 py-3">
                    {e.recipient ? (
                      <Link
                        to="/u/$handle"
                        params={{ handle: e.recipient.handle }}
                        className="inline-flex items-center gap-2 hover:text-foreground"
                      >
                        <SocialAvatar
                          provider={asProvider(e.recipient.provider)}
                          handle={e.recipient.handle}
                          avatarUrl={e.recipient.avatar_url}
                          size="sm"
                        />
                        <span className="truncate">@{e.recipient.handle}</span>
                      </Link>
                    ) : (
                      "—"
                    )}
                  </td>
                ) : null}
                <td className="num px-4 py-3 text-right">{usd(e.gross_usd)}</td>
                <td className="num px-4 py-3 text-right text-muted-foreground">
                  −{usd(e.protocol_fee_usd)}
                </td>
                <td className="num px-4 py-3 text-right font-medium text-success">{usd(e.net_usd)}</td>
                <td className="px-4 py-3">
                  <div className="flex flex-wrap gap-1">
                    {eventPayouts.length === 0 ? (
                      <span className="text-xs text-muted-foreground">No payout rows</span>
                    ) : (
                      eventPayouts.map((p) => (
                        <span
                          key={p.id}
                          title={p.failure_reason ?? undefined}
                          className="inline-flex items-center gap-1 rounded border border-border px-1.5 py-0.5 text-[11px]"
                        >
                          {DESTINATION_LABELS[p.destination] ?? p.destination}
                          <PayoutStatusPill status={p.status} />
                          {p.tx_signature ? (
                            <a
                              href={explorerTx(p.tx_signature)}
                              target="_blank"
                              rel="noreferrer noopener"
                              className="num inline-flex items-center gap-0.5 text-info hover:underline"
                              title="Settlement transaction"
                            >
                              {shortAddress(p.tx_signature, 4)}
                              <ExternalLink className="size-2.5" />
                            </a>
                          ) : null}
                        </span>
                      ))
                    )}
                  </div>
                </td>
                <td className="px-4 py-3">
                  <a
                    href={explorerTx(e.tx_signature)}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="num inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
                  >
                    {shortAddress(e.tx_signature, 5)}
                    <ExternalLink className="size-3" />
                  </a>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
