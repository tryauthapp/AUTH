import type { ButtonHTMLAttributes, ReactNode } from "react";
import { Inbox } from "lucide-react";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";

/**
 * Standard page container. Every route renders inside one of these so the
 * gutters, max width and vertical rhythm are identical on phone, tablet and
 * desktop — only the spacing scale changes with the breakpoint.
 */
export function PageShell({
  children,
  width = "wide",
  className,
}: {
  children: ReactNode;
  /** "wide" for dashboards and lists, "narrow" for forms and reading pages. */
  width?: "wide" | "narrow";
  className?: string;
}) {
  return (
    <div
      className={cn(
        width === "narrow" ? "page-shell-narrow" : "page-shell",
        "page-enter",
        className,
      )}
    >
      {children}
    </div>
  );
}

/**
 * Standard page header: fluid title, one-line lede, optional trailing action.
 * Uses the grid/flex pattern so a long title truncates instead of shoving the
 * action off-screen on narrow devices.
 */
export function PageHeader({
  title,
  description,
  action,
  eyebrow,
  className,
}: {
  title: ReactNode;
  description?: ReactNode;
  action?: ReactNode;
  eyebrow?: ReactNode;
  className?: string;
}) {
  return (
    <header
      className={cn(
        "mb-5 grid gap-3 sm:mb-6 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end sm:gap-4",
        className,
      )}
    >
      <div className="min-w-0">
        {eyebrow ? <div className="workspace-label mb-2">{eyebrow}</div> : null}
        <h1 className="page-title">{title}</h1>
        {description ? <p className="page-lede mt-2">{description}</p> : null}
      </div>
      {action ? <div className="flex flex-wrap items-center gap-2">{action}</div> : null}
    </header>
  );
}

/** One chip style for every filter, platform selector and toggle in the app. */
export function Chip({
  active,
  className,
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { active?: boolean }) {
  return (
    <button
      type="button"
      aria-pressed={active}
      className={cn("chip", active && "chip-active", className)}
      {...props}
    >
      {children}
    </button>
  );
}

/** Horizontally scrollable chip strip on phones, wrapping row from md up. */
export function ChipRow({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("chip-row", className)}>{children}</div>;
}

export function StatusPill({
  status,
  children,
}: {
  status: "live" | "sandbox" | "planned" | "disabled" | "paid" | "pending" | "claimable" | "failed" | "verified" | "unverified" | "neutral";
  children?: ReactNode;
}) {
  const tone: Record<string, string> = {
    live: "bg-success/15 text-success border-success/30",
    paid: "bg-success/15 text-success border-success/30",
    verified: "bg-success/15 text-success border-success/30",
    sandbox: "bg-info/15 text-info border-info/30",
    pending: "bg-warning/15 text-warning border-warning/30",
    claimable: "bg-warning/15 text-warning border-warning/30",
    planned: "bg-muted text-muted-foreground border-border",
    unverified: "bg-muted text-muted-foreground border-border",
    neutral: "bg-muted text-muted-foreground border-border",
    disabled: "bg-destructive/10 text-destructive border-destructive/30",
    failed: "bg-destructive/10 text-destructive border-destructive/30",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-sm border px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide",
        tone[status] ?? tone["neutral"],
      )}
    >
      <span className="size-1.5 rounded-full bg-current" />
      {children ?? status}
    </span>
  );
}


export function StatCard({
  label,
  value,
  hint,
  accent,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  accent?: boolean;
}) {
  return (
    <div
      className={cn(
        "min-w-0 border-b border-border px-4 py-3 last:border-b-0 sm:border-b-0 sm:border-r sm:py-2 sm:last:border-r-0",
        accent && "",
      )}
    >
      <div className="workspace-label truncate">{label}</div>
      <div className="num mt-1 truncate text-lg font-bold leading-none sm:text-xl">
        {value}
      </div>
      {hint ? <div className="mt-2 text-xs text-muted-foreground">{hint}</div> : null}
    </div>
  );
}

export function SectionHeading({
  title,
  description,
  action,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-4 grid grid-cols-[minmax(0,1fr)_auto] items-end gap-3 sm:flex sm:flex-wrap sm:justify-between">
      <div className="min-w-0">
        <h2 className="truncate text-base font-semibold">{title}</h2>
        {description ? <p className="mt-1 text-sm text-muted-foreground">{description}</p> : null}
      </div>
      {action}
    </div>
  );
}

export function LoadingRows({ rows = 5 }: { rows?: number }) {
  return (
    <div className="space-y-2" aria-busy="true" aria-live="polite">
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} className="shimmer h-14 w-full rounded-lg" />
      ))}
    </div>
  );
}

/**
 * Deliberate empty state: a small visual, one sentence, one useful action.
 * Borders are avoided in favour of a soft surface so pages stop looking like
 * a grid of boxes.
 */
export function EmptyState({
  title,
  description,
  icon,
  action,
}: {
  title: string;
  description?: string;
  icon?: ReactNode;
  action?: ReactNode;
}) {
  return (
    <div className="page-enter flex flex-col items-center justify-center gap-3 rounded-2xl bg-surface px-4 py-10 text-center sm:px-6 sm:py-12">
      <span className="grid size-11 place-items-center rounded-full bg-background text-muted-foreground shadow-sm">
        {icon ?? <Inbox className="size-5" />}
      </span>
      <div className="space-y-1">
        <p className="text-[15px] font-semibold">{title}</p>
        {description ? (
          <p className="mx-auto max-w-sm text-sm leading-6 text-muted-foreground">{description}</p>
        ) : null}
      </div>
      {action}
    </div>
  );
}

export function ErrorState({ error, retry }: { error: unknown; retry?: () => void }) {
  const message = error instanceof Error ? error.message : "Something went wrong.";
  return (
    <div className="panel border-destructive/40 p-6">
      <p className="font-medium text-destructive">Couldn't load this data</p>
      <p className="mt-1 text-sm text-muted-foreground">{message}</p>
      {retry ? (
        <button
          onClick={retry}
          className="press mt-3 rounded-md border border-border px-3 py-1.5 text-sm transition-colors hover:bg-secondary"
        >
          Try again
        </button>
      ) : null}
    </div>
  );
}

export function QueryBoundary<T>({
  query,
  children,
  empty,
  rows,
}: {
  query: { data: T | undefined; isPending: boolean; error: unknown; refetch: () => void };
  children: (data: T) => ReactNode;
  empty?: { title: string; description?: string };
  rows?: number;
}) {
  if (query.isPending) return <LoadingRows rows={rows ?? 5} />;
  if (query.error) return <ErrorState error={query.error} retry={query.refetch} />;
  const data = query.data;
  if (data === undefined || data === null || (Array.isArray(data) && data.length === 0)) {
    return (
      <EmptyState
        title={empty?.title ?? "Nothing here yet"}
        {...(empty?.description ? { description: empty.description } : {})}
      />
    );
  }
  return <>{children(data)}</>;
}
