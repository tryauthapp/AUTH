import { Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { RoutingBreakdown } from "@/components/RoutingBreakdown";
import type { RoutingSplitRow } from "@/lib/queries";
import { usd } from "@/lib/format";

export function PayoutReceipt({
  handle,
  amount,
  coinCount,
  splits,
  period = "today",
}: {
  handle: string;
  amount: number;
  coinCount: number;
  splits: RoutingSplitRow[];
  period?: string;
}) {
  const text = `@${handle} earned ${usd(amount)} ${period} from ${coinCount} community ${
    coinCount === 1 ? "token" : "tokens"
  } — routed automatically on AUTH.`;

  function share() {
    const url = typeof window !== "undefined" ? window.location.href : "";
    window.open(
      `https://x.com/intent/post?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`,
      "_blank",
      "noopener,noreferrer",
    );
  }

  return (
    <div className="panel grid-lines relative overflow-hidden p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-[11px] uppercase tracking-widest text-muted-foreground">
            Payout receipt
          </div>
          <p className="mt-2 text-xl font-semibold leading-snug">
            <span className="text-primary">@{handle}</span> earned{" "}
            <span className="num">{usd(amount)}</span> {period}
          </p>
          <p className="text-sm text-muted-foreground">
            from {coinCount} community {coinCount === 1 ? "token" : "tokens"}
          </p>
        </div>
      </div>

      <div className="mt-5">
        {splits.length > 0 ? (
          <RoutingBreakdown splits={splits} compact />
        ) : (
          <p className="text-sm text-muted-foreground">No routing configured yet.</p>
        )}
      </div>

      <Button onClick={share} className="mt-5 w-full sm:w-auto">
        <Share2 className="size-4" />
        Share on X
      </Button>
    </div>
  );
}
