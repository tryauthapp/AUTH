import { useState } from "react";
import { toast } from "sonner";
import { ShieldCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/hooks/useSession";
import { Button } from "@/components/ui/button";
import { LoadingRows } from "@/components/primitives";

/**
 * Ownership-verification session.
 *
 * AUTH has no login. Browsing, searching and building a payment never touch
 * this. It exists only so that a claim — "this X username is mine, send its
 * money here" — can be bound to one device-held session while the proof is
 * checked. No email, no password, no credentials of any kind: the session is
 * created silently and carries no identity until X ownership is proved.
 */
export function useVerificationSession() {
  const { session, loading } = useSession();
  const [starting, setStarting] = useState(false);

  async function start(): Promise<boolean> {
    if (session) return true;
    setStarting(true);
    try {
      const { error } = await supabase.auth.signInAnonymously();
      if (error) {
        toast.error("Couldn't start verification. Try again in a moment.");
        return false;
      }
      return true;
    } finally {
      setStarting(false);
    }
  }

  return { session, loading, starting, start };
}

export function VerificationGate({
  title,
  description,
  action = "Continue",
  children,
}: {
  title: string;
  description: string;
  action?: string;
  children: React.ReactNode;
}) {
  const { session, loading, starting, start } = useVerificationSession();

  if (loading) return <LoadingRows rows={4} />;
  if (session) return <>{children}</>;

  return (
    <div className="panel space-y-3 p-5">
      <div className="flex items-center gap-2">
        <ShieldCheck className="size-4 text-info" />
        <h2 className="text-base font-semibold">{title}</h2>
      </div>
      <p className="text-sm text-muted-foreground">{description}</p>
      <Button className="press rounded-full" disabled={starting} onClick={() => void start()}>
        {starting ? "Preparing…" : action}
      </Button>
    </div>
  );
}
