import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ExternalLink, Send } from "lucide-react";
import {
  preparePayoutTransfer,
  settlePayoutSignature,
  refreshPayoutConfirmation,
  type TransferPlanResponse,
} from "@/lib/payouts.functions";
import { useWallet } from "@/lib/wallet/WalletProvider";
import { AccountPanel } from "@/components/AccountPanel";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { explorerTx, formatAsset } from "@/lib/solana";
import { shortAddress, usd } from "@/lib/format";

type Plan = NonNullable<TransferPlanResponse["plan"]>;
type Step = "idle" | "preparing" | "review" | "signing" | "confirming" | "done";

export function PayoutSigner({
  payoutId,
  label,
  amountUsd,
}: {
  payoutId: string;
  label: string;
  amountUsd: number;
}) {
  const { address, signer } = useWallet();
  const queryClient = useQueryClient();
  const prepare = useServerFn(preparePayoutTransfer);
  const settle = useServerFn(settlePayoutSignature);
  const refresh = useServerFn(refreshPayoutConfirmation);

  const [step, setStep] = useState<Step>("idle");
  const [plan, setPlan] = useState<Plan | null>(null);
  const [signature, setSignature] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!address || !signer) {
    return <AccountPanel />;
  }

  async function start() {
    setError(null);
    setStep("preparing");
    try {
      const res = await prepare({ data: { payoutId, signerAddress: address! } });
      if (!res.ok || !res.plan) {
        setStep("idle");
        toast.error(res.message ?? "Could not prepare this payout.");
        return;
      }
      setPlan(res.plan);
      setStep("review");
    } catch (e) {
      setStep("idle");
      toast.error(e instanceof Error ? e.message : "Could not prepare this payout.");
    }
  }

  async function sign() {
    if (!plan || !signer || !address) return;
    setError(null);
    setStep("signing");
    try {
      const sig = await signer.signAndSendTransfer({
        to: plan.to,
        asset: plan.asset,
        amount: plan.amount,
        decimals: plan.decimals,
        blockhash: plan.blockhash,
        lastValidBlockHeight: plan.lastValidBlockHeight,
        destinationTokenAccountExists: plan.destinationTokenAccountExists,
        memo: plan.memo,
      });
      setSignature(sig);
      setStep("confirming");

      const res = await settle({
        data: {
          payoutId,
          signature: sig,
          signerAddress: address,
          asset: plan.asset,
          amount: plan.amount,
          destination: plan.to,
          idempotencyKey: plan.idempotencyKey,
        },
      });
      await queryClient.invalidateQueries();
      if (res.ok && res.status === "paid") {
        setStep("done");
        toast.success("Payout confirmed on-chain");
      } else if (res.ok) {
        setStep("done");
        toast.message(res.message ?? "Submitted — waiting for confirmation.");
      } else {
        setStep("review");
        setError(res.message ?? "Settlement failed.");
      }
    } catch (e) {
      setStep("review");
      setError(e instanceof Error ? e.message : "The wallet could not complete this transfer.");
    }
  }

  return (
    <>
      <Button size="sm" className="press" onClick={start} disabled={step === "preparing"}>
        <Send className="size-4" />
        {step === "preparing" ? "Preparing…" : "Pay on-chain"}
      </Button>

      <Dialog
        open={step === "review" || step === "signing" || step === "confirming" || step === "done"}
        onOpenChange={(o) => {
          if (!o) {
            setStep("idle");
            setPlan(null);
            setError(null);
          }
        }}
      >
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{step === "done" ? "Transaction submitted" : "Review transaction"}</DialogTitle>
            <DialogDescription>
              {step === "done"
                ? "AUTH verified this signature against Solana mainnet before recording it."
                : "Your wallet will ask you to approve this exact transfer on Solana mainnet."}
            </DialogDescription>
          </DialogHeader>

          {plan ? (
            <dl className="space-y-2 rounded-xl border border-border bg-secondary/40 p-4 text-sm">
              <Row label="Destination split" value={label} />
              <Row label="Amount" value={`${formatAsset(plan.amount, plan.asset)}`} />
              <Row label="Ledger value" value={usd(plan.amountUsd)} />
              {plan.solPriceUsd ? (
                <Row
                  label="SOL price"
                  value={`${usd(plan.solPriceUsd)} (${plan.priceSource})`}
                />
              ) : null}
              <Row label="To" value={<span className="num">{shortAddress(plan.to, 6)}</span>} />
              <Row label="From" value={<span className="num">{shortAddress(address, 6)}</span>} />
              <Row label="Network" value="Solana mainnet-beta" />
              {plan.asset === "USDC" && !plan.destinationTokenAccountExists ? (
                <p className="text-xs text-muted-foreground">
                  The destination has no USDC account yet, so the transaction also creates one
                  (small extra network rent paid by you).
                </p>
              ) : null}
            </dl>
          ) : null}

          {signature ? (
            <a
              href={explorerTx(signature)}
              target="_blank"
              rel="noreferrer noopener"
              className="num inline-flex items-center gap-1 text-xs text-primary hover:underline"
            >
              {shortAddress(signature, 8)} <ExternalLink className="size-3" />
            </a>
          ) : null}

          {error ? <p className="text-sm text-destructive">{error}</p> : null}

          <div className="flex flex-wrap gap-2">
            {step === "done" ? (
              <>
                <Button
                  size="sm"
                  variant="outline"
                  className="press"
                  onClick={async () => {
                    const res = await refresh({ data: { payoutId } });
                    await queryClient.invalidateQueries();
                    toast.message(res.message ?? "Checked.");
                  }}
                >
                  Re-check status
                </Button>
                <Button size="sm" className="press" onClick={() => setStep("idle")}>
                  Close
                </Button>
              </>
            ) : (
              <Button
                size="sm"
                className="press"
                onClick={sign}
                disabled={step === "signing" || step === "confirming"}
              >
                {step === "signing"
                  ? "Waiting for your authorization…"
                  : step === "confirming"
                    ? "Confirming on-chain…"
                    : "Sign & send"}
              </Button>
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            Amount is fixed by the ledger entry. AUTH cannot sign for you — nothing moves without
            your approval.
          </p>
        </DialogContent>
      </Dialog>
    </>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="text-right font-medium">{value}</dd>
    </div>
  );
}
