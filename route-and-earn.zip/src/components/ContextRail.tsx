import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowUpRight } from "lucide-react";
import { feeEventsQuery, leaderboard, paymentsQuery, tokenBoard } from "@/lib/queries";
import { timeAgo, usd } from "@/lib/format";
import { HandleSearch } from "@/components/HandleSearch";
import { IdentityAvatar, TokenAvatar } from "@/components/Avatar";

/** Right-hand contextual column: search, live assets, trending people/coins, activity, honest states. */
export function ContextRail() {
  const events = useQuery(feeEventsQuery());
  const payments = useQuery(paymentsQuery(8));

  const people = leaderboard(events.data ?? [], 24).slice(0, 5);
  const tokens = tokenBoard(events.data ?? [], 24).slice(0, 5);
  const recent = (payments.data ?? []).slice(0, 4);

  return (
    <aside className="hidden w-[286px] shrink-0 border-l border-border px-4 py-4 2xl:block">
      <div className="sticky top-4 flex max-h-[calc(100vh-2rem)] flex-col gap-3 overflow-y-auto pb-4">
        <HandleSearch />

        {people.length === 0 && tokens.length === 0 ? (
          <section className="workspace-panel overflow-hidden">
            <h2 className="border-b border-border px-4 py-2.5 text-sm font-semibold">
              Getting started
            </h2>
            <ul className="divide-y divide-border text-sm">
              <li>
                <Link to="/launch" className="row-hover block px-4 py-3">
                  <span className="block font-medium">Launch a token</span>
                  <span className="block text-xs text-muted-foreground">
                    Route its creator fees to any @username.
                  </span>
                </Link>
              </li>
              <li>
                <Link to="/claim" className="row-hover block px-4 py-3">
                  <span className="block font-medium">Claim your @username</span>
                  <span className="block text-xs text-muted-foreground">
                    Prove ownership on X to receive fees.
                  </span>
                </Link>
              </li>
              <li>
                <Link to="/docs" className="row-hover block px-4 py-3">
                  <span className="block font-medium">How routing works</span>
                  <span className="block text-xs text-muted-foreground">
                    Splits, payouts and the public ledger.
                  </span>
                </Link>
              </li>
            </ul>
          </section>
        ) : null}

        {people.length > 0 ? (
          <section className="workspace-panel overflow-hidden py-2">
            <h2 className="px-3 py-2 text-sm font-semibold">Creator activity</h2>
            <ul className="-mx-2 space-y-0.5">
              {people.map((row) => (
                <li key={row.id}>
                  <Link
                    to="/u/$handle"
                    params={{ handle: row.handle }}
                    className="row-hover flex items-center gap-3 px-4 py-3"
                  >
                    <IdentityAvatar handle={row.handle} size="sm" />
                    <span className="min-w-0 flex-1"><span className="block truncate text-sm font-semibold">@{row.handle}</span><span className="block text-xs text-muted-foreground">Trending creator</span></span>
                    <span className="num text-xs font-semibold text-success">
                      {usd(row.total, { compact: true })}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        ) : null}

        {tokens.length > 0 ? (
          <section className="workspace-panel overflow-hidden py-2">
            <h2 className="px-3 py-2 text-sm font-semibold">Assets to watch</h2>
            <ul className="-mx-2 space-y-0.5">
              {tokens.map((row) => (
                <li key={row.mint}>
                  <Link
                    to="/t/$mint"
                    params={{ mint: row.mint }}
                    className="row-hover flex items-center gap-3 px-4 py-3"
                  >
                    <TokenAvatar symbol={row.symbol} size="sm" />
                    <span className="min-w-0 flex-1 truncate text-sm font-semibold">${row.symbol}</span>
                    <span className="num text-xs text-muted-foreground">
                      {usd(row.total, { compact: true })}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        ) : null}


        {recent.length > 0 ? (
          <section className="workspace-panel overflow-hidden p-3">
            <h2 className="mb-3 text-sm font-semibold">Latest payments</h2>
            <ul className="space-y-2.5">
              {recent.map((p) => (
                <li key={p.id} className="flex items-center gap-2.5">
                  <IdentityAvatar handle={p.recipient_handle} size="sm" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">@{p.recipient_handle}</p>
                    <p className="text-[11px] text-muted-foreground">{timeAgo(p.created_at)}</p>
                  </div>
                  <span className="num text-xs font-semibold">
                    {Number(p.amount)} {p.asset}
                  </span>
                </li>
              ))}
            </ul>
            <Link to="/ledger" className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-info hover:underline">
              Open ledger <ArrowUpRight className="size-3" />
            </Link>
          </section>
        ) : null}

        <nav className="flex flex-wrap gap-x-3 gap-y-1 px-1 text-xs text-muted-foreground">
          <Link to="/docs" className="hover:underline">How it works</Link>
          <Link to="/claim" className="hover:underline">Claim your @username</Link>
          <Link to="/ledger" className="hover:underline">Ledger</Link>
          <Link to="/terms" className="hover:underline">Terms</Link>
          <Link to="/privacy" className="hover:underline">Privacy</Link>
          <span>© AUTH</span>
        </nav>
      </div>
    </aside>
  );
}
