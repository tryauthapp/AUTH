import { useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  ArrowRight,
  ArrowUpRight,
  AtSign,
  Coins,
  Fingerprint,
  Lock,
  ShieldCheck,
  Sparkles,
  Zap,
} from "lucide-react";

import { BrandMark } from "@/components/BrandMark";
import { ThemeToggle } from "@/components/ThemeToggle";
import {
  copyAuthTokenAddress,
  GitHubMark,
  shortMint,
  XMark,
} from "@/components/TopLinks";
import {
  AUTH_GITHUB_URL,
  AUTH_TOKEN_MINT,
  AUTH_X_URL,
  solscanTokenUrl,
} from "@/lib/external-links";

import authMark from "@/assets/auth-mark.png.asset.json";
import { useQuery } from "@tanstack/react-query";
import { ProviderCard } from "@/components/social/ProviderCard";
import { ExternalLink } from "@/components/ExternalLink";
import { AssetIcon } from "@/components/AssetIcon";
import { TURNKEY_PROOF_PATH, platformHomeUrl, socialProfileUrl } from "@/lib/external-links";
import { ProviderIcon } from "@/components/social/ProviderIcon";
import { lookupXProfile } from "@/lib/x-profile.functions";

/** Illustrative recipient used in the marketing transfer preview only. */
const DEMO_HANDLE = "elonmusk";

const NAV = [
  { label: "Docs", to: "/docs" },
  { label: "Integrations", to: "/docs/integrations" },
  { label: "Security", to: "/risk" },
];

const STEPS = [
  {
    icon: AtSign,
    label: "Identity",
    body: "An X @username is the address. Ownership is proven at claim time.",
    tag: "Identity layer",
  },
  {
    icon: Fingerprint,
    label: "AUTH",
    body: "Compose a payment, launch a token, or route creator fees in public.",
    tag: "Live",
  },
  {
    icon: Lock,
    label: "Wallet",
    body: "Verified identities get an embedded wallet secured by Turnkey.",
    tag: "Turnkey",
  },
  {
    icon: Zap,
    label: "Settlement",
    body: "Transfers settle on Solana mainnet with a real confirmed signature.",
    tag: "Solana",
  },
];

const BENEFITS = [
  {
    icon: Fingerprint,
    title: "Onchain identity",
    body: "Send Solana assets to an X @username. Unclaimed payments stay claimable.",
  },
  {
    icon: Sparkles,
    title: "Walletless by default",
    body: "Browse, search and compose a payment with no account and no extension.",
  },
  {
    icon: Coins,
    title: "Creator fees, in public",
    body: "Launch tokens and route fee splits with a transparent ledger.",
  },
];

/**
 * The full five-platform product. All five are presented as active.
 */
const SOCIAL_IDS = [
  { id: "x" as const, label: "X", soon: false },
  { id: "tiktok" as const, label: "TikTok", soon: false },
  { id: "youtube" as const, label: "YouTube", soon: false },
  { id: "twitch" as const, label: "Twitch", soon: false },
  { id: "instagram" as const, label: "Instagram", soon: false },
];

const INFRA = [
  { k: "Wallet infrastructure", v: "Turnkey embedded wallets" },
  { k: "Network", v: "Solana mainnet-beta" },
  { k: "Assets", v: "Verified SPL registry" },
  { k: "Key custody", v: "Never handled by AUTH" },
];

/**
 * Full-screen entrance landing shown once per page load.
 * Purely visual — nothing is gated behind it, and no account is required.
 */
export function EntranceOverlay() {
  // Real profile data for the illustrative recipient, when the configured X
  // lookup can supply it. Falls back to the plain handle — nothing invented.
  const demoLookup = useQuery({
    queryKey: ["entrance-demo-x-profile", DEMO_HANDLE],
    queryFn: () => lookupXProfile({ data: { handle: DEMO_HANDLE } }),
    staleTime: 30 * 60_000,
    retry: false,
  });
  const demoProfile =
    demoLookup.data?.status === "ok" ? demoLookup.data.profile : null;
  // The welcome screen belongs to the front page only; deep links such as the
  // Turnkey proof page must render their own content immediately.
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [mounted, setMounted] = useState(false);
  const [open, setOpen] = useState(pathname === "/");
  const [leaving, setLeaving] = useState(false);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (!mounted || !open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Enter" || e.key === "Escape") enter();
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mounted, open]);

  function enter() {
    setLeaving(true);
    window.setTimeout(() => setOpen(false), 420);
  }

  if (!mounted || !open) return null;

  return (
    <div
      className={`fixed inset-0 z-[100] overflow-y-auto bg-background transition-all duration-500 ${
        leaving ? "pointer-events-none -translate-y-1 opacity-0" : "opacity-100"
      }`}
      role="dialog"
      aria-label="Welcome to AUTH"
    >
      {/* ambient layer */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-56 -top-40 size-[42rem] rounded-full bg-brand/10 blur-[150px]" />
        <div className="absolute right-[-18rem] top-[22rem] size-[34rem] rounded-full bg-brand/[0.06] blur-[130px]" />
        <div className="absolute inset-0 text-foreground opacity-[0.028] [background-image:linear-gradient(to_right,currentColor_1px,transparent_1px),linear-gradient(to_bottom,currentColor_1px,transparent_1px)] [background-size:72px_72px] [mask-image:radial-gradient(120%_80%_at_20%_0%,black,transparent_75%)]" />
        {/* oversized cropped A */}
        <img
          src={authMark.url}
          alt=""
          className="absolute -left-40 top-24 hidden w-[42rem] opacity-[0.035] dark:invert lg:block"
        />
      </div>

      <div className="relative mx-auto flex min-h-full w-full max-w-6xl flex-col px-5 sm:px-8">
        {/* nav */}
        <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 py-6">
          <div className="flex min-w-0 items-center gap-7">
            <span className="flex items-center gap-2">
              <BrandMark className="size-7" />
              <span className="text-base font-extrabold tracking-tight">AUTH</span>
            </span>
            <nav className="hidden items-center gap-6 md:flex">
              {NAV.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={enter}
                  className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <button
              type="button"
              onClick={copyAuthTokenAddress}
              title={`AUTH token address — ${AUTH_TOKEN_MINT}`}
              aria-label="Copy the AUTH token's on-chain address"
              className="press hidden items-center gap-1.5 rounded-lg border border-border bg-card/70 px-2.5 py-1.5 font-mono text-[11px] font-medium text-muted-foreground transition-colors hover:border-brand/40 hover:text-foreground sm:inline-flex"
            >
              <BrandMark className="size-3.5" />
              {shortMint(AUTH_TOKEN_MINT)}
            </button>
            <a
              href={AUTH_X_URL}
              target="_blank"
              rel="noopener noreferrer"
              title="AUTH on X — @TryAuthApp"
              aria-label="AUTH on X"
              className="inline-flex size-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            >
              <XMark className="size-4 text-platform-x" />
            </a>
            <a
              href={AUTH_GITHUB_URL}
              target="_blank"
              rel="noopener noreferrer"
              title="AUTH on GitHub"
              aria-label="AUTH on GitHub"
              className="inline-flex size-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            >
              <GitHubMark className="size-4" />
            </a>
            <ThemeToggle />
            <button
              type="button"
              onClick={enter}
              className="press shrink-0 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90"
            >
              Enter Auth
            </button>
          </div>
        </header>


        {/* hero — asymmetric */}
        <section className="grid items-center gap-12 py-10 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)] lg:gap-16 lg:py-20">
          {/* copy column */}
          <div className="fade-up min-w-0">
            <Link
              to={TURNKEY_PROOF_PATH}
              onClick={enter}
              title="See the proof that AUTH really runs on Turnkey"
              className="inline-flex items-center gap-2 rounded-full border border-border bg-card/70 py-1 pl-1.5 pr-3 backdrop-blur-sm transition-colors hover:border-brand/40 hover:bg-card"
            >
              <span className="grid size-5 place-items-center rounded-full bg-brand/10 text-brand">
                <ShieldCheck className="size-3" />
              </span>
              <span className="font-mono text-[10px] font-medium uppercase tracking-[0.2em] text-muted-foreground">
                Built on Turnkey
              </span>
              <ArrowUpRight className="size-3 text-muted-foreground" />
            </Link>

            <h1 className="mt-6 text-balance text-[2.6rem] font-extrabold leading-[0.98] tracking-[-0.03em] sm:text-6xl lg:text-[4.25rem]">
              The identity layer for the{" "}
              <span className="text-brand">onchain world.</span>
            </h1>

            <p className="mt-6 max-w-lg text-base leading-relaxed text-muted-foreground sm:text-lg">
              Pay any social handle in Solana assets, launch tokens, and route creator
              fees in public — with embedded wallet infrastructure secured by{" "}
              <Link
                to={TURNKEY_PROOF_PATH}
                onClick={enter}
                className="font-medium text-foreground underline decoration-border underline-offset-4 hover:decoration-foreground"
              >
                Turnkey
              </Link>
              .
            </p>


            <p className="mt-7 text-2xl font-bold tracking-[-0.02em] sm:text-3xl">
              Launch for free. <span className="text-success">No wallet connection.</span>
            </p>
            <p className="mt-2 max-w-lg text-sm text-muted-foreground">
              0 AUTH launch fee. Network and optional dev-buy costs may apply.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={enter}
                className="cta inline-flex items-center gap-2 rounded-xl bg-primary px-8 py-4 text-base font-semibold text-primary-foreground outline-none hover:bg-primary/90 focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
              >
                Enter Auth
                <ArrowRight className="size-4" />
              </button>
              <Link
                to="/docs"
                onClick={enter}
                className="text-sm font-medium text-muted-foreground underline-offset-4 transition-colors hover:text-foreground hover:underline"
              >
                Read the docs
              </Link>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">
              No account and no external wallet connection needed to browse or compose a payment.
            </p>

            <div className="mt-7 border-t border-border pt-5">
              <p className="text-lg font-bold tracking-[-0.02em] sm:text-xl">
                Your social identity is your crypto identity.
              </p>
              <ul className="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-5">
                {SOCIAL_IDS.map((p) => (
                  <li key={p.id}>
                    <ProviderCard
                      provider={p.id}
                      label={p.label}
                      live
                      href={platformHomeUrl(p.id)}
                    />
                  </li>
                ))}
              </ul>
              <p className="mt-3 text-xs text-muted-foreground">
                All five platforms are active. Ownership is always proven with the
                platform&apos;s own authorization.
              </p>
            </div>


          </div>

          {/* product preview column */}
          <div className="relative min-w-0">
            <div className="drift-slow absolute -bottom-14 -left-10 z-10 hidden w-44 rounded-2xl border border-border bg-card/90 p-4 shadow-[0_24px_60px_-42px_rgb(0_0_0/0.5)] backdrop-blur-sm lg:block">
              <div className="flex items-center gap-2">
                <span className="grid size-7 place-items-center rounded-lg bg-brand/10 text-brand">
                  <Lock className="size-3.5" />
                </span>
                <Link
                  to={TURNKEY_PROOF_PATH}
                  onClick={enter}
                  className="inline-flex items-center gap-1 text-xs font-semibold tracking-tight hover:underline"
                >
                  Turnkey <ArrowUpRight className="size-3" />
                </Link>
              </div>
              <p className="mt-3 text-[11px] leading-relaxed text-muted-foreground">
                Embedded wallets. Keys generated and signed inside Turnkey — never by AUTH.
              </p>
              <div className="mt-3 h-1 w-full overflow-hidden rounded-full bg-muted">
                <div className="h-full w-2/3 rounded-full bg-brand" />
              </div>
            </div>

            {/* mini AUTH interface — illustration, no data */}
            <div className="lift relative rounded-3xl border border-border bg-card/90 p-5 shadow-[0_40px_90px_-60px_rgb(0_0_0/0.6)] backdrop-blur-sm sm:p-6">
              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                  New transfer
                </span>
                <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                  <span className="size-1.5 rounded-full bg-success" />
                  Mainnet
                </span>
              </div>

              <div className="mt-5 space-y-3">
                <div className="rounded-xl border border-border bg-background px-4 py-3">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-[11px] text-muted-foreground">Recipient</p>
                    <span className="rounded-full bg-muted px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-[0.14em] text-muted-foreground">
                      Example
                    </span>
                  </div>
                  <ExternalLink
                    href={socialProfileUrl("x", DEMO_HANDLE) ?? platformHomeUrl("x")}
                    className="group mt-2 flex items-center gap-2.5"
                  >
                    {demoProfile?.avatarUrl ? (
                      <img
                        src={demoProfile.avatarUrl}
                        alt=""
                        className="size-8 shrink-0 rounded-full border border-border object-cover"
                      />
                    ) : (
                      <span className="grid size-8 shrink-0 place-items-center rounded-full border border-border bg-muted">
                        <AtSign className="size-3.5 text-muted-foreground" />
                      </span>
                    )}
                    <span className="min-w-0 flex-1">
                      {demoProfile ? (
                        <span className="block truncate text-sm font-semibold">{demoProfile.name}</span>
                      ) : null}
                      <span className="flex items-center gap-1 text-xs text-muted-foreground">
                        <ProviderIcon provider="x" brand className="size-3" />
                        @{demoProfile?.username ?? DEMO_HANDLE}
                      </span>
                    </span>
                    <ArrowUpRight className="size-3.5 shrink-0 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
                  </ExternalLink>
                  <div className="mt-3 flex items-center justify-between gap-2 rounded-lg bg-success/10 px-2.5 py-1.5">
                    <span className="font-mono text-[9px] uppercase tracking-[0.16em] text-success">
                      Claimable
                    </span>
                    <span className="flex items-center gap-2">
                      <span className="num text-xs font-semibold text-success">1.2M SOL</span>
                      <span className="rounded-full bg-background/70 px-1.5 py-0.5 font-mono text-[8px] uppercase tracking-[0.14em] text-muted-foreground">
                        Example
                      </span>
                    </span>
                  </div>


                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-xl border border-border bg-background px-4 py-3">
                    <p className="text-[11px] text-muted-foreground">USDC or Solana</p>
                    <p className="mt-1 flex items-center gap-2 text-sm font-semibold">
                      <AssetIcon symbol="USDC" assetKey="solana:USDC" chainKey="solana" size="xs" showNetwork={false} />
                      <AssetIcon symbol="SOL" assetKey="solana:SOL" chainKey="solana" size="xs" showNetwork={false} />
                    </p>
                  </div>
                  <div className="rounded-xl border border-border bg-background px-4 py-3">
                    <p className="text-[11px] text-muted-foreground">Amount</p>
                    <p className="num mt-1 text-sm font-semibold text-muted-foreground">0.00</p>
                  </div>
                </div>
                <div className="rounded-xl bg-primary px-4 py-3 text-center text-sm font-semibold text-primary-foreground">
                  Authorize
                </div>
              </div>

              <div className="mt-5 flex items-center justify-between border-t border-border pt-4">
                {["@elonmusk", "USDC / SOL", "Amount", "Authorize"].map((s, i) => (
                  <span
                    key={s}
                    className={`font-mono text-[9px] uppercase tracking-[0.16em] ${
                      i === 0 ? "text-brand" : "text-muted-foreground/70"
                    }`}
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>

            <div className="drift absolute -right-8 -top-12 z-10 hidden w-40 rounded-2xl border border-border bg-card/90 p-4 shadow-[0_24px_60px_-42px_rgb(0_0_0/0.5)] backdrop-blur-sm lg:block">
              <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                Claim
              </p>
              <p className="mt-2 text-xs leading-relaxed">
                Prove you own the handle, then choose how you get paid.
              </p>
            </div>
          </div>
        </section>

        {/* workflow strip */}
        <section className="border-t border-border py-10">
          <div className="flex items-center gap-4">
            <span className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
              How it flows
            </span>
            <span className="h-px flex-1 bg-border" />
          </div>
          <ol className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS.map(({ icon: Icon, label, body, tag }, i) => (
              <li
                key={label}
                className="lift min-w-0 rounded-2xl border border-border bg-card/70 p-4 backdrop-blur-sm"
              >
                <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2">
                  <span className="flex min-w-0 items-center gap-2">
                    <span className="grid size-7 shrink-0 place-items-center rounded-lg bg-brand/10 text-brand">
                      <Icon className="size-3.5" />
                    </span>
                    <span className="truncate text-sm font-semibold">{label}</span>
                  </span>
                  <span className="num shrink-0 text-[10px] text-muted-foreground/70">
                    0{i + 1}
                  </span>
                </div>
                <p className="mt-3 text-xs leading-relaxed text-muted-foreground">{body}</p>
                <p className="mt-3 font-mono text-[9px] uppercase tracking-[0.18em] text-muted-foreground/70">
                  {tag}
                </p>
              </li>
            ))}
          </ol>
        </section>

        {/* benefits */}
        <section className="grid gap-5 border-t border-border py-10 sm:grid-cols-3">
          {BENEFITS.map(({ icon: Icon, title, body }) => (
            <div key={title} className="flex min-w-0 gap-3">
              <span className="mt-0.5 grid size-9 shrink-0 place-items-center rounded-lg bg-brand/10 text-brand">
                <Icon className="size-4" />
              </span>
              <div className="min-w-0">
                <p className="text-sm font-semibold">{title}</p>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{body}</p>
              </div>
            </div>
          ))}
        </section>

        {/* trusted infrastructure */}
        <section className="border-t border-border py-10">
          <div className="flex items-center gap-4">
            <span className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
              Trusted infrastructure
            </span>
            <span className="h-px flex-1 bg-border" />
          </div>
          <dl className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {INFRA.map((item) => (
              <div key={item.k} className="min-w-0">
                <dt className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                  {item.k}
                </dt>
                <dd className="mt-2 text-sm font-semibold">{item.v}</dd>
              </div>
            ))}
          </dl>
        </section>

        {/* footer */}
        <footer className="grid grid-cols-[minmax(0,1fr)_auto] items-end gap-4 border-t border-border py-8">
          <div className="min-w-0">
            <span className="flex items-center gap-2">
              <BrandMark className="size-5" />
              <span className="text-sm font-extrabold tracking-tight">AUTH</span>
            </span>
            <p className="mt-2 max-w-sm text-xs leading-relaxed text-muted-foreground">
              Social identity payments and creator-fee routing on Solana. Not affiliated
              with X Corp.
            </p>
          </div>
          <nav className="flex shrink-0 flex-wrap justify-end gap-x-5 gap-y-2 text-xs text-muted-foreground">
            {[
              { label: "Docs", to: "/docs" },
              { label: "Privacy", to: "/privacy" },
              { label: "Terms", to: "/terms" },
              { label: "Risk", to: "/risk" },
            ].map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={enter}
                className="transition-colors hover:text-foreground"
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </footer>
      </div>
    </div>
  );
}
