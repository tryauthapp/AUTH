import { AssetIcon } from "@/components/AssetIcon";
import { cn } from "@/lib/utils";
import { usd } from "@/lib/format";
import type { ClaimableBucket, PublicClaimable } from "@/lib/claimable.functions";

/**
 * Public claimable-balance panel.
 *
 * Renders only real accounting totals handed to it. A zero total is shown as
 * zero — this component never substitutes a placeholder or illustrative amount.
 */

function amount(value: number) {
  if (value === 0) return "0";
  if (value < 0.001) return value.toExponential(2);
  return value.toLocaleString(undefined, { maximumFractionDigits: value < 1 ? 6 : 4 });
}

function AssetRow({
  symbol,
  value,
  tone,
}: {
  symbol: "SOL" | "USDC";
  value: number;
  tone: "available" | "claimed";
}) {
  const positive = value > 0;
  return (
    <div
      className={cn(
        "flex items-center justify-between gap-3 rounded-xl border px-4 py-3",
        tone === "available" && positive
          ? "border-success/40 bg-success/5"
          : "border-border bg-background",
      )}
    >
      <span className="flex items-center gap-2.5">
        <AssetIcon
          symbol={symbol}
          assetKey={`solana:${symbol}`}
          chainKey="solana"
          size="sm"
          showNetwork={false}
        />
        <span className="text-sm font-semibold">{symbol}</span>
      </span>
      <span
        className={cn(
          "num text-lg font-semibold tabular-nums",
          tone === "available" && positive ? "text-success" : "text-foreground",
          !positive && "text-muted-foreground",
        )}
      >
        {amount(value)}
      </span>
    </div>
  );
}

export function ClaimableBalance({
  data,
  className,
}: {
  data: PublicClaimable;
  className?: string;
}) {
  const hasClaimed = data.claimed.SOL > 0 || data.claimed.USDC > 0;
  const nothing = data.available.SOL === 0 && data.available.USDC === 0;

  return (
    <div className={cn("rounded-2xl border border-border bg-card p-5 sm:p-6", className)}>
      <div className="flex items-baseline justify-between gap-3">
        <h2 className="text-sm font-semibold">Available to claim</h2>
        <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
          Solana mainnet
        </span>
      </div>

      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        <AssetRow symbol="SOL" value={data.available.SOL} tone="available" />
        <AssetRow symbol="USDC" value={data.available.USDC} tone="available" />
      </div>

      {nothing ? (
        <p className="mt-3 text-sm text-muted-foreground">
          Nothing is waiting for this identity yet. Creator fees and payments sent to the handle
          show up here the moment they are recorded.
        </p>
      ) : (
        <p className="mt-3 text-sm text-muted-foreground">
          {data.approxUsd === null ? (
            "Approximate total unavailable — no price source answered just now."
          ) : (
            <>
              ≈ {usd(data.approxUsd)} total{" "}
              <span className="text-xs">
                (approximate
                {data.priceSource ? `, priced via ${data.priceSource}` : ""})
              </span>
            </>
          )}
        </p>
      )}

      {hasClaimed ? (
        <div className="mt-5 border-t border-border pt-4">
          <h3 className="text-sm font-semibold text-muted-foreground">Already claimed</h3>
          <div className="mt-2 grid gap-2 sm:grid-cols-2">
            <AssetRow symbol="SOL" value={data.claimed.SOL} tone="claimed" />
            <AssetRow symbol="USDC" value={data.claimed.USDC} tone="claimed" />
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            Lifetime settled to this identity. Separate from the available balance above.
          </p>
        </div>
      ) : null}
    </div>
  );
}

export function claimableTotal(bucket: ClaimableBucket) {
  return bucket.SOL + bucket.USDC;
}
