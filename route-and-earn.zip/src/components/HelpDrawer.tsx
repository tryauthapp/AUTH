import { Link } from "@tanstack/react-router";
import { BookOpen, HelpCircle, Rocket, Send, ShieldCheck, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetClose,
} from "@/components/ui/sheet";

const LINKS = [
  {
    to: "/docs",
    icon: BookOpen,
    title: "How AUTH works",
    body: "Identities, payments, launches and creator-fee routing.",
  },
  {
    to: "/pay",
    icon: Send,
    title: "Pay an X handle",
    body: "Send SOL or USDC to any X identity.",
  },
  {
    to: "/launch",
    icon: Rocket,
    title: "Launch for an X handle",
    body: "Free from AUTH — Solana network costs still apply.",
  },
  {
    to: "/ledger",
    icon: Sparkles,
    title: "Fee ledger",
    body: "Readable public receipts for every fee event.",
  },
  {
    to: "/turnkey-proof",
    icon: ShieldCheck,
    title: "Turnkey proof",
    body: "How wallet infrastructure is secured. AUTH holds no private keys.",
  },
] as const;

/**
 * Replaces the old permanent right-hand docs column. Help is one click away,
 * but it no longer consumes product width on every page.
 */
export function HelpDrawer() {
  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button
          variant="outline"
          size="icon"
          aria-label="Help and docs"
          className="fixed bottom-[calc(5.5rem+env(safe-area-inset-bottom))] right-4 z-40 size-11 rounded-full bg-card shadow-lg md:bottom-5 md:right-5"
        >
          <HelpCircle className="size-5" />
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-full gap-0 sm:max-w-sm">
        <SheetHeader>
          <SheetTitle>Help</SheetTitle>
          <SheetDescription>
            Short answers and the full docs, without taking over the page.
          </SheetDescription>
        </SheetHeader>
        <div className="space-y-2 overflow-y-auto px-4 pb-6">
          {LINKS.map((link) => (
            <SheetClose asChild key={link.to}>
              <Link
                to={link.to}
                className="flex items-start gap-3 rounded-xl bg-surface p-3 transition-colors hover:bg-secondary"
              >
                <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary">
                  <link.icon className="size-4" />
                </span>
                <span className="min-w-0">
                  <span className="block text-sm font-semibold">{link.title}</span>
                  <span className="block text-[13px] leading-5 text-muted-foreground">
                    {link.body}
                  </span>
                </span>
              </Link>
            </SheetClose>
          ))}
          <p className="px-1 pt-2 text-xs leading-5 text-muted-foreground">
            AUTH is walletless: no wallet connection is required to browse, search or compose a
            payment. Solana mainnet only.
          </p>
        </div>
      </SheetContent>
    </Sheet>
  );
}
