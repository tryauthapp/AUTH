import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Sparkles, Trash2 } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { charitiesQuery, type RoutingConfigRow } from "@/lib/queries";
import { DESTINATION_LABELS } from "@/lib/format";
import { recommendRouting } from "@/lib/routing-ai.functions";

type Draft = {
  destination: string;
  label: string;
  percent: number;
  address: string | null;
  charity_id: string | null;
};

/**
 * Destinations offered in the product are the ones with a working payout path.
 * Buyback, burn and X Money remain in the schema and adapter registry but are
 * not offered until their adapters actually execute.
 */
const DESTINATIONS = [
  "sol",
  "usdc",
  "wallet_withdrawal",
  "charity",
  "split_recipient",
] as const;

const ADAPTER_NOTE: Record<string, { note: string }> = {
  sol: { note: "Held as SOL in your recipient balance." },
  usdc: { note: "Paid out in USDC on Solana." },
  wallet_withdrawal: { note: "Sent to your Solana payout address." },
  charity: { note: "Resolved through the charity registry." },
  split_recipient: { note: "Forwarded to another handle's balance." },
};

export function RoutingEditor({
  recipientId,
  config,
}: {
  recipientId: string;
  config: RoutingConfigRow | null;
}) {
  const queryClient = useQueryClient();
  const charities = useQuery(charitiesQuery());
  const [rows, setRows] = useState<Draft[]>(
    config?.splits.length
      ? [...config.splits]
          .sort((a, b) => a.sort_order - b.sort_order)
          .map((s) => ({
            destination: s.destination,
            label: s.label,
            percent: Number(s.percent),
            address: s.address,
            charity_id: s.charity_id,
          }))
      : [{ destination: "sol", label: "Hold as SOL", percent: 100, address: null, charity_id: null }],
  );
  const [busy, setBusy] = useState(false);
  const [goal, setGoal] = useState("");
  const [aiBusy, setAiBusy] = useState(false);
  const [recommendation, setRecommendation] = useState<string | null>(null);
  const recommend = useServerFn(recommendRouting);

  const total = rows.reduce((a, b) => a + (Number(b.percent) || 0), 0);
  const valid = Math.abs(total - 100) < 0.001 && rows.every((r) => Number(r.percent) > 0);

  function update(i: number, patch: Partial<Draft>) {
    setRows((prev) => prev.map((r, idx) => (idx === i ? { ...r, ...patch } : r)));
  }

  async function generateRecommendation() {
    setAiBusy(true);
    setRecommendation(null);
    try {
      const result = await recommend({ data: { goal: goal.trim() } });
      setRows(result.splits);
      setRecommendation(result.summary);
      toast.success("Validated recommendation applied. Review it before saving.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not create a recommendation.");
    } finally {
      setAiBusy(false);
    }
  }

  async function save() {
    if (!valid) {
      toast.error("Splits must total exactly 100%.");
      return;
    }
    setBusy(true);
    try {
      let configId = config?.id;
      if (!configId) {
        const { data, error } = await supabase
          .from("routing_configs")
          .insert({ recipient_id: recipientId, name: "Default routing", is_active: true })
          .select("id")
          .single();
        if (error) throw new Error(error.message);
        configId = data.id;
      } else {
        const { error } = await supabase.from("routing_splits").delete().eq("config_id", configId);
        if (error) throw new Error(error.message);
      }

      if (!configId) throw new Error("Could not create routing configuration.");

      const { error: insertError } = await supabase.from("routing_splits").insert(
        rows.map((r, i) => ({
          config_id: configId,
          destination: r.destination as "sol",
          label: r.label || DESTINATION_LABELS[r.destination] || r.destination,
          percent: Number(r.percent),
          address: r.address || null,
          charity_id: r.destination === "charity" ? r.charity_id : null,
          sort_order: i,
        })),
      );
      if (insertError) throw new Error(insertError.message);

      await supabase
        .from("routing_configs")
        .update({ updated_at: new Date().toISOString() })
        .eq("id", configId);

      await queryClient.invalidateQueries({ queryKey: ["routing"] });
      toast.success("Routing saved. New fee events will use it.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save routing.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="panel space-y-5 p-5">
      <section className="rounded-md border border-border bg-background p-4">
        <div className="flex items-start gap-3">
          <Sparkles className="mt-0.5 size-4 shrink-0 text-info" />
          <div className="min-w-0 flex-1">
            <h3 className="text-sm font-semibold">Describe your payout goals</h3>
            <p className="mt-1 text-xs leading-5 text-muted-foreground">
              AI can draft a split using live destinations. Nothing changes until you review and save it.
            </p>
          </div>
        </div>
        <Textarea
          value={goal}
          onChange={(event) => setGoal(event.target.value)}
          placeholder="Example: Keep most fees in SOL, make income steadier with USDC, and give a small amount to charity."
          className="mt-3 min-h-24 resize-y bg-surface"
          maxLength={1200}
        />
        <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
          <span className="text-xs text-muted-foreground">{goal.length}/1200</span>
          <Button type="button" variant="outline" disabled={goal.trim().length < 12 || aiBusy} onClick={generateRecommendation}>
            <Sparkles className="size-4" /> {aiBusy ? "Recommending…" : "Recommend split"}
          </Button>
        </div>
        {recommendation ? <p className="mt-3 border-t border-border pt-3 text-sm leading-6">{recommendation}</p> : null}
      </section>

      {rows.map((row, i) => {
        const meta = ADAPTER_NOTE[row.destination];
        return (
          <div key={i} className="rounded-lg border border-border p-4">
            <div className="grid gap-4 sm:grid-cols-[1.4fr_1fr_auto]">
              <div className="space-y-2">
                <Label>Destination</Label>
                <Select
                  value={row.destination}
                  onValueChange={(v) =>
                    update(i, {
                      destination: v,
                      label: DESTINATION_LABELS[v] ?? v,
                      charity_id: null,
                      address: null,
                    })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {DESTINATIONS.map((d) => (
                      <SelectItem key={d} value={d}>
                        {DESTINATION_LABELS[d] ?? d}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Percent</Label>
                <Input
                  type="number"
                  min={1}
                  max={100}
                  value={row.percent}
                  className="num"
                  onChange={(e) => update(i, { percent: Number(e.target.value) })}
                />
              </div>
              <div className="flex items-end">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  aria-label="Remove split"
                  disabled={rows.length === 1}
                  onClick={() => setRows((prev) => prev.filter((_, idx) => idx !== i))}
                >
                  <Trash2 className="size-4" />
                </Button>
              </div>
            </div>

            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Label</Label>
                <Input value={row.label} onChange={(e) => update(i, { label: e.target.value })} />
              </div>
              {row.destination === "charity" ? (
                <div className="space-y-2">
                  <Label>Charity</Label>
                  <Select
                    value={row.charity_id ?? ""}
                    onValueChange={(v) => update(i, { charity_id: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a charity" />
                    </SelectTrigger>
                    <SelectContent>
                      {(charities.data ?? []).map((c) => (
                        <SelectItem key={c.id} value={c.id}>
                          {c.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ) : row.destination === "wallet_withdrawal" || row.destination === "split_recipient" ? (
                <div className="space-y-2">
                  <Label>
                    {row.destination === "wallet_withdrawal" ? "Wallet address" : "Recipient handle"}
                  </Label>
                  <Input
                    value={row.address ?? ""}
                    className="num"
                    placeholder={row.destination === "wallet_withdrawal" ? "Solana address" : "@handle"}
                    onChange={(e) => update(i, { address: e.target.value })}
                  />
                </div>
              ) : null}
            </div>

            {meta ? (
              <p className="mt-3 text-xs text-muted-foreground">{meta.note}</p>
            ) : null}
          </div>
        );
      })}

      <div className="flex flex-wrap items-center gap-3">
        <Button
          type="button"
          variant="outline"
          onClick={() =>
            setRows((prev) => [
              ...prev,
              { destination: "usdc", label: "Convert to USDC", percent: 0, address: null, charity_id: null },
            ])
          }
        >
          <Plus className="mr-1 size-4" /> Add split
        </Button>
        <span className={`num text-sm ${valid ? "text-success" : "text-warning"}`}>
          Total {total}% {valid ? "" : "— must equal 100%"}
        </span>
        <Button type="button" className="ml-auto" disabled={!valid || busy} onClick={save}>
          {busy ? "Saving…" : "Save routing"}
        </Button>
      </div>
      <p className="text-xs text-muted-foreground">
        Saving affects future fee events only. Already-processed events keep the routing they were
        settled with.
      </p>
    </div>
  );
}
