import { useCallback, useEffect, useRef, useState } from "react";
import { ImagePlus, Loader2, RefreshCw, Trash2, UploadCloud } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

const ACCEPTED = ["image/png", "image/jpeg", "image/webp"] as const;
const MAX_BYTES = 5 * 1024 * 1024;
const SIGNED_URL_SECONDS = 60 * 60 * 24 * 365 * 5;

export interface UploadedImage {
  url: string;
  path: string;
}

export function ImageUploader({
  value,
  onChange,
  userId,
  disabled,
}: {
  value: UploadedImage | null;
  onChange: (next: UploadedImage | null) => void;
  userId: string | null;
  disabled?: boolean;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [localPreview, setLocalPreview] = useState<string | null>(null);

  useEffect(() => {
    return () => {
      if (localPreview) URL.revokeObjectURL(localPreview);
    };
  }, [localPreview]);

  const upload = useCallback(
    async (file: File) => {
      setError(null);

      if (!ACCEPTED.includes(file.type as (typeof ACCEPTED)[number])) {
        setError("Use a PNG, JPG or WebP image.");
        return;
      }
      if (file.size > MAX_BYTES) {
        setError(`That file is ${(file.size / 1024 / 1024).toFixed(1)}MB. The limit is 5MB.`);
        return;
      }
      if (!userId) {
        setError("Verify your username before uploading a token image.");
        return;
      }

      const preview = URL.createObjectURL(file);
      setLocalPreview((old) => {
        if (old) URL.revokeObjectURL(old);
        return preview;
      });

      setUploading(true);
      setProgress(8);
      // Supabase Storage has no progress event in the browser SDK, so we show a
      // steady indeterminate-style climb that completes on the real response.
      const timer = setInterval(() => setProgress((p) => (p < 88 ? p + 6 : p)), 160);

      try {
        const ext = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : "jpg";
        const path = `${userId}/${crypto.randomUUID()}.${ext}`;
        const { error: uploadError } = await supabase.storage
          .from("token-images")
          .upload(path, file, { contentType: file.type, upsert: false });
        if (uploadError) throw new Error(uploadError.message);

        const { data, error: signError } = await supabase.storage
          .from("token-images")
          .createSignedUrl(path, SIGNED_URL_SECONDS);
        if (signError || !data?.signedUrl) {
          throw new Error(signError?.message ?? "Could not create an image link.");
        }

        setProgress(100);
        onChange({ url: data.signedUrl, path });
      } catch (e) {
        setError(e instanceof Error ? e.message : "Upload failed. Try again.");
        onChange(null);
        setLocalPreview((old) => {
          if (old) URL.revokeObjectURL(old);
          return null;
        });
      } finally {
        clearInterval(timer);
        setUploading(false);
        setTimeout(() => setProgress(0), 600);
      }
    },
    [onChange, userId],
  );

  function handleFiles(files: FileList | null) {
    const file = files?.[0];
    if (file) void upload(file);
  }

  async function remove() {
    const path = value?.path;
    onChange(null);
    setError(null);
    setLocalPreview((old) => {
      if (old) URL.revokeObjectURL(old);
      return null;
    });
    if (inputRef.current) inputRef.current.value = "";
    if (path) await supabase.storage.from("token-images").remove([path]);
  }

  const shownImage = value?.url ?? localPreview;

  return (
    <div className="space-y-2">
      <input
        ref={inputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        className="sr-only"
        onChange={(e) => handleFiles(e.target.files)}
        disabled={disabled || uploading}
      />

      {shownImage ? (
        <div className="panel flex flex-col gap-4 p-4 sm:flex-row sm:items-center">
          <img
            src={shownImage}
            alt="Token image preview"
            className="size-24 shrink-0 self-start rounded-xl border border-border object-cover sm:self-auto"
          />
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium">
              {uploading ? "Uploading…" : "Image ready"}
            </p>
            <p className="mt-0.5 text-xs text-muted-foreground">
              {uploading
                ? "Don't close this page."
                : "This image is saved with the token and shown on its public page."}
            </p>
            {uploading ? <Progress value={progress} className="mt-3 h-1.5" /> : null}
          </div>
          <div className="flex shrink-0 gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="press"
              disabled={uploading || disabled}
              onClick={() => inputRef.current?.click()}
            >
              <RefreshCw className="size-4" /> Replace
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="press text-destructive hover:text-destructive"
              disabled={uploading || disabled}
              onClick={() => void remove()}
            >
              <Trash2 className="size-4" />
              <span className="sr-only sm:not-sr-only">Remove</span>
            </Button>
          </div>
        </div>
      ) : (
        <button
          type="button"
          disabled={disabled || uploading}
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => {
            e.preventDefault();
            setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDragging(false);
            handleFiles(e.dataTransfer.files);
          }}
          className={cn(
            "flex w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-border bg-surface-2 px-4 py-10 text-center transition-all duration-200 hover:border-primary/50 hover:bg-primary/[0.03]",
            dragging && "scale-[1.01] border-primary bg-primary/5",
            (disabled || uploading) && "opacity-70",
          )}
        >
          {uploading ? (
            <Loader2 className="size-6 animate-spin text-primary" />
          ) : dragging ? (
            <UploadCloud className="size-6 text-primary" />
          ) : (
            <ImagePlus className="size-6 text-muted-foreground" />
          )}
          <span className="text-sm font-medium">
            {uploading ? "Uploading…" : "Drag an image here, or tap to choose"}
          </span>
          <span className="text-xs text-muted-foreground">PNG, JPG or WebP · up to 5MB</span>
          {uploading ? <Progress value={progress} className="mt-2 h-1.5 w-40" /> : null}
        </button>
      )}

      {error ? (
        <p role="alert" className="text-xs font-medium text-destructive">
          {error}
        </p>
      ) : null}
    </div>
  );
}
