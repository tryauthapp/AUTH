import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { networkLogo, resolveAssetLogo } from "@/lib/crypto-icons";


/**
 * Renders the real, project-standard logo for a crypto asset.
 *
 * Identity is driven by the registry key (chain + symbol, e.g. "ethereum:WBTC"),
 * never by symbol text alone, so wrapped/bridged assets never borrow the logo of
 * the asset they track. A network badge disambiguates the same symbol across
 * chains (USDC on Solana vs Base). When no vetted logo exists we fall back to a
 * neutral initials chip instead of inventing artwork.
 */

const SIZES = {
  xs: "size-5",
  sm: "size-8",
  md: "size-10",
  lg: "size-12",
  xl: "size-16",
} as const;

const TEXT = {
  xs: "text-[8px]",
  sm: "text-[10px]",
  md: "text-[11px]",
  lg: "text-xs",
  xl: "text-sm",
} as const;

const BADGE = {
  xs: "hidden",
  sm: "size-3",
  md: "size-3.5",
  lg: "size-4",
  xl: "size-5",
} as const;

export function AssetIcon({
  symbol,
  assetKey,
  chainKey,
  logoUrl,
  size = "md",
  showNetwork = true,
  className,
}: {
  symbol: string;
  assetKey?: string | null;
  chainKey?: string | null;
  logoUrl?: string | null;
  size?: keyof typeof SIZES;
  showNetwork?: boolean;
  className?: string;
}) {
  const preferred = logoUrl || resolveAssetLogo({ assetKey, symbol, chainKey });
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [preferred]);
  const src = failed ? null : preferred;
  const badge = showNetwork && chainKey ? networkLogo(chainKey) : null;
  const label = symbol.replace(/^\$/, "").slice(0, 4).toUpperCase();

  return (
    <span className={cn("relative inline-flex shrink-0", SIZES[size], className)}>
      {src ? (
        <img
          src={src}
          alt={`${symbol} logo`}
          loading="lazy"
          onError={() => setFailed(true)}
          className="size-full rounded-full bg-card object-contain ring-1 ring-border"
        />
      ) : (

        <span
          className={cn(
            "grid size-full place-items-center rounded-full bg-muted font-semibold text-muted-foreground ring-1 ring-border",
            TEXT[size],
          )}
          aria-label={`${symbol} logo unavailable`}
        >
          {label}
        </span>
      )}
      {badge ? (
        <img
          src={badge}
          alt=""
          aria-hidden
          loading="lazy"
          className={cn(
            "absolute -bottom-0.5 -right-0.5 rounded-full bg-card object-contain p-px ring-1 ring-border",
            BADGE[size],
          )}
        />
      ) : null}
    </span>
  );
}
