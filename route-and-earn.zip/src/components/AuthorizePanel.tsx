import { toast } from "sonner";
import { Fingerprint, ShieldAlert } from "lucide-react";
import { useWallet } from "@/lib/wallet/WalletProvider";
import { SignerError } from "@/lib/wallet/signer";
import { WALLETLESS_PLANNED_MESSAGE } from "@/lib/wallet/account";
import { Button } from "@/components/ui/button";
import { shortAddress } from "@/lib/format";
import { cn } from "@/lib/utils";

/**
 * Walletless authorization.
 *
 * The only path is a device passkey through a non-custodial embedded-wallet
 * provider — nothing to install, no seed phrase, nothing AUTH can sign on its
 * own. Until that provider is live the panel says so plainly instead of
 * offering an authorization method the product cannot actually perform.
 */
export function AuthorizePanel({
  label,
  onAuthorize,
  busy = false,
  disabled = false,
  className,
}: {
  label: string;
  onAuthorize: () => void | Promise<void>;
  busy?: boolean;
  disabled?: boolean;
  className?: string;
}) {
  const { address, walletless, authorize, connecting } = useWallet();
  const ready = Boolean(address);
  const passkeyLive = walletless === "live";

  if (ready) {
    return (
      <div className={cn("space-y-3", className)}>
        <Button
          className="press h-12 w-full rounded-full text-base font-semibold"
          onClick={() => void onAuthorize()}
          disabled={busy || disabled}
        >
          {busy ? "Working…" : label}
        </Button>
        <p className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          <Fingerprint className="size-3.5" />
          Passkey account · <span className="num">{shortAddress(address!, 4)}</span>
        </p>
      </div>
    );
  }

  return (
    <div className={cn("space-y-3", className)}>
      {passkeyLive ? (
        <>
          <Button
            className="press h-12 w-full rounded-full text-base font-semibold"
            disabled={connecting}
            onClick={async () => {
              try {
                await authorize();
              } catch (e) {
                toast.error(
                  e instanceof SignerError ? e.message : "Passkey authorization is unavailable.",
                );
              }
            }}
          >
            <Fingerprint className="size-4" />
            {label} with a passkey
          </Button>
          <p className="text-xs text-muted-foreground">
             You authorize every transfer yourself. AUTH never asks for a private key or seed
            phrase and never signs on your behalf.
          </p>
        </>
      ) : (
        <div className="flex gap-2.5 rounded-md border border-info/25 bg-info/8 p-3.5">
          <ShieldAlert className="mt-0.5 size-4 shrink-0 text-info" />
          <p className="text-xs text-muted-foreground">{WALLETLESS_PLANNED_MESSAGE}</p>
        </div>
      )}
    </div>
  );
}
