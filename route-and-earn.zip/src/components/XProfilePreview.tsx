import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ArrowUpRight, BadgeCheck, CircleAlert, Loader2, MapPin, RefreshCw, UserRound } from "lucide-react";
import { ExternalLink } from "@/components/ExternalLink";
import { socialProfileUrl } from "@/lib/external-links";
import { lookupXProfile, type XProfileResult } from "@/lib/x-profile.functions";
import { normalizeHandle as normalize, X_HANDLE_RE as HANDLE_RE, type XIdentity as XProfile } from "@/lib/x-identity";
import { Button } from "@/components/ui/button";
import { ProviderIcon } from "@/components/social/ProviderIcon";

interface Props {
  handle: string;
  confirmed: XProfile | null;
  onConfirm: (profile: XProfile) => void;
  onClear: () => void;
  /** Reports whether lookup is available, so the flow can fall back honestly. */
  onAvailabilityChange?: (available: boolean) => void;
}


export function XProfilePreview({
  handle,
  confirmed,
  onConfirm,
  onClear,
  onAvailabilityChange,
}: Props) {
  const lookup = useServerFn(lookupXProfile);
  const clean = normalize(handle);
  const [result, setResult] = useState<XProfileResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    if (!HANDLE_RE.test(clean)) {
      setResult(null);
      setLoading(false);
      return;
    }
    if (confirmed && confirmed.username.toLowerCase() === clean.toLowerCase()) return;

    let cancelled = false;
    setLoading(true);
    // Debounced: one request after typing settles, not per keystroke.
    const id = setTimeout(async () => {
      try {
        const res = await lookup({ data: { handle: clean } });
        if (!cancelled) setResult(res);
      } catch (e) {
        if (!cancelled) {
          setResult({
            status: "error",
            message: e instanceof Error ? e.message : "Lookup failed.",
          });
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }, 450);
    return () => {
      cancelled = true;
      clearTimeout(id);
    };
  }, [clean, attempt, lookup, confirmed]);

  useEffect(() => {
    if (!result) return;
    onAvailabilityChange?.(result.status !== "unconfigured" && result.status !== "unauthorized");
  }, [result, onAvailabilityChange]);

  if (!HANDLE_RE.test(clean)) return null;

  const shell =
    "mt-3 rounded-xl border border-border bg-card p-4 text-sm shadow-[0_1px_2px_rgba(16,18,27,0.04)]";

  if (confirmed && confirmed.username.toLowerCase() === clean.toLowerCase()) {
    return (
      <div
        className={`${shell} border-success/50 ring-4 ring-[color-mix(in_oklab,var(--color-success)_10%,transparent)]`}
      >
        <ProfileBody profile={confirmed} />
        <div className="mt-3 flex items-center justify-between gap-3 border-t border-border pt-3">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-success/12 px-2.5 py-1 text-xs font-semibold text-success">
            <BadgeCheck className="size-3.5" /> Recipient confirmed
          </span>
          <Button type="button" variant="ghost" size="sm" onClick={onClear}>
            Change
          </Button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className={`${shell} flex items-center gap-2 text-muted-foreground`}>
        <Loader2 className="size-4 animate-spin" />
        Looking up @{clean} on X…
      </div>
    );
  }

  if (!result) return null;

  if (result.status === "ok" && result.profile) {
    const profile = result.profile;
    return (
      <div className={shell}>
        <ProfileBody profile={profile} />
        <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground">
            Confirm this is the right person — fees route to this X identity.
          </p>
          <Button type="button" size="sm" onClick={() => onConfirm(profile)}>
            Confirm
          </Button>
        </div>
      </div>
    );
  }

  const retryable = result.status === "error" || result.status === "rate_limited";
  return (
    <div className={`${shell} flex items-start gap-2`}>
      <CircleAlert className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
      <div className="flex-1">
        <p className="font-medium">
          {result.status === "not_found"
            ? `No X account found for @${clean}.`
            : result.status === "unconfigured"
              ? "X profile lookup isn't configured on the server"
              : result.status === "unauthorized"
                ? "X credential rejected or lacks access"
                : result.status === "rate_limited"
                  ? "X lookup rate limited"
                  : "X lookup failed"}
        </p>
        {result.message ? (
          <p className="mt-1 text-xs text-muted-foreground">{result.message}</p>
        ) : null}
        {retryable ? (
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="mt-3"
            onClick={() => setAttempt((a) => a + 1)}
          >
            <RefreshCw className="size-3.5" /> Retry
          </Button>
        ) : null}
      </div>
    </div>
  );
}

function ProfileBody({ profile }: { profile: XProfile }) {
  // Built from the resolved handle against the official x.com host only.
  const profileUrl = socialProfileUrl("x", profile.username);
  const Header = profileUrl
    ? ({ children }: { children: React.ReactNode }) => (
        <ExternalLink
          href={profileUrl}
          title={`Open @${profile.username} on X (opens in a new tab)`}
          className="group flex flex-1 items-start gap-3"
        >
          {children}
        </ExternalLink>
      )
    : ({ children }: { children: React.ReactNode }) => (
        <div className="flex flex-1 items-start gap-3">{children}</div>
      );
  return (
    <Header>
      <span className="relative shrink-0">
        {profile.avatarUrl ? (
          <img
            src={profile.avatarUrl}
            alt=""
            className="size-12 rounded-full border border-border object-cover"
          />
        ) : (
          <span className="flex size-12 items-center justify-center rounded-full border border-border bg-muted">
            <UserRound className="size-5 text-muted-foreground" />
          </span>
        )}
        <span className="absolute -bottom-0.5 -right-0.5 grid size-5 place-items-center rounded-full border border-border bg-card text-platform-x">
          <ProviderIcon provider="x" className="size-2.5" />
        </span>
      </span>
      <div className="min-w-0 flex-1">
        <p className="flex items-center gap-1.5 font-semibold">
          <span className="truncate group-hover:underline">{profile.name}</span>
          {profile.verified ? (
            <BadgeCheck className="size-4 shrink-0 text-primary" aria-label="Verified by X" />
          ) : null}
          {profileUrl ? (
            <ArrowUpRight className="size-3.5 shrink-0 text-muted-foreground opacity-60 transition-opacity group-hover:opacity-100" />
          ) : null}
        </p>
        <p className="text-xs text-muted-foreground group-hover:underline">@{profile.username}</p>
        {profile.description ? (
          <p className="mt-1.5 line-clamp-3 text-xs leading-5 text-muted-foreground">
            {profile.description}
          </p>
        ) : null}
        <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
          {profile.followers !== null ? (
            <span>
              <span className="num font-medium text-foreground">
                {profile.followers.toLocaleString()}
              </span>{" "}
              followers
            </span>
          ) : null}
          {profile.location ? (
            <span className="inline-flex items-center gap-1">
              <MapPin className="size-3" />
              {profile.location}
            </span>
          ) : null}
        </div>
      </div>
    </Header>
  );
}
