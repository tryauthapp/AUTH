import { Moon, Sun } from "lucide-react";
import { useTheme, type Theme } from "@/hooks/useTheme";
import { cn } from "@/lib/utils";

const OPTIONS: { value: Theme; label: string; icon: typeof Sun }[] = [
  { value: "light", label: "Light", icon: Sun },
  { value: "dark", label: "Dark", icon: Moon },
];

/**
 * Explicit Light / Dark appearance control. Light is the product default;
 * the choice is stored locally and restored on every future visit.
 */
export function ThemeSetting({ className }: { className?: string }) {
  const { theme, setTheme } = useTheme();

  return (
    <section className={cn("workspace-panel p-5 sm:p-6", className)}>
      <p className="workspace-label">Appearance</p>
      <h3 className="mt-2 text-base font-semibold tracking-tight">Theme</h3>
      <p className="mt-1 text-sm text-muted-foreground">
        AUTH uses light mode by default. Switch to dark whenever you prefer — your choice is
        remembered on this device.
      </p>
      <div
        role="radiogroup"
        aria-label="Theme"
        className="mt-4 inline-flex rounded-lg border border-border bg-surface-2 p-1"
      >
        {OPTIONS.map((option) => {
          const active = theme === option.value;
          const Icon = option.icon;
          return (
            <button
              key={option.value}
              type="button"
              role="radio"
              aria-checked={active}
              onClick={() => setTheme(option.value)}
              className={cn(
                "press inline-flex items-center gap-2 rounded-md px-4 py-2 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                active
                  ? "bg-card text-foreground shadow-float"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              <Icon className="size-4" />
              {option.label}
            </button>
          );
        })}
      </div>
    </section>
  );
}
