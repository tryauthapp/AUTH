export function LegalPage({
  title,
  sections,
}: {
  title: string;
  sections: { heading: string; body: string[] }[];
}) {
  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-10 sm:px-7 sm:py-12">
      <h1 className="text-4xl sm:text-5xl">{title}</h1>
      <p className="mt-2 text-xs uppercase tracking-widest text-warning">
        Placeholder — not legal advice
      </p>
      <div className="mt-8 space-y-6">
        {sections.map((s) => (
          <section key={s.heading} className="panel p-6">
            <h2 className="text-base font-semibold">{s.heading}</h2>
            <div className="mt-2 space-y-2 text-sm text-muted-foreground">
              {s.body.map((p, i) => (
                <p key={i}>{p}</p>
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
