import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import { myClaimable, claimAll } from "@/lib/claims.functions";
import { Button } from "@/components/ui/button";
import { SectionHeading, StatusPill } from "@/components/primitives";
import { SocialIdentity } from "@/components/social/SocialIdentity";
import { shortAddress, usd } from "@/lib/format";

/**
 * One balance for everything owed to this account's verified identities:
 * direct payments and creator fees, summed from the identity ledger.
 */
export function ClaimBalance({ enabled }: { enabled: boolean }) {
  const queryClient = useQueryClient();
  const load = useServerFn(myClaimable);
  const claim = useServerFn(claimAll);
  const [claiming, setClaiming] = useState(false);

  const balance = useQuery({
    queryKey: ["my-claimable"],
    enabled,
    queryFn: () => load(),
  });

  if (!enabled) return null;

  const data = balance.data;
  const total = data?.total ?? { SOL: 0, USDC: 0 };
  const hasFunds = total.SOL > 0 || total.USDC > 0;

  async function onClaim() {
    setClaiming(true);
    try {
      const res = await claim({ data: {} });
      if (res.ok) toast.success(res.message);
      else toast.error(res.message);
      for (const f of res.failed) toast.error(`${f.asset}: ${f.reason}`);
      await queryClient.invalidateQueries();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "The claim could not be completed.");
    } finally {
      setClaiming(false);
    }
  }

  return (
    <section className="space-y-4">
      <SectionHeading
        title="Available to claim"
        description="Payments and creator fees sent to the accounts you've verified."
      />

      <div className="rounded-2xl border border-border bg-card p-5 sm:p-6">
        {balance.isLoading ? (
          <p className="text-sm text-muted-foreground">Loading your balance…</p>
        ) : (
          <>
            <p className="text-4xl font-semibold tracking-tight">
              {data?.approxUsd === null ? "—" : usd(data?.approxUsd ?? 0)}
            </p>
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs uppercase tracking-wide text-muted-foreground">SOL</p>
                <p className="text-lg font-medium">{total.SOL.toFixed(4)}</p>
              </div>
              <div>
                <p className="text-xs uppercase tracking-wide text-muted-foreground">USDC</p>
                <p className="text-lg font-medium">{total.USDC.toFixed(2)}</p>
              </div>
            </div>

            {data?.identities.length ? (
              <ul className="mt-5 space-y-3 border-t border-border pt-4">
                {data.identities.map((identity) => (
                  <li
                    key={identity.recipientId}
                    className="flex flex-wrap items-center justify-between gap-3"
                  >
                    <SocialIdentity
                      provider={identity.provider}
                      handle={identity.handle}
                      displayName={identity.displayName}
                      avatarUrl={identity.avatarUrl}
                      size="sm"
                    />
                    <div className="text-right text-sm">
                      <p className="font-medium">
                        {identity.SOL > 0 ? `${identity.SOL.toFixed(4)} SOL` : null}
                        {identity.SOL > 0 && identity.USDC > 0 ? " · " : null}
                        {identity.USDC > 0 ? `${identity.USDC.toFixed(2)} USDC` : null}
                        {identity.SOL === 0 && identity.USDC === 0 ? "Nothing yet" : null}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Payments {identity.sources.payments.SOL.toFixed(2)} SOL · Creator fees{" "}
                        {identity.sources.creatorFees.SOL.toFixed(2)} SOL
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            ) : null}

            {data?.claiming.SOL || data?.claiming.USDC ? (
              <p className="mt-4">
                <StatusPill status="pending">Claim in progress</StatusPill>
              </p>
            ) : null}

            <div className="mt-6 space-y-2">
              <Button
                className="w-full"
                size="lg"
                disabled={!hasFunds || claiming || !data?.destination}
                onClick={onClaim}
              >
                {claiming ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                {claiming ? "Claiming…" : "Claim all"}
              </Button>
              {data?.destination ? (
                <p className="text-xs text-muted-foreground">
                  Paid out to{" "}
                  {data.destination.kind === "auth_wallet"
                    ? "your AUTH wallet"
                    : "your verified wallet"}{" "}
                  {shortAddress(data.destination.address)} · network cost about{" "}
                  {data.estimatedNetworkFeeSol.toFixed(6)} SOL.
                </p>
              ) : (
                <p className="text-xs text-muted-foreground">
                  Verify a social account to get a payout wallet.
                </p>
              )}
            </div>
          </>
        )}
      </div>
    </section>
  );
}
