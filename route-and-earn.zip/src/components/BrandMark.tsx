import { cn } from "@/lib/utils";
import authMark from "@/assets/auth-mark.png.asset.json";

/** AUTH brand mark — the official A logo. Black on light, white on dark. */
export function BrandMark({ className }: { className?: string }) {
  return (
    <span
      className={cn("grid size-8 shrink-0 place-items-center overflow-hidden", className)}
      aria-hidden="true"
    >
      <img
        src={authMark.url}
        alt=""
        className="size-full object-contain dark:invert"
      />
    </span>
  );
}

export function BrandLockup({ className }: { className?: string }) {
  return (
    <span className={cn("flex items-center gap-2", className)}>
      <BrandMark className="size-8" />
      <span className="text-lg font-extrabold tracking-tight">AUTH</span>
    </span>
  );
}
