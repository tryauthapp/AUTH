import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ShieldCheck, ExternalLink } from "lucide-react";
import { useWallet } from "@/lib/wallet/WalletProvider";
import { AccountPanel } from "@/components/AccountPanel";
import { createWalletNonce, ownershipMessage, verifyWalletOwnership } from "@/lib/wallet.functions";
import { Button } from "@/components/ui/button";
import { explorerAddress } from "@/lib/solana";
import { shortAddress } from "@/lib/format";

/**
 * Payout destination for a claimed handle. Ownership is proved by authorizing a
 * plain-text message from the account — no transaction, no funds, no key.
 */
export function PayoutAccountPanel({ recipientId }: { recipientId?: string | null }) {
  const { address, signer } = useWallet();
  const queryClient = useQueryClient();
  const nonceFn = useServerFn(createWalletNonce);
  const verifyFn = useServerFn(verifyWalletOwnership);
  const [busy, setBusy] = useState(false);

  async function verify() {
    if (!signer || !address) return;
    setBusy(true);
    try {
      const { nonce } = await nonceFn({ data: {} });
      const signed = await signer.signMessage(ownershipMessage(address, nonce));
      const res = await verifyFn({
        data: {
          address,
          signature: signed.signature,
          nonce,
          provider: signer.key,
          recipientId: recipientId ?? null,
        },
      });
      if (!res.ok) {
        toast.error(res.message);
        return;
      }
      await queryClient.invalidateQueries();
      toast.success("Payout destination verified");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Verification failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="panel space-y-3 p-4">
      <div className="flex flex-wrap items-center gap-2">
        <AccountPanel />
        {address ? (
          <a
            href={explorerAddress(address)}
            target="_blank"
            rel="noreferrer noopener"
            className="num inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
          >
            {shortAddress(address, 6)} <ExternalLink className="size-3" />
          </a>
        ) : null}
      </div>
      {address ? (
        <Button size="sm" className="press" onClick={verify} disabled={busy}>
          <ShieldCheck className="size-4" />
          {busy ? "Waiting for authorization…" : "Verify ownership"}
        </Button>
      ) : null}
      <p className="text-xs text-muted-foreground">
        Verification authorizes a plain-text message. It moves no funds and approves no transaction.
      </p>
    </div>
  );
}
