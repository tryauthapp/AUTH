import { toast } from "sonner";
import { Fingerprint, ShieldAlert } from "lucide-react";
import { useWallet } from "@/lib/wallet/WalletProvider";
import { SignerError } from "@/lib/wallet/signer";
import { WALLETLESS_PLANNED_MESSAGE } from "@/lib/wallet/account";
import { Button } from "@/components/ui/button";
import { shortAddress } from "@/lib/format";

/**
 * Payment account view: a walletless passkey account. No extension, no seed
 * phrase, and AUTH holds no keys.
 */
export function AccountPanel() {
  const { address, walletless, authorize, connecting, forget } = useWallet();

  if (address) {
    return (
      <div className="space-y-2">
        <p className="flex flex-wrap items-center gap-2 text-sm">
          <Fingerprint className="size-4 text-muted-foreground" />
          <span className="font-medium">Passkey account</span>
          <span className="num">{shortAddress(address, 6)}</span>
          <span className="text-xs text-muted-foreground">Solana mainnet</span>
        </p>
        <Button
          variant="outline"
          size="sm"
          className="press rounded-full"
          onClick={() => void forget()}
        >
          Forget on this device
        </Button>
      </div>
    );
  }

  if (walletless !== "live") {
    return (
      <div className="flex gap-2.5 rounded-xl border border-border bg-secondary/40 p-3.5">
        <ShieldAlert className="mt-0.5 size-4 shrink-0 text-warning" />
        <p className="text-xs text-muted-foreground">{WALLETLESS_PLANNED_MESSAGE}</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground">
         Create a passkey account — nothing to install, no seed phrase, and AUTH never holds your
        keys.
      </p>
      <Button
        className="press rounded-full"
        disabled={connecting}
        onClick={async () => {
          try {
            await authorize();
          } catch (e) {
            toast.error(
              e instanceof SignerError ? e.message : "Passkey accounts are unavailable right now.",
            );
          }
        }}
      >
        <Fingerprint className="size-4" /> Set up passkey account
      </Button>
    </div>
  );
}
