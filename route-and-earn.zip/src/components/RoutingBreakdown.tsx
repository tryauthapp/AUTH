import { DESTINATION_LABELS, pct, shortAddress } from "@/lib/format";
import type { RoutingSplitRow } from "@/lib/queries";

const BAR_TONE: Record<string, string> = {
  sol: "bg-chart-2",
  usdc: "bg-chart-5",
  wallet_withdrawal: "bg-chart-2",
  x_money: "bg-chart-4",
  buyback: "bg-primary",
  burn: "bg-destructive",
  charity: "bg-chart-3",
  split_recipient: "bg-chart-4",
};

export function RoutingBreakdown({
  splits,
  compact,
}: {
  splits: RoutingSplitRow[];
  compact?: boolean;
}) {
  const ordered = [...splits].sort((a, b) => a.sort_order - b.sort_order);
  const total = ordered.reduce((a, b) => a + Number(b.percent), 0);

  return (
    <div>
      <div className="flex h-2 w-full overflow-hidden rounded-full bg-muted">
        {ordered.map((s) => (
          <div
            key={s.id}
            className={BAR_TONE[s.destination] ?? "bg-muted-foreground"}
            style={{ width: `${Number(s.percent)}%` }}
            title={`${s.label} — ${pct(Number(s.percent))}`}
          />
        ))}
      </div>
      <ul className="mt-3 space-y-2">
        {ordered.map((s) => (
          <li key={s.id} className="flex items-center gap-3 text-sm">
            <span className={`size-2 rounded-full ${BAR_TONE[s.destination] ?? "bg-muted-foreground"}`} />
            <span className="num w-14 shrink-0 text-right font-medium">{pct(Number(s.percent))}</span>
            <span className="truncate">{s.label}</span>
            {!compact ? (
              <span className="ml-auto flex items-center gap-2 text-xs text-muted-foreground">
                <span className="rounded border border-border px-1.5 py-0.5">
                  {DESTINATION_LABELS[s.destination] ?? s.destination}
                </span>
                {s.address ? <span className="num hidden sm:inline">{shortAddress(s.address)}</span> : null}
              </span>
            ) : null}
          </li>
        ))}
      </ul>
      {Math.round(total) !== 100 ? (
        <p className="mt-2 text-xs text-destructive">
          Routing does not sum to 100% (currently {pct(total)}).
        </p>
      ) : null}
    </div>
  );
}
