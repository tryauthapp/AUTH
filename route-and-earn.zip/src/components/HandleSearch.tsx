import { useMemo, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { recipientsQuery } from "@/lib/queries";
import { Input } from "@/components/ui/input";

/** Search people by X username. Always offers the typed handle, claimed or not. */
export function HandleSearch({ autoFocus = false }: { autoFocus?: boolean }) {
  const [term, setTerm] = useState("");
  const navigate = useNavigate();
  const recipients = useQuery(recipientsQuery());

  const clean = term.trim().replace(/^@/, "");
  const matches = useMemo(() => {
    if (!clean) return [];
    const lower = clean.toLowerCase();
    return (recipients.data ?? [])
      .filter(
        (r) =>
          r.handle.toLowerCase().includes(lower) ||
          (r.display_name ?? "").toLowerCase().includes(lower),
      )
      .slice(0, 6);
  }, [clean, recipients.data]);

  const exact = matches.some((m) => m.handle.toLowerCase() === clean.toLowerCase());

  return (
    <div className="relative">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (!clean) return;
          navigate({ to: "/u/$handle", params: { handle: clean } });
        }}
        className="relative"
      >
        <Search className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={term}
          autoFocus={autoFocus}
          onChange={(e) => setTerm(e.target.value)}
          placeholder="Search AUTH"
          aria-label="Search AUTH usernames"
          className="h-9 rounded-md border-border bg-surface pl-10 text-xs focus:border-input"
        />
      </form>

      {clean ? (
        <ul className="absolute inset-x-0 top-full z-30 mt-2 overflow-hidden rounded-md border border-border bg-popover py-2 shadow-float">
          {matches.map((r) => (
            <li key={r.id}>
              <Link
                to="/u/$handle"
                params={{ handle: r.handle }}
                className="flex items-center justify-between gap-2 rounded-lg px-2 py-2 transition-colors hover:bg-secondary"
                onClick={() => setTerm("")}
              >
                <span className="truncate text-sm font-medium">@{r.handle}</span>
                <span className="truncate text-xs text-muted-foreground">
                  {r.claimed_by ? "Claimed" : "Unclaimed"}
                </span>
              </Link>
            </li>
          ))}
          {!exact ? (
            <li>
              <Link
                to="/pay"
                search={{ to: clean }}
                className="flex items-center justify-between gap-2 rounded-lg px-2 py-2 text-sm transition-colors hover:bg-secondary"
                onClick={() => setTerm("")}
              >
                <span className="truncate font-medium">Pay @{clean}</span>
                <span className="text-xs text-muted-foreground">Any X username</span>
              </Link>
            </li>
          ) : null}
        </ul>
      ) : null}
    </div>
  );
}
