import { cn } from "@/lib/utils";

/**
 * Deterministic artwork for identities and tokens.
 * Uses real avatar/token images when the data has them, and a stable
 * generated gradient with initials otherwise — never a random placeholder.
 */
function hash(input: string) {
  let h = 0;
  for (let i = 0; i < input.length; i += 1) h = (h * 31 + input.charCodeAt(i)) % 100000;
  return h;
}

function gradient(seed: string) {
  const h = hash(seed);
  const a = h % 360;
  const b = (a + 40 + (h % 60)) % 360;
  return `linear-gradient(135deg, oklch(0.72 0.15 ${a}), oklch(0.55 0.16 ${b}))`;
}

const SIZES = {
  sm: "size-8 text-[11px]",
  md: "size-10 text-xs",
  lg: "size-12 text-sm",
  xl: "size-20 text-xl",
} as const;

export function IdentityAvatar({
  handle,
  src,
  size = "md",
  className,
}: {
  handle: string;
  src?: string | null;
  size?: keyof typeof SIZES;
  className?: string;
}) {
  const initials = handle.replace(/^@/, "").slice(0, 2).toUpperCase();
  return (
    <span
      className={cn(
        "grid shrink-0 place-items-center overflow-hidden rounded-full border border-border font-bold text-white/95",
        SIZES[size],
        className,
      )}
      style={src ? undefined : { backgroundImage: gradient(handle) }}
      aria-hidden
    >
      {src ? (
        <img src={src} alt="" className="size-full object-cover" loading="lazy" />
      ) : (
        initials
      )}
    </span>
  );
}

export function TokenAvatar({
  symbol,
  src,
  size = "md",
  className,
}: {
  symbol: string;
  src?: string | null;
  size?: keyof typeof SIZES;
  className?: string;
}) {
  const initials = symbol.replace(/^\$/, "").slice(0, 3).toUpperCase();
  return (
    <span
      className={cn(
        "grid shrink-0 place-items-center overflow-hidden rounded-xl border border-border font-bold text-white/95",
        SIZES[size],
        className,
      )}
      style={src ? undefined : { backgroundImage: gradient(`t:${symbol}`) }}
      aria-hidden
    >
      {src ? <img src={src} alt="" className="size-full object-cover" loading="lazy" /> : initials}
    </span>
  );
}
