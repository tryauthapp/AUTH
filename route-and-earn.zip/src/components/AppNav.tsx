import { useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  Bell,
  Compass,
  Home,
  Rocket,
  Send,
  ShieldCheck,
  User,
  BookOpen,
  Rows3,
  Plug,
  MoreHorizontal,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { useSession } from "@/hooks/useSession";
import { Button } from "@/components/ui/button";
import { BrandMark } from "@/components/BrandMark";
import { ThemeToggle } from "@/components/ThemeToggle";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { MobileTopLinks } from "@/components/TopLinks";

type NavItem = { to: string; label: string; icon: LucideIcon; exact?: boolean };

/** Core product destinations. */
const MAIN_ITEMS: NavItem[] = [
  { to: "/", label: "Home", icon: Home, exact: true },
  { to: "/explore", label: "Explore", icon: Compass },
  { to: "/pay", label: "Pay", icon: Send },
  { to: "/launch", label: "Launch", icon: Rocket },
];

/** Personal and utility destinations. */
const PERSONAL_ITEMS: NavItem[] = [
  { to: "/notifications", label: "Notifications", icon: Bell },
  { to: "/profile", label: "Profile", icon: User },
  { to: "/ledger", label: "Fee Ledger", icon: Rows3 },
  { to: "/integrations", label: "Integrations", icon: Plug },
  { to: "/docs", label: "Docs", icon: BookOpen },
];

export const NAV_ITEMS: NavItem[] = [...MAIN_ITEMS, ...PERSONAL_ITEMS];

const navLinkClass =
  "group flex w-full items-center gap-3 rounded-lg px-3 py-2 text-[14px] font-medium text-muted-foreground transition-colors hover:bg-sidebar-accent hover:text-foreground";
const navActiveClass = "nav-active bg-sidebar-accent font-semibold text-foreground";

/** Desktop left rail — primary product navigation. */
export function AppSidebar() {
  const { isAdmin } = useSession();


  return (
    <aside className="sticky top-0 hidden h-screen w-[212px] shrink-0 flex-col border-r border-sidebar-border bg-sidebar px-3 py-4 md:flex xl:w-[232px]">
      <Link
        to="/"
        aria-label="AUTH home"
        className="mb-6 flex items-center gap-2.5 px-2 py-1"
      >
        <BrandMark className="size-7" />
        <span className="text-sm font-bold tracking-[0.18em]">AUTH</span>
      </Link>

      <p className="px-3 pb-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground/70">
        Main
      </p>
      <nav className="flex flex-col gap-0.5">
        {MAIN_ITEMS.map((item) => (
          <Link
            key={item.to}
            to={item.to}
            title={item.label}
            className={navLinkClass}
            activeProps={{ className: navActiveClass }}
            {...(item.exact ? { activeOptions: { exact: true } } : {})}
          >
            <item.icon className="size-[18px] shrink-0" strokeWidth={1.7} />
            <span>{item.label}</span>
          </Link>
        ))}
      </nav>

      <p className="mt-6 px-3 pb-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground/70">
        Personal
      </p>
      <nav className="flex flex-col gap-0.5">
        {PERSONAL_ITEMS.map((item) => (
          <Link
            key={item.to}
            to={item.to}
            title={item.label}
            className={navLinkClass}
            activeProps={{ className: navActiveClass }}
          >
            <item.icon className="size-[18px] shrink-0" strokeWidth={1.7} />
            <span>{item.label}</span>
          </Link>
        ))}
        {isAdmin ? (
          <Link to="/admin" title="Admin" className={navLinkClass} activeProps={{ className: navActiveClass }}>
            <ShieldCheck className="size-[18px] shrink-0" strokeWidth={1.7} />
            <span>Admin</span>
          </Link>
        ) : null}
      </nav>


      <div className="mt-auto border-t border-sidebar-border pt-3">
        <div className="flex items-center justify-between px-2">
          <span className="workspace-label inline-flex items-center gap-1.5 text-success">
            <span className="size-1.5 rounded-full bg-success" />
            Mainnet
          </span>
          <ThemeToggle />
        </div>
      </div>
    </aside>
  );
}

/** Mobile bottom navigation. */
export function MobileBottomNav() {
  const [moreOpen, setMoreOpen] = useState(false);
  const { isAdmin } = useSession();
  const more: NavItem[] = [
    ...PERSONAL_ITEMS.filter((item) => item.to !== "/profile"),
    ...(isAdmin ? [{ to: "/admin", label: "Admin", icon: ShieldCheck } as NavItem] : []),
  ];

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-50 border-t border-border bg-background/88 backdrop-blur-xl md:hidden"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      aria-label="Primary"
    >
      <ul className="mx-auto flex max-w-lg items-stretch justify-between px-1">
        {NAV_ITEMS.filter((item) => ["/", "/explore", "/pay", "/launch", "/profile"].includes(item.to)).map((item) => (
          <li key={item.to} className="flex-1">
            <Link
              to={item.to}
              className="press mx-0.5 flex h-[58px] flex-col items-center justify-center gap-1 text-[10px] font-medium text-muted-foreground transition-colors"
              activeProps={{ className: "text-foreground" }}
              {...(item.exact ? { activeOptions: { exact: true } } : {})}
            >
              <item.icon className="size-[21px]" />
              <span>{item.label}</span>
            </Link>
          </li>
        ))}
        <li className="flex-1">
          <Sheet open={moreOpen} onOpenChange={setMoreOpen}>
            <SheetTrigger asChild>
              <button
                type="button"
                aria-label="More destinations"
                className="press mx-0.5 flex h-[58px] w-full flex-col items-center justify-center gap-1 text-[10px] font-medium text-muted-foreground transition-colors"
              >
                <MoreHorizontal className="size-[21px]" />
                <span>More</span>
              </button>
            </SheetTrigger>
            <SheetContent side="bottom" className="rounded-t-2xl border-border pb-8">
              <SheetHeader className="text-left">
                <SheetTitle>More</SheetTitle>
              </SheetHeader>
              <ul className="mt-2 grid gap-1">
                {more.map((item) => (
                  <li key={item.to}>
                    <Link
                      to={item.to}
                      onClick={() => setMoreOpen(false)}
                      className="press flex items-center gap-3 rounded-lg px-3 py-3 text-[15px] font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                      activeProps={{ className: "bg-secondary text-foreground" }}
                    >
                      <item.icon className="size-[18px]" />
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </SheetContent>
          </Sheet>
        </li>
      </ul>
    </nav>
  );
}

/** Compact mobile top bar — brand, theme, wallet. */
export function MobileTopBar() {
  return (
    <header className="sticky top-0 z-40 flex h-14 items-center gap-2 border-b border-border bg-background/90 px-4 backdrop-blur-md md:hidden">
      <Link to="/" aria-label="AUTH home" className="flex items-center gap-2">
        <BrandMark className="size-7" />
        <span className="text-base font-extrabold">AUTH</span>
      </Link>
      <div className="ml-auto flex items-center gap-1">
        <MobileTopLinks />
        <Button asChild size="icon" variant="ghost" className="size-8" title="Notifications">
          <Link to="/notifications" aria-label="Notifications">
            <Bell className="size-4" />
          </Link>
        </Button>
        <ThemeToggle />
      </div>
    </header>
  );
}
