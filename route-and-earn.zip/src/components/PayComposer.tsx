import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ArrowLeft, AtSign, CheckCircle2, ExternalLink, Loader2, Send } from "lucide-react";
import {
  createPayment,
  lookupPayee,
  settlePaymentSignature,
  type PayeeLookup,
  type PaymentPlanResponse,
} from "@/lib/payments.functions";
import { assetsQuery, payableAssets, type AssetRow } from "@/lib/assets";
import { getChainAdapter } from "@/integrations/chains/registry";
import { useWallet } from "@/lib/wallet/WalletProvider";
import { AuthorizePanel } from "@/components/AuthorizePanel";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { AssetIcon } from "@/components/AssetIcon";
import { PlatformIdentityPicker } from "@/components/social/PlatformIdentityPicker";
import { ProviderIcon } from "@/components/social/ProviderIcon";
import type { SocialProvider } from "@/lib/social/providers";
import { SOCIAL_PROVIDERS } from "@/lib/social/providers";
import { StatusPill } from "@/components/primitives";
import { explorerTx } from "@/lib/solana";
import { shortAddress, usd } from "@/lib/format";
import { cn } from "@/lib/utils";

type Plan = NonNullable<PaymentPlanResponse["plan"]>;
type Step = "compose" | "review" | "done";

/**
 * @username → asset → amount → review → wallet signature → on-chain
 * confirmation → receipt. Assets come from the registry; only live, payable
 * ones are selectable.
 */
export function PayComposer({
  initialHandle = "",
  initialProvider = "x",
}: {
  initialHandle?: string;
  initialProvider?: SocialProvider;
}) {
  const { address, signer } = useWallet();
  const queryClient = useQueryClient();
  const lookup = useServerFn(lookupPayee);
  const create = useServerFn(createPayment);
  const settle = useServerFn(settlePaymentSignature);
  const assets = useQuery(assetsQuery());

  // Only the two assets this flow actually supports: USDC and native SOL,
  // both on Solana mainnet. USDC is listed first to match the label.
  const live = useMemo(() => {
    const payable = payableAssets(assets.data ?? []);
    const pick = (symbol: string) =>
      payable.find((a) => a.chain_key === "solana" && a.symbol === symbol);
    return [pick("USDC"), pick("SOL")].filter((a): a is AssetRow => Boolean(a));
  }, [assets.data]);

  const [provider, setProvider] = useState<SocialProvider>(initialProvider);
  const [handle, setHandle] = useState(initialHandle);
  const [assetKey, setAssetKey] = useState<string>("solana:SOL");
  const [amount, setAmount] = useState("");

  const [note, setNote] = useState("");
  const [payee, setPayee] = useState<PayeeLookup | null>(null);
  const [checking, setChecking] = useState(false);
  const [step, setStep] = useState<Step>("compose");
  const [busy, setBusy] = useState<null | "creating" | "signing" | "confirming">(null);
  const [result, setResult] = useState<
    { kind: "sent" | "reserved" | "error"; message: string; signature?: string } | null
  >(null);

  const clean = handle.trim().replace(/^@/, "");
  const selected: AssetRow | undefined =
    live.find((a) => a.key === assetKey) ?? live[0];
  const chain = getChainAdapter(selected?.chain_key);



  useEffect(() => {
    if (selected && selected.key !== assetKey) setAssetKey(selected.key);
  }, [selected, assetKey]);

  const providerMetaRow = SOCIAL_PROVIDERS.find((p) => p.id === provider)!;

  useEffect(() => {
    if (!providerMetaRow.handlePattern.test(clean)) {
      setPayee(null);
      return;
    }
    let active = true;
    setChecking(true);
    const t = setTimeout(async () => {
      try {
        const res = await lookup({ data: { handle: clean, provider } });
        if (active) setPayee(res);
      } catch {
        if (active) setPayee(null);
      } finally {
        if (active) setChecking(false);
      }
    }, 350);
    return () => {
      active = false;
      clearTimeout(t);
      setChecking(false);
    };
  }, [clean, provider, providerMetaRow, lookup]);

  function toReview() {
    const value = Number(amount);
    if (!clean) {
      toast.error(`Enter a ${providerMetaRow.label} username.`);
      return;
    }
    if (!(value > 0)) {
      toast.error("Enter an amount greater than zero.");
      return;
    }
    if (!selected) {
      toast.error("Pick an asset.");
      return;
    }
    setResult(null);
    setStep("review");
  }

  async function confirmAndSign() {
    const value = Number(amount);
    if (!address || !signer || !selected) {
      toast.error("Set up your payment account to authorize this transfer.");
      return;
    }
    setBusy("creating");
    try {
      const res: PaymentPlanResponse = await create({
        data: {
          handle: clean,
          provider,
          assetKey: selected.key,
          amount: value,
          note,
          senderWallet: address,
        },
      });
      if (!res.ok) {
        setBusy(null);
        setStep("done");
        setResult({ kind: "error", message: res.message ?? "Could not create this payment." });
        return;
      }
      if (!res.plan) {
        setBusy(null);
        setStep("done");
        await queryClient.invalidateQueries();
        setResult({
          kind: "reserved",
          message:
            res.message ??
            `@${clean} has no verified payout wallet yet, so this payment is reserved and unfunded.`,
        });
        return;
      }

      const plan: Plan = res.plan;
      const toDeposit = res.destinationKind === "identity_deposit";
      setBusy("signing");
      const signature = await signer.signAndSendTransfer({
        to: plan.to,
        asset: plan.asset,
        mint: plan.mint,
        tokenProgram: plan.tokenProgram,
        amount: plan.amount,
        decimals: plan.decimals,
        blockhash: plan.blockhash,
        lastValidBlockHeight: plan.lastValidBlockHeight,
        destinationTokenAccountExists: plan.destinationTokenAccountExists,
        memo: plan.memo,
      });

      setBusy("confirming");
      const done = await settle({ data: { paymentId: plan.paymentId, signature } });
      await queryClient.invalidateQueries();
      setBusy(null);
      setStep("done");
      if (done.ok) {
        const message = toDeposit
          ? `Sent. The funds are held for @${clean} and only they can claim them, once they verify the account.`
          : (done.message ?? "Payment submitted.");
        setResult({ kind: "sent", message, signature });
        toast.success(toDeposit ? "Sent — they can claim it any time" : (done.message ?? "Payment sent"));
      } else {
        setResult({ kind: "error", message: done.message ?? "The payment failed.", signature });
      }
    } catch (e) {
      setBusy(null);
      setStep("done");
      setResult({
        kind: "error",
        message: e instanceof Error ? e.message : "The wallet could not complete this payment.",
      });
    }
  }

  function reset() {
    setStep("compose");
    setResult(null);
    setAmount("");
    setNote("");
  }

  return (
    <div>
      <div className="flex items-center gap-2.5">
        <div><p className="workspace-label">platform → @username → USDC or SOL → amount</p><h2 className="mt-1 text-xl font-semibold">Payment details</h2></div>
        <StepDots step={step} />
      </div>

      {step === "compose" ? (
        <div className="mt-6 space-y-5">
          <PlatformIdentityPicker
            provider={provider}
            onProviderChange={setProvider}
            handle={handle}
            onHandleChange={setHandle}
          />

          <div>
            <div className="mb-2 flex items-center justify-between gap-3">
              <span className="text-sm font-semibold">USDC or Solana</span>
              <span className="text-sm text-muted-foreground">Solana mainnet</span>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              {live.map((a) => {
                const isSelected = selected?.key === a.key;
                return (
                  <button
                    key={a.key}
                    type="button"
                    onClick={() => setAssetKey(a.key)}
                    aria-pressed={isSelected}
                    className={cn(
                      "flex items-center gap-3 rounded-xl border bg-card p-4 text-left transition-all",
                      isSelected
                        ? "border-2 border-success bg-success/5"
                        : "border-border hover:border-foreground/30 hover:bg-secondary",
                    )}
                  >
                    <AssetIcon symbol={a.symbol} assetKey={a.key} chainKey={a.chain_key} logoUrl={a.logo_url} size="md" showNetwork={false} />
                    <span className="min-w-0 flex-1">
                      <span className="block font-bold">{a.symbol}</span>
                      <span className="block truncate text-sm text-muted-foreground">{a.name}</span>
                    </span>
                    {isSelected ? <CheckCircle2 className="size-5 text-success" /> : null}
                  </button>
                );
              })}
            </div>
            {selected ? (
              <p className="mt-2 text-xs text-muted-foreground">
                {selected.contract_address
                  ? `${selected.name} · ${shortAddress(selected.contract_address, 4)}`
                  : `${selected.name} · native`}
              </p>
            ) : null}
          </div>


          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label htmlFor="pay-amount" className="mb-2 block text-sm font-semibold">
                Amount ({selected?.symbol ?? "SOL"})
              </label>
              <Input
                id="pay-amount"
                inputMode="decimal"
                value={amount}
                onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))}
                placeholder="0.00"
                 className="num h-11 rounded-md text-base"
              />
            </div>
            <div>
              <label htmlFor="pay-note" className="mb-2 block text-sm font-semibold">
                Note (optional)
              </label>
              <Textarea
                id="pay-note"
                value={note}
                onChange={(e) => setNote(e.target.value.slice(0, 140))}
                rows={1}
                placeholder="What's this for?"
                className="min-h-11 rounded-md text-sm"
              />
            </div>
          </div>

          <Button
            className="press h-10 w-full rounded-md text-sm font-semibold"
            onClick={toReview}
            disabled={!clean}
          >
            Review payment
          </Button>
          <p className="text-xs text-muted-foreground">
             No AUTH account or wallet extension is needed to compose this payment. You authorize the
            transfer on the next step.
          </p>
        </div>
      ) : null}

      {step === "review" ? (
        <div className="mt-4 space-y-4">
           <dl className="divide-y divide-border rounded-md border border-border bg-background text-sm">
            <Row label="To">
              <ProviderIcon provider={provider} brand />
              <span className="font-medium">
                {providerMetaRow.handlePrefix}
                {clean}
              </span>
              <span className="text-muted-foreground">{providerMetaRow.label}</span>
              {payee?.payable ? (
                <StatusPill status="verified">Payable</StatusPill>
              ) : (
                <StatusPill status="pending">Reserved until claimed</StatusPill>
              )}
            </Row>
            <Row label="Destination wallet">
              {payee?.destinationWallet ? (
                <span className="num">{shortAddress(payee.destinationWallet, 6)}</span>
              ) : (
                <span className="text-muted-foreground">None yet — nothing leaves your account</span>
              )}
            </Row>
            <Row label="USDC or Solana">
              <span className="font-medium">{selected?.symbol}</span>
              <span className="text-muted-foreground">{chain?.name ?? selected?.chain_key}</span>
            </Row>
            <Row label="Amount">
              <span className="num font-medium">
                {amount} {selected?.symbol}
              </span>
            </Row>
            <Row label="From">
              <span className="num">
                 {address ? shortAddress(address, 6) : "Your AUTH payment account"}
              </span>
            </Row>
            <Row label="Network fee">
              <span className="text-muted-foreground">Paid in SOL from your account at authorization</span>
            </Row>
            {note ? <Row label="Note">“{note}”</Row> : null}
          </dl>

          <AuthorizePanel
            label={payee?.payable ? "Authorize and send" : `Reserve for @${clean}`}
            busy={busy !== null}
            onAuthorize={confirmAndSign}
          />
          <Button
            variant="outline"
            className="press h-10 w-full rounded-md"
            onClick={() => setStep("compose")}
            disabled={busy !== null}
          >
            <ArrowLeft className="size-4" /> Edit
          </Button>
          {busy ? (
            <p className="text-xs text-muted-foreground">
              {busy === "creating"
                ? "Preparing the transfer…"
                : busy === "signing"
                  ? "Waiting for your authorization…"
                  : "Confirming on-chain…"}
            </p>
          ) : null}
          <p className="text-xs text-muted-foreground">
             You approve this exact transfer — AUTH can never move funds on its own, never holds
            your funds, and never sees a private key or seed phrase.
          </p>
        </div>
      ) : null}

      {step === "done" && result ? (
        <div className="mt-4 space-y-3">
          <div
            className={cn(
              "rounded-xl border p-4 text-sm",
              result.kind === "sent"
                ? "border-success/40 bg-success/10"
                : result.kind === "reserved"
                  ? "border-warning/40 bg-warning/10"
                  : "border-destructive/40 bg-destructive/10",
            )}
          >
            <p className="flex items-start gap-2">
              {result.kind === "sent" ? <CheckCircle2 className="mt-0.5 size-4 text-success" /> : null}
              <span>{result.message}</span>
            </p>
            {result.signature ? (
              <a
                href={explorerTx(result.signature)}
                target="_blank"
                rel="noreferrer noopener"
                className="num mt-2 inline-flex items-center gap-1 text-xs text-info hover:underline"
              >
                Receipt: {shortAddress(result.signature, 8)} <ExternalLink className="size-3" />
              </a>
            ) : null}
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" className="press rounded-md" onClick={reset}>
              Send another
            </Button>
            <Button asChild variant="ghost" className="press rounded-md">
              <Link to="/ledger">Open ledger</Link>
            </Button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-center gap-2 p-3">
      <dt className="w-32 shrink-0 text-xs text-muted-foreground">{label}</dt>
      <dd className="flex flex-wrap items-center gap-2">{children}</dd>
    </div>
  );
}

function StepDots({ step }: { step: Step }) {
  const steps: Step[] = ["compose", "review", "done"];
  return (
    <span className="ml-auto flex items-center gap-1.5" aria-hidden>
      {steps.map((s) => (
        <span
          key={s}
          className={cn(
            "size-1.5 rounded-full transition-colors",
            steps.indexOf(step) >= steps.indexOf(s) ? "bg-primary" : "bg-border",
          )}
        />
      ))}
    </span>
  );
}

export function PaymentAmount({ asset, amount, amountUsd }: { asset: string; amount: number; amountUsd: number | null }) {
  return (
    <span className="num">
      {amount} {asset}
      {amountUsd ? <span className="ml-1 text-muted-foreground">({usd(amountUsd)})</span> : null}
    </span>
  );
}
