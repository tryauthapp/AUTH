import { ExternalLink } from "lucide-react";
import { toast } from "sonner";
import { BrandMark } from "@/components/BrandMark";
import {
  AUTH_GITHUB_URL,
  AUTH_TOKEN_MINT,
  AUTH_X_URL,
  solscanTokenUrl,
} from "@/lib/external-links";

/**
 * Compact top-right utility cluster: the AUTH token's on-chain address with a
 * one-tap copy, plus X and GitHub links. Logos are real SVG marks (never text).
 */

export function XMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor" className={className}>
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231ZM17.083 19.77h1.833L7.084 4.126H5.117Z" />
    </svg>
  );
}

export function GitHubMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor" className={className}>
      <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12" />
    </svg>
  );
}

/** Short display form of the mint: first and last few characters. */
export function shortMint(mint: string): string {
  return `${mint.slice(0, 4)}…${mint.slice(-4)}`;
}

export async function copyAuthTokenAddress(): Promise<void> {
  try {
    await navigator.clipboard.writeText(AUTH_TOKEN_MINT);
    toast.success("AUTH token address copied");
  } catch {
    toast.error("Could not copy the address");
  }
}

const iconLinkClass =
  "inline-flex size-8 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground";

/** Desktop top bar — token address, X, and GitHub, right-aligned. */
export function DesktopTopLinks() {
  return (
    <div className="sticky top-0 z-30 hidden h-11 items-center justify-end gap-1.5 border-b border-border/70 bg-background/85 px-4 backdrop-blur-md md:flex">
      <button
        type="button"
        onClick={copyAuthTokenAddress}
        title={`AUTH token address — ${AUTH_TOKEN_MINT}`}
        aria-label="Copy the AUTH token's on-chain address"
        className="press inline-flex h-8 items-center gap-1.5 rounded-lg border border-border bg-secondary/60 px-2.5 text-[12px] font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
      >
        <BrandMark className="size-4" />
        <span className="font-mono tracking-tight">{shortMint(AUTH_TOKEN_MINT)}</span>
      </button>
      <a
        href={solscanTokenUrl(AUTH_TOKEN_MINT)}
        target="_blank"
        rel="noopener noreferrer"
        title="View the AUTH token on Solscan"
        aria-label="View the AUTH token on Solscan"
        className={iconLinkClass}
      >
        <ExternalLink className="size-4" strokeWidth={1.7} />
      </a>
      <span className="mx-1 h-4 w-px bg-border" aria-hidden="true" />
      <a
        href={AUTH_X_URL}
        target="_blank"
        rel="noopener noreferrer"
        title="AUTH on X — @TryAuthApp"
        aria-label="AUTH on X"
        className={iconLinkClass}
      >
        <XMark className="size-4 text-platform-x" />
      </a>
      <a
        href={AUTH_GITHUB_URL}
        target="_blank"
        rel="noopener noreferrer"
        title="AUTH on GitHub"
        aria-label="AUTH on GitHub"
        className={iconLinkClass}
      >
        <GitHubMark className="size-4" />
      </a>
    </div>
  );
}

/** Icons-only variant for the compact mobile top bar. */
export function MobileTopLinks() {
  return (
    <>
      <a
        href={AUTH_X_URL}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="AUTH on X"
        className="inline-flex size-8 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
      >
        <XMark className="size-4 text-platform-x" />
      </a>
      <a
        href={AUTH_GITHUB_URL}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="AUTH on GitHub"
        className="inline-flex size-8 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
      >
        <GitHubMark className="size-4" />
      </a>
    </>
  );
}
