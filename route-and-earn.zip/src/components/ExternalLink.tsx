import type { AnchorHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

/**
 * Outbound link. Always opens in a new tab with safe rel attributes so the
 * opened page can never reach back into AUTH.
 */
export function ExternalLink({
  href,
  className,
  children,
  ...rest
}: AnchorHTMLAttributes<HTMLAnchorElement> & { href: string }) {
  return (
    <a
      {...rest}
      href={href}
      target="_blank"
      rel="noopener noreferrer external"
      className={cn(
        "outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background rounded-sm",
        className,
      )}
    >
      {children}
    </a>
  );
}
