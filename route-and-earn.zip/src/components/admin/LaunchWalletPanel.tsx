import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Wallet } from "lucide-react";
import { launchWalletStatus } from "@/lib/launch-ownership.functions";
import { ErrorState, LoadingRows, StatusPill } from "@/components/primitives";
import { shortAddress } from "@/lib/format";

/**
 * Launch wallet status. Shows the derived public address only — the secret key
 * is never fetched, returned or rendered anywhere.
 */
export function LaunchWalletPanel() {
  const statusFn = useServerFn(launchWalletStatus);
  const q = useQuery({
    queryKey: ["launch-wallet-status"],
    queryFn: () => statusFn(),
    staleTime: 30_000,
  });

  if (q.isPending) return <LoadingRows rows={3} />;
  if (q.error) return <ErrorState error={q.error} retry={q.refetch} />;
  const s = q.data!;

  return (
    <section className="rounded-lg border border-border bg-card p-4">
      <div className="flex flex-wrap items-center gap-2">
        <span className="grid size-7 place-items-center rounded-full bg-muted">
          <Wallet className="size-3.5 text-muted-foreground" />
        </span>
        <h2 className="text-sm font-semibold">Launch wallet</h2>
        <StatusPill status={s.state === "configured" ? "live" : "planned"}>
          {s.state === "configured" ? "configured" : s.state}
        </StatusPill>
      </div>

      <dl className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
        <div>
          <dt className="text-xs uppercase tracking-wide text-muted-foreground">Public address</dt>
          <dd className="font-medium">
            {s.address ? (
              <code className="break-all text-xs">{s.address}</code>
            ) : (
              <span className="text-muted-foreground">Not configured</span>
            )}
          </dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-muted-foreground">SOL balance</dt>
          <dd className="font-medium">
            {s.solBalance === null ? "—" : `${s.solBalance.toFixed(4)} SOL`}
          </dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-muted-foreground">Signer mode</dt>
          <dd className="font-medium">
            {s.signerMode === "external_wallet"
              ? "Server-side external Solana wallet"
              : s.signerMode === "provider_hosted"
                ? "Provider-hosted execution wallet (fallback)"
                : "No signer available"}
          </dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-muted-foreground">Provider mode</dt>
          <dd className="font-medium">
            {s.signerMode === "external_wallet"
              ? "PumpPortal local transaction path"
              : "PumpPortal Lightning (hosted)"}
          </dd>
        </div>
      </dl>

      <p className="mt-3 text-xs leading-5 text-muted-foreground">{s.providerRole}</p>
      {!s.rpcConfigured ? (
        <p className="mt-2 text-xs leading-5 text-warning-foreground">
          No Solana RPC is configured, so AUTH cannot broadcast its own launch transactions.
        </p>
      ) : null}
      {s.message ? (
        <p className="mt-2 text-xs leading-5 text-warning-foreground">{s.message}</p>
      ) : null}
      <p className="mt-3 text-xs leading-5 text-muted-foreground">
        The private key lives only in server secrets. It is never sent to the browser, never logged
        and never returned by any request.
        {s.address ? ` Dev-buy tokens are delivered to ${shortAddress(s.address)}.` : ""}
      </p>
    </section>
  );
}
