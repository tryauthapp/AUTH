import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { AlertTriangle, Check, ExternalLink, Loader2, PlayCircle, X as XIcon } from "lucide-react";
import {
  platformIntegrationStatus,
  testPlatformIntegration,
  type IntegrationTestResult,
  type PlatformIntegrationStatus,
} from "@/lib/platform-identity.functions";
import { ProviderIcon } from "@/components/social/ProviderIcon";
import { SocialAvatar } from "@/components/social/SocialIdentity";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  ErrorState,
  LoadingRows,
  SectionHeading,
  StatusPill,
} from "@/components/primitives";
import { timeAgo } from "@/lib/format";

const LIFECYCLE_COPY: Record<string, string> = {
  live: "Live",
  sandbox: "Sandbox",
  planned: "Planned",
  disabled: "Disabled",
};

/**
 * Social integrations dashboard: per-platform lifecycle state derived from real
 * configuration, the exact env vars still missing, platform restrictions, the
 * last real API error, and a read-only test control that writes nothing.
 */
export function PlatformStatusPanel() {
  const fetchStatus = useServerFn(platformIntegrationStatus);
  const q = useQuery({
    queryKey: ["platform-integration-status"],
    queryFn: () => fetchStatus(),
    refetchOnWindowFocus: false,
  });

  if (q.isPending) return <LoadingRows rows={5} />;
  if (q.error) return <ErrorState error={q.error} retry={q.refetch} />;

  const items = q.data ?? [];
  const counts = items.reduce<Record<string, number>>((acc, p) => {
    acc[p.lifecycle] = (acc[p.lifecycle] ?? 0) + 1;
    return acc;
  }, {});

  return (
    <div>
      <SectionHeading
        title="Social integrations"
        description="Lifecycle state is derived from live configuration — never hand-set. Test runs are read-only lookups against each platform's own API."
      />

      <div className="mt-3 flex flex-wrap gap-2">
        {(["live", "sandbox", "planned", "disabled"] as const).map((k) => (
          <StatusPill key={k} status={k}>
            {counts[k] ?? 0} {LIFECYCLE_COPY[k]}
          </StatusPill>
        ))}
      </div>

      <ul className="mt-4 grid gap-3">
        {items.map((p) => (
          <IntegrationCard key={p.id} p={p} />
        ))}
      </ul>
    </div>
  );
}

function IntegrationCard({ p }: { p: PlatformIntegrationStatus }) {
  const [handle, setHandle] = useState(p.sampleHandle);
  const runTest = useServerFn(testPlatformIntegration);
  const test = useMutation<IntegrationTestResult, Error, void>({
    mutationFn: () => runTest({ data: { provider: p.id, handle } }),
  });

  const testable = p.lifecycle !== "disabled" && p.lookupAvailable;

  return (
    <li className="workspace-panel p-4">
      <div className="flex flex-wrap items-center gap-2">
        <ProviderIcon provider={p.id} brand className="size-5" />
        <span className="font-semibold">{p.label}</span>
        <StatusPill status={p.lifecycle}>{LIFECYCLE_COPY[p.lifecycle]}</StatusPill>
        <Flag ok={p.lookupAvailable} label="Profile lookup" />
        <Flag ok={p.oauthAvailable} label="Ownership OAuth" />
        {p.reviewRequired ? (
          <span className="inline-flex items-center gap-1 rounded-full border border-warning/40 px-2 py-0.5 text-xs text-warning">
            <AlertTriangle className="size-3" /> App review required
          </span>
        ) : null}
      </div>

      <p className="mt-2 text-xs leading-5 text-muted-foreground">{p.lifecycleReason}</p>
      {p.limitation ? (
        <p className="mt-1 text-xs leading-5 text-muted-foreground">{p.limitation}</p>
      ) : null}

      <dl className="mt-3 grid gap-2 text-xs sm:grid-cols-2">
        <Row
          term="Lookup credentials"
          names={p.lookupSecretNames}
          missing={p.missingLookupSecrets}
          kind={p.lookupKind}
        />
        <Row term="OAuth credentials" names={p.oauthSecretNames} missing={p.missingOauthSecrets} />
      </dl>

      <div className="mt-3 rounded-md border border-border p-3">
        <p className="text-xs font-medium">Safe test</p>
        <p className="mt-1 text-xs text-muted-foreground">
          Read-only profile lookup. No records are written, nothing is claimed and no funds move.
        </p>
        <div className="mt-2 flex flex-col gap-2 sm:flex-row">
          <Input
            value={handle}
            onChange={(e) => setHandle(e.target.value)}
            placeholder={p.sampleHandle}
            aria-label={`${p.label} test handle`}
            disabled={!testable}
            className="sm:max-w-[240px]"
          />
          <Button
            type="button"
            variant="outline"
            size="sm"
            disabled={!testable || test.isPending}
            onClick={() => test.mutate()}
          >
            {test.isPending ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <PlayCircle className="size-4" />
            )}
            Run test
          </Button>
        </div>
        {!testable ? (
          <p className="mt-2 text-xs text-muted-foreground">
            {p.lifecycle === "disabled"
              ? "Testing is off while this integration is disabled."
              : p.lookupKind === "owner_only"
                ? "No public lookup exists on this platform, so there is nothing to test without the owner signing in."
                : "Add the missing lookup credentials to enable testing."}
          </p>
        ) : null}

        {test.error ? (
          <p className="mt-2 text-xs text-destructive">{test.error.message}</p>
        ) : null}

        {test.data ? (
          <div className="mt-3 rounded-md border border-border bg-muted/40 p-3 text-xs">
            <div className="flex flex-wrap items-center gap-2">
              <StatusPill status={test.data.ok ? "live" : "failed"}>
                {test.data.status}
              </StatusPill>
              <span className="num text-muted-foreground">{test.data.latencyMs} ms</span>
              <span className="text-muted-foreground">{timeAgo(test.data.ranAt)}</span>
            </div>
            <p className="mt-2 text-muted-foreground">{test.data.message}</p>
            {test.data.profile ? (
              <div className="mt-2 flex items-center gap-2">
                <SocialAvatar
                  provider={p.id}
                  handle={test.data.profile.handle}
                  avatarUrl={test.data.profile.avatarUrl}
                  size="sm"
                />
                <div className="min-w-0">
                  <p className="truncate font-medium">
                    {test.data.profile.displayName ?? test.data.profile.handle}
                  </p>
                  <p className="truncate text-muted-foreground">
                    {p.handlePrefix}
                    {test.data.profile.handle}
                    {test.data.profile.followerCount != null
                      ? ` · ${test.data.profile.followerCount.toLocaleString()} followers`
                      : ""}
                  </p>
                </div>
              </div>
            ) : null}
          </div>
        ) : null}
      </div>

      <p className="mt-3 break-all text-xs text-muted-foreground">
        Redirect URI: <span className="num">{p.callbackUrl}</span>
      </p>
      {p.lastError ? (
        <p className="mt-2 rounded-md border border-destructive/30 bg-destructive/5 p-2 text-xs text-destructive">
          Last error ({timeAgo(p.lastError.at)}): {p.lastError.message}
        </p>
      ) : null}
      <a
        href={p.consoleUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="mt-2 inline-flex items-center gap-1 text-xs hover:underline"
      >
        Developer console <ExternalLink className="size-3" />
      </a>
    </li>
  );
}

function Flag({ ok, label }: { ok: boolean; label: string }) {
  return (
    <span
      className={
        ok
          ? "inline-flex items-center gap-1 rounded-full border border-success/40 px-2 py-0.5 text-xs text-success"
          : "inline-flex items-center gap-1 rounded-full border border-border px-2 py-0.5 text-xs text-muted-foreground"
      }
    >
      {ok ? <Check className="size-3" /> : <XIcon className="size-3" />} {label}
    </span>
  );
}

function Row({
  term,
  names,
  missing,
  kind,
}: {
  term: string;
  names: string[];
  missing: string[];
  kind?: string;
}) {
  return (
    <div className="rounded-md border border-border p-2">
      <dt className="font-medium">{term}</dt>
      <dd className="mt-1 text-muted-foreground">
        {kind === "owner_only" ? (
          <>Not offered by the platform: owner OAuth only.</>
        ) : names.length === 0 ? (
          <>None required.</>
        ) : (
          <span className="num">
            {names.map((n) => (
              <span key={n} className={missing.includes(n) ? "block text-destructive" : "block text-success"}>
                {n} {missing.includes(n) ? "— missing" : "— set"}
              </span>
            ))}
          </span>
        )}
      </dd>
    </div>
  );
}
