import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { FlaskConical, ExternalLink } from "lucide-react";
import { myClaimable } from "@/lib/claims.functions";
import { runLiveDepositTest, type LiveDepositTestResult } from "@/lib/live-claim-test.functions";
import { Button } from "@/components/ui/button";
import { ErrorState, LoadingRows, StatusPill } from "@/components/primitives";

/**
 * Admin live test for the deposit → claim pipeline. Sends a tiny real SOL
 * transfer from the launch wallet into a verified identity's Turnkey deposit
 * wallet; the final claim step runs through the normal Claim flow.
 */
export function LiveClaimTestPanel() {
  const claimableFn = useServerFn(myClaimable);
  const depositFn = useServerFn(runLiveDepositTest);
  const queryClient = useQueryClient();

  const q = useQuery({
    queryKey: ["live-test-claimable"],
    queryFn: () => claimableFn(),
    staleTime: 15_000,
  });

  const run = useMutation({
    mutationFn: (args: { recipientId: string; handle: string }) =>
      depositFn({ data: { recipientId: args.recipientId, amountSol: 0.05 } }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["live-test-claimable"] });
      queryClient.invalidateQueries({ queryKey: ["my-claimable"] });
    },
  });

  const owned = (q.data?.identities ?? []).filter(
    (i) => i.providerUserId && i.providerUserId.length > 0,
  );

  return (
    <section className="rounded-lg border border-border bg-card p-4">
      <div className="flex flex-wrap items-center gap-2">
        <span className="grid size-7 place-items-center rounded-full bg-muted">
          <FlaskConical className="size-3.5 text-muted-foreground" />
        </span>
        <h2 className="text-sm font-semibold">Live deposit test</h2>
        <StatusPill status="live">real funds</StatusPill>
      </div>
      <p className="mt-3 text-xs leading-5 text-muted-foreground">
        Sends 0.05 SOL from the launch wallet into the selected identity's Turnkey deposit wallet
        and verifies it on-chain before it becomes claimable. To finish the test, open Claim and
        claim the balance — that exercises Turnkey signing and the payout to your wallet.
      </p>

      {q.isPending ? <div className="mt-4"><LoadingRows rows={2} /></div> : null}
      {q.error ? (
        <div className="mt-4"><ErrorState error={q.error} retry={q.refetch} /></div>
      ) : null}

      {q.data && owned.length === 0 ? (
        <p className="mt-4 text-xs leading-5 text-muted-foreground">
          You have no verified identities yet. Verify an account on the Claim page first — the test
          only funds identities your account owns.
        </p>
      ) : null}

      {owned.length > 0 ? (
        <ul className="mt-4 space-y-2">
          {owned.map((identity) => {
            const res: LiveDepositTestResult | undefined = run.data && run.variables?.recipientId === identity.recipientId
              ? (run.data as LiveDepositTestResult)
              : undefined;
            return (
              <li
                key={identity.recipientId}
                className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-border px-3 py-2"
              >
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">
                    @{identity.handle}
                    <span className="ml-2 text-xs uppercase tracking-wide text-muted-foreground">
                      {identity.provider}
                    </span>
                  </p>
                  {identity.depositAddress ? (
                    <p className="truncate text-xs text-muted-foreground">
                      deposit {identity.depositAddress.slice(0, 4)}…{identity.depositAddress.slice(-4)}
                    </p>
                  ) : null}
                </div>
                <div className="flex items-center gap-2">
                  {res ? (
                    res.ok ? (
                      <a
                        href={res.explorerUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 text-xs font-medium text-success-foreground underline-offset-4 hover:underline"
                      >
                        sent · view tx <ExternalLink className="size-3" />
                      </a>
                    ) : (
                      <span className="text-xs text-warning-foreground">{res.message}</span>
                    )
                  ) : null}
                  <Button
                    size="sm"
                    variant="outline"
                    className="press rounded-full"
                    disabled={run.isPending}
                    onClick={() => run.mutate({ recipientId: identity.recipientId, handle: identity.handle })}
                  >
                    {run.isPending && run.variables?.recipientId === identity.recipientId
                      ? "Sending…"
                      : "Send 0.05 SOL"}
                  </Button>
                </div>
              </li>
            );
          })}
        </ul>
      ) : null}

      {run.isError ? (
        <p className="mt-3 text-xs leading-5 text-warning-foreground">
          {(run.error as Error).message}
        </p>
      ) : null}
    </section>
  );
}
