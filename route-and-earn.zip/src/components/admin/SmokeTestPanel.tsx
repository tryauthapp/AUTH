import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2, CircleSlash, AlertTriangle, XCircle, FlaskConical, Info } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { ErrorState, StatusPill } from "@/components/primitives";
import { runLaunchSmokeTest, type SmokeTestReport } from "@/lib/launch-audit.functions";

const ICONS: Record<string, typeof CheckCircle2> = {
  pass: CheckCircle2,
  fail: XCircle,
  warn: AlertTriangle,
  skipped: CircleSlash,
  info: Info,
};

const TONES: Record<string, string> = {
  pass: "text-success",
  fail: "text-destructive",
  warn: "text-warning",
  skipped: "text-muted-foreground",
  info: "text-muted-foreground",
};

/**
 * Safe launch preflight. Every check is read-only or simulated — no launch is
 * ever broadcast from here.
 */
export function SmokeTestPanel({ onComplete }: { onComplete?: (runKey: string) => void }) {
  const run = useServerFn(runLaunchSmokeTest);
  const [report, setReport] = useState<SmokeTestReport | null>(null);

  const mutation = useMutation({
    mutationFn: () => run(),
    onSuccess: (data) => {
      setReport(data);
      onComplete?.(data.runKey);
      toast.success(
        data.failed === 0 ? "Smoke test finished — no failures." : `Smoke test finished with ${data.failed} failure(s).`,
      );
    },
    onError: (e: unknown) => toast.error(e instanceof Error ? e.message : "The smoke test could not run."),
  });

  return (
    <section className="rounded-lg border border-border bg-card p-4">
      <div className="flex flex-wrap items-center gap-2">
        <span className="grid size-7 place-items-center rounded-full bg-muted">
          <FlaskConical className="size-3.5 text-muted-foreground" />
        </span>
        <h2 className="text-sm font-semibold">Launch smoke test</h2>
        <StatusPill status="neutral">no broadcast</StatusPill>
        <Button
          size="sm"
          className="ml-auto"
          onClick={() => mutation.mutate()}
          disabled={mutation.isPending}
        >
          {mutation.isPending ? "Running checks…" : "Run checks"}
        </Button>
      </div>

      <p className="mt-3 text-xs leading-5 text-muted-foreground">
        Validates the launch wallet, its SOL balance, real transaction construction, server-side signing and
        signature acceptance by simulating against mainnet, then re-reads the last confirmed launch. No token is
        created, no SOL moves, and no key is ever shown.
      </p>

      {mutation.error ? <div className="mt-3"><ErrorState error={mutation.error} /></div> : null}

      {report ? (
        <div className="mt-4 space-y-2">
          <p className="text-xs text-muted-foreground">
            {report.passed} passed · {report.warned} warnings · {report.failed} failed · run {report.runKey}
          </p>
          <ul className="divide-y divide-border rounded-md border border-border">
            {report.checks.map((check) => {
              const Icon = ICONS[check.status] ?? Info;
              return (
                <li key={check.id} className="flex gap-3 p-3">
                  <Icon className={`mt-0.5 size-4 shrink-0 ${TONES[check.status] ?? ""}`} />
                  <div className="min-w-0">
                    <p className="text-sm font-medium">{check.label}</p>
                    <p className="break-words text-xs leading-5 text-muted-foreground">{check.message}</p>
                  </div>
                  <span className="ml-auto self-start text-[10px] uppercase tracking-wide text-muted-foreground">
                    {check.status}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>
      ) : null}
    </section>
  );
}
