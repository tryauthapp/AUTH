import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { RefreshCw, Radar } from "lucide-react";
import { getCreatorFeeStatus, runCreatorFeeSyncNow } from "@/lib/creator-fees.functions";
import { Button } from "@/components/ui/button";
import { ErrorState, LoadingRows, StatusPill } from "@/components/primitives";

/**
 * Admin visibility for automatic creator-fee detection: when it last ran, what
 * it found, what failed and which coins are being reconciled.
 */
export function CreatorFeeIndexerPanel() {
  const statusFn = useServerFn(getCreatorFeeStatus);
  const syncFn = useServerFn(runCreatorFeeSyncNow);
  const queryClient = useQueryClient();

  const q = useQuery({
    queryKey: ["creator-fee-status"],
    queryFn: () => statusFn(),
    staleTime: 30_000,
  });

  const sync = useMutation({
    mutationFn: () => syncFn(),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["creator-fee-status"] }),
  });

  const time = (value: string | null) =>
    value ? new Date(value).toLocaleString() : "—";

  return (
    <section className="rounded-lg border border-border bg-card p-4">
      <div className="flex flex-wrap items-center gap-2">
        <span className="grid size-7 place-items-center rounded-full bg-muted">
          <Radar className="size-3.5 text-muted-foreground" />
        </span>
        <h2 className="text-sm font-semibold">Creator-fee automation</h2>
        <StatusPill status="live">automatic</StatusPill>
        <div className="ml-auto">
          <Button
            size="sm"
            variant="outline"
            disabled={sync.isPending || !q.data?.isAdmin}
            onClick={() => sync.mutate()}
          >
            <RefreshCw className={`size-3.5 ${sync.isPending ? "animate-spin" : ""}`} />
            Run now
          </Button>
        </div>
      </div>

      <p className="mt-3 text-xs leading-5 text-muted-foreground">
        Creator fees are detected from Solana itself — the pump.fun creator vault balance change on
        every trade of a launched coin — and credited to the social identity recorded at launch.
        AUTH reconciles continuously and every {q.data?.cronIntervalMinutes ?? 5} minutes as a
        fallback. Money only leaves when someone presses Claim.
      </p>

      {q.isPending ? <div className="mt-4"><LoadingRows rows={2} /></div> : null}
      {q.error ? <div className="mt-4"><ErrorState error={q.error} retry={q.refetch} /></div> : null}

      {q.data && !q.data.isAdmin ? (
        <p className="mt-4 text-xs text-muted-foreground">Admin access is required to view sync details.</p>
      ) : null}

      {q.data?.isAdmin ? (
        <>
          <dl className="mt-4 grid grid-cols-2 gap-3 text-xs sm:grid-cols-4">
            <div>
              <dt className="text-muted-foreground">Last run</dt>
              <dd className="mt-0.5 font-medium">{time(q.data.lastRunAt)}</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Last success</dt>
              <dd className="mt-0.5 font-medium">{time(q.data.lastSuccessAt)}</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Next run (approx.)</dt>
              <dd className="mt-0.5 font-medium">{time(q.data.nextRunEstimate)}</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Events processed</dt>
              <dd className="mt-0.5 font-medium">{q.data.totals.eventsProcessed.toLocaleString()}</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Credits created</dt>
              <dd className="mt-0.5 font-medium">{q.data.totals.creditsCreated.toLocaleString()}</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Fees credited</dt>
              <dd className="mt-0.5 font-medium">{q.data.totals.solCredited.toFixed(4)} SOL</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Awaiting settlement</dt>
              <dd className="mt-0.5 font-medium">{q.data.accrued.sol.toFixed(4)} SOL</dd>
            </div>
            <div>
              <dt className="text-muted-foreground">Coins tracked</dt>
              <dd className="mt-0.5 font-medium">{q.data.mints.length.toLocaleString()}</dd>
            </div>
          </dl>

          {q.data.lastError ? (
            <p className="mt-3 rounded-md bg-destructive/10 p-2 text-xs leading-5 text-destructive">
              Last error: {q.data.lastError}
            </p>
          ) : null}

          {sync.data ? (
            <p className="mt-3 text-xs leading-5 text-muted-foreground">{sync.data.message}</p>
          ) : null}

          {q.data.mints.length > 0 ? (
            <ul className="mt-4 space-y-2">
              {q.data.mints.map((m) => (
                <li key={m.mint} className="rounded-md border border-border/70 p-3 text-xs">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono">{m.mint.slice(0, 6)}…{m.mint.slice(-4)}</span>
                    {m.recipientHandle ? (
                      <span className="text-muted-foreground">
                        fees to @{m.recipientHandle}
                        {m.provider ? ` · ${m.provider}` : ""}
                      </span>
                    ) : null}
                    <span className="ml-auto text-muted-foreground">{time(m.lastSyncedAt)}</span>
                  </div>
                  <div className="mt-1 text-muted-foreground">
                    {m.eventsProcessed.toLocaleString()} events · {m.creditsCreated.toLocaleString()} credits ·{" "}
                    {m.solCredited.toFixed(4)} SOL
                  </div>
                  {m.lastError ? <div className="mt-1 text-destructive">{m.lastError}</div> : null}
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-4 text-xs text-muted-foreground">
              No launched coins are being tracked yet. A real pump.fun launch with a creator-fee
              recipient starts reconciliation automatically.
            </p>
          )}
        </>
      ) : null}
    </section>
  );
}
