import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { History, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EmptyState, ErrorState, LoadingRows } from "@/components/primitives";
import { recentLaunchAudit, type AuditEvent } from "@/lib/launch-audit.functions";

const STAGE_LABEL: Record<string, string> = {
  config_validation: "Configuration",
  transaction_construction: "Construction",
  signing: "Signing",
  submission: "Submission",
  confirmation: "Confirmation",
  failure: "Failure",
};

const DOT: Record<string, string> = {
  pass: "bg-success",
  fail: "bg-destructive",
  warn: "bg-warning",
  skipped: "bg-muted-foreground/40",
  info: "bg-muted-foreground/40",
};

function EventRow({ event }: { event: AuditEvent }) {
  const [open, setOpen] = useState(false);
  const hasDetail = Boolean(event.detailJson && event.detailJson !== "{}");
  return (
    <li className="relative pl-6">
      <span className={`absolute left-1 top-2 size-2 rounded-full ${DOT[event.status] ?? "bg-muted-foreground/40"}`} />
      <div className="flex flex-wrap items-baseline gap-x-2 gap-y-1">
        <span className="text-sm font-medium">{STAGE_LABEL[event.stage] ?? event.stage}</span>
        <span className="text-[10px] uppercase tracking-wide text-muted-foreground">{event.status}</span>
        <span className="ml-auto text-[11px] text-muted-foreground">
          {new Date(event.createdAt).toLocaleString()}
        </span>
      </div>
      {event.message ? (
        <p className="break-words text-xs leading-5 text-muted-foreground">{event.message}</p>
      ) : null}
      {hasDetail ? (
        <>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="mt-1 inline-flex items-center gap-1 text-[11px] text-muted-foreground underline-offset-2 hover:underline"
          >
            <ChevronDown className={`size-3 transition-transform ${open ? "rotate-180" : ""}`} />
            {open ? "Hide detail" : "Show detail"}
          </button>
          {open ? (
            <pre className="mt-1 overflow-x-auto rounded-md bg-muted p-2 text-[11px] leading-5">
              {event.detailJson}
            </pre>
          ) : null}
        </>
      ) : null}
    </li>
  );
}

/**
 * Append-only timeline of what actually happened on each launch and smoke test.
 * Secrets are redacted before anything is written, so nothing sensitive can
 * appear here.
 */
export function LaunchAuditTimeline({ refreshKey }: { refreshKey?: string | undefined }) {
  const load = useServerFn(recentLaunchAudit);
  const query = useQuery({
    queryKey: ["launch-audit", refreshKey ?? "latest"],
    queryFn: () => load(),
    staleTime: 15_000,
  });

  const grouped = (query.data ?? []).reduce<Record<string, AuditEvent[]>>((acc, event) => {
    (acc[event.launchKey] ??= []).push(event);
    return acc;
  }, {});
  const keys = Object.keys(grouped);

  return (
    <section className="rounded-lg border border-border bg-card p-4">
      <div className="flex flex-wrap items-center gap-2">
        <span className="grid size-7 place-items-center rounded-full bg-muted">
          <History className="size-3.5 text-muted-foreground" />
        </span>
        <h2 className="text-sm font-semibold">Launch audit timeline</h2>
        <Button
          size="sm"
          variant="outline"
          className="ml-auto"
          onClick={() => query.refetch()}
          disabled={query.isFetching}
        >
          {query.isFetching ? "Refreshing…" : "Refresh"}
        </Button>
      </div>

      {query.isLoading ? (
        <div className="mt-4"><LoadingRows rows={4} /></div>
      ) : query.error ? (
        <div className="mt-4"><ErrorState error={query.error} /></div>
      ) : keys.length === 0 ? (
        <div className="mt-4">
          <EmptyState
            title="No audit events yet"
            description="Run the smoke test or launch a token and every stage will be recorded here."
          />
        </div>
      ) : (
        <div className="mt-4 space-y-5">
          {keys.map((key) => (
            <div key={key}>
              <p className="truncate text-[11px] font-medium text-muted-foreground">{key}</p>
              <ul className="mt-2 space-y-3 border-l border-border pl-1">
                {grouped[key]!
                  .slice()
                  .sort((a, b) => a.createdAt.localeCompare(b.createdAt))
                  .map((event) => (
                    <EventRow key={event.id} event={event} />
                  ))}
              </ul>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
