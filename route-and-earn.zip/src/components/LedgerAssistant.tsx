import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { MessageCircleQuestion } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ErrorState } from "@/components/primitives";
import { askLedgerQuestion, type LedgerAnswer } from "@/lib/ledger-ai.functions";

const SUGGESTIONS = [
  "What can I claim right now?",
  "Why is one of my balances not claimable yet?",
  "Show me where my last payout went.",
];

/**
 * Lets a verified recipient ask questions about their own earnings. The answer
 * is generated only from their own ledger and payout rows.
 */
export function LedgerAssistant() {
  const ask = useServerFn(askLedgerQuestion);
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState<LedgerAnswer | null>(null);

  const mutation = useMutation({
    mutationFn: (q: string) => ask({ data: { question: q } }),
    onSuccess: (data) => setAnswer(data),
  });

  const submit = (q: string) => {
    const trimmed = q.trim();
    if (trimmed.length < 3 || mutation.isPending) return;
    setQuestion(trimmed);
    mutation.mutate(trimmed);
  };

  return (
    <section className="rounded-lg border border-border bg-card p-4">
      <div className="flex items-center gap-2">
        <span className="grid size-7 place-items-center rounded-full bg-muted">
          <MessageCircleQuestion className="size-3.5 text-muted-foreground" />
        </span>
        <h2 className="text-sm font-semibold">Ask about your earnings</h2>
      </div>
      <p className="mt-2 text-xs leading-5 text-muted-foreground">
        Ask anything about your balances, payout statuses or past transactions. Answers come only from your own
        verified accounts.
      </p>

      <form
        className="mt-3 space-y-2"
        onSubmit={(e) => {
          e.preventDefault();
          submit(question);
        }}
      >
        <Textarea
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="e.g. How much of my SOL is ready to claim?"
          rows={2}
          maxLength={500}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              submit(question);
            }
          }}
        />
        <div className="flex flex-wrap items-center gap-2">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => submit(s)}
              disabled={mutation.isPending}
              className="rounded-full border border-border px-3 py-1 text-[11px] text-muted-foreground transition-colors hover:bg-muted disabled:opacity-50"
            >
              {s}
            </button>
          ))}
          <Button type="submit" size="sm" className="ml-auto" disabled={mutation.isPending || question.trim().length < 3}>
            {mutation.isPending ? "Thinking…" : "Ask"}
          </Button>
        </div>
      </form>

      {mutation.error ? <div className="mt-3"><ErrorState error={mutation.error} /></div> : null}

      {answer ? (
        <div className="mt-4 rounded-md border border-border bg-muted/40 p-3">
          <p className="whitespace-pre-wrap text-sm leading-6">{answer.answer}</p>
          <p className="mt-2 text-[11px] text-muted-foreground">
            Based on {answer.context.ledgerRows} ledger entries and {answer.context.payoutRows} payouts across{" "}
            {answer.context.identities} verified account{answer.context.identities === 1 ? "" : "s"}, as of{" "}
            {new Date(answer.context.asOf).toLocaleString()}.
          </p>
        </div>
      ) : null}
    </section>
  );
}
