import { cn } from "@/lib/utils";
import { ProviderIcon, providerTint } from "@/components/social/ProviderIcon";
import type { SocialProvider } from "@/lib/social/providers";

/**
 * Marketing/product surface listing the five platforms AUTH supports.
 * All five are presented as active product surfaces.
 */

type PlatformId = SocialProvider | "instagram";

const PLATFORMS: { id: PlatformId; label: string }[] = [
  { id: "x", label: "X" },
  { id: "tiktok", label: "TikTok" },
  { id: "youtube", label: "YouTube" },
  { id: "twitch", label: "Twitch" },
  { id: "instagram", label: "Instagram" },
];

function InstagramMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" fill="currentColor" className={className}>
      <path d="M12 2.16c3.2 0 3.58.01 4.85.07 1.17.05 1.8.25 2.23.41.56.22.96.48 1.38.9.42.42.68.82.9 1.38.16.42.36 1.06.41 2.23.06 1.27.07 1.65.07 4.85s-.01 3.58-.07 4.85c-.05 1.17-.25 1.8-.41 2.23-.22.56-.48.96-.9 1.38-.42.42-.82.68-1.38.9-.42.16-1.06.36-2.23.41-1.27.06-1.65.07-4.85.07s-3.58-.01-4.85-.07c-1.17-.05-1.8-.25-2.23-.41-.56-.22-.96-.48-1.38-.9-.42-.42-.68-.82-.9-1.38-.16-.42-.36-1.06-.41-2.23C2.17 15.58 2.16 15.2 2.16 12s.01-3.58.07-4.85c.05-1.17.25-1.8.41-2.23.22-.56.48-.96.9-1.38.42-.42.82-.68 1.38-.9.42-.16 1.06-.36 2.23-.41C8.42 2.17 8.8 2.16 12 2.16Zm0 3.18a6.66 6.66 0 1 0 0 13.32 6.66 6.66 0 0 0 0-13.32Zm0 10.98a4.32 4.32 0 1 1 0-8.64 4.32 4.32 0 0 1 0 8.64Zm8.48-11.24a1.56 1.56 0 1 1-3.11 0 1.56 1.56 0 0 1 3.11 0Z" />
    </svg>
  );
}

function PlatformMark({ id }: { id: PlatformId }) {
  if (id === "instagram") {
    return <InstagramMark className="size-5 text-platform-instagram" />;
  }
  return <ProviderIcon provider={id} brand className="size-5" />;
}

export function PlatformSupport({ className }: { className?: string }) {
  return (
    <section className={cn("workspace-panel px-6 py-7 sm:px-8", className)}>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="workspace-label">Social identity</p>
          <h2 className="mt-2 text-2xl font-semibold tracking-tight">
            Built for social platforms. <span className="text-success">All five active.</span>
          </h2>
          <p className="mt-2 max-w-2xl text-[15px] leading-6 text-muted-foreground">
            Pay, launch, and route creator fees to a social identity on X, TikTok, YouTube, Twitch,
            or Instagram — with ownership always proven through each platform&apos;s official
            sign-in.
          </p>
        </div>
      </div>

      <ul className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {PLATFORMS.map((platform) => (
          <li
            key={platform.id}
            style={platform.id === "instagram" ? undefined : providerTint(platform.id)}
            className="flex flex-col gap-3 rounded-2xl bg-surface p-4 ring-1 ring-success/30 transition-colors"
          >
            <span className="grid size-10 place-items-center rounded-xl bg-background shadow-sm">
              <PlatformMark id={platform.id} />
            </span>
            <span className="text-sm font-semibold">{platform.label}</span>
            <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-success/12 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-success">
              <span className="size-1.5 rounded-full bg-success" />
              Active
            </span>
          </li>
        ))}
      </ul>
    </section>
  );
}
