import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowUpRight, UserRound } from "lucide-react";
import { listPublicClaimable } from "@/lib/claimable.functions";
import { AssetIcon } from "@/components/AssetIcon";
import { ProviderIcon } from "@/components/social/ProviderIcon";
import { SocialAvatar } from "@/components/social/SocialIdentity";
import { ExternalLink } from "@/components/ExternalLink";
import { socialProfileUrl } from "@/lib/external-links";
import { providerMeta } from "@/lib/social/providers";
import { EmptyState, LoadingRows } from "@/components/primitives";
import { Button } from "@/components/ui/button";
import { usd } from "@/lib/format";

/**
 * Main-app feed of social identities with a real claimable balance.
 * Every amount comes from AUTH accounting rows; an empty database renders the
 * empty state rather than any illustrative number.
 */

function amount(value: number) {
  if (value === 0) return "0";
  if (value < 0.001) return value.toExponential(2);
  return value.toLocaleString(undefined, { maximumFractionDigits: value < 1 ? 6 : 4 });
}

export function ClaimableFeed({ limit = 6 }: { limit?: number }) {
  const claimable = useQuery({
    queryKey: ["public-claimable-list"],
    queryFn: () => listPublicClaimable(),
    staleTime: 60_000,
  });
  const items = (claimable.data ?? []).slice(0, limit);

  return (
    <section className="mt-4 workspace-panel px-6 py-6 sm:px-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="workspace-label">Unclaimed on AUTH</p>
          <h2 className="mt-2 text-2xl font-semibold">Available to claim</h2>
          <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
            Creator fees and payments routed to social identities that haven't been claimed yet.
            Every balance is read live from AUTH accounting — nothing here is illustrative.
          </p>
        </div>
        <Button asChild variant="outline" size="sm" className="rounded-md">
          <Link to="/explore">See all</Link>
        </Button>
      </div>

      {claimable.isPending ? (
        <div className="mt-4">
          <LoadingRows rows={3} />
        </div>
      ) : items.length === 0 ? (
        <div className="mt-4">
          <EmptyState
            title="Nothing is waiting to be claimed yet"
            description="When a launch routes creator fees or someone pays a handle that hasn't been claimed, the identity and its real balance appear here."
          />
        </div>
      ) : (
        <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {items.map((c) => {
            const meta = providerMeta(c.provider);
            const profileUrl = socialProfileUrl(c.provider, c.handle);
            return (
              <article
                key={`${c.provider}:${c.handle}`}
                className="flex flex-col rounded-2xl border border-border bg-card p-4 transition-colors hover:border-foreground/20"
              >
                <div className="flex items-start gap-3">
                  <SocialAvatar
                    provider={c.provider}
                    handle={c.handle}
                    avatarUrl={c.avatarUrl}
                    size="lg"
                  />
                  <div className="min-w-0 flex-1">
                    <span className="block truncate font-semibold">
                      {c.displayName ?? `@${c.handle}`}
                    </span>
                    {profileUrl ? (
                      <ExternalLink
                        href={profileUrl}
                        className="group flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
                      >
                        <ProviderIcon provider={c.provider} brand className="size-3.5" />@{c.handle}
                        <ArrowUpRight className="size-3 opacity-0 transition-opacity group-hover:opacity-100" />
                      </ExternalLink>
                    ) : (
                      <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
                        <ProviderIcon provider={c.provider} brand className="size-3.5" />@{c.handle}{" "}
                        · {meta?.label ?? c.provider}
                      </span>
                    )}
                  </div>
                </div>

                <dl className="mt-4 grid grid-cols-2 gap-2">
                  <Balance symbol="SOL" value={c.SOL} />
                  <Balance symbol="USDC" value={c.USDC} />
                </dl>

                <p className="mt-2 text-xs text-muted-foreground">
                  {c.approxUsd === null
                    ? "Approximate total unavailable right now"
                    : `≈ ${usd(c.approxUsd)} total (approximate)`}
                </p>

                <div className="mt-4 flex gap-2">
                  <Button asChild size="sm" className="flex-1 rounded-md">
                    <Link
                      to="/c/$handle"
                      params={{ handle: c.handle }}
                      search={{ provider: c.provider }}
                    >
                      {c.isClaimed ? "View balance" : "Claim"}
                    </Link>
                  </Button>
                  <Button asChild size="sm" variant="outline" className="rounded-md">
                    <Link to="/u/$handle" params={{ handle: c.handle }}>
                      Profile
                    </Link>
                  </Button>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}

function Balance({ symbol, value }: { symbol: "SOL" | "USDC"; value: number }) {
  return (
    <div className="rounded-xl border border-border bg-background px-3 py-2">
      <dt className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <AssetIcon
          symbol={symbol}
          assetKey={`solana:${symbol}`}
          chainKey="solana"
          size="sm"
          showNetwork={false}
        />
        {symbol}
      </dt>
      <dd
        className={
          value > 0
            ? "num mt-1 text-base font-semibold text-success"
            : "num mt-1 text-base font-semibold text-muted-foreground"
        }
      >
        {amount(value)}
      </dd>
    </div>
  );
}
