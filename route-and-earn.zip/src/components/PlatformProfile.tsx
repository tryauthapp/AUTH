import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { BadgeCheck, ExternalLink, Info, Send } from "lucide-react";
import { publicPlatformProfile } from "@/lib/platform-profile.functions";
import { SOCIAL_PROVIDERS, type SocialProvider } from "@/lib/social/providers";
import { ProviderIcon, providerTint } from "@/components/social/ProviderIcon";
import { SocialAvatar } from "@/components/social/SocialIdentity";
import {
  EmptyState,
  ErrorState,
  LoadingRows,
  SectionHeading,
  StatCard,
  StatusPill,
} from "@/components/primitives";
import { Button } from "@/components/ui/button";
import { shortAddress, timeAgo, usd } from "@/lib/format";
import { explorerTx } from "@/lib/solana";

/**
 * Public identity page for one platform account. Balances, fees and activity
 * all come from AUTH records; the profile block comes from the platform's own
 * API and says so, including the moment it was read.
 */
export function PlatformProfile({
  provider,
  handle,
}: {
  provider: SocialProvider;
  handle: string;
}) {
  const fetchProfile = useServerFn(publicPlatformProfile);
  const meta = SOCIAL_PROVIDERS.find((p) => p.id === provider)!;
  const query = useQuery({
    queryKey: ["platform-profile", provider, handle.toLowerCase()],
    queryFn: () => fetchProfile({ data: { provider, handle } }),
  });

  if (query.isPending) {
    return (
      <div className="px-4 py-6">
        <LoadingRows rows={8} />
      </div>
    );
  }
  if (query.error) {
    return (
      <div className="px-4 py-6">
        <ErrorState error={query.error} retry={query.refetch} />
      </div>
    );
  }

  const p = query.data;

  return (
    <div className="mx-auto w-full max-w-5xl px-4 pb-10 pt-6 sm:px-6 lg:px-8">
      <div
        style={providerTint(provider)}
        className="platform-tint flex flex-col gap-4 rounded-2xl border p-5 sm:flex-row sm:items-center"
      >
        <SocialAvatar provider={provider} handle={p.handle} avatarUrl={p.avatarUrl} size="xl" />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-xl font-bold">{p.displayName ?? `${meta.handlePrefix}${p.handle}`}</h1>
            {p.platformVerified ? <BadgeCheck className="size-5 text-success" /> : null}
            <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-background px-2 py-0.5 text-xs font-medium">
              <ProviderIcon provider={provider} brand className="size-3.5" /> {meta.label}
            </span>
            <StatusPill status={p.claimed ? "verified" : "pending"}>
              {p.claimed ? "Claimed" : "Unclaimed"}
            </StatusPill>
          </div>
          <p className="mt-1 text-sm text-muted-foreground">
            {meta.handlePrefix}
            {p.handle}
            {p.followerCount !== null ? ` · ${p.followerCount.toLocaleString()} followers` : ""}
            {p.profileFetchedAt ? ` · profile read ${timeAgo(p.profileFetchedAt)}` : ""}
          </p>
          {p.bio ? <p className="mt-2 max-w-xl text-sm">{p.bio}</p> : null}
        </div>
        <div className="flex flex-wrap gap-2">
          <Button asChild className="press rounded-full">
            <Link to="/pay" search={{ to: p.handle }}>
              <Send className="size-4" /> Pay {meta.handlePrefix}
              {p.handle}
            </Link>
          </Button>
          {p.profileUrl ? (
            <Button asChild variant="outline" className="rounded-full">
              <a href={p.profileUrl} target="_blank" rel="noopener noreferrer">
                {meta.label} <ExternalLink className="size-3.5" />
              </a>
            </Button>
          ) : null}
        </div>
      </div>

      {p.lookupMessage ? (
        <p className="mt-3 flex items-start gap-2 rounded-lg border border-border bg-secondary/50 p-3 text-xs text-muted-foreground">
          <Info className="mt-0.5 size-3.5 shrink-0" /> {p.lookupMessage}
        </p>
      ) : null}

      <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Claimable SOL" value={p.claimableSol.toLocaleString(undefined, { maximumFractionDigits: 6 })} />
        <StatCard label="Claimable USDC" value={p.claimableUsdc.toLocaleString(undefined, { maximumFractionDigits: 2 })} />
        <StatCard label="Creator fees" value={usd(p.totalFeesUsd)} />
        <StatCard label="Paid out" value={usd(p.paidOutUsd)} />
      </div>

      <div className="mt-6">
        <SectionHeading title="Public activity" description="Payments and payouts recorded on AUTH." />
        {p.activity.length === 0 ? (
          <EmptyState
            title={p.onAuth ? "No activity yet" : `${meta.handlePrefix}${p.handle} isn't on AUTH yet`}
            description={
              p.onAuth
                ? "Payments and creator-fee payouts will appear here as they settle."
                : "You can still send them crypto — it's reserved until they prove they own the account."
            }
          />
        ) : (
          <ul className="mt-3 divide-y divide-border rounded-xl border border-border">
            {p.activity.map((a) => (
              <li key={`${a.kind}-${a.id}`} className="flex flex-wrap items-center gap-3 p-3 text-sm">
                <span className="font-medium capitalize">{a.kind}</span>
                <span className="num">
                  {a.amount !== null ? a.amount.toLocaleString(undefined, { maximumFractionDigits: 6 }) : "—"}{" "}
                  {a.asset}
                </span>
                {a.amountUsd !== null ? (
                  <span className="text-muted-foreground">{usd(a.amountUsd)}</span>
                ) : null}
                <StatusPill status={a.status === "paid" || a.status === "settled" ? "verified" : "pending"}>
                  {a.status}
                </StatusPill>
                <span className="ml-auto text-xs text-muted-foreground">{timeAgo(a.at)}</span>
                {a.signature ? (
                  <a
                    href={explorerTx(a.signature)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="num text-xs hover:underline"
                  >
                    {shortAddress(a.signature, 6)}
                  </a>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
