import type { IntegrationStatus } from "@/integrations/adapters/types";
import { ADDRESS_RE, explorerAddress, explorerTx } from "@/lib/solana";

/**
 * Chain adapter layer.
 *
 * Every chain AUTH knows about is described here. Only a chain whose adapter
 * reports `canSendPayments: true` may ever be selected in the Pay flow — the
 * others exist for discovery and are labelled Planned everywhere in the UI.
 *
 * Adding a chain later means implementing this interface and registering it;
 * no product code changes. No adapter may accept, store or transmit a private
 * key: authorization always happens in the user's own non-custodial account.
 */

export type ChainSignerKind = "browser_wallet" | "custody" | "none";

export interface ChainAdapter {
  key: string;
  name: string;
  nativeSymbol: string;
  status: IntegrationStatus;
  signerKind: ChainSignerKind;
  /** True only when a working payment path exists end-to-end today. */
  canSendPayments: boolean;
  isValidAddress(value: string): boolean;
  explorerTx(signature: string): string;
  explorerAddress(address: string): string;
  notes: string;
}

export const solanaChain: ChainAdapter = {
  key: "solana",
  name: "Solana",
  nativeSymbol: "SOL",
  status: "live",
  signerKind: "browser_wallet",
  canSendPayments: true,
  isValidAddress: (v) => ADDRESS_RE.test(v.trim()),
  explorerTx,
  explorerAddress,
  notes: "Mainnet transfers authorized by the account owner and confirmed on-chain.",
};

/** Placeholder shape for a chain with no working payment adapter yet. */
function plannedChain(
  key: string,
  name: string,
  nativeSymbol: string,
  txBase: string,
  addressBase: string,
  addressRe: RegExp,
): ChainAdapter {
  return {
    key,
    name,
    nativeSymbol,
    status: "planned",
    signerKind: "none",
    canSendPayments: false,
    isValidAddress: (v) => addressRe.test(v.trim()),
    explorerTx: (s) => `${txBase}${s}`,
    explorerAddress: (a) => `${addressBase}${a}`,
    notes: "No payment adapter implemented. Listed for discovery only.",
  };
}

const EVM_RE = /^0x[a-fA-F0-9]{40}$/;
const BTC_RE = /^(bc1[a-z0-9]{8,87}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/;

export const chainAdapters: Record<string, ChainAdapter> = {
  solana: solanaChain,
  bitcoin: plannedChain(
    "bitcoin",
    "Bitcoin",
    "BTC",
    "https://mempool.space/tx/",
    "https://mempool.space/address/",
    BTC_RE,
  ),
  ethereum: plannedChain(
    "ethereum",
    "Ethereum",
    "ETH",
    "https://etherscan.io/tx/",
    "https://etherscan.io/address/",
    EVM_RE,
  ),
  base: plannedChain("base", "Base", "ETH", "https://basescan.org/tx/", "https://basescan.org/address/", EVM_RE),
  polygon: plannedChain(
    "polygon",
    "Polygon",
    "POL",
    "https://polygonscan.com/tx/",
    "https://polygonscan.com/address/",
    EVM_RE,
  ),
  arbitrum: plannedChain(
    "arbitrum",
    "Arbitrum One",
    "ETH",
    "https://arbiscan.io/tx/",
    "https://arbiscan.io/address/",
    EVM_RE,
  ),
  bnb: plannedChain("bnb", "BNB Chain", "BNB", "https://bscscan.com/tx/", "https://bscscan.com/address/", EVM_RE),
};

export function getChainAdapter(key: string | null | undefined): ChainAdapter | null {
  if (!key) return null;
  return chainAdapters[key] ?? null;
}

/** Chains that can actually move money right now. */
export function liveChains(): ChainAdapter[] {
  return Object.values(chainAdapters).filter((c) => c.canSendPayments);
}
