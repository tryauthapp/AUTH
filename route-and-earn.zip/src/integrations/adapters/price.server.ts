/** SOL spot price — SERVER ONLY. Read-only public market data, no credentials. */

const SOL_MINT = "So11111111111111111111111111111111111111112";
const TIMEOUT_MS = 8000;

export type PriceResult =
  | { ok: true; usd: number; source: string; at: string }
  | { ok: false; message: string };

import { cached } from "@/lib/server-cache.server";

/** Shared 30s spot cache: one upstream call serves every concurrent visitor. */
export async function getSolUsdPrice(): Promise<PriceResult> {
  return cached("price:sol-usd", 30_000, fetchSolUsdPrice);
}

async function fetchSolUsdPrice(): Promise<PriceResult> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(`https://lite-api.jup.ag/price/v3?ids=${SOL_MINT}`, {
      signal: controller.signal,
    });
    if (!res.ok) return { ok: false, message: `Price provider returned ${res.status}` };
    const json = (await res.json()) as Record<string, { usdPrice?: number }>;
    const usd = json?.[SOL_MINT]?.usdPrice;
    if (!usd || !Number.isFinite(usd) || usd <= 0) {
      return { ok: false, message: "Price provider returned no SOL price." };
    }
    return { ok: true, usd, source: "Jupiter", at: new Date().toISOString() };
  } catch (e) {
    return { ok: false, message: e instanceof Error ? e.message : "Price lookup failed." };
  } finally {
    clearTimeout(timer);
  }
}
