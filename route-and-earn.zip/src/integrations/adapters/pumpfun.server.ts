/**
 * pump.fun launch adapter (SERVER ONLY).
 *
 * Real mainnet token creation with the token image and metadata pinned to IPFS
 * through pump.fun's own upload endpoint.
 *
 * Two signer modes, in order of preference:
 *
 * 1. EXTERNAL WALLET (preferred) — PumpPortal's *local* transaction API builds
 *    an unsigned create transaction for a public key AUTH supplies. AUTH signs
 *    it server-side with the launch wallet (`LAUNCHER_PRIVATE_KEY`) plus the
 *    single-use mint keypair, then broadcasts it to Solana itself. The launch
 *    wallet is the real signer and funder, and dev-buy tokens land directly in
 *    it. PumpPortal is used only to construct the transaction.
 *
 * 2. PROVIDER-HOSTED (fallback) — the Lightning API signs with PumpPortal's own
 *    hosted wallet. That wallet is execution infrastructure only; it is never
 *    the beneficial owner, and dev-buy delivery is reported as pending manual
 *    settlement because the provider exposes no transfer endpoint.
 *
 * Key handling: AUTH never handles a user's key. The launch wallet secret is a
 * server-only secret, used inside one signing step, never logged or returned.
 * A fresh mint keypair is generated per launch, used once, never persisted.
 *
 * This adapter never fabricates a mint or a signature.
 */

import { Keypair, VersionedTransaction } from "@solana/web3.js";
import bs58 from "bs58";
import { loadLauncherKeypair, launcherWalletStatus } from "@/lib/launcher-wallet.server";
import { getSolBalance, rpcEndpoint, sendRawTransactionBase64 } from "./helius.server";

/**
 * Creator-fee / pair asset for the launch. pump.fun itself supports SOL- and
 * USDC-paired coins, but a pair is only launchable here if the provider path
 * AUTH actually uses can create it. See `pumpfunSupportsQuoteAsset`.
 */
export type PumpfunQuoteAsset = "sol" | "usdc";

export interface PumpfunLaunchRequest {
  /** Pair/reward asset the creator fees are collected and paid in. */
  quoteAsset: PumpfunQuoteAsset;
  name: string;
  symbol: string;
  description: string | null;
  imageUrl: string | null;
  website: string | null;
  twitter: string | null;
  telegram: string | null;
  /**
   * Optional dev buy: extra SOL, on top of the creation cost, spent in the same
   * pump.fun create transaction to buy the new token. In external-wallet mode
   * the SOL comes from the launch wallet and the tokens land in it. Either way
   * the tokens belong to the launcher, never to the social recipient. AUTH
   * takes no cut and applies no fee to it.
   */
  devBuySol?: number;
  /**
   * Optional audit hook. Called at each stage (construction, signing,
   * submission) so the launch audit timeline records what actually happened.
   * Only public, non-secret values are ever passed to it.
   */
  onStage?: (
    stage: "transaction_construction" | "signing" | "submission",
    status: "pass" | "fail",
    message: string,
    detail?: Record<string, unknown>,
  ) => void | Promise<void>;
}

export type PumpfunSignerMode = "external_wallet" | "provider_hosted";

export type PumpfunLaunchResult =
  | {
      ok: true;
      mint: string;
      signature: string;
      metadataUri: string;
      /** The wallet that signed and funded the launch. */
      launchWallet: string;
      signerMode: PumpfunSignerMode;
      /** Wallet the dev-buy tokens actually land in, or null when there was no dev buy. */
      devBuyOwnerWallet: string | null;
      /** True only when dev-buy tokens are in the launcher's own wallet. */
      devBuyDelivered: boolean;
    }
  | { ok: false; message: string };

export const PUMPFUN_BLOCKER =
  "pump.fun launching needs a configured launch wallet (LAUNCHER_PRIVATE_KEY plus a Solana RPC), or a PumpPortal API key, before a real token can be created. AUTH will not fabricate a mint or a launch transaction.";

const PUMPPORTAL_TRADE_URL = "https://pumpportal.fun/api/trade";
/** Builds an unsigned transaction for a public key AUTH supplies. No API key, no custody. */
const PUMPPORTAL_TRADE_LOCAL_URL = "https://pumpportal.fun/api/trade-local";
// Provider/execution infrastructure ONLY. This is PumpPortal's hosted account
// for this app's Lightning API key. It is never the beneficial owner of any
// token, and it is only used when no external launch wallet is configured.
const PUMPPORTAL_LAUNCH_WALLET = "7JpVSfV2sJPRLpkg3jij4ohsRgBMnYamku4e4dxBzfP";
const PUMPFUN_IPFS_URL = "https://pump.fun/api/ipfs";
const TIMEOUT_MS = 30_000;

function creds() {
  return {
    pumpportal: process.env["PUMPPORTAL_API_KEY"]?.trim() || null,
  };
}

/**
 * Which pairs the PumpPortal Lightning `create` path can actually launch today.
 *
 * The documented create payload exposes `pool` and `denominatedInSol` only —
 * there is no quote-mint parameter, so USDC-paired creation is not reachable
 * through this integration. AUTH blocks it instead of launching a SOL pair and
 * calling it USDC.
 */
export const PUMPFUN_SUPPORTED_QUOTE_ASSETS: PumpfunQuoteAsset[] = ["sol"];

export function pumpfunSupportsQuoteAsset(asset: PumpfunQuoteAsset): boolean {
  return PUMPFUN_SUPPORTED_QUOTE_ASSETS.includes(asset);
}

export function pumpfunQuoteAssetBlocker(asset: PumpfunQuoteAsset): string {
  return `USDC-paired launches are not available through AUTH's current pump.fun provider path, so creator fees cannot be collected in ${asset.toUpperCase()} yet. Choose SOL to launch now.`;
}

/**
 * Dev-buy custody, stated honestly.
 *
 * The PumpPortal Lightning API exposes exactly two actions on its hosted
 * wallet: `create` and `trade` (buy/sell). There is no transfer/withdraw
 * endpoint and AUTH holds no private key for that wallet, so AUTH cannot
 * move dev-buy tokens to the launcher automatically today. The launcher is
 * recorded as the beneficial owner and delivery is tracked as pending manual
 * settlement — AUTH never claims the launcher has received the tokens.
 */
export const PUMPFUN_DEV_BUY_AUTO_DELIVERY = false;

/** True when launches are signed by AUTH's own Solana launch wallet. */
export function pumpfunDevBuyAutoDelivery(): boolean {
  return pumpfunSignerMode() === "external_wallet";
}

export const PUMPFUN_DEV_BUY_CUSTODY_NOTE =
  "Dev-buy tokens are bought by the provider-hosted execution wallet that signs the launch. AUTH records you as the beneficial owner, but the current pump.fun provider API (PumpPortal Lightning) has no transfer endpoint, so delivery to your own wallet is settled manually and is marked pending until it lands.";

export const PUMPFUN_DEV_BUY_PENDING_NOTE =
  "Your dev-buy tokens were bought in the launch transaction and are held by the execution wallet for a moment before AUTH forwards them to your wallet. Until the forwarding transaction confirms on Solana, AUTH shows this as pending — never as delivered.";

/**
 * Solana network/provider cost of a pump.fun create transaction, kept as launch
 * INFRASTRUCTURE funding. AUTH's launch wallet covers this and nothing else —
 * it never funds a launcher's dev buy.
 */
export const LAUNCH_INFRASTRUCTURE_COST_LAMPORTS = 3_000_000; // ~0.003 SOL
/** Headroom the launch wallet keeps for infrastructure costs. */
const INFRASTRUCTURE_RESERVE_SOL = 0.01;

/**
 * Where a launcher's optional dev-buy SOL must be sent. This is always the
 * account that will actually sign and execute the buy, so AUTH's infrastructure
 * balance is never spent on a user's dev buy.
 */
export function pumpfunDevBuyFundingAddress(): string | null {
  const mode = pumpfunSignerMode();
  if (mode === "external_wallet") {
    const status = launcherWalletStatus();
    return status.state === "configured" ? status.address : null;
  }
  if (mode === "provider_hosted") return PUMPPORTAL_LAUNCH_WALLET;
  return null;
}

/** External-wallet signing is available when the launch wallet secret parses. */
export function pumpfunSignerMode(): PumpfunSignerMode | null {
  if (launcherWalletStatus().state === "configured" && rpcEndpoint()) return "external_wallet";
  if (creds().pumpportal) return "provider_hosted";
  return null;
}

export function pumpfunConfigured(): boolean {
  return pumpfunSignerMode() !== null;
}

export function pumpfunMissing(): string[] {
  if (pumpfunConfigured()) return [];
  const missing: string[] = [];
  const status = launcherWalletStatus();
  if (status.state !== "configured") missing.push("Launch wallet secret (LAUNCHER_PRIVATE_KEY)");
  if (!rpcEndpoint()) missing.push("Solana RPC (HELIUS_RPC_URL or HELIUS_API_KEY)");
  if (!creds().pumpportal) missing.push("PumpPortal API key");
  return missing;
}

async function withTimeout(input: string, init: RequestInit): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    return await fetch(input, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Uploads the token image plus metadata through pump.fun's own IPFS endpoint
 * and returns the metadata URI pump.fun expects on the create transaction.
 */
async function uploadMetadata(
  request: PumpfunLaunchRequest,
  image: Blob,
  filename: string,
): Promise<string> {
  const form = new FormData();
  form.append("file", image, filename);
  form.append("name", request.name);
  form.append("symbol", request.symbol);
  form.append("description", request.description ?? "");
  form.append("twitter", request.twitter ?? "");
  form.append("telegram", request.telegram ?? "");
  form.append("website", request.website ?? "");
  form.append("showName", "true");

  const res = await withTimeout(PUMPFUN_IPFS_URL, { method: "POST", body: form });
  const text = await res.text();
  let uri: string | null = null;
  try {
    uri = (JSON.parse(text) as { metadataUri?: string }).metadataUri ?? null;
  } catch {
    uri = null;
  }
  if (!res.ok || !uri) {
    throw new Error(`metadata upload rejected (${res.status}) ${text.slice(0, 160)}`);
  }
  return uri;
}

async function fetchImage(url: string): Promise<Blob | null> {
  try {
    const res = await withTimeout(url, { method: "GET" });
    if (!res.ok) return null;
    const blob = await res.blob();
    if (blob.size === 0 || blob.size > 5_000_000) return null;
    return blob;
  } catch {
    return null;
  }
}

export async function createPumpfunLaunch(
  request: PumpfunLaunchRequest,
): Promise<PumpfunLaunchResult> {
  const mode = pumpfunSignerMode();
  if (!mode) return { ok: false, message: PUMPFUN_BLOCKER };
  if (!pumpfunSupportsQuoteAsset(request.quoteAsset)) {
    return { ok: false, message: pumpfunQuoteAssetBlocker(request.quoteAsset) };
  }

  // 1. Pin the image and metadata document through pump.fun's IPFS endpoint.
  let metadataUri: string;
  try {
    if (!request.imageUrl) {
      return { ok: false, message: "pump.fun requires a token image. Add one and try again." };
    }
    const image = await fetchImage(request.imageUrl);
    if (!image) {
      return { ok: false, message: "The token image could not be read. Upload it again and retry." };
    }
    metadataUri = await uploadMetadata(
      request,
      image,
      `${request.symbol.toLowerCase()}-image`,
    );
  } catch (e) {
    return {
      ok: false,
      message: e instanceof Error ? `Token metadata upload failed: ${e.message}` : "Token metadata upload failed.",
    };
  }

  // 2. Fresh, single-use mint keypair. Never stored, never reused.
  const mintKeypair = Keypair.generate();
  const mint = mintKeypair.publicKey.toBase58();
  const devBuySol = Math.max(0, request.devBuySol ?? 0);

  // 3. Real pump.fun creation transaction.
  if (mode === "external_wallet") {
    return await createWithExternalWallet(request, metadataUri, mintKeypair, devBuySol);
  }
  return await createWithProviderWallet(request, metadataUri, mintKeypair, devBuySol);
}

/**
 * Preferred path: AUTH's own Solana launch wallet is the signer and funder.
 *
 * PumpPortal only builds the transaction. AUTH signs it server-side and
 * broadcasts it, so the dev buy is paid by the launch wallet and the purchased
 * tokens land in that same wallet — no provider custody at any point.
 */
async function createWithExternalWallet(
  request: PumpfunLaunchRequest,
  metadataUri: string,
  mintKeypair: Keypair,
  devBuySol: number,
): Promise<PumpfunLaunchResult> {
  const launcher = loadLauncherKeypair();
  if (!launcher) {
    return {
      ok: false,
      message:
        "The launch wallet secret could not be read, so no transaction was built or sent. Check LAUNCHER_PRIVATE_KEY.",
    };
  }
  const launchWallet = launcher.publicKey.toBase58();
  const mint = mintKeypair.publicKey.toBase58();

  // Mainnet safety, with the two pots kept strictly separate:
  //  - INFRASTRUCTURE: AUTH's own launch-wallet SOL, for network/provider cost
  //    of the create transaction only.
  //  - DEV BUY: SOL the launcher already sent to this same execution account
  //    for this exact attempt. AUTH never tops a dev buy up from its own SOL.
  const balance = await getSolBalance(launchWallet);
  if (!balance.ok) {
    return { ok: false, message: `The launch wallet balance could not be read, so nothing was sent: ${balance.message}` };
  }
  if (balance.data < devBuySol + INFRASTRUCTURE_RESERVE_SOL) {
    return {
      ok: false,
      message:
        devBuySol > 0
          ? `Your ${devBuySol} SOL dev-buy funding has not arrived in the launch account yet, and AUTH will not fund a dev buy from its own launch infrastructure balance. Nothing was sent — wait for the payment to confirm and retry.`
          : `The launch wallet holds ${balance.data.toFixed(4)} SOL, which is not enough to cover the Solana network cost of the launch transaction. Nothing was sent.`,
    };
  }

  const stage = request.onStage ?? (() => {});

  // Construct -> sign -> send, with a bounded rebuild on a stale blockhash.
  // pump.fun returns a transaction with its own recent blockhash; if that
  // expires before Solana sees it, the only correct fix is to rebuild it.
  let signature = "";
  const MAX_TRIES = 3;
  for (let tryIndex = 1; tryIndex <= MAX_TRIES; tryIndex++) {
    let serialized: Uint8Array;
    try {
      const res = await withTimeout(PUMPPORTAL_TRADE_LOCAL_URL, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          publicKey: launchWallet,
          action: "create",
          tokenMetadata: { name: request.name, symbol: request.symbol, uri: metadataUri },
          mint,
          denominatedInSol: "true",
          amount: devBuySol,
          slippage: 10,
          priorityFee: 0.0005,
          pool: "pump",
        }),
      });
      if (!res.ok) {
        const text = await res.text();
        const message = `pump.fun rejected the launch transaction (${res.status}): ${text.slice(0, 200)}`;
        await stage("transaction_construction", "fail", message, { mint, launchWallet, try: tryIndex });
        return { ok: false, message };
      }
      serialized = new Uint8Array(await res.arrayBuffer());
      if (serialized.byteLength === 0) {
        const message = "pump.fun returned an empty launch transaction. Nothing was signed or sent.";
        await stage("transaction_construction", "fail", message, { mint, launchWallet, try: tryIndex });
        return { ok: false, message };
      }
      await stage("transaction_construction", "pass", "pump.fun returned an unsigned create transaction.", {
        mint,
        launchWallet,
        transactionBytes: serialized.byteLength,
        devBuySol,
        try: tryIndex,
      });
    } catch (e) {
      const message =
        e instanceof Error ? `Building the launch transaction failed: ${e.message}` : "Building the launch transaction failed.";
      await stage("transaction_construction", "fail", message, { mint, launchWallet, try: tryIndex });
      return { ok: false, message };
    }

    // Sign server-side: the mint being created, plus the launch wallet that pays.
    try {
      const tx = VersionedTransaction.deserialize(serialized);
      tx.sign([mintKeypair, launcher]);
      const encoded = Buffer.from(tx.serialize()).toString("base64");
      await stage("signing", "pass", "Transaction signed server-side by the launch wallet and the new mint.", {
        mint,
        launchWallet,
        signers: 2,
        try: tryIndex,
      });
      const sent = await sendRawTransactionBase64(encoded);
      if (!sent.ok) {
        const stale = /blockhash not found|block height exceeded|blockhash expired/i.test(sent.message);
        if (stale && tryIndex < MAX_TRIES) {
          await stage("submission", "fail", "Blockhash expired before broadcast; rebuilding the transaction.", {
            mint,
            try: tryIndex,
          });
          continue;
        }
        // Honest failure: no mint and no signature are recorded.
        const message = `The launch transaction was rejected by Solana: ${sent.message}`;
        await stage("submission", "fail", message, { mint, launchWallet, try: tryIndex });
        return { ok: false, message };
      }
      signature = sent.data;
      await stage("submission", "pass", "Transaction broadcast to Solana mainnet.", { mint, signature });
      break;
    } catch (e) {
      const message =
        e instanceof Error ? `Signing or sending the launch failed: ${e.message}` : "Signing or sending the launch failed.";
      await stage("signing", "fail", message, { mint, launchWallet, try: tryIndex });
      return { ok: false, message };
    }
  }

  if (!signature) {
    return { ok: false, message: "The launch transaction could not be broadcast. Nothing was sent." };
  }

  return {
    ok: true,
    mint,
    signature,
    metadataUri,
    launchWallet,
    signerMode: "external_wallet",
    // The execution wallet only holds the dev-buy tokens momentarily. It is
    // never the beneficial owner, and delivery is only true once the forwarding
    // transfer to the launcher's own wallet has confirmed.
    devBuyOwnerWallet: devBuySol > 0 ? launchWallet : null,
    devBuyDelivered: false,
  };
}

/**
 * Fallback path: PumpPortal's hosted wallet signs. It is execution
 * infrastructure only — dev-buy tokens sit there pending manual settlement and
 * AUTH never calls them delivered.
 */
async function createWithProviderWallet(
  request: PumpfunLaunchRequest,
  metadataUri: string,
  mintKeypair: Keypair,
  devBuySol: number,
): Promise<PumpfunLaunchResult> {
  const { pumpportal } = creds();
  if (!pumpportal) return { ok: false, message: PUMPFUN_BLOCKER };
  const mint = mintKeypair.publicKey.toBase58();

  try {
    const res = await withTimeout(`${PUMPPORTAL_TRADE_URL}?api-key=${encodeURIComponent(pumpportal)}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        action: "create",
        tokenMetadata: { name: request.name, symbol: request.symbol, uri: metadataUri },
        mint: bs58.encode(mintKeypair.secretKey),
        denominatedInSol: "true",
        amount: devBuySol,
        slippage: 10,
        priorityFee: 0.0005,
        pool: "pump",
      }),
    });

    const text = await res.text();
    let signature: string | null = null;
    try {
      const json = JSON.parse(text) as { signature?: string; errors?: unknown; error?: unknown };
      signature = json.signature ?? null;
      if (!signature) {
        const detail = json.errors ?? json.error ?? text;
        return { ok: false, message: `pump.fun launch was rejected: ${JSON.stringify(detail).slice(0, 300)}` };
      }
    } catch {
      return { ok: false, message: `pump.fun launch failed (${res.status}): ${text.slice(0, 200)}` };
    }

    return {
      ok: true,
      mint,
      signature,
      metadataUri,
      launchWallet: PUMPPORTAL_LAUNCH_WALLET,
      signerMode: "provider_hosted",
      devBuyOwnerWallet: null,
      devBuyDelivered: false,
    };
  } catch (e) {
    return {
      ok: false,
      message: e instanceof Error ? `pump.fun launch failed: ${e.message}` : "pump.fun launch failed.",
    };
  }
}
