import {
  notConfigured,
  type AdapterResult,
  type CharityAdapter,
  type FeeSourceAdapter,
  type IdentityAdapter,
  type PayoutAdapter,
  type SwapAdapter,
} from "./types";

/**
 * Stub implementations. Each one is deliberately inert: it reports that it is
 * not configured instead of pretending a transfer happened. Swapping in a real
 * provider means replacing the object here — no product code changes.
 */

export const solanaIndexerAdapter: FeeSourceAdapter = {
  key: "solana_rpc",
  name: "Solana RPC / Indexer",
  category: "data",
  status: "live",
  description:
    "Helius mainnet RPC is connected. Mint verification, balances, blockhashes and transaction confirmation are read live from Solana.",
  async fetchFeeEvents() {
    return notConfigured("Solana RPC") as AdapterResult<never>;
  },
};

export const pumpfunAdapter: FeeSourceAdapter = {
  key: "pumpfun",
  name: "pump.fun launchpad",
  category: "launchpad",
  status: "planned",
  description: "Launch source adapter. Interface only — no credentials connected.",
  async fetchFeeEvents() {
    return notConfigured("pump.fun adapter") as AdapterResult<never>;
  },
};

export const swapAdapter: SwapAdapter = {
  key: "jupiter_swap",
  name: "Swap router (buyback & burn)",
  category: "swap",
  status: "planned",
  description: "Converts routed fees into token buybacks or burns.",
  async quote() {
    return notConfigured("Swap router") as AdapterResult<never>;
  },
};

export const xOAuthAdapter: IdentityAdapter = {
  key: "x_oauth",
  name: "X (Twitter) OAuth",
  category: "identity",
  status: "planned",
  description: "Handle ownership verification. Manual review is used in the meantime.",
  async startVerification() {
    return notConfigured("X OAuth") as AdapterResult<never>;
  },
};

export const xMoneyPayoutAdapter: PayoutAdapter = {
  key: "x_money",
  name: "X Money payout",
  category: "payout",
  status: "disabled",
  description:
    "No public third-party payout API into X balances exists today, so this rail is off. Amounts routed here stay claimable by the recipient.",
  async send() {
    return notConfigured("X Money payout adapter") as AdapterResult<never>;
  },
};

export const walletPayoutAdapter: PayoutAdapter = {
  key: "wallet_payout",
  name: "Solana wallet payout",
  category: "payout",
  status: "live",
  description:
    "SOL and USDC payouts authorized by the account owner with a passkey and confirmed on Solana mainnet. Private keys and seed phrases are never requested or stored. Automated custody signing is not enabled.",
  async send() {
    return notConfigured("Automated custody signer (walletless passkey authorization is used instead)") as AdapterResult<never>;
  },
};

export const charityAdapter: CharityAdapter = {
  key: "charity_registry",
  name: "Charity registry",
  category: "charity",
  status: "sandbox",
  description: "Resolves a charity slug to a destination wallet. Demo wallets only.",
  async resolve() {
    return notConfigured("Charity registry") as AdapterResult<never>;
  },
};

export const adapterRegistry = {
  solana_rpc: solanaIndexerAdapter,
  pumpfun: pumpfunAdapter,
  jupiter_swap: swapAdapter,
  x_oauth: xOAuthAdapter,
  x_money: xMoneyPayoutAdapter,
  wallet_payout: walletPayoutAdapter,
  charity_registry: charityAdapter,
} as const;

export type AdapterKey = keyof typeof adapterRegistry;
