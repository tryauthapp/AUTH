/**
 * Helius RPC client — SERVER ONLY.
 *
 * Read-only JSON-RPC access to Solana via Helius. This module never handles,
 * requests, or stores private keys or seed phrases: it only reads public
 * chain state. The API key is read from the server environment at call time.
 */

export type HeliusResult<T> =
  | { ok: true; data: T }
  | { ok: false; reason: "not_configured" | "provider_error"; message: string };

const RPC_TIMEOUT_MS = 12_000;

/** Accepts either a bare Helius API key or a full Helius RPC URL. */
function endpoint(): string | null {
  // An explicit RPC URL wins; otherwise a Helius key or full Helius URL.
  const explicit = process.env["HELIUS_RPC_URL"]?.trim();
  if (explicit) return explicit;
  const raw = process.env["HELIUS_API_KEY"]?.trim();
  if (!raw) return null;
  if (raw.startsWith("http://") || raw.startsWith("https://")) return raw;
  return `https://mainnet.helius-rpc.com/?api-key=${raw}`;
}

export function heliusConfigured(): boolean {
  return Boolean(endpoint());
}

/** The mainnet RPC endpoint in use, or null when none is configured. */
export function rpcEndpoint(): string | null {
  return endpoint();
}

/**
 * Broadcasts an already-signed transaction. Signing happens elsewhere; this
 * module never sees a private key.
 */
export async function sendRawTransactionBase64(
  base64: string,
): Promise<HeliusResult<string>> {
  return rpc<string>("sendTransaction", [
    base64,
    { encoding: "base64", skipPreflight: false, maxRetries: 3 },
  ]);
}

/**
 * Dry-runs a signed transaction against the current bank WITHOUT broadcasting
 * it. Used by the admin smoke test: nothing is ever committed on-chain.
 */
export async function simulateTransactionBase64(
  base64: string,
  sigVerify = true,
): Promise<HeliusResult<{ err: unknown; unitsConsumed: number | null; logs: string[] }>> {
  const r = await rpc<{
    value: { err: unknown; unitsConsumed?: number | null; logs?: string[] | null };
  }>("simulateTransaction", [
    base64,
    { encoding: "base64", sigVerify, replaceRecentBlockhash: !sigVerify, commitment: "confirmed" },
  ]);
  if (!r.ok) return r;
  return {
    ok: true,
    data: {
      err: r.data?.value?.err ?? null,
      unitsConsumed: r.data?.value?.unitsConsumed ?? null,
      logs: (r.data?.value?.logs ?? []).slice(0, 12),
    },
  };
}

async function rpc<T>(method: string, params: unknown[]): Promise<HeliusResult<T>> {
  const url = endpoint();
  if (!url) {
    return {
      ok: false,
      reason: "not_configured",
      message: "Helius RPC is not configured. No on-chain data was read.",
    };
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), RPC_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: "crypto", method, params }),
      signal: controller.signal,
    });
    if (!res.ok) {
      return { ok: false, reason: "provider_error", message: `Helius returned ${res.status}` };
    }
    const json = (await res.json()) as { result?: T; error?: { message?: string } };
    if (json.error) {
      return { ok: false, reason: "provider_error", message: json.error.message ?? "RPC error" };
    }
    return { ok: true, data: json.result as T };
  } catch (e) {
    const message = e instanceof Error ? e.message : "Unknown RPC failure";
    return { ok: false, reason: "provider_error", message };
  } finally {
    clearTimeout(timer);
  }
}

export const LAMPORTS_PER_SOL = 1_000_000_000;

export async function getSolBalance(address: string): Promise<HeliusResult<number>> {
  const r = await rpc<{ value: number }>("getBalance", [address]);
  if (!r.ok) return r;
  return { ok: true, data: (r.data?.value ?? 0) / LAMPORTS_PER_SOL };
}

export interface ChainSignature {
  signature: string;
  slot: number;
  blockTime: number | null;
  err: unknown;
}

export async function getRecentSignatures(
  address: string,
  limit = 10,
): Promise<HeliusResult<ChainSignature[]>> {
  const r = await rpc<ChainSignature[]>("getSignaturesForAddress", [address, { limit }]);
  if (!r.ok) return r;
  return { ok: true, data: r.data ?? [] };
}

export interface TransactionSummary {
  signature: string;
  slot: number;
  blockTime: number | null;
  succeeded: boolean;
  feeLamports: number;
}

export async function getTransactionSummary(
  signature: string,
): Promise<HeliusResult<TransactionSummary | null>> {
  const r = await rpc<{
    slot: number;
    blockTime: number | null;
    meta: { err: unknown; fee: number } | null;
  }>("getTransaction", [
    signature,
    { maxSupportedTransactionVersion: 0, encoding: "json" },
  ]);
  if (!r.ok) return r;
  if (!r.data) return { ok: true, data: null };
  return {
    ok: true,
    data: {
      signature,
      slot: r.data.slot,
      blockTime: r.data.blockTime,
      succeeded: !r.data.meta?.err,
      feeLamports: r.data.meta?.fee ?? 0,
    },
  };
}

export async function getTokenSupply(mint: string): Promise<HeliusResult<number | null>> {
  const r = await rpc<{ value: { uiAmount: number | null } }>("getTokenSupply", [mint]);
  if (!r.ok) return r;
  return { ok: true, data: r.data?.value?.uiAmount ?? null };
}

/* ------------------------------------------------------------------ *
 * Transaction-support reads (still read-only; no key material here).  *
 * ------------------------------------------------------------------ */

export async function getLatestBlockhash(): Promise<
  HeliusResult<{ blockhash: string; lastValidBlockHeight: number }>
> {
  const r = await rpc<{ value: { blockhash: string; lastValidBlockHeight: number } }>(
    "getLatestBlockhash",
    [{ commitment: "confirmed" }],
  );
  if (!r.ok) return r;
  if (!r.data?.value) {
    return { ok: false, reason: "provider_error", message: "No blockhash returned." };
  }
  return { ok: true, data: r.data.value };
}

export async function accountExists(address: string): Promise<HeliusResult<boolean>> {
  const r = await rpc<{ value: unknown }>("getAccountInfo", [
    address,
    { encoding: "base64", commitment: "confirmed" },
  ]);
  if (!r.ok) return r;
  return { ok: true, data: Boolean(r.data?.value) };
}

export interface MintInfo {
  mint: string;
  decimals: number;
  supply: number | null;
  isToken: boolean;
}

/** Confirms a mint really exists on mainnet and reads its supply/decimals. */
export async function getMintInfo(mint: string): Promise<HeliusResult<MintInfo | null>> {
  const r = await rpc<{
    value: { uiAmount: number | null; decimals: number } | null;
  }>("getTokenSupply", [mint, { commitment: "confirmed" }]);
  if (!r.ok) {
    // getTokenSupply errors for non-mint accounts; treat as "not a token".
    if (/could not find mint|invalid param|not a Token mint/i.test(r.message)) {
      return { ok: true, data: null };
    }
    return r;
  }
  if (!r.data?.value) return { ok: true, data: null };
  return {
    ok: true,
    data: {
      mint,
      decimals: r.data.value.decimals,
      supply: r.data.value.uiAmount,
      isToken: true,
    },
  };
}

export interface SignatureStatus {
  confirmationStatus: "processed" | "confirmed" | "finalized" | null;
  err: unknown;
  slot: number | null;
}

export async function getSignatureStatus(
  signature: string,
): Promise<HeliusResult<SignatureStatus | null>> {
  const r = await rpc<{ value: (SignatureStatus | null)[] }>("getSignatureStatuses", [
    [signature],
    { searchTransactionHistory: true },
  ]);
  if (!r.ok) return r;
  return { ok: true, data: r.data?.value?.[0] ?? null };
}

export interface TransferVerification {
  /** The transaction exists on-chain. */
  found: boolean;
  /** It executed without error. */
  succeeded: boolean;
  /** The expected sender signed it. */
  senderSigned: boolean;
  /** The destination's balance for the expected asset increased by the expected amount. */
  amountMatched: boolean;
  receivedRaw: number;
}

/**
 * Verifies that a submitted signature really is the transfer the payment record
 * describes: signed by the sender, crediting the destination with at least the
 * expected amount of the expected asset.
 *
 * This is what makes accountless payments safe — authorization comes from the
 * chain, not from a platform login.
 */
export async function verifyTransfer(
  signature: string,
  expected: { from: string; to: string; mint: string | null; amount: number; decimals: number },
): Promise<HeliusResult<TransferVerification>> {
  const r = await rpc<{
    meta: {
      err: unknown;
      preBalances: number[];
      postBalances: number[];
      preTokenBalances?: { accountIndex: number; mint: string; owner?: string; uiTokenAmount: { amount: string } }[];
      postTokenBalances?: { accountIndex: number; mint: string; owner?: string; uiTokenAmount: { amount: string } }[];
    } | null;
    transaction: { message: { accountKeys: { pubkey: string; signer: boolean }[] } };
  }>("getTransaction", [
    signature,
    { maxSupportedTransactionVersion: 0, encoding: "jsonParsed" },
  ]);
  if (!r.ok) return r;
  if (!r.data) {
    return {
      ok: true,
      data: { found: false, succeeded: false, senderSigned: false, amountMatched: false, receivedRaw: 0 },
    };
  }

  const keys = r.data.transaction?.message?.accountKeys ?? [];
  const senderSigned = keys.some((k) => k.pubkey === expected.from && k.signer);
  const succeeded = !r.data.meta?.err;

  // Tolerate rounding at the last unit of precision.
  const expectedRaw = Math.round(expected.amount * 10 ** expected.decimals);
  let receivedRaw = 0;

  if (!expected.mint) {
    const index = keys.findIndex((k) => k.pubkey === expected.to);
    if (index >= 0 && r.data.meta) {
      receivedRaw =
        (r.data.meta.postBalances[index] ?? 0) - (r.data.meta.preBalances[index] ?? 0);
    }
  } else {
    const sum = (rows: { mint: string; owner?: string; accountIndex: number; uiTokenAmount: { amount: string } }[] | undefined) =>
      (rows ?? [])
        .filter((b) => b.mint === expected.mint && b.owner === expected.to)
        .reduce((acc, b) => acc + Number(b.uiTokenAmount.amount ?? 0), 0);
    receivedRaw = sum(r.data.meta?.postTokenBalances) - sum(r.data.meta?.preTokenBalances);
  }

  return {
    ok: true,
    data: {
      found: true,
      succeeded,
      senderSigned,
      amountMatched: receivedRaw >= expectedRaw - 1,
      receivedRaw,
    },
  };
}

/**
 * Verifies a plain SOL credit: that `signature` is a successful mainnet
 * transaction which increased `to`'s balance by at least `minLamports`.
 * Used for the launch fee, where any wallet may pay.
 */
export async function verifySolCredit(
  signature: string,
  to: string,
  minLamports: number,
): Promise<
  HeliusResult<{
    found: boolean;
    succeeded: boolean;
    creditedLamports: number;
    payer: string | null;
    senders: string[];
  }>
> {
  const r = await rpc<{
    meta: { err: unknown; preBalances: number[]; postBalances: number[] } | null;
    transaction: { message: { accountKeys: { pubkey: string; signer: boolean }[] } };
  }>("getTransaction", [
    signature,
    { maxSupportedTransactionVersion: 0, encoding: "jsonParsed" },
  ]);
  if (!r.ok) return r;
  if (!r.data) {
    return {
      ok: true,
      data: { found: false, succeeded: false, creditedLamports: 0, payer: null, senders: [] },
    };
  }
  const keys = r.data.transaction?.message?.accountKeys ?? [];
  const index = keys.findIndex((k) => k.pubkey === to);
  const credited =
    index >= 0 && r.data.meta
      ? (r.data.meta.postBalances[index] ?? 0) - (r.data.meta.preBalances[index] ?? 0)
      : 0;
  // Every account whose balance went down: the fee payer, but also a wallet
  // that funded the transfer without signing it (relayers, smart wallets).
  const senders = keys
    .map((k, i) => ({
      pubkey: k.pubkey,
      delta:
        (r.data!.meta?.postBalances[i] ?? 0) - (r.data!.meta?.preBalances[i] ?? 0),
    }))
    .filter((k) => k.delta < 0)
    .map((k) => k.pubkey);
  void minLamports;
  return {
    ok: true,
    data: {
      found: true,
      succeeded: !r.data.meta?.err,
      creditedLamports: credited,
      payer: keys.find((k) => k.signer)?.pubkey ?? null,
      senders,
    },
  };
}

/**
 * Lists recent incoming SOL credits to `address` by reading its latest
 * transactions. Read-only; used to match a launch-fee payment automatically so
 * the payer never has to paste a signature.
 */
export async function listRecentSolCredits(
  address: string,
  limit = 15,
): Promise<
  HeliusResult<
    {
      signature: string;
      credited: number;
      payer: string | null;
      senders: string[];
      blockTime: number | null;
    }[]
  >
> {
  const sigs = await getRecentSignatures(address, limit);
  if (!sigs.ok) return sigs;
  // Read transactions concurrently. Sequential RPC calls made the launch-fee
  // poll take long enough for the browser request to time out even when a valid
  // payment was already visible on-chain.
  const checked = await Promise.all(
    sigs.data
      .filter((s) => !s.err)
      .map(async (s) => ({ signature: s, transaction: await verifySolCredit(s.signature, address, 0) })),
  );
  const out = checked.flatMap(({ signature: s, transaction: tx }) => {
    if (!tx.ok || !tx.data.found || !tx.data.succeeded || tx.data.creditedLamports <= 0) {
      return [];
    }
    return [{
      signature: s.signature,
      credited: tx.data.creditedLamports,
      payer: tx.data.payer,
      senders: tx.data.senders,
      blockTime: s.blockTime,
    }];
  });
  return { ok: true, data: out };
}
