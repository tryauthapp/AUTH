/**
 * Integration adapter contracts.
 *
 * UI and business logic depend ONLY on these interfaces. Concrete providers
 * (RPC/indexer, launchpads, swap routers, charity registries, X OAuth,
 * X Money, payout rails) are registered separately so they can be added later
 * without touching product code.
 *
 * Every adapter is required to report an honest status. An adapter that is not
 * configured must return { ok: false, reason: "not_configured" } — it must
 * never fabricate a success.
 */

export type IntegrationStatus = "live" | "sandbox" | "planned" | "disabled";

export type AdapterFailureReason =
  | "not_configured"
  | "unsupported"
  | "provider_error"
  | "rejected";

export type AdapterResult<T> =
  | { ok: true; data: T }
  | { ok: false; reason: AdapterFailureReason; message: string };

export function notConfigured(name: string): AdapterResult<never> {
  return {
    ok: false,
    reason: "not_configured",
    message: `${name} is not configured. No funds were moved.`,
  };
}

export interface AdapterDescriptor {
  key: string;
  name: string;
  category: "data" | "launchpad" | "swap" | "charity" | "identity" | "payout";
  status: IntegrationStatus;
  description: string;
}

/** Reads creator-fee events from a chain indexer. */
export interface FeeSourceAdapter extends AdapterDescriptor {
  category: "data" | "launchpad";
  fetchFeeEvents(params: {
    mint: string;
    since?: string;
  }): Promise<AdapterResult<RawFeeEvent[]>>;
}

export interface RawFeeEvent {
  externalId: string;
  txSignature: string;
  mint: string;
  grossUsd: number;
  occurredAt: string;
}

/** Converts routed fees into buybacks or burns. */
export interface SwapAdapter extends AdapterDescriptor {
  category: "swap";
  quote(params: { mint: string; amountUsd: number }): Promise<AdapterResult<{ outAmount: number }>>;
}

/** Verifies ownership of an X handle. */
export interface IdentityAdapter extends AdapterDescriptor {
  category: "identity";
  startVerification(handle: string): Promise<AdapterResult<{ verificationUrl: string }>>;
}

/** Sends a payout on a given rail. Never handles private keys. */
export interface PayoutAdapter extends AdapterDescriptor {
  category: "payout";
  send(params: {
    idempotencyKey: string;
    amountUsd: number;
    destination: string;
  }): Promise<AdapterResult<{ reference: string }>>;
}

export interface CharityAdapter extends AdapterDescriptor {
  category: "charity";
  resolve(slug: string): Promise<AdapterResult<{ walletAddress: string }>>;
}

export type AnyAdapter =
  | FeeSourceAdapter
  | SwapAdapter
  | IdentityAdapter
  | PayoutAdapter
  | CharityAdapter;
