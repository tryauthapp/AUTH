export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      assets: {
        Row: {
          category: string | null
          chain_key: string
          coingecko_id: string | null
          contract_address: string | null
          decimals: number
          freeze_authority: string | null
          is_payable: boolean
          issuer: string | null
          key: string
          kind: string
          logo_url: string | null
          market_rank: number | null
          mint_verified_at: string | null
          name: string
          notes: string | null
          status: Database["public"]["Enums"]["integration_status"]
          symbol: string
          token_program: string | null
          updated_at: string
        }
        Insert: {
          category?: string | null
          chain_key: string
          coingecko_id?: string | null
          contract_address?: string | null
          decimals?: number
          freeze_authority?: string | null
          is_payable?: boolean
          issuer?: string | null
          key: string
          kind?: string
          logo_url?: string | null
          market_rank?: number | null
          mint_verified_at?: string | null
          name: string
          notes?: string | null
          status?: Database["public"]["Enums"]["integration_status"]
          symbol: string
          token_program?: string | null
          updated_at?: string
        }
        Update: {
          category?: string | null
          chain_key?: string
          coingecko_id?: string | null
          contract_address?: string | null
          decimals?: number
          freeze_authority?: string | null
          is_payable?: boolean
          issuer?: string | null
          key?: string
          kind?: string
          logo_url?: string | null
          market_rank?: number | null
          mint_verified_at?: string | null
          name?: string
          notes?: string | null
          status?: Database["public"]["Enums"]["integration_status"]
          symbol?: string
          token_program?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "assets_chain_key_fkey"
            columns: ["chain_key"]
            isOneToOne: false
            referencedRelation: "chains"
            referencedColumns: ["key"]
          },
        ]
      }
      audit_log: {
        Row: {
          action: string
          actor_id: string | null
          created_at: string
          entity: string | null
          entity_id: string | null
          id: string
          metadata: Json
        }
        Insert: {
          action: string
          actor_id?: string | null
          created_at?: string
          entity?: string | null
          entity_id?: string | null
          id?: string
          metadata?: Json
        }
        Update: {
          action?: string
          actor_id?: string | null
          created_at?: string
          entity?: string | null
          entity_id?: string | null
          id?: string
          metadata?: Json
        }
        Relationships: []
      }
      chains: {
        Row: {
          explorer_address_url: string | null
          explorer_tx_url: string | null
          key: string
          name: string
          native_symbol: string
          notes: string | null
          signer_kind: string
          sort_order: number
          status: Database["public"]["Enums"]["integration_status"]
          updated_at: string
        }
        Insert: {
          explorer_address_url?: string | null
          explorer_tx_url?: string | null
          key: string
          name: string
          native_symbol: string
          notes?: string | null
          signer_kind?: string
          sort_order?: number
          status?: Database["public"]["Enums"]["integration_status"]
          updated_at?: string
        }
        Update: {
          explorer_address_url?: string | null
          explorer_tx_url?: string | null
          key?: string
          name?: string
          native_symbol?: string
          notes?: string | null
          signer_kind?: string
          sort_order?: number
          status?: Database["public"]["Enums"]["integration_status"]
          updated_at?: string
        }
        Relationships: []
      }
      charities: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_demo: boolean
          name: string
          slug: string
          wallet_address: string | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_demo?: boolean
          name: string
          slug: string
          wallet_address?: string | null
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_demo?: boolean
          name?: string
          slug?: string
          wallet_address?: string | null
        }
        Relationships: []
      }
      claim_batches: {
        Row: {
          amount: number
          amount_usd: number | null
          asset: string
          confirmed_at: string | null
          created_at: string
          destination_address: string
          failure_reason: string | null
          id: string
          idempotency_key: string
          recipient_id: string
          source_address: string
          status: string
          tx_signature: string | null
          user_id: string
        }
        Insert: {
          amount: number
          amount_usd?: number | null
          asset: string
          confirmed_at?: string | null
          created_at?: string
          destination_address: string
          failure_reason?: string | null
          id?: string
          idempotency_key: string
          recipient_id: string
          source_address: string
          status?: string
          tx_signature?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          amount_usd?: number | null
          asset?: string
          confirmed_at?: string | null
          created_at?: string
          destination_address?: string
          failure_reason?: string | null
          id?: string
          idempotency_key?: string
          recipient_id?: string
          source_address?: string
          status?: string
          tx_signature?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "claim_batches_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
        ]
      }
      claims: {
        Row: {
          amount_usd: number
          claimed_by: string | null
          created_at: string
          id: string
          payout_id: string
          recipient_id: string
          resolved_at: string | null
          status: string
          wallet_address: string | null
        }
        Insert: {
          amount_usd: number
          claimed_by?: string | null
          created_at?: string
          id?: string
          payout_id: string
          recipient_id: string
          resolved_at?: string | null
          status?: string
          wallet_address?: string | null
        }
        Update: {
          amount_usd?: number
          claimed_by?: string | null
          created_at?: string
          id?: string
          payout_id?: string
          recipient_id?: string
          resolved_at?: string | null
          status?: string
          wallet_address?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "claims_payout_id_fkey"
            columns: ["payout_id"]
            isOneToOne: true
            referencedRelation: "payouts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "claims_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
        ]
      }
      creator_fee_mint_state: {
        Row: {
          creator_vault: string | null
          creator_wallet: string | null
          credits_created: number
          events_processed: number
          lamports_credited: number
          last_error: string | null
          last_signature: string | null
          last_synced_at: string | null
          mint: string
          provider: string | null
          provider_user_id: string | null
          recipient_id: string | null
          token_id: string | null
          updated_at: string
        }
        Insert: {
          creator_vault?: string | null
          creator_wallet?: string | null
          credits_created?: number
          events_processed?: number
          lamports_credited?: number
          last_error?: string | null
          last_signature?: string | null
          last_synced_at?: string | null
          mint: string
          provider?: string | null
          provider_user_id?: string | null
          recipient_id?: string | null
          token_id?: string | null
          updated_at?: string
        }
        Update: {
          creator_vault?: string | null
          creator_wallet?: string | null
          credits_created?: number
          events_processed?: number
          lamports_credited?: number
          last_error?: string | null
          last_signature?: string | null
          last_synced_at?: string | null
          mint?: string
          provider?: string | null
          provider_user_id?: string | null
          recipient_id?: string | null
          token_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "creator_fee_mint_state_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "creator_fee_mint_state_token_id_fkey"
            columns: ["token_id"]
            isOneToOne: false
            referencedRelation: "tokens"
            referencedColumns: ["id"]
          },
        ]
      }
      creator_fee_sync_runs: {
        Row: {
          credits_created: number
          error: string | null
          events_processed: number
          finished_at: string | null
          id: string
          lamports_credited: number
          mints_scanned: number
          settlement_note: string | null
          settlements: number
          started_at: string
          status: string
          trigger: string
        }
        Insert: {
          credits_created?: number
          error?: string | null
          events_processed?: number
          finished_at?: string | null
          id?: string
          lamports_credited?: number
          mints_scanned?: number
          settlement_note?: string | null
          settlements?: number
          started_at?: string
          status?: string
          trigger?: string
        }
        Update: {
          credits_created?: number
          error?: string | null
          events_processed?: number
          finished_at?: string | null
          id?: string
          lamports_credited?: number
          mints_scanned?: number
          settlement_note?: string | null
          settlements?: number
          started_at?: string
          status?: string
          trigger?: string
        }
        Relationships: []
      }
      embedded_wallets: {
        Row: {
          address: string
          created_at: string
          handle: string
          id: string
          identity_provider: string
          is_primary: boolean
          provider: string
          provider_user_id: string | null
          purpose: string
          recipient_id: string | null
          sub_organization_id: string
          user_id: string | null
          wallet_id: string
          x_user_id: string
        }
        Insert: {
          address: string
          created_at?: string
          handle: string
          id?: string
          identity_provider?: string
          is_primary?: boolean
          provider?: string
          provider_user_id?: string | null
          purpose?: string
          recipient_id?: string | null
          sub_organization_id: string
          user_id?: string | null
          wallet_id: string
          x_user_id: string
        }
        Update: {
          address?: string
          created_at?: string
          handle?: string
          id?: string
          identity_provider?: string
          is_primary?: boolean
          provider?: string
          provider_user_id?: string | null
          purpose?: string
          recipient_id?: string | null
          sub_organization_id?: string
          user_id?: string | null
          wallet_id?: string
          x_user_id?: string
        }
        Relationships: []
      }
      escrow_accounts: {
        Row: {
          address: string
          chain_key: string
          created_at: string
          id: string
          is_active: boolean
          kind: string
          notes: string | null
          signer_kind: string
        }
        Insert: {
          address: string
          chain_key?: string
          created_at?: string
          id?: string
          is_active?: boolean
          kind?: string
          notes?: string | null
          signer_kind?: string
        }
        Update: {
          address?: string
          chain_key?: string
          created_at?: string
          id?: string
          is_active?: boolean
          kind?: string
          notes?: string | null
          signer_kind?: string
        }
        Relationships: []
      }
      escrow_deposits: {
        Row: {
          amount: number
          amount_usd: number | null
          asset_key: string
          chain_key: string
          created_at: string
          deposit_signature: string | null
          deposited_at: string | null
          escrow_account_id: string
          id: string
          idempotency_key: string
          payment_id: string | null
          recipient_handle: string
          recipient_id: string | null
          refund_signature: string | null
          release_signature: string | null
          released_at: string | null
          sender_id: string | null
          sender_wallet: string | null
          status: string
        }
        Insert: {
          amount: number
          amount_usd?: number | null
          asset_key: string
          chain_key?: string
          created_at?: string
          deposit_signature?: string | null
          deposited_at?: string | null
          escrow_account_id: string
          id?: string
          idempotency_key: string
          payment_id?: string | null
          recipient_handle: string
          recipient_id?: string | null
          refund_signature?: string | null
          release_signature?: string | null
          released_at?: string | null
          sender_id?: string | null
          sender_wallet?: string | null
          status?: string
        }
        Update: {
          amount?: number
          amount_usd?: number | null
          asset_key?: string
          chain_key?: string
          created_at?: string
          deposit_signature?: string | null
          deposited_at?: string | null
          escrow_account_id?: string
          id?: string
          idempotency_key?: string
          payment_id?: string | null
          recipient_handle?: string
          recipient_id?: string | null
          refund_signature?: string | null
          release_signature?: string | null
          released_at?: string | null
          sender_id?: string | null
          sender_wallet?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "escrow_deposits_escrow_account_id_fkey"
            columns: ["escrow_account_id"]
            isOneToOne: false
            referencedRelation: "escrow_accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "escrow_deposits_payment_id_fkey"
            columns: ["payment_id"]
            isOneToOne: false
            referencedRelation: "payments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "escrow_deposits_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
        ]
      }
      fee_events: {
        Row: {
          external_id: string | null
          gross_usd: number
          id: string
          is_demo: boolean
          net_usd: number
          occurred_at: string
          protocol_fee_usd: number
          recipient_id: string
          sol_amount: number | null
          source: Database["public"]["Enums"]["launch_source"]
          token_id: string
          tx_signature: string
        }
        Insert: {
          external_id?: string | null
          gross_usd: number
          id?: string
          is_demo?: boolean
          net_usd: number
          occurred_at?: string
          protocol_fee_usd: number
          recipient_id: string
          sol_amount?: number | null
          source?: Database["public"]["Enums"]["launch_source"]
          token_id: string
          tx_signature: string
        }
        Update: {
          external_id?: string | null
          gross_usd?: number
          id?: string
          is_demo?: boolean
          net_usd?: number
          occurred_at?: string
          protocol_fee_usd?: number
          recipient_id?: string
          sol_amount?: number | null
          source?: Database["public"]["Enums"]["launch_source"]
          token_id?: string
          tx_signature?: string
        }
        Relationships: [
          {
            foreignKeyName: "fee_events_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fee_events_token_id_fkey"
            columns: ["token_id"]
            isOneToOne: false
            referencedRelation: "tokens"
            referencedColumns: ["id"]
          },
        ]
      }
      identity_claims: {
        Row: {
          created_at: string
          handle: string
          id: string
          method: string
          proof_code: string
          proof_code_expires_at: string
          proof_url: string | null
          recipient_id: string
          review_note: string | null
          reviewed_at: string | null
          reviewer_id: string | null
          status: string
          submitted_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          handle: string
          id?: string
          method?: string
          proof_code: string
          proof_code_expires_at?: string
          proof_url?: string | null
          recipient_id: string
          review_note?: string | null
          reviewed_at?: string | null
          reviewer_id?: string | null
          status?: string
          submitted_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          handle?: string
          id?: string
          method?: string
          proof_code?: string
          proof_code_expires_at?: string
          proof_url?: string | null
          recipient_id?: string
          review_note?: string | null
          reviewed_at?: string | null
          reviewer_id?: string | null
          status?: string
          submitted_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "identity_claims_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
        ]
      }
      identity_deposit_wallets: {
        Row: {
          address: string
          created_at: string
          custody: string
          handle: string
          id: string
          provider: string
          provider_user_id: string
          recipient_id: string | null
          sub_organization_id: string | null
          wallet_id: string | null
        }
        Insert: {
          address: string
          created_at?: string
          custody?: string
          handle: string
          id?: string
          provider: string
          provider_user_id: string
          recipient_id?: string | null
          sub_organization_id?: string | null
          wallet_id?: string | null
        }
        Update: {
          address?: string
          created_at?: string
          custody?: string
          handle?: string
          id?: string
          provider?: string
          provider_user_id?: string
          recipient_id?: string | null
          sub_organization_id?: string | null
          wallet_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "identity_deposit_wallets_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
        ]
      }
      identity_ledger: {
        Row: {
          amount: number
          amount_usd: number | null
          asset: string
          asset_key: string | null
          chain_key: string
          claim_batch_id: string | null
          claim_signature: string | null
          claimed_at: string | null
          claimed_by: string | null
          created_at: string
          deposit_address: string | null
          id: string
          provider: string
          provider_user_id: string | null
          recipient_id: string
          settled_at: string | null
          settlement_signature: string | null
          source: string
          source_event_id: string
          status: string
          tx_signature: string | null
        }
        Insert: {
          amount: number
          amount_usd?: number | null
          asset: string
          asset_key?: string | null
          chain_key?: string
          claim_batch_id?: string | null
          claim_signature?: string | null
          claimed_at?: string | null
          claimed_by?: string | null
          created_at?: string
          deposit_address?: string | null
          id?: string
          provider: string
          provider_user_id?: string | null
          recipient_id: string
          settled_at?: string | null
          settlement_signature?: string | null
          source: string
          source_event_id: string
          status?: string
          tx_signature?: string | null
        }
        Update: {
          amount?: number
          amount_usd?: number | null
          asset?: string
          asset_key?: string | null
          chain_key?: string
          claim_batch_id?: string | null
          claim_signature?: string | null
          claimed_at?: string | null
          claimed_by?: string | null
          created_at?: string
          deposit_address?: string | null
          id?: string
          provider?: string
          provider_user_id?: string | null
          recipient_id?: string
          settled_at?: string | null
          settlement_signature?: string | null
          source?: string
          source_event_id?: string
          status?: string
          tx_signature?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "identity_ledger_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
        ]
      }
      integrations: {
        Row: {
          category: string
          description: string | null
          key: string
          name: string
          status: Database["public"]["Enums"]["integration_status"]
          updated_at: string
        }
        Insert: {
          category: string
          description?: string | null
          key: string
          name: string
          status?: Database["public"]["Enums"]["integration_status"]
          updated_at?: string
        }
        Update: {
          category?: string
          description?: string | null
          key?: string
          name?: string
          status?: Database["public"]["Enums"]["integration_status"]
          updated_at?: string
        }
        Relationships: []
      }
      launch_attempts: {
        Row: {
          confirmed_at: string | null
          created_at: string
          creator_fee_recipient_id: string | null
          dev_buy_delivered_at: string | null
          dev_buy_delivery_note: string | null
          dev_buy_delivery_signature: string | null
          dev_buy_delivery_status: string
          dev_buy_destination_wallet: string | null
          dev_buy_funding_lamports: number
          dev_buy_funding_signature: string | null
          dev_buy_funding_wallet: string | null
          dev_buy_owner_user_id: string | null
          dev_buy_owner_wallet: string | null
          dev_buy_sol: number
          execution_provider: string | null
          execution_wallet: string | null
          failed_at: string | null
          failure_reason: string | null
          fee_lamports_received: number
          fee_payer: string | null
          fee_signature: string | null
          funded_at: string | null
          id: string
          launch_infrastructure_cost_lamports: number
          launch_key: string
          launch_signature: string | null
          launch_wallet_address: string | null
          launcher_wallet: string | null
          mint: string | null
          recipient_id: string | null
          refund_destination: string | null
          refund_signature: string | null
          refund_status: string
          refundable_lamports: number
          retry_of_attempt_id: string | null
          retry_of_launch_key: string | null
          signer_mode: string | null
          social_identity_id: string | null
          spent_lamports: number
          status: string
          submitted_at: string | null
          symbol: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          confirmed_at?: string | null
          created_at?: string
          creator_fee_recipient_id?: string | null
          dev_buy_delivered_at?: string | null
          dev_buy_delivery_note?: string | null
          dev_buy_delivery_signature?: string | null
          dev_buy_delivery_status?: string
          dev_buy_destination_wallet?: string | null
          dev_buy_funding_lamports?: number
          dev_buy_funding_signature?: string | null
          dev_buy_funding_wallet?: string | null
          dev_buy_owner_user_id?: string | null
          dev_buy_owner_wallet?: string | null
          dev_buy_sol?: number
          execution_provider?: string | null
          execution_wallet?: string | null
          failed_at?: string | null
          failure_reason?: string | null
          fee_lamports_received?: number
          fee_payer?: string | null
          fee_signature?: string | null
          funded_at?: string | null
          id?: string
          launch_infrastructure_cost_lamports?: number
          launch_key: string
          launch_signature?: string | null
          launch_wallet_address?: string | null
          launcher_wallet?: string | null
          mint?: string | null
          recipient_id?: string | null
          refund_destination?: string | null
          refund_signature?: string | null
          refund_status?: string
          refundable_lamports?: number
          retry_of_attempt_id?: string | null
          retry_of_launch_key?: string | null
          signer_mode?: string | null
          social_identity_id?: string | null
          spent_lamports?: number
          status?: string
          submitted_at?: string | null
          symbol?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          confirmed_at?: string | null
          created_at?: string
          creator_fee_recipient_id?: string | null
          dev_buy_delivered_at?: string | null
          dev_buy_delivery_note?: string | null
          dev_buy_delivery_signature?: string | null
          dev_buy_delivery_status?: string
          dev_buy_destination_wallet?: string | null
          dev_buy_funding_lamports?: number
          dev_buy_funding_signature?: string | null
          dev_buy_funding_wallet?: string | null
          dev_buy_owner_user_id?: string | null
          dev_buy_owner_wallet?: string | null
          dev_buy_sol?: number
          execution_provider?: string | null
          execution_wallet?: string | null
          failed_at?: string | null
          failure_reason?: string | null
          fee_lamports_received?: number
          fee_payer?: string | null
          fee_signature?: string | null
          funded_at?: string | null
          id?: string
          launch_infrastructure_cost_lamports?: number
          launch_key?: string
          launch_signature?: string | null
          launch_wallet_address?: string | null
          launcher_wallet?: string | null
          mint?: string | null
          recipient_id?: string | null
          refund_destination?: string | null
          refund_signature?: string | null
          refund_status?: string
          refundable_lamports?: number
          retry_of_attempt_id?: string | null
          retry_of_launch_key?: string | null
          signer_mode?: string | null
          social_identity_id?: string | null
          spent_lamports?: number
          status?: string
          submitted_at?: string | null
          symbol?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "launch_attempts_creator_fee_recipient_id_fkey"
            columns: ["creator_fee_recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "launch_attempts_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "launch_attempts_retry_of_attempt_id_fkey"
            columns: ["retry_of_attempt_id"]
            isOneToOne: false
            referencedRelation: "launch_attempts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "launch_attempts_social_identity_id_fkey"
            columns: ["social_identity_id"]
            isOneToOne: false
            referencedRelation: "social_identities"
            referencedColumns: ["id"]
          },
        ]
      }
      launch_audit_events: {
        Row: {
          created_at: string
          detail: Json
          id: string
          kind: string
          launch_key: string
          message: string | null
          stage: string
          status: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          detail?: Json
          id?: string
          kind?: string
          launch_key: string
          message?: string | null
          stage: string
          status: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          detail?: Json
          id?: string
          kind?: string
          launch_key?: string
          message?: string | null
          stage?: string
          status?: string
          user_id?: string | null
        }
        Relationships: []
      }
      payments: {
        Row: {
          amount: number
          amount_usd: number | null
          asset: string
          asset_key: string | null
          chain_key: string | null
          confirmed_at: string | null
          created_at: string
          destination_kind: string | null
          destination_wallet: string | null
          failure_reason: string | null
          id: string
          is_demo: boolean
          ledger_entry_id: string | null
          network: string
          note: string | null
          recipient_handle: string
          recipient_id: string
          recipient_provider: string
          sender_id: string | null
          sender_wallet: string | null
          settled_at: string | null
          status: string
          tx_signature: string | null
        }
        Insert: {
          amount: number
          amount_usd?: number | null
          asset?: string
          asset_key?: string | null
          chain_key?: string | null
          confirmed_at?: string | null
          created_at?: string
          destination_kind?: string | null
          destination_wallet?: string | null
          failure_reason?: string | null
          id?: string
          is_demo?: boolean
          ledger_entry_id?: string | null
          network?: string
          note?: string | null
          recipient_handle: string
          recipient_id: string
          recipient_provider?: string
          sender_id?: string | null
          sender_wallet?: string | null
          settled_at?: string | null
          status?: string
          tx_signature?: string | null
        }
        Update: {
          amount?: number
          amount_usd?: number | null
          asset?: string
          asset_key?: string | null
          chain_key?: string | null
          confirmed_at?: string | null
          created_at?: string
          destination_kind?: string | null
          destination_wallet?: string | null
          failure_reason?: string | null
          id?: string
          is_demo?: boolean
          ledger_entry_id?: string | null
          network?: string
          note?: string | null
          recipient_handle?: string
          recipient_id?: string
          recipient_provider?: string
          sender_id?: string | null
          sender_wallet?: string | null
          settled_at?: string | null
          status?: string
          tx_signature?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "payments_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
        ]
      }
      payout_attempts: {
        Row: {
          asset: string
          asset_amount: number
          confirmed_at: string | null
          created_at: string
          destination_address: string
          failure_reason: string | null
          id: string
          idempotency_key: string
          payout_id: string
          recipient_id: string
          signer_address: string
          status: string
          tx_signature: string | null
        }
        Insert: {
          asset: string
          asset_amount: number
          confirmed_at?: string | null
          created_at?: string
          destination_address: string
          failure_reason?: string | null
          id?: string
          idempotency_key: string
          payout_id: string
          recipient_id: string
          signer_address: string
          status?: string
          tx_signature?: string | null
        }
        Update: {
          asset?: string
          asset_amount?: number
          confirmed_at?: string | null
          created_at?: string
          destination_address?: string
          failure_reason?: string | null
          id?: string
          idempotency_key?: string
          payout_id?: string
          recipient_id?: string
          signer_address?: string
          status?: string
          tx_signature?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "payout_attempts_payout_id_fkey"
            columns: ["payout_id"]
            isOneToOne: false
            referencedRelation: "payouts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payout_attempts_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
        ]
      }
      payouts: {
        Row: {
          adapter: string
          amount_usd: number
          asset: string | null
          asset_amount: number | null
          attempted_at: string | null
          confirmed_at: string | null
          created_at: string
          destination: Database["public"]["Enums"]["destination_type"]
          failure_reason: string | null
          fee_event_id: string
          id: string
          idempotency_key: string
          is_demo: boolean
          label: string | null
          network: string
          recipient_id: string
          settled_at: string | null
          signer_address: string | null
          status: Database["public"]["Enums"]["payout_status"]
          tx_signature: string | null
        }
        Insert: {
          adapter?: string
          amount_usd: number
          asset?: string | null
          asset_amount?: number | null
          attempted_at?: string | null
          confirmed_at?: string | null
          created_at?: string
          destination: Database["public"]["Enums"]["destination_type"]
          failure_reason?: string | null
          fee_event_id: string
          id?: string
          idempotency_key: string
          is_demo?: boolean
          label?: string | null
          network?: string
          recipient_id: string
          settled_at?: string | null
          signer_address?: string | null
          status?: Database["public"]["Enums"]["payout_status"]
          tx_signature?: string | null
        }
        Update: {
          adapter?: string
          amount_usd?: number
          asset?: string | null
          asset_amount?: number | null
          attempted_at?: string | null
          confirmed_at?: string | null
          created_at?: string
          destination?: Database["public"]["Enums"]["destination_type"]
          failure_reason?: string | null
          fee_event_id?: string
          id?: string
          idempotency_key?: string
          is_demo?: boolean
          label?: string | null
          network?: string
          recipient_id?: string
          settled_at?: string | null
          signer_address?: string | null
          status?: Database["public"]["Enums"]["payout_status"]
          tx_signature?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "payouts_fee_event_id_fkey"
            columns: ["fee_event_id"]
            isOneToOne: false
            referencedRelation: "fee_events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payouts_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
        ]
      }
      processed_events: {
        Row: {
          external_id: string
          id: string
          processed_at: string
          source: string
        }
        Insert: {
          external_id: string
          id?: string
          processed_at?: string
          source: string
        }
        Update: {
          external_id?: string
          id?: string
          processed_at?: string
          source?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string | null
          email: string | null
          id: string
          x_handle: string | null
        }
        Insert: {
          created_at?: string
          display_name?: string | null
          email?: string | null
          id: string
          x_handle?: string | null
        }
        Update: {
          created_at?: string
          display_name?: string | null
          email?: string | null
          id?: string
          x_handle?: string | null
        }
        Relationships: []
      }
      protocol_settings: {
        Row: {
          description: string | null
          key: string
          updated_at: string
          updated_by: string | null
          value: Json
        }
        Insert: {
          description?: string | null
          key: string
          updated_at?: string
          updated_by?: string | null
          value: Json
        }
        Update: {
          description?: string | null
          key?: string
          updated_at?: string
          updated_by?: string | null
          value?: Json
        }
        Relationships: []
      }
      recipients: {
        Row: {
          avatar_url: string | null
          bio: string | null
          claimed_by: string | null
          created_at: string
          display_name: string | null
          follower_count: number | null
          handle: string
          id: string
          is_demo: boolean
          platform_verified: boolean | null
          profile_synced_at: string | null
          profile_url: string | null
          provider: string
          provider_user_id: string | null
          verification: Database["public"]["Enums"]["verification_status"]
          x_user_id: string | null
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          claimed_by?: string | null
          created_at?: string
          display_name?: string | null
          follower_count?: number | null
          handle: string
          id?: string
          is_demo?: boolean
          platform_verified?: boolean | null
          profile_synced_at?: string | null
          profile_url?: string | null
          provider?: string
          provider_user_id?: string | null
          verification?: Database["public"]["Enums"]["verification_status"]
          x_user_id?: string | null
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          claimed_by?: string | null
          created_at?: string
          display_name?: string | null
          follower_count?: number | null
          handle?: string
          id?: string
          is_demo?: boolean
          platform_verified?: boolean | null
          profile_synced_at?: string | null
          profile_url?: string | null
          provider?: string
          provider_user_id?: string | null
          verification?: Database["public"]["Enums"]["verification_status"]
          x_user_id?: string | null
        }
        Relationships: []
      }
      routing_configs: {
        Row: {
          id: string
          is_active: boolean
          name: string
          recipient_id: string
          updated_at: string
        }
        Insert: {
          id?: string
          is_active?: boolean
          name?: string
          recipient_id: string
          updated_at?: string
        }
        Update: {
          id?: string
          is_active?: boolean
          name?: string
          recipient_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "routing_configs_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
        ]
      }
      routing_splits: {
        Row: {
          address: string | null
          charity_id: string | null
          config_id: string
          destination: Database["public"]["Enums"]["destination_type"]
          id: string
          label: string
          percent: number
          sort_order: number
        }
        Insert: {
          address?: string | null
          charity_id?: string | null
          config_id: string
          destination: Database["public"]["Enums"]["destination_type"]
          id?: string
          label: string
          percent: number
          sort_order?: number
        }
        Update: {
          address?: string | null
          charity_id?: string | null
          config_id?: string
          destination?: Database["public"]["Enums"]["destination_type"]
          id?: string
          label?: string
          percent?: number
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "routing_splits_charity_id_fkey"
            columns: ["charity_id"]
            isOneToOne: false
            referencedRelation: "charities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "routing_splits_config_id_fkey"
            columns: ["config_id"]
            isOneToOne: false
            referencedRelation: "routing_configs"
            referencedColumns: ["id"]
          },
        ]
      }
      social_identities: {
        Row: {
          avatar_url: string | null
          created_at: string
          disconnected_at: string | null
          display_name: string | null
          handle: string
          id: string
          profile_url: string | null
          provider: string
          provider_user_id: string
          recipient_id: string | null
          updated_at: string
          user_id: string
          verified_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          disconnected_at?: string | null
          display_name?: string | null
          handle: string
          id?: string
          profile_url?: string | null
          provider: string
          provider_user_id: string
          recipient_id?: string | null
          updated_at?: string
          user_id: string
          verified_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          disconnected_at?: string | null
          display_name?: string | null
          handle?: string
          id?: string
          profile_url?: string | null
          provider?: string
          provider_user_id?: string
          recipient_id?: string | null
          updated_at?: string
          user_id?: string
          verified_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "social_identities_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
        ]
      }
      social_oauth_states: {
        Row: {
          code_verifier: string
          consumed_at: string | null
          created_at: string
          handle_hint: string | null
          provider: string
          redirect_uri: string
          state: string
          user_id: string
        }
        Insert: {
          code_verifier: string
          consumed_at?: string | null
          created_at?: string
          handle_hint?: string | null
          provider: string
          redirect_uri: string
          state: string
          user_id: string
        }
        Update: {
          code_verifier?: string
          consumed_at?: string | null
          created_at?: string
          handle_hint?: string | null
          provider?: string
          redirect_uri?: string
          state?: string
          user_id?: string
        }
        Relationships: []
      }
      token_recipients: {
        Row: {
          id: string
          recipient_id: string
          share_percent: number
          token_id: string
        }
        Insert: {
          id?: string
          recipient_id: string
          share_percent?: number
          token_id: string
        }
        Update: {
          id?: string
          recipient_id?: string
          share_percent?: number
          token_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "token_recipients_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "token_recipients_token_id_fkey"
            columns: ["token_id"]
            isOneToOne: false
            referencedRelation: "tokens"
            referencedColumns: ["id"]
          },
        ]
      }
      tokens: {
        Row: {
          community_url: string | null
          created_at: string
          created_by: string | null
          creator_fee_recipient_id: string | null
          decimals: number | null
          description: string | null
          dev_buy_delivered_at: string | null
          dev_buy_delivery_note: string | null
          dev_buy_delivery_signature: string | null
          dev_buy_delivery_status: string
          dev_buy_destination_wallet: string | null
          dev_buy_funding_lamports: number
          dev_buy_funding_signature: string | null
          dev_buy_funding_wallet: string | null
          dev_buy_owner_user_id: string | null
          dev_buy_owner_wallet: string | null
          dev_buy_sol: number
          execution_provider: string | null
          id: string
          image_url: string | null
          is_demo: boolean
          launch_infrastructure_cost_lamports: number
          launch_signature: string | null
          launch_wallet: string | null
          launcher_user_id: string | null
          launcher_wallet: string | null
          mint: string
          name: string
          signer_mode: string | null
          source: Database["public"]["Enums"]["launch_source"]
          supply: number | null
          symbol: string
          telegram_url: string | null
          verified_on_chain_at: string | null
          website_url: string | null
          x_url: string | null
        }
        Insert: {
          community_url?: string | null
          created_at?: string
          created_by?: string | null
          creator_fee_recipient_id?: string | null
          decimals?: number | null
          description?: string | null
          dev_buy_delivered_at?: string | null
          dev_buy_delivery_note?: string | null
          dev_buy_delivery_signature?: string | null
          dev_buy_delivery_status?: string
          dev_buy_destination_wallet?: string | null
          dev_buy_funding_lamports?: number
          dev_buy_funding_signature?: string | null
          dev_buy_funding_wallet?: string | null
          dev_buy_owner_user_id?: string | null
          dev_buy_owner_wallet?: string | null
          dev_buy_sol?: number
          execution_provider?: string | null
          id?: string
          image_url?: string | null
          is_demo?: boolean
          launch_infrastructure_cost_lamports?: number
          launch_signature?: string | null
          launch_wallet?: string | null
          launcher_user_id?: string | null
          launcher_wallet?: string | null
          mint: string
          name: string
          signer_mode?: string | null
          source?: Database["public"]["Enums"]["launch_source"]
          supply?: number | null
          symbol: string
          telegram_url?: string | null
          verified_on_chain_at?: string | null
          website_url?: string | null
          x_url?: string | null
        }
        Update: {
          community_url?: string | null
          created_at?: string
          created_by?: string | null
          creator_fee_recipient_id?: string | null
          decimals?: number | null
          description?: string | null
          dev_buy_delivered_at?: string | null
          dev_buy_delivery_note?: string | null
          dev_buy_delivery_signature?: string | null
          dev_buy_delivery_status?: string
          dev_buy_destination_wallet?: string | null
          dev_buy_funding_lamports?: number
          dev_buy_funding_signature?: string | null
          dev_buy_funding_wallet?: string | null
          dev_buy_owner_user_id?: string | null
          dev_buy_owner_wallet?: string | null
          dev_buy_sol?: number
          execution_provider?: string | null
          id?: string
          image_url?: string | null
          is_demo?: boolean
          launch_infrastructure_cost_lamports?: number
          launch_signature?: string | null
          launch_wallet?: string | null
          launcher_user_id?: string | null
          launcher_wallet?: string | null
          mint?: string
          name?: string
          signer_mode?: string | null
          source?: Database["public"]["Enums"]["launch_source"]
          supply?: number | null
          symbol?: string
          telegram_url?: string | null
          verified_on_chain_at?: string | null
          website_url?: string | null
          x_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tokens_creator_fee_recipient_id_fkey"
            columns: ["creator_fee_recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      wallets: {
        Row: {
          address: string
          chain: string
          created_at: string
          id: string
          is_default: boolean
          label: string | null
          proof_message: string | null
          proof_signature: string | null
          provider: string | null
          recipient_id: string | null
          user_id: string
          verified_at: string | null
        }
        Insert: {
          address: string
          chain?: string
          created_at?: string
          id?: string
          is_default?: boolean
          label?: string | null
          proof_message?: string | null
          proof_signature?: string | null
          provider?: string | null
          recipient_id?: string | null
          user_id: string
          verified_at?: string | null
        }
        Update: {
          address?: string
          chain?: string
          created_at?: string
          id?: string
          is_default?: boolean
          label?: string | null
          proof_message?: string | null
          proof_signature?: string | null
          provider?: string | null
          recipient_id?: string | null
          user_id?: string
          verified_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wallets_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
        ]
      }
      x_identities: {
        Row: {
          avatar_url: string | null
          created_at: string
          display_name: string | null
          handle: string
          id: string
          recipient_id: string | null
          user_id: string
          verified_at: string
          x_user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          handle: string
          id?: string
          recipient_id?: string | null
          user_id: string
          verified_at?: string
          x_user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          display_name?: string | null
          handle?: string
          id?: string
          recipient_id?: string | null
          user_id?: string
          verified_at?: string
          x_user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "x_identities_recipient_id_fkey"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "recipients"
            referencedColumns: ["id"]
          },
        ]
      }
      x_oauth_states: {
        Row: {
          code_verifier: string
          consumed_at: string | null
          created_at: string
          handle_hint: string | null
          redirect_uri: string
          state: string
          user_id: string
        }
        Insert: {
          code_verifier: string
          consumed_at?: string | null
          created_at?: string
          handle_hint?: string | null
          redirect_uri: string
          state: string
          user_id: string
        }
        Update: {
          code_verifier?: string
          consumed_at?: string | null
          created_at?: string
          handle_hint?: string | null
          redirect_uri?: string
          state?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
      destination_type:
        | "sol"
        | "usdc"
        | "wallet_withdrawal"
        | "x_money"
        | "buyback"
        | "burn"
        | "charity"
        | "split_recipient"
      integration_status: "live" | "sandbox" | "planned" | "disabled"
      launch_source: "manual" | "pumpfun" | "raydium" | "other"
      payout_status:
        | "pending"
        | "processing"
        | "paid"
        | "failed"
        | "claimable"
        | "claimed"
        | "cancelled"
      verification_status: "unverified" | "pending" | "verified" | "rejected"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
      destination_type: [
        "sol",
        "usdc",
        "wallet_withdrawal",
        "x_money",
        "buyback",
        "burn",
        "charity",
        "split_recipient",
      ],
      integration_status: ["live", "sandbox", "planned", "disabled"],
      launch_source: ["manual", "pumpfun", "raydium", "other"],
      payout_status: [
        "pending",
        "processing",
        "paid",
        "failed",
        "claimable",
        "claimed",
        "cancelled",
      ],
      verification_status: ["unverified", "pending", "verified", "rejected"],
    },
  },
} as const
