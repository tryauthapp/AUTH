# Roadmap
- [x] Add AI payout-goal recommendations with validated routing splits
- [x] Add admin launch data-health panel with authoritative comparison
- [x] Add metric timestamps and source labels
- [x] Polish and verify light/dark desktop/mobile UI
- [x] Run typecheck, production build, and browser checks
- [x] Restore X OAuth only for username claims with exact account matching
- [x] Light-first AUTH identity with indigo accent, light default theme, entrance splash
