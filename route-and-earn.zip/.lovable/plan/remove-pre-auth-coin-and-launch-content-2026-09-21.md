# Remove pre-AUTH coin and launch content

## Changes
- Establish a single AUTH-era cutoff for public token, launch, recipient, fee, payout, and payment reads so the 20 pre-rebrand launches and related identities cannot appear anywhere in the product.
- Add a database migration that marks existing legacy project records as non-production while leaving new AUTH launches and payments untouched.
- Remove the old token contract address, old social links, and payable-assets counter from shared navigation and the right rail.
- Keep Search AUTH, Creator activity, Assets to watch, and current AUTH activity in the right rail.
- Audit Home, Explore, Coins, token pages, public profiles, ledger, and shared queries for direct paths to old rows.

## Technical details
- Use one exported UTC launch-era cutoff in public queries and server projections as defense in depth.
- Preserve the existing `is_demo = false` filter for future genuine AUTH records.
- Restrict direct token-detail lookups too, so old mint URLs no longer expose legacy projects.
- Apply the cleanup through a migration without changing launch/payment creation logic.
- Verify with typecheck, production build, database reads, and desktop/mobile browser checks.
