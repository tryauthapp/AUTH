# AUTH Social Platform Redesign

## Goal
Rebuild AUTH as a spacious, readable social product with crypto integrated into dedicated flows—not a compact dashboard. Preserve all existing payment, Solana, launch, claim, routing, and verification behavior.

## What will change
- Replace Home with a true activity timeline: sticky title, readable social rows, avatars, timestamps, concise payment/fee/launch context, subtle actions, and an honest empty state.
- Rebalance the desktop shell into a substantial left navigation, approximately 620px center feed, and secondary right rail; keep mobile full-width with top and bottom navigation.
- Simplify left navigation to AUTH, Home, Explore, Notifications, Pay, Launch, and Profile with larger icon-and-label rows.
- Rebuild the right rail around one large search field, “What’s happening,” and compact suggested people/assets without token-chip walls.
- Make Explore search-first with a small set of clear discovery tabs and feed-style results rather than summary statistics.
- Make Pay a focused, large-control flow. Replace the many-token chip wall with a searchable single asset list/selector while preserving the existing review, authorization, and settlement behavior.
- Refine Launch into a readable step flow with larger controls and flat sections while preserving pump.fun creation, exact launch-fee verification, dev buy, image upload, links, and fee routing.
- Refine Profile to the familiar social information architecture: banner, overlapping avatar, identity metadata, primary action, tabs, and timeline content.
- Remove remaining decorative/dashboard utilities from active screens and keep the palette strictly black, white, and neutral gray. Real asset logos retain native colors.

## Technical boundaries
- No OAuth work, fabricated content, backend changes, payment/security architecture changes, deployment, or integration changes.
- Existing live queries supply timeline/discovery content. If they return no records, the interface shows a polished empty timeline.
- Route metadata, dark-first theme behavior, responsive navigation, and existing URLs remain intact.

## Verification
- Run TypeScript checks and a production build.
- Check Home, Explore, Pay, Launch, and Profile at desktop and mobile sizes for readability, overflow, runtime errors, and preserved interactions.
