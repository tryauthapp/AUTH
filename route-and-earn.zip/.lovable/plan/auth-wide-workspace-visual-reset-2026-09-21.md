# AUTH Wide Workspace Visual Reset

## Goal
Rebuild AUTH as a wide, near-black premium crypto/social workspace inspired by the restraint and density of the supplied PAID references, while keeping AUTH original and preserving every existing live payment, Solana, pump.fun, claim, and fee-routing behavior.

## What will change
- Replace the narrow timeline composition with a wide desktop workspace: compact fixed sidebar, slim utility header, broad primary canvas, and contextual panels only where useful.
- Rebuild Home around a controlled AUTH introduction, concise Pay/Launch actions, a compact live system overview, and real discovery/activity below; empty datasets remain explicit rather than filled with examples.
- Restyle Explore as a compact discovery workspace for people, payable Solana assets, launches, and payment activity.
- Restyle Pay as a quiet four-stage workspace for recipient, asset, amount, and review, retaining the searchable registry-backed selector and existing authorization behavior.
- Restructure Launch into a dense primary form plus contextual token/routing preview on desktop, retaining pump.fun-only creation, image and social fields, dev buy, unique launch-fee verification, and idempotency.
- Bring profiles, token pages, ledger, routing/receipt panels, and documentation into the same flat charcoal system with thin borders, modest radii, compact tables, diagrams, and readable article widths.
- Keep the original monochrome AUTH mark, native token logos, first-visit dark mode, responsive bottom navigation, and clean light-mode compatibility.

## Technical boundaries
- Presentation only: no OAuth, database, payment security, Solana, launch adapter, fee-routing, or integration behavior changes.
- No fabricated users, balances, transactions, launches, analytics, or successful states.
- No external-wallet, sign-in, PAID/X branding, proprietary assets, Lovable branding, or deployment work.
- Existing routes and route-specific metadata remain intact.

## Verification
- Run TypeScript checks and a production build.
- Check Home, Explore, Pay, Launch, Profile, Ledger, and Docs at desktop and mobile widths.
- Confirm no overflow, runtime errors, external-wallet/sign-in remnants, fabricated activity, or regressions in interactive controls.
