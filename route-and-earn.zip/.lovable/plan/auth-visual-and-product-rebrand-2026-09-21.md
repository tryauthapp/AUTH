# AUTH visual and product rebrand

## Goal
Rebuild the current product as AUTH using the selected sophisticated glass identity: graphite surfaces, restrained electric-cyan highlights, editorial typography, and a dense social-product shell. Preserve all existing Solana, payment, claim, launch, fee-routing, database, and integration behavior.

## Brand system
- Replace the orange CRYPTO identity with an original AUTH monogram and wordmark, including favicon and app icon.
- Introduce a premium dark-neutral token system with glass surfaces, crisp borders, subtle cyan focus states, and real asset colors.
- Use an editorial display face for major identity moments and a clean sans face for product UI; keep dark mode first.
- Remove stale CRYPTO marketing language and user-facing metadata across every route while retaining accurate legal/security statements.

## Shared experience
- Redesign the desktop shell as a compact left navigation, dense central social/activity surface, and useful right discovery rail.
- Redesign mobile navigation and top bar for a native-feeling AUTH experience with stable sizing and safe-area support.
- Rework cards, tabs, fields, empty states, status indicators, activity rows, and actions into one coherent AUTH system.

## Primary screens
- **Home:** social identity-led header, fast pay entry, asset strip, launches/people/activity feed, and real data or honest empty states.
- **Explore:** denser discovery across people, assets, launches, payments, creator fees, and charities.
- **Pay:** simplify the visible path to recipient → asset → amount → review/authorize while preserving current validation and blocked signing behavior.
- **Launch:** restyle the existing pump.fun-only token, routing, review, exact-fee, and dev-buy flow without changing launch logic.
- **Profile:** social-first cover/avatar/name/@username treatment, Pay action, identities, payment account, sent activity, assets/earnings/launches where real data exists.
- Update Notifications, Coins, Claims, token and public profile views, ledger, dashboard, docs/legal, and system states so no stale public CRYPTO identity remains.

## Verification
- Search all user-facing source and metadata for stale CRYPTO/orange identity references.
- Run typecheck and production build.
- Check desktop and mobile Home, Explore, Pay, Launch, Notifications, and Profile for layout, overflow, dark default, branding, and runtime errors.
- Do not publish or deploy.

## Technical boundaries
- No X OAuth implementation or fake OAuth controls.
- No signing, payment-security, database, RLS, launch-adapter, fee-routing, or integration architecture changes.
- Internal historical identifiers that are part of persisted protocol records may remain only when changing them would alter compatibility; all visible copy becomes AUTH.
