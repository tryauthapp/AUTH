# FeeRail — programmable creator-fee routing on Solana

Working name: **FeeRail** (neutral, rebrandable). Original branding, no resemblance to any existing product.

Tagline: "Launch for anyone. They choose how they get paid."

## What gets built

A database-backed full-stack app (not a mockup) with a public side, a recipient dashboard, and an admin area. All money movement is clearly labeled demo/sandbox until real integrations are configured.

### Public
- Landing page: how programmable creator revenue works, CTA to launch for an X handle and to browse earners/tokens.
- Recipient pages `/u/$handle`: lifetime fees, 24h fees, contributing coin count, top token, pending/paid/buyback totals, live routing config, transaction history, share receipt.
- Token pages `/t/$mint`: total fees generated, recipients, routing, recent fee events, payout history.
- Discovery `/discover`: trending earners, trending tokens, most fees generated, top creators, top charities, recently paid.
- Ledger `/ledger`: every fee event with source mint, tx signature, gross, protocol fee, net, payout status, timestamps, Solana explorer links.
- Docs `/docs` (fee flow, claims, routing, payout status, security assumptions, integrations) and `/legal/terms`, `/legal/privacy`, `/legal/risk`.
- Shareable receipt component: "@handle earned $X today from N community tokens" + routing breakdown + share-to-X.

### Authenticated (recipient dashboard)
- Sign in with email; verification state machine for the X handle (unverified → pending → verified).
- Routing editor: destinations SOL, USDC, wallet withdrawal, X Money adapter (Planned badge), token buyback, burn, charity; multi-recipient splits (creator/artist/community/charity) with percentages validated to exactly 100% client and server side.
- Wallet connection architecture: address + signed-message ownership proof; never keys or seed phrases anywhere.
- Claims flow: failed off-chain payouts stay attributable to the intended recipient and appear as claimable; claim requires verified identity + connected wallet. Unclaimed funds never move to treasury.

### Admin (role-gated)
- Protocol economics configurable (default demo 90% recipient / 10% protocol), integration registry with Live/Sandbox/Planned/Disabled badges, audit log viewer.

## Technical approach

- **Backend**: Lovable Cloud (Postgres + auth). Tables: `profiles`, `user_roles` (separate table + `has_role` security-definer fn), `recipients`, `tokens`, `token_recipients`, `routing_configs`, `routing_splits`, `fee_events`, `payouts`, `claims`, `wallets`, `charities`, `integrations`, `protocol_settings`, `audit_log`, `processed_events` (idempotency + replay protection: unique `(source, external_id)` and unique tx signature on `fee_events`).
- RLS on every table; public read policies limited to safe columns on public tables; owner-scoped read/write for routing, wallets, claims; admin-only for settings/audit. Explicit GRANTs per table.
- **Adapters** under `src/integrations/adapters/` with TypeScript interfaces only, plus registry + status badges: `rpc/indexer`, `launchpad` (pump.fun stub), `swap` (buyback/burn), `charity`, `x-oauth`, `x-money`, `payout`. Each returns `not_configured` rather than faking success. UI/business logic never imports a provider directly.
- **Server logic**: `createServerFn` with `requireSupabaseAuth` for user-scoped writes; public read fns for discovery/ledger. Percent-sum, role, and ownership validated server-side.
- **Seeding**: demo rows shipped as literal INSERTs in the migration (recipients, tokens, fee events across time, payouts incl. failures, claims, charities) so every page is testable. Demo rows carry an `is_demo` flag and render a visible demo badge.
- **Design**: original dark fintech/crypto aesthetic — deep slate base, signal-green accent, mono numerics, tight data-dense cards. All tokens in `src/styles.css`. Real loading/empty/error states everywhere.

## Sequencing

1. Enable Cloud, schema + RLS + grants + demo seed.
2. Design system, shell, landing.
3. Adapter layer + integration registry.
4. Public pages: recipient, token, discovery, ledger, receipt.
5. Auth, dashboard, routing editor, wallet, claims.
6. Admin, audit log, docs and legal pages.

## Assumptions

- Email sign-in for the MVP; X OAuth is an adapter stub (Planned) since no credentials exist.
- No real on-chain transfers or RPC calls; amounts are demo data until integrations are configured.
