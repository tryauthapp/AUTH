ALTER TABLE public.launch_attempts
  ADD COLUMN IF NOT EXISTS retry_of_attempt_id uuid REFERENCES public.launch_attempts(id),
  ADD COLUMN IF NOT EXISTS retry_of_launch_key text;

CREATE INDEX IF NOT EXISTS launch_attempts_retry_of_idx
  ON public.launch_attempts (retry_of_attempt_id);
