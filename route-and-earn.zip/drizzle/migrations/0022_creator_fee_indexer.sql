ALTER TABLE public.identity_ledger
  ADD COLUMN IF NOT EXISTS settlement_signature TEXT,
  ADD COLUMN IF NOT EXISTS settled_at TIMESTAMPTZ;

COMMENT ON COLUMN public.identity_ledger.settlement_signature IS
  'Signature of the transfer that moved detected creator-fee SOL into the identity deposit wallet.';

CREATE TABLE IF NOT EXISTS public.creator_fee_mint_state (
  mint TEXT PRIMARY KEY,
  token_id UUID REFERENCES public.tokens(id),
  recipient_id UUID REFERENCES public.recipients(id),
  provider TEXT,
  provider_user_id TEXT,
  creator_wallet TEXT,
  creator_vault TEXT,
  last_signature TEXT,
  last_synced_at TIMESTAMPTZ,
  last_error TEXT,
  events_processed INTEGER NOT NULL DEFAULT 0,
  credits_created INTEGER NOT NULL DEFAULT 0,
  lamports_credited BIGINT NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS creator_fee_mint_state_synced_idx
  ON public.creator_fee_mint_state (last_synced_at NULLS FIRST);

GRANT SELECT ON public.creator_fee_mint_state TO authenticated;
GRANT ALL ON public.creator_fee_mint_state TO service_role;
ALTER TABLE public.creator_fee_mint_state ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Admins read creator fee mint state" ON public.creator_fee_mint_state;
CREATE POLICY "Admins read creator fee mint state"
  ON public.creator_fee_mint_state FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE TABLE IF NOT EXISTS public.creator_fee_sync_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trigger TEXT NOT NULL DEFAULT 'cron',
  status TEXT NOT NULL DEFAULT 'running',
  mints_scanned INTEGER NOT NULL DEFAULT 0,
  events_processed INTEGER NOT NULL DEFAULT 0,
  credits_created INTEGER NOT NULL DEFAULT 0,
  lamports_credited BIGINT NOT NULL DEFAULT 0,
  settlements INTEGER NOT NULL DEFAULT 0,
  settlement_note TEXT,
  error TEXT,
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  finished_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS creator_fee_sync_runs_started_idx
  ON public.creator_fee_sync_runs (started_at DESC);

GRANT SELECT ON public.creator_fee_sync_runs TO authenticated;
GRANT ALL ON public.creator_fee_sync_runs TO service_role;
ALTER TABLE public.creator_fee_sync_runs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Admins read creator fee runs" ON public.creator_fee_sync_runs;
CREATE POLICY "Admins read creator fee runs"
  ON public.creator_fee_sync_runs FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

COMMENT ON TABLE public.creator_fee_sync_runs IS
  'One row per creator-fee reconciliation run (event-driven or 5-minute cron fallback).';