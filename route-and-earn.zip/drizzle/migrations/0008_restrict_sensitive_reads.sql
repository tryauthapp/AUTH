-- payments: remove blanket public read, scope to sender/recipient owner/admin
drop policy if exists "payments public read" on public.payments;
create policy "payments participant read"
on public.payments for select to authenticated
using (
  sender_id = auth.uid()
  or exists (select 1 from public.recipients r where r.id = payments.recipient_id and r.claimed_by = auth.uid())
  or public.has_role(auth.uid(), 'admin')
);

-- public activity feed without wallet addresses or sender identity
create or replace view public.public_payments_feed
with (security_barrier = true) as
select id, recipient_id, recipient_handle, asset, asset_key, chain_key, amount,
       amount_usd, note, status, network, tx_signature, is_demo, created_at, settled_at
from public.payments;

grant select on public.public_payments_feed to anon, authenticated;

-- claims: owner/admin only
drop policy if exists "claims public read" on public.claims;
create policy "claims owner read"
on public.claims for select to authenticated
using (
  claimed_by = auth.uid()
  or exists (select 1 from public.recipients r where r.id = claims.recipient_id and r.claimed_by = auth.uid())
  or public.has_role(auth.uid(), 'admin')
);

-- payout attempts: owning recipient or admin
drop policy if exists "payout attempts public read" on public.payout_attempts;
create policy "payout attempts owner read"
on public.payout_attempts for select to authenticated
using (
  exists (select 1 from public.recipients r where r.id = payout_attempts.recipient_id and r.claimed_by = auth.uid())
  or public.has_role(auth.uid(), 'admin')
);

-- x identities: owner or admin only
drop policy if exists "x identities public read" on public.x_identities;
create policy "x identities owner read"
on public.x_identities for select to authenticated
using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

-- escrow: admin only
drop policy if exists "escrow accounts public read" on public.escrow_accounts;
create policy "escrow accounts admin read"
on public.escrow_accounts for select to authenticated
using (public.has_role(auth.uid(), 'admin'));

drop policy if exists "escrow deposits public read" on public.escrow_deposits;
create policy "escrow deposits participant read"
on public.escrow_deposits for select to authenticated
using (
  sender_id = auth.uid()
  or exists (select 1 from public.recipients r where r.id = escrow_deposits.recipient_id and r.claimed_by = auth.uid())
  or public.has_role(auth.uid(), 'admin')
);

-- revoke anon grants that are no longer backed by public policies
revoke select on public.payments from anon;
revoke select on public.claims from anon;
revoke select on public.payout_attempts from anon;
revoke select on public.x_identities from anon;
revoke select on public.escrow_accounts from anon;
revoke select on public.escrow_deposits from anon;

-- identity claim proof codes are never selectable in bulk: hash-grade secret handling
alter table public.identity_claims
  add column if not exists proof_code_expires_at timestamptz not null default (now() + interval '24 hours');

-- SECURITY DEFINER functions: no anonymous execution
revoke all on function public.has_role(uuid, public.app_role) from public, anon;
grant execute on function public.has_role(uuid, public.app_role) to authenticated, service_role;
revoke all on function public.handle_new_user() from public, anon, authenticated;