CREATE TABLE public.launch_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  launch_key text NOT NULL,
  status text NOT NULL DEFAULT 'draft',
  fee_signature text,
  fee_payer text,
  fee_lamports_received bigint NOT NULL DEFAULT 0,
  spent_lamports bigint NOT NULL DEFAULT 0,
  refundable_lamports bigint NOT NULL DEFAULT 0,
  refund_status text NOT NULL DEFAULT 'none',
  refund_signature text,
  refund_destination text,
  launch_signature text,
  mint text,
  symbol text,
  failure_reason text,
  created_at timestamptz NOT NULL DEFAULT now(),
  funded_at timestamptz,
  submitted_at timestamptz,
  confirmed_at timestamptz,
  failed_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX launch_attempts_user_key_idx ON public.launch_attempts (user_id, launch_key);
CREATE UNIQUE INDEX launch_attempts_fee_signature_idx ON public.launch_attempts (fee_signature) WHERE fee_signature IS NOT NULL;
CREATE UNIQUE INDEX launch_attempts_refund_signature_idx ON public.launch_attempts (refund_signature) WHERE refund_signature IS NOT NULL;

GRANT SELECT ON public.launch_attempts TO authenticated;
GRANT ALL ON public.launch_attempts TO service_role;

ALTER TABLE public.launch_attempts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Launchers read their own launch attempts"
ON public.launch_attempts
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);