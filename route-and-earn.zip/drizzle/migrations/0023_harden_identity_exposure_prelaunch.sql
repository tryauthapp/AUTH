-- 1. Identity deposit wallets: custody infrastructure must not be readable by
-- every signed-in user. Only the AUTH account that has verified ownership of
-- the identity (recipients.claimed_by) may read its own deposit wallet.
drop policy if exists "Deposit wallet addresses are public" on public.identity_deposit_wallets;
drop policy if exists "identity_deposit_wallets public read" on public.identity_deposit_wallets;

create policy "Owners read their own identity deposit wallet"
on public.identity_deposit_wallets
for select
to authenticated
using (
  exists (
    select 1 from public.recipients r
    where r.id = identity_deposit_wallets.recipient_id
      and r.claimed_by = auth.uid()
  )
  or public.has_role(auth.uid(), 'admin')
);

-- 2. recipients: keep the public directory readable, but never expose the
-- immutable third-party identifiers used for ownership decisions.
revoke select (provider_user_id, x_user_id) on public.recipients from anon, authenticated;

-- 3. social_identities: linked-account rows tie an AUTH user_id to a platform
-- account. Public identity pages are served server-side, so no anonymous
-- Data API read is needed.
drop policy if exists "Verified identities are publicly readable" on public.social_identities;

create policy "Users read their own linked identities"
on public.social_identities
for select
to authenticated
using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

revoke select on public.social_identities from anon;

-- 4. token-images is a private bucket; drop anonymous read. Uploads and
-- signed-URL creation stay with authenticated users, and already-signed URLs
-- continue to resolve.
drop policy if exists "token images read" on storage.objects;

create policy "token images read"
on storage.objects
for select
to authenticated
using (bucket_id = 'token-images');