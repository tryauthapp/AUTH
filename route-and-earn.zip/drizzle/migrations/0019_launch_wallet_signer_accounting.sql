-- Records the real signer/funder of each launch and where dev-buy tokens landed.
ALTER TABLE public.tokens
  ADD COLUMN IF NOT EXISTS signer_mode TEXT,
  ADD COLUMN IF NOT EXISTS dev_buy_owner_wallet TEXT;

ALTER TABLE public.launch_attempts
  ADD COLUMN IF NOT EXISTS signer_mode TEXT,
  ADD COLUMN IF NOT EXISTS launch_wallet_address TEXT,
  ADD COLUMN IF NOT EXISTS dev_buy_owner_wallet TEXT;

COMMENT ON COLUMN public.tokens.signer_mode IS
  'external_wallet = signed by AUTH''s own Solana launch wallet; provider_hosted = signed by provider execution infrastructure (never a beneficial owner).';
COMMENT ON COLUMN public.tokens.dev_buy_owner_wallet IS
  'Wallet holding the dev-buy tokens. Set only when the dev buy actually landed in the launcher''s wallet.';
COMMENT ON COLUMN public.launch_attempts.launch_wallet_address IS
  'Public address of the wallet that signed and funded the launch transaction.';
