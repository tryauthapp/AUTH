ALTER TABLE public.assets
  ADD COLUMN IF NOT EXISTS token_program text,
  ADD COLUMN IF NOT EXISTS mint_verified_at timestamptz,
  ADD COLUMN IF NOT EXISTS issuer text,
  ADD COLUMN IF NOT EXISTS category text,
  ADD COLUMN IF NOT EXISTS freeze_authority text;

CREATE UNIQUE INDEX IF NOT EXISTS assets_chain_mint_unique
  ON public.assets (chain_key, contract_address)
  WHERE contract_address IS NOT NULL;
