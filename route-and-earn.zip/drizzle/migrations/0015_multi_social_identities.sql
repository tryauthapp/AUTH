-- Multi-provider social identity layer (X, TikTok, YouTube, Twitch).
-- Canonical key is always (provider, provider_user_id): the immutable ID the
-- provider owns. Handles/display names are mutable profile metadata only.

CREATE TABLE IF NOT EXISTS public.social_identities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider TEXT NOT NULL CHECK (provider IN ('x','tiktok','youtube','twitch')),
  provider_user_id TEXT NOT NULL,
  handle TEXT NOT NULL,
  display_name TEXT,
  avatar_url TEXT,
  profile_url TEXT,
  user_id UUID NOT NULL,
  recipient_id UUID REFERENCES public.recipients(id) ON DELETE SET NULL,
  verified_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  disconnected_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- One provider identity can be linked to at most one AUTH account at a time.
CREATE UNIQUE INDEX IF NOT EXISTS social_identities_active_key
  ON public.social_identities (provider, provider_user_id)
  WHERE disconnected_at IS NULL;
CREATE INDEX IF NOT EXISTS social_identities_user_idx ON public.social_identities (user_id);
CREATE INDEX IF NOT EXISTS social_identities_handle_idx ON public.social_identities (provider, lower(handle));

GRANT SELECT ON public.social_identities TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.social_identities TO authenticated;
GRANT ALL ON public.social_identities TO service_role;

ALTER TABLE public.social_identities ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Verified identities are publicly readable" ON public.social_identities;
CREATE POLICY "Verified identities are publicly readable"
  ON public.social_identities FOR SELECT TO anon, authenticated
  USING (disconnected_at IS NULL);

DROP POLICY IF EXISTS "Owners read their identities" ON public.social_identities;
CREATE POLICY "Owners read their identities"
  ON public.social_identities FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

-- Linking/unlinking is performed server-side after provider proof only.

-- OAuth transaction state: CSRF state + PKCE verifier, one-time use.
CREATE TABLE IF NOT EXISTS public.social_oauth_states (
  state TEXT PRIMARY KEY,
  provider TEXT NOT NULL CHECK (provider IN ('x','tiktok','youtube','twitch')),
  user_id UUID NOT NULL,
  code_verifier TEXT NOT NULL,
  redirect_uri TEXT NOT NULL,
  handle_hint TEXT,
  consumed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT ALL ON public.social_oauth_states TO service_role;
ALTER TABLE public.social_oauth_states ENABLE ROW LEVEL SECURITY;
-- No anon/authenticated grants or policies: server-side only.

-- Recipients become provider-scoped payment identities.
ALTER TABLE public.recipients
  ADD COLUMN IF NOT EXISTS provider TEXT NOT NULL DEFAULT 'x',
  ADD COLUMN IF NOT EXISTS provider_user_id TEXT;

UPDATE public.recipients SET provider_user_id = x_user_id
  WHERE provider_user_id IS NULL AND x_user_id IS NOT NULL;

DO $$ BEGIN
  ALTER TABLE public.recipients
    ADD CONSTRAINT recipients_provider_check CHECK (provider IN ('x','tiktok','youtube','twitch'));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE UNIQUE INDEX IF NOT EXISTS recipients_provider_handle_key
  ON public.recipients (provider, lower(handle));

-- Embedded wallets are keyed by provider identity, not by X alone.
ALTER TABLE public.embedded_wallets
  ADD COLUMN IF NOT EXISTS identity_provider TEXT NOT NULL DEFAULT 'x',
  ADD COLUMN IF NOT EXISTS provider_user_id TEXT;

UPDATE public.embedded_wallets SET provider_user_id = x_user_id WHERE provider_user_id IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS embedded_wallets_identity_key
  ON public.embedded_wallets (identity_provider, provider_user_id);

-- Backfill existing verified X identities into the unified table.
INSERT INTO public.social_identities (provider, provider_user_id, handle, display_name, avatar_url, user_id, recipient_id, verified_at, created_at)
SELECT 'x', x.x_user_id, x.handle, x.display_name, x.avatar_url, x.user_id, x.recipient_id, x.verified_at, x.created_at
FROM public.x_identities x
ON CONFLICT DO NOTHING;