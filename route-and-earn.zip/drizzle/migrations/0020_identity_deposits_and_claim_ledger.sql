-- Send now, claim later: identity-scoped deposit wallets, an immutable
-- balance ledger, and claim batches.

-- 1. One protected deposit destination per canonical social identity.
CREATE TABLE IF NOT EXISTS public.identity_deposit_wallets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider TEXT NOT NULL,
  provider_user_id TEXT NOT NULL,
  recipient_id UUID REFERENCES public.recipients(id),
  handle TEXT NOT NULL,
  address TEXT NOT NULL,
  custody TEXT NOT NULL DEFAULT 'turnkey',
  sub_organization_id TEXT,
  wallet_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS identity_deposit_wallets_canonical_idx
  ON public.identity_deposit_wallets (provider, provider_user_id);
CREATE UNIQUE INDEX IF NOT EXISTS identity_deposit_wallets_address_idx
  ON public.identity_deposit_wallets (address);
CREATE INDEX IF NOT EXISTS identity_deposit_wallets_recipient_idx
  ON public.identity_deposit_wallets (recipient_id);

GRANT SELECT ON public.identity_deposit_wallets TO authenticated;
GRANT ALL ON public.identity_deposit_wallets TO service_role;
ALTER TABLE public.identity_deposit_wallets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Deposit wallet addresses are public"
  ON public.identity_deposit_wallets FOR SELECT TO authenticated USING (true);

COMMENT ON TABLE public.identity_deposit_wallets IS
  'Turnkey-held deposit wallet for one canonical social identity (provider + immutable provider_user_id). Holds funds sent to an identity before its owner joins AUTH. AUTH never sees the key material.';

-- 2. Immutable balance ledger. Every credit and claim derives from these rows.
CREATE TABLE IF NOT EXISTS public.identity_ledger (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_id UUID NOT NULL REFERENCES public.recipients(id),
  provider TEXT NOT NULL,
  provider_user_id TEXT,
  source TEXT NOT NULL,
  source_event_id TEXT NOT NULL,
  chain_key TEXT NOT NULL DEFAULT 'solana',
  asset TEXT NOT NULL,
  asset_key TEXT,
  amount NUMERIC NOT NULL,
  amount_usd NUMERIC,
  deposit_address TEXT,
  tx_signature TEXT,
  status TEXT NOT NULL DEFAULT 'deposited',
  claim_batch_id UUID,
  claim_signature TEXT,
  claimed_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  claimed_at TIMESTAMPTZ
);

CREATE UNIQUE INDEX IF NOT EXISTS identity_ledger_source_idx
  ON public.identity_ledger (source, source_event_id);
CREATE UNIQUE INDEX IF NOT EXISTS identity_ledger_signature_idx
  ON public.identity_ledger (tx_signature) WHERE tx_signature IS NOT NULL;
CREATE INDEX IF NOT EXISTS identity_ledger_recipient_status_idx
  ON public.identity_ledger (recipient_id, status);
CREATE INDEX IF NOT EXISTS identity_ledger_canonical_idx
  ON public.identity_ledger (provider, provider_user_id);

GRANT SELECT ON public.identity_ledger TO authenticated;
GRANT ALL ON public.identity_ledger TO service_role;
ALTER TABLE public.identity_ledger ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owners read their identity ledger"
  ON public.identity_ledger FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.recipients r
      WHERE r.id = identity_ledger.recipient_id AND r.claimed_by = auth.uid()
    )
  );

COMMENT ON TABLE public.identity_ledger IS
  'Immutable credit rows for a social identity: direct payments and creator fees. Balances are always summed from these rows, never from an editable counter. Status: deposited, available, claiming, claimed, failed.';

-- 3. Claim batches: one payout transaction per asset per claim.
CREATE TABLE IF NOT EXISTS public.claim_batches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_id UUID NOT NULL REFERENCES public.recipients(id),
  user_id UUID NOT NULL,
  asset TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  amount_usd NUMERIC,
  source_address TEXT NOT NULL,
  destination_address TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'claiming',
  tx_signature TEXT,
  failure_reason TEXT,
  idempotency_key TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  confirmed_at TIMESTAMPTZ
);

CREATE UNIQUE INDEX IF NOT EXISTS claim_batches_idempotency_idx
  ON public.claim_batches (idempotency_key);
CREATE UNIQUE INDEX IF NOT EXISTS claim_batches_signature_idx
  ON public.claim_batches (tx_signature) WHERE tx_signature IS NOT NULL;
CREATE INDEX IF NOT EXISTS claim_batches_user_idx ON public.claim_batches (user_id);

GRANT SELECT ON public.claim_batches TO authenticated;
GRANT ALL ON public.claim_batches TO service_role;
ALTER TABLE public.claim_batches ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read their own claim batches"
  ON public.claim_batches FOR SELECT TO authenticated USING (user_id = auth.uid());

COMMENT ON TABLE public.claim_batches IS
  'One on-chain payout per asset when a verified owner claims. Marked claimed only after the signature is verified on-chain.';

-- 4. Payments gain the deposit destination kind so legacy unfunded
--    reservations stay distinguishable from real settled deposits.
ALTER TABLE public.payments
  ADD COLUMN IF NOT EXISTS destination_kind TEXT,
  ADD COLUMN IF NOT EXISTS ledger_entry_id UUID;

COMMENT ON COLUMN public.payments.destination_kind IS
  'payout_wallet = straight to the claimed owner''s verified wallet; identity_deposit = settled into the identity''s protected deposit wallet; legacy_reservation = older unfunded record where no money ever moved.';

UPDATE public.payments
  SET destination_kind = CASE
    WHEN tx_signature IS NOT NULL THEN 'payout_wallet'
    WHEN status = 'awaiting_recipient' THEN 'legacy_reservation'
    ELSE 'payout_wallet'
  END
  WHERE destination_kind IS NULL;
