-- 1. Remove the SECURITY DEFINER view; public feeds now come from server code.
drop view if exists public.public_payments_feed;

-- 2. has_role runs as the caller (users can read their own role rows).
create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean
language sql
stable
security invoker
set search_path = public
as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

-- 3. fee_events: owner + admin only.
drop policy if exists "fee events public read" on public.fee_events;
create policy "fee events owner read" on public.fee_events
for select to authenticated
using (
  exists (select 1 from public.recipients r where r.id = fee_events.recipient_id and r.claimed_by = auth.uid())
  or public.has_role(auth.uid(), 'admin')
);
revoke select on public.fee_events from anon;

-- 4. payouts: owner + admin only.
drop policy if exists "payouts public read" on public.payouts;
create policy "payouts owner read" on public.payouts
for select to authenticated
using (
  exists (select 1 from public.recipients r where r.id = payouts.recipient_id and r.claimed_by = auth.uid())
  or public.has_role(auth.uid(), 'admin')
);
revoke select on public.payouts from anon;

-- 5. routing configs/splits: owner + admin only.
drop policy if exists "routing public read" on public.routing_configs;
create policy "routing owner read" on public.routing_configs
for select to authenticated
using (
  exists (select 1 from public.recipients r where r.id = routing_configs.recipient_id and r.claimed_by = auth.uid())
  or public.has_role(auth.uid(), 'admin')
);
revoke select on public.routing_configs from anon;

drop policy if exists "splits public read" on public.routing_splits;
create policy "splits owner read" on public.routing_splits
for select to authenticated
using (
  exists (
    select 1 from public.routing_configs c
    join public.recipients r on r.id = c.recipient_id
    where c.id = routing_splits.config_id
      and (r.claimed_by = auth.uid() or public.has_role(auth.uid(), 'admin'))
  )
);
revoke select on public.routing_splits from anon;

-- 6. protocol_settings: admin only (treasury address / fee config).
drop policy if exists "settings public read" on public.protocol_settings;
create policy "settings admin read" on public.protocol_settings
for select to authenticated
using (public.has_role(auth.uid(), 'admin'));
revoke select on public.protocol_settings from anon;

-- 7. escrow_deposits stay server-side only: no client write grants at all.
revoke insert, update, delete on public.escrow_deposits from anon, authenticated;
revoke all on public.escrow_deposits from anon;
revoke insert, update, delete on public.escrow_accounts from anon, authenticated;
revoke all on public.escrow_accounts from anon;

-- 8. Bind ownership at insert time for recipients and tokens.
drop policy if exists "recipients insert auth" on public.recipients;
create policy "recipients insert own" on public.recipients
for insert to authenticated
with check (claimed_by = auth.uid() and verification <> 'verified'::verification_status);

drop policy if exists "tokens insert auth" on public.tokens;
create policy "tokens insert own" on public.tokens
for insert to authenticated
with check (created_by = auth.uid());

-- 9. Wallets remain strictly owner-scoped with no anon access.
revoke all on public.wallets from anon;