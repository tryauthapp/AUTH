-- 1. Promote real Solana-native assets to live/payable with verified mainnet mints.
UPDATE public.assets SET contract_address = 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB', decimals = 6, status = 'live', is_payable = true
  WHERE key = 'solana:USDT';
UPDATE public.assets SET contract_address = 'JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN', decimals = 6, status = 'live', is_payable = true
  WHERE key = 'solana:JUP';
UPDATE public.assets SET contract_address = 'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263', decimals = 5, status = 'live', is_payable = true
  WHERE key = 'solana:BONK';
UPDATE public.assets SET contract_address = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', decimals = 6 WHERE key = 'solana:USDC';

-- 2. X (Twitter) OAuth PKCE state, short-lived, server-only.
CREATE TABLE public.x_oauth_states (
  state text PRIMARY KEY,
  user_id uuid NOT NULL,
  code_verifier text NOT NULL,
  redirect_uri text NOT NULL,
  handle_hint text,
  created_at timestamptz NOT NULL DEFAULT now(),
  consumed_at timestamptz
);
GRANT ALL ON public.x_oauth_states TO service_role;
ALTER TABLE public.x_oauth_states ENABLE ROW LEVEL SECURITY;

-- 3. Verified X identities returned by X OAuth. One X account id -> one CRYPTO user.
CREATE TABLE public.x_identities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  x_user_id text NOT NULL UNIQUE,
  handle text NOT NULL,
  display_name text,
  avatar_url text,
  user_id uuid NOT NULL,
  recipient_id uuid REFERENCES public.recipients(id),
  verified_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX x_identities_handle_key ON public.x_identities (lower(handle));
GRANT SELECT ON public.x_identities TO anon, authenticated;
GRANT ALL ON public.x_identities TO service_role;
ALTER TABLE public.x_identities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "x identities public read" ON public.x_identities FOR SELECT TO anon, authenticated USING (true);

-- 4. Escrow deposits: funds held for an unclaimed X handle.
-- No release path is enabled until a signer exists; enforced in application code
-- and by escrow_accounts.is_active defaulting to false.
CREATE TABLE public.escrow_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chain_key text NOT NULL DEFAULT 'solana',
  address text NOT NULL,
  kind text NOT NULL DEFAULT 'program',
  signer_kind text NOT NULL DEFAULT 'none',
  is_active boolean NOT NULL DEFAULT false,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.escrow_accounts TO anon, authenticated;
GRANT ALL ON public.escrow_accounts TO service_role;
ALTER TABLE public.escrow_accounts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "escrow accounts public read" ON public.escrow_accounts FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.escrow_deposits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_id uuid REFERENCES public.payments(id),
  escrow_account_id uuid NOT NULL REFERENCES public.escrow_accounts(id),
  recipient_handle text NOT NULL,
  recipient_id uuid REFERENCES public.recipients(id),
  sender_id uuid,
  sender_wallet text,
  asset_key text NOT NULL,
  chain_key text NOT NULL DEFAULT 'solana',
  amount numeric NOT NULL,
  amount_usd numeric,
  deposit_signature text,
  release_signature text,
  refund_signature text,
  status text NOT NULL DEFAULT 'pending_deposit',
  idempotency_key text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  deposited_at timestamptz,
  released_at timestamptz
);
CREATE INDEX escrow_deposits_handle_idx ON public.escrow_deposits (lower(recipient_handle));
GRANT SELECT ON public.escrow_deposits TO anon, authenticated;
GRANT ALL ON public.escrow_deposits TO service_role;
ALTER TABLE public.escrow_deposits ENABLE ROW LEVEL SECURITY;
CREATE POLICY "escrow deposits public read" ON public.escrow_deposits FOR SELECT TO anon, authenticated USING (true);

INSERT INTO public.escrow_accounts (chain_key, address, kind, signer_kind, is_active, notes)
VALUES ('solana', 'not_configured', 'program', 'none', false,
  'No escrow program deployed and no custody signer configured. Escrow deposits stay disabled until one exists, so no funds can be locked without a release path.');