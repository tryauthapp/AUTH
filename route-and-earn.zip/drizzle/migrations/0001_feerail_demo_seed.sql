-- integrations registry
insert into public.integrations (key,name,category,status,description) values
 ('solana_rpc','Solana RPC / Indexer','data','sandbox','Reads fee events from Solana. Currently serving demo records until an RPC endpoint is configured.'),
 ('pumpfun','pump.fun launchpad','launchpad','planned','Adapter interface exists; no credentials or indexer connected.'),
 ('raydium','Raydium / AMM launch source','launchpad','planned','Adapter interface only.'),
 ('jupiter_swap','Swap router (buyback & burn)','swap','planned','Used to convert fees into token buybacks or burns.'),
 ('x_oauth','X (Twitter) OAuth','identity','planned','Handle ownership verification. Manual review used in the meantime.'),
 ('x_money','X Money payout adapter','payout','planned','Optional payout rail. Not a dependency of the protocol.'),
 ('wallet_payout','Solana wallet payout','payout','sandbox','User-signed or explicitly configured server infrastructure. No keys are ever stored.'),
 ('charity_registry','Charity registry','charity','sandbox','Demo charity wallets only.'),
 ('usdc_settlement','USDC settlement','payout','planned','Stablecoin settlement rail.'),
 ('email_auth','Email authentication','identity','live','Account sign-in for recipients and admins.');

insert into public.protocol_settings (key,value,description) values
 ('fee_split','{"recipient_percent":90,"protocol_percent":10}','Default protocol economics. Demo configuration.'),
 ('min_payout_usd','{"amount":5}','Minimum balance before an automatic payout is attempted.'),
 ('treasury_policy','{"sweep_unclaimed":false}','Unclaimed recipient funds are never swept to protocol treasury.'),
 ('demo_mode','{"enabled":true}','All ledger records are demo data. No real money movement.');

insert into public.charities (id,slug,name,description,wallet_address) values
 ('c0000000-0000-4000-8000-000000000001','ocean-fund','Ocean Cleanup Fund','Demo charity: marine plastic removal.','CHAR1oceanDemo1111111111111111111111111111'),
 ('c0000000-0000-4000-8000-000000000002','code-for-kids','Code For Kids','Demo charity: youth programming education.','CHAR2kidsDemo2222222222222222222222222222'),
 ('c0000000-0000-4000-8000-000000000003','open-source-fund','Open Source Fund','Demo charity: maintainer grants.','CHAR3osDemo33333333333333333333333333333');

-- recipients
insert into public.recipients (id,handle,display_name,bio,verification) values
 ('a0000000-0000-4000-8000-000000000001','novaquinn','Nova Quinn','Synth producer. Ships one track a week.','verified'),
 ('a0000000-0000-4000-8000-000000000002','deltamaps','Delta Maps','Open-source cartography and data viz.','verified'),
 ('a0000000-0000-4000-8000-000000000003','ripley_dev','Ripley','Solana dev tooling, mostly at 3am.','verified'),
 ('a0000000-0000-4000-8000-000000000004','harborcollective','Harbor Collective','Artist collective, 9 members, one treasury.','pending'),
 ('a0000000-0000-4000-8000-000000000005','junipercodes','Juniper','Teaching people to read a block explorer.','verified'),
 ('a0000000-0000-4000-8000-000000000006','mirabelrun','Mirabel','Ultra runner documenting every mile.','unverified');

-- tokens
insert into public.tokens (id,mint,symbol,name,source) values
 ('b0000000-0000-4000-8000-000000000001','NovaMint111111111111111111111111111111111','NOVA','Nova Community Coin','pumpfun'),
 ('b0000000-0000-4000-8000-000000000002','SynthMint22222222222222222222222222222222','SYNTH','Synthwave','pumpfun'),
 ('b0000000-0000-4000-8000-000000000003','DeltaMint3333333333333333333333333333333','DELTA','Delta Atlas','manual'),
 ('b0000000-0000-4000-8000-000000000004','RipleyMint444444444444444444444444444444','RIPL','Ripley Devcoin','pumpfun'),
 ('b0000000-0000-4000-8000-000000000005','HarborMint55555555555555555555555555555','HRBR','Harbor','manual'),
 ('b0000000-0000-4000-8000-000000000006','JuniperMint6666666666666666666666666666','JUNI','Juniper Learn','pumpfun'),
 ('b0000000-0000-4000-8000-000000000007','MileMint777777777777777777777777777777','MILE','Mile Club','manual'),
 ('b0000000-0000-4000-8000-000000000008','AtlasMint8888888888888888888888888888888','ATLS','Atlas Nights','raydium');

insert into public.token_recipients (token_id,recipient_id,share_percent) values
 ('b0000000-0000-4000-8000-000000000001','a0000000-0000-4000-8000-000000000001',100),
 ('b0000000-0000-4000-8000-000000000002','a0000000-0000-4000-8000-000000000001',100),
 ('b0000000-0000-4000-8000-000000000003','a0000000-0000-4000-8000-000000000002',100),
 ('b0000000-0000-4000-8000-000000000008','a0000000-0000-4000-8000-000000000002',100),
 ('b0000000-0000-4000-8000-000000000004','a0000000-0000-4000-8000-000000000003',100),
 ('b0000000-0000-4000-8000-000000000005','a0000000-0000-4000-8000-000000000004',100),
 ('b0000000-0000-4000-8000-000000000006','a0000000-0000-4000-8000-000000000005',100),
 ('b0000000-0000-4000-8000-000000000007','a0000000-0000-4000-8000-000000000006',100);

-- routing configs
insert into public.routing_configs (id,recipient_id,name) values
 ('d0000000-0000-4000-8000-000000000001','a0000000-0000-4000-8000-000000000001','Default routing'),
 ('d0000000-0000-4000-8000-000000000002','a0000000-0000-4000-8000-000000000002','Default routing'),
 ('d0000000-0000-4000-8000-000000000003','a0000000-0000-4000-8000-000000000003','Default routing'),
 ('d0000000-0000-4000-8000-000000000004','a0000000-0000-4000-8000-000000000004','Collective split'),
 ('d0000000-0000-4000-8000-000000000005','a0000000-0000-4000-8000-000000000005','Default routing'),
 ('d0000000-0000-4000-8000-000000000006','a0000000-0000-4000-8000-000000000006','Default routing');

insert into public.routing_splits (config_id,destination,label,percent,address,charity_id,sort_order) values
 ('d0000000-0000-4000-8000-000000000001','usdc','USDC to wallet',60,'NovaWallet1111111111111111111111111111111',null,0),
 ('d0000000-0000-4000-8000-000000000001','buyback','Buy back NOVA',30,null,null,1),
 ('d0000000-0000-4000-8000-000000000001','charity','Ocean Cleanup Fund',10,null,'c0000000-0000-4000-8000-000000000001',2),
 ('d0000000-0000-4000-8000-000000000002','sol','SOL to wallet',70,'DeltaWallet222222222222222222222222222222',null,0),
 ('d0000000-0000-4000-8000-000000000002','charity','Open Source Fund',30,null,'c0000000-0000-4000-8000-000000000003',1),
 ('d0000000-0000-4000-8000-000000000003','x_money','X Money payout',50,null,null,0),
 ('d0000000-0000-4000-8000-000000000003','wallet_withdrawal','Manual withdrawal balance',25,'RipleyWallet33333333333333333333333333333',null,1),
 ('d0000000-0000-4000-8000-000000000003','burn','Burn RIPL',25,null,null,2),
 ('d0000000-0000-4000-8000-000000000004','split_recipient','Artists pool',50,'HarborArtists4444444444444444444444444444',null,0),
 ('d0000000-0000-4000-8000-000000000004','split_recipient','Community treasury',30,'HarborTreasury444444444444444444444444444',null,1),
 ('d0000000-0000-4000-8000-000000000004','charity','Code For Kids',20,null,'c0000000-0000-4000-8000-000000000002',2),
 ('d0000000-0000-4000-8000-000000000005','usdc','USDC to wallet',100,'JuniperWallet55555555555555555555555555',null,0),
 ('d0000000-0000-4000-8000-000000000006','sol','SOL to wallet',80,'MirabelWallet666666666666666666666666666',null,0),
 ('d0000000-0000-4000-8000-000000000006','buyback','Buy back MILE',20,null,null,1);

-- fee events: spread across last 30 days per token
insert into public.fee_events (token_id,recipient_id,tx_signature,source,external_id,gross_usd,protocol_fee_usd,net_usd,sol_amount,occurred_at)
select tr.token_id,
       tr.recipient_id,
       'DEMOsig' || replace(gen_random_uuid()::text,'-',''),
       t.source,
       'demo-' || t.symbol || '-' || g,
       round(gross::numeric,2),
       round((gross*0.10)::numeric,2),
       round((gross*0.90)::numeric,2),
       round((gross/150.0)::numeric,4),
       now() - ((g * 0.9) || ' hours')::interval
from public.token_recipients tr
join public.tokens t on t.id = tr.token_id
cross join lateral generate_series(0, 24) as g
cross join lateral (select (12 + (abs(hashtext(t.symbol || g::text)) % 340))::float as gross) s;

-- payouts derived from routing splits
insert into public.payouts (fee_event_id,recipient_id,destination,label,adapter,amount_usd,status,failure_reason,idempotency_key,attempted_at,settled_at)
select fe.id,
       fe.recipient_id,
       rs.destination,
       rs.label,
       case rs.destination when 'x_money' then 'x_money' when 'buyback' then 'jupiter_swap' when 'burn' then 'jupiter_swap'
            when 'charity' then 'charity_registry' else 'wallet_payout' end,
       round((fe.net_usd * rs.percent / 100)::numeric,2),
       case
         when rs.destination = 'x_money' then 'claimable'::public.payout_status
         when fe.occurred_at > now() - interval '6 hours' then 'pending'::public.payout_status
         else 'paid'::public.payout_status
       end,
       case when rs.destination = 'x_money' then 'X Money adapter is not configured. Funds remain attributable to the recipient.' else null end,
       fe.id::text || ':' || rs.id::text,
       case when fe.occurred_at > now() - interval '6 hours' then null else fe.occurred_at + interval '4 minutes' end,
       case when rs.destination = 'x_money' or fe.occurred_at > now() - interval '6 hours' then null else fe.occurred_at + interval '6 minutes' end
from public.fee_events fe
join public.routing_configs rc on rc.recipient_id = fe.recipient_id and rc.is_active
join public.routing_splits rs on rs.config_id = rc.id;

-- claims opened for every claimable payout
insert into public.claims (payout_id,recipient_id,amount_usd,status)
select p.id, p.recipient_id, p.amount_usd, 'open'
from public.payouts p where p.status = 'claimable';
