drop policy if exists "token images read" on storage.objects;

create policy "token images read"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'token-images'
  and (
    (storage.foldername(name))[1] = auth.uid()::text
    or public.has_role(auth.uid(), 'admin')
  )
);