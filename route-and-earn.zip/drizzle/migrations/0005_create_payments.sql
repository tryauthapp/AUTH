CREATE TABLE IF NOT EXISTS public.payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  sender_wallet text,
  recipient_id uuid NOT NULL REFERENCES public.recipients(id) ON DELETE CASCADE,
  recipient_handle text NOT NULL,
  destination_wallet text,
  asset text NOT NULL DEFAULT 'SOL',
  amount numeric NOT NULL,
  amount_usd numeric,
  note text,
  status text NOT NULL DEFAULT 'awaiting_recipient',
  network text NOT NULL DEFAULT 'mainnet-beta',
  tx_signature text,
  failure_reason text,
  is_demo boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  settled_at timestamptz,
  confirmed_at timestamptz
);

CREATE UNIQUE INDEX IF NOT EXISTS payments_tx_signature_key
  ON public.payments (tx_signature) WHERE tx_signature IS NOT NULL;
CREATE INDEX IF NOT EXISTS payments_recipient_idx ON public.payments (recipient_id, created_at DESC);
CREATE INDEX IF NOT EXISTS payments_sender_idx ON public.payments (sender_id, created_at DESC);

GRANT SELECT ON public.payments TO anon;
GRANT SELECT, INSERT, UPDATE ON public.payments TO authenticated;
GRANT ALL ON public.payments TO service_role;

ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "payments public read" ON public.payments
  FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "payments sender insert" ON public.payments
  FOR INSERT TO authenticated WITH CHECK (sender_id = auth.uid());

CREATE POLICY "payments sender update" ON public.payments
  FOR UPDATE TO authenticated
  USING (sender_id = auth.uid())
  WITH CHECK (sender_id = auth.uid());