INSERT INTO public.protocol_settings (key, value, description)
VALUES (
  'treasury_wallet',
  '{"chain":"solana","address":"Fzgva1ef4hBJ3aL7ExTcaF9ERny3xhqiD3ueJEtZ73nr","role":"protocol_fee_treasury"}'::jsonb,
  'Public Solana address that receives the protocol fee share. Public address only — no keys are stored.'
)
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, description = EXCLUDED.description, updated_at = now();

INSERT INTO public.integrations (key, name, category, status, description)
VALUES (
  'helius_rpc',
  'Helius RPC',
  'data',
  'live',
  'Read-only Solana JSON-RPC via Helius. Powers live balances, transaction lookups and signature history.'
)
ON CONFLICT (key) DO UPDATE SET name = EXCLUDED.name, category = EXCLUDED.category, status = EXCLUDED.status, description = EXCLUDED.description, updated_at = now();

UPDATE public.integrations
SET status = 'live',
    description = 'Reads live Solana state through the configured Helius RPC endpoint. Fee-event indexing runs in sandbox until on-chain fee sources are connected.',
    updated_at = now()
WHERE key = 'solana_rpc';