-- On-chain settlement metadata for payouts signed by a connected browser wallet.
ALTER TABLE public.payouts
  ADD COLUMN IF NOT EXISTS tx_signature text,
  ADD COLUMN IF NOT EXISTS network text NOT NULL DEFAULT 'mainnet-beta',
  ADD COLUMN IF NOT EXISTS signer_address text,
  ADD COLUMN IF NOT EXISTS asset text,
  ADD COLUMN IF NOT EXISTS asset_amount numeric,
  ADD COLUMN IF NOT EXISTS confirmed_at timestamptz,
  ADD COLUMN IF NOT EXISTS is_demo boolean NOT NULL DEFAULT true;

CREATE UNIQUE INDEX IF NOT EXISTS payouts_tx_signature_key
  ON public.payouts (tx_signature) WHERE tx_signature IS NOT NULL;

-- Existing rows predate real settlement and are demo records.
UPDATE public.payouts SET is_demo = true WHERE is_demo IS NULL;

-- Wallet ownership proofs (signed message, never a private key).
ALTER TABLE public.wallets
  ADD COLUMN IF NOT EXISTS provider text,
  ADD COLUMN IF NOT EXISTS proof_message text;

-- Real (non-demo) launches created through CRYPTO.
ALTER TABLE public.tokens
  ADD COLUMN IF NOT EXISTS launch_wallet text,
  ADD COLUMN IF NOT EXISTS verified_on_chain_at timestamptz,
  ADD COLUMN IF NOT EXISTS decimals integer,
  ADD COLUMN IF NOT EXISTS supply numeric;

-- Payout attempts audit trail, one row per wallet signature attempt.
CREATE TABLE IF NOT EXISTS public.payout_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payout_id uuid NOT NULL REFERENCES public.payouts(id) ON DELETE CASCADE,
  recipient_id uuid NOT NULL REFERENCES public.recipients(id) ON DELETE CASCADE,
  signer_address text NOT NULL,
  asset text NOT NULL,
  asset_amount numeric NOT NULL,
  destination_address text NOT NULL,
  tx_signature text,
  status text NOT NULL DEFAULT 'submitted',
  failure_reason text,
  idempotency_key text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  confirmed_at timestamptz
);

CREATE UNIQUE INDEX IF NOT EXISTS payout_attempts_idempotency_key
  ON public.payout_attempts (idempotency_key);

GRANT SELECT ON public.payout_attempts TO anon;
GRANT SELECT ON public.payout_attempts TO authenticated;
GRANT ALL ON public.payout_attempts TO service_role;

ALTER TABLE public.payout_attempts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "payout attempts public read"
  ON public.payout_attempts FOR SELECT
  TO anon, authenticated
  USING (true);
