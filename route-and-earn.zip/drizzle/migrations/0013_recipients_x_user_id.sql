ALTER TABLE public.recipients ADD COLUMN IF NOT EXISTS x_user_id text;
CREATE UNIQUE INDEX IF NOT EXISTS recipients_x_user_id_key ON public.recipients (x_user_id) WHERE x_user_id IS NOT NULL;