-- Separate launch infrastructure cost from launcher-funded dev buys, and make
-- dev-buy funding source / destination / delivery explicit.

ALTER TABLE public.tokens
  ADD COLUMN IF NOT EXISTS launch_infrastructure_cost_lamports BIGINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS dev_buy_funding_wallet TEXT,
  ADD COLUMN IF NOT EXISTS dev_buy_funding_signature TEXT,
  ADD COLUMN IF NOT EXISTS dev_buy_funding_lamports BIGINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS dev_buy_destination_wallet TEXT,
  ADD COLUMN IF NOT EXISTS dev_buy_delivery_signature TEXT,
  ADD COLUMN IF NOT EXISTS dev_buy_delivered_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS dev_buy_delivery_note TEXT;

COMMENT ON COLUMN public.tokens.launch_infrastructure_cost_lamports IS
  'Solana network/provider cost of the launch transaction, paid by AUTH launch infrastructure. Never dev-buy capital.';
COMMENT ON COLUMN public.tokens.dev_buy_funding_wallet IS
  'Launcher wallet that funded the optional dev buy. AUTH never funds dev buys.';
COMMENT ON COLUMN public.tokens.dev_buy_destination_wallet IS
  'Launcher wallet the purchased dev-buy tokens are delivered to.';

ALTER TABLE public.launch_attempts
  ADD COLUMN IF NOT EXISTS launch_infrastructure_cost_lamports BIGINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS dev_buy_funding_wallet TEXT,
  ADD COLUMN IF NOT EXISTS dev_buy_funding_signature TEXT,
  ADD COLUMN IF NOT EXISTS dev_buy_funding_lamports BIGINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS dev_buy_destination_wallet TEXT,
  ADD COLUMN IF NOT EXISTS dev_buy_delivered_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS tokens_dev_buy_delivery_status_idx
  ON public.tokens (dev_buy_delivery_status)
  WHERE dev_buy_sol > 0;