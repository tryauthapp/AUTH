-- ========== enums ==========
create type public.app_role as enum ('admin','moderator','user');
create type public.verification_status as enum ('unverified','pending','verified','rejected');
create type public.destination_type as enum ('sol','usdc','wallet_withdrawal','x_money','buyback','burn','charity','split_recipient');
create type public.payout_status as enum ('pending','processing','paid','failed','claimable','claimed','cancelled');
create type public.integration_status as enum ('live','sandbox','planned','disabled');
create type public.launch_source as enum ('manual','pumpfun','raydium','other');

-- ========== profiles ==========
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text,
  x_handle text,
  created_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "own profile read" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "own profile insert" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "own profile update" on public.profiles for update to authenticated using (auth.uid() = id);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, display_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)))
  on conflict (id) do nothing;
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ========== roles ==========
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "read own roles" on public.user_roles for select to authenticated using (auth.uid() = user_id);

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

-- ========== charities ==========
create table public.charities (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  description text,
  wallet_address text,
  is_demo boolean not null default true,
  created_at timestamptz not null default now()
);
grant select on public.charities to anon, authenticated;
grant all on public.charities to service_role;
alter table public.charities enable row level security;
create policy "charities public read" on public.charities for select to anon, authenticated using (true);
create policy "charities admin write" on public.charities for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- ========== recipients ==========
create table public.recipients (
  id uuid primary key default gen_random_uuid(),
  handle text not null unique,
  display_name text,
  avatar_url text,
  bio text,
  verification public.verification_status not null default 'unverified',
  claimed_by uuid references auth.users(id) on delete set null,
  is_demo boolean not null default true,
  created_at timestamptz not null default now()
);
grant select on public.recipients to anon, authenticated;
grant insert, update on public.recipients to authenticated;
grant all on public.recipients to service_role;
alter table public.recipients enable row level security;
create policy "recipients public read" on public.recipients for select to anon, authenticated using (true);
create policy "recipients insert auth" on public.recipients for insert to authenticated with check (true);
create policy "recipients owner update" on public.recipients for update to authenticated
  using (claimed_by = auth.uid() or public.has_role(auth.uid(),'admin'))
  with check (claimed_by = auth.uid() or public.has_role(auth.uid(),'admin'));

-- ========== tokens ==========
create table public.tokens (
  id uuid primary key default gen_random_uuid(),
  mint text not null unique,
  symbol text not null,
  name text not null,
  image_url text,
  source public.launch_source not null default 'manual',
  created_by uuid references auth.users(id) on delete set null,
  is_demo boolean not null default true,
  created_at timestamptz not null default now()
);
grant select on public.tokens to anon, authenticated;
grant insert on public.tokens to authenticated;
grant all on public.tokens to service_role;
alter table public.tokens enable row level security;
create policy "tokens public read" on public.tokens for select to anon, authenticated using (true);
create policy "tokens insert auth" on public.tokens for insert to authenticated with check (true);

create table public.token_recipients (
  id uuid primary key default gen_random_uuid(),
  token_id uuid not null references public.tokens(id) on delete cascade,
  recipient_id uuid not null references public.recipients(id) on delete cascade,
  share_percent numeric(5,2) not null default 100,
  unique (token_id, recipient_id)
);
grant select on public.token_recipients to anon, authenticated;
grant all on public.token_recipients to service_role;
alter table public.token_recipients enable row level security;
create policy "token_recipients public read" on public.token_recipients for select to anon, authenticated using (true);

-- ========== routing ==========
create table public.routing_configs (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references public.recipients(id) on delete cascade,
  name text not null default 'Default routing',
  is_active boolean not null default true,
  updated_at timestamptz not null default now()
);
grant select on public.routing_configs to anon, authenticated;
grant insert, update, delete on public.routing_configs to authenticated;
grant all on public.routing_configs to service_role;
alter table public.routing_configs enable row level security;
create policy "routing public read" on public.routing_configs for select to anon, authenticated using (true);
create policy "routing owner write" on public.routing_configs for all to authenticated
  using (exists (select 1 from public.recipients r where r.id = recipient_id and (r.claimed_by = auth.uid() or public.has_role(auth.uid(),'admin'))))
  with check (exists (select 1 from public.recipients r where r.id = recipient_id and (r.claimed_by = auth.uid() or public.has_role(auth.uid(),'admin'))));

create table public.routing_splits (
  id uuid primary key default gen_random_uuid(),
  config_id uuid not null references public.routing_configs(id) on delete cascade,
  destination public.destination_type not null,
  label text not null,
  percent numeric(5,2) not null check (percent > 0 and percent <= 100),
  address text,
  charity_id uuid references public.charities(id) on delete set null,
  sort_order int not null default 0
);
grant select on public.routing_splits to anon, authenticated;
grant insert, update, delete on public.routing_splits to authenticated;
grant all on public.routing_splits to service_role;
alter table public.routing_splits enable row level security;
create policy "splits public read" on public.routing_splits for select to anon, authenticated using (true);
create policy "splits owner write" on public.routing_splits for all to authenticated
  using (exists (select 1 from public.routing_configs c join public.recipients r on r.id = c.recipient_id
                 where c.id = config_id and (r.claimed_by = auth.uid() or public.has_role(auth.uid(),'admin'))))
  with check (exists (select 1 from public.routing_configs c join public.recipients r on r.id = c.recipient_id
                 where c.id = config_id and (r.claimed_by = auth.uid() or public.has_role(auth.uid(),'admin'))));

-- ========== wallets ==========
create table public.wallets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  recipient_id uuid references public.recipients(id) on delete set null,
  address text not null,
  chain text not null default 'solana',
  proof_signature text,
  verified_at timestamptz,
  created_at timestamptz not null default now(),
  unique (user_id, address)
);
grant select, insert, update, delete on public.wallets to authenticated;
grant all on public.wallets to service_role;
alter table public.wallets enable row level security;
create policy "wallets owner all" on public.wallets for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ========== fee events ==========
create table public.fee_events (
  id uuid primary key default gen_random_uuid(),
  token_id uuid not null references public.tokens(id) on delete cascade,
  recipient_id uuid not null references public.recipients(id) on delete cascade,
  tx_signature text not null unique,
  source public.launch_source not null default 'manual',
  external_id text,
  gross_usd numeric(14,2) not null,
  protocol_fee_usd numeric(14,2) not null,
  net_usd numeric(14,2) not null,
  sol_amount numeric(18,6),
  occurred_at timestamptz not null default now(),
  is_demo boolean not null default true,
  unique (source, external_id)
);
grant select on public.fee_events to anon, authenticated;
grant all on public.fee_events to service_role;
alter table public.fee_events enable row level security;
create policy "fee events public read" on public.fee_events for select to anon, authenticated using (true);

create table public.processed_events (
  id uuid primary key default gen_random_uuid(),
  source text not null,
  external_id text not null,
  processed_at timestamptz not null default now(),
  unique (source, external_id)
);
grant all on public.processed_events to service_role;
alter table public.processed_events enable row level security;

-- ========== payouts ==========
create table public.payouts (
  id uuid primary key default gen_random_uuid(),
  fee_event_id uuid not null references public.fee_events(id) on delete cascade,
  recipient_id uuid not null references public.recipients(id) on delete cascade,
  destination public.destination_type not null,
  label text,
  adapter text not null default 'demo',
  amount_usd numeric(14,2) not null,
  status public.payout_status not null default 'pending',
  failure_reason text,
  idempotency_key text not null unique,
  attempted_at timestamptz,
  settled_at timestamptz,
  created_at timestamptz not null default now()
);
grant select on public.payouts to anon, authenticated;
grant all on public.payouts to service_role;
alter table public.payouts enable row level security;
create policy "payouts public read" on public.payouts for select to anon, authenticated using (true);

-- ========== claims ==========
create table public.claims (
  id uuid primary key default gen_random_uuid(),
  payout_id uuid not null references public.payouts(id) on delete cascade,
  recipient_id uuid not null references public.recipients(id) on delete cascade,
  claimed_by uuid references auth.users(id) on delete set null,
  wallet_address text,
  amount_usd numeric(14,2) not null,
  status text not null default 'open',
  created_at timestamptz not null default now(),
  resolved_at timestamptz,
  unique (payout_id)
);
grant select, insert, update on public.claims to authenticated;
grant select on public.claims to anon;
grant all on public.claims to service_role;
alter table public.claims enable row level security;
create policy "claims public read" on public.claims for select to anon, authenticated using (true);
create policy "claims owner write" on public.claims for all to authenticated
  using (exists (select 1 from public.recipients r where r.id = recipient_id and (r.claimed_by = auth.uid() or public.has_role(auth.uid(),'admin'))))
  with check (exists (select 1 from public.recipients r where r.id = recipient_id and (r.claimed_by = auth.uid() or public.has_role(auth.uid(),'admin'))));

-- ========== integrations & settings ==========
create table public.integrations (
  key text primary key,
  name text not null,
  category text not null,
  status public.integration_status not null default 'planned',
  description text,
  updated_at timestamptz not null default now()
);
grant select on public.integrations to anon, authenticated;
grant all on public.integrations to service_role;
alter table public.integrations enable row level security;
create policy "integrations public read" on public.integrations for select to anon, authenticated using (true);
create policy "integrations admin write" on public.integrations for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table public.protocol_settings (
  key text primary key,
  value jsonb not null,
  description text,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id) on delete set null
);
grant select on public.protocol_settings to anon, authenticated;
grant all on public.protocol_settings to service_role;
alter table public.protocol_settings enable row level security;
create policy "settings public read" on public.protocol_settings for select to anon, authenticated using (true);
create policy "settings admin write" on public.protocol_settings for all to authenticated
  using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

-- ========== audit log ==========
create table public.audit_log (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity text,
  entity_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
grant select on public.audit_log to authenticated;
grant all on public.audit_log to service_role;
alter table public.audit_log enable row level security;
create policy "audit admin read" on public.audit_log for select to authenticated using (public.has_role(auth.uid(),'admin'));
