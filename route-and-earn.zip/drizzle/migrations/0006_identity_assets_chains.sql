-- Chain registry: one row per supported or planned chain.
CREATE TABLE IF NOT EXISTS public.chains (
  key text PRIMARY KEY,
  name text NOT NULL,
  native_symbol text NOT NULL,
  status public.integration_status NOT NULL DEFAULT 'planned',
  signer_kind text NOT NULL DEFAULT 'none',
  explorer_tx_url text,
  explorer_address_url text,
  sort_order integer NOT NULL DEFAULT 100,
  notes text,
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.chains TO anon;
GRANT SELECT ON public.chains TO authenticated;
GRANT ALL ON public.chains TO service_role;
ALTER TABLE public.chains ENABLE ROW LEVEL SECURITY;
CREATE POLICY "chains public read" ON public.chains
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "chains admin write" ON public.chains
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Asset registry: extensible to many assets across many chains.
CREATE TABLE IF NOT EXISTS public.assets (
  key text PRIMARY KEY,
  symbol text NOT NULL,
  name text NOT NULL,
  chain_key text NOT NULL REFERENCES public.chains(key) ON DELETE CASCADE,
  kind text NOT NULL DEFAULT 'native',
  contract_address text,
  decimals integer NOT NULL DEFAULT 9,
  status public.integration_status NOT NULL DEFAULT 'planned',
  is_payable boolean NOT NULL DEFAULT false,
  market_rank integer,
  logo_url text,
  coingecko_id text,
  notes text,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS assets_chain_idx ON public.assets (chain_key);
CREATE INDEX IF NOT EXISTS assets_rank_idx ON public.assets (market_rank);

GRANT SELECT ON public.assets TO anon;
GRANT SELECT ON public.assets TO authenticated;
GRANT ALL ON public.assets TO service_role;
ALTER TABLE public.assets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "assets public read" ON public.assets
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "assets admin write" ON public.assets
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Identity claims: an X username is the payment identity until someone proves ownership.
CREATE TABLE IF NOT EXISTS public.identity_claims (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_id uuid NOT NULL REFERENCES public.recipients(id) ON DELETE CASCADE,
  handle text NOT NULL,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  method text NOT NULL DEFAULT 'post_proof',
  proof_code text NOT NULL,
  proof_url text,
  status text NOT NULL DEFAULT 'pending',
  reviewer_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  review_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  submitted_at timestamptz,
  reviewed_at timestamptz
);

CREATE UNIQUE INDEX IF NOT EXISTS identity_claims_open_idx
  ON public.identity_claims (recipient_id, user_id)
  WHERE status IN ('pending', 'submitted');
CREATE INDEX IF NOT EXISTS identity_claims_handle_idx ON public.identity_claims (handle);

GRANT SELECT, INSERT, UPDATE ON public.identity_claims TO authenticated;
GRANT ALL ON public.identity_claims TO service_role;
ALTER TABLE public.identity_claims ENABLE ROW LEVEL SECURITY;
CREATE POLICY "identity claims own read" ON public.identity_claims
  FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "identity claims own insert" ON public.identity_claims
  FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "identity claims own update" ON public.identity_claims
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));

-- Payments become chain/asset aware.
ALTER TABLE public.payments ADD COLUMN IF NOT EXISTS chain_key text;
ALTER TABLE public.payments ADD COLUMN IF NOT EXISTS asset_key text;
UPDATE public.payments SET chain_key = COALESCE(chain_key, 'solana');
UPDATE public.payments
  SET asset_key = COALESCE(asset_key, 'solana:' || upper(asset));

-- Payout wallets can be marked as the default destination per recipient.
ALTER TABLE public.wallets ADD COLUMN IF NOT EXISTS is_default boolean NOT NULL DEFAULT false;
ALTER TABLE public.wallets ADD COLUMN IF NOT EXISTS label text;