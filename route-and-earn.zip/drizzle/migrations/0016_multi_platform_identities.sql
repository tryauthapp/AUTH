-- Generalize recipients from X-only to five platforms.
-- Existing rows keep provider='x' and are untouched.

-- A handle is only unique *within* a platform. @news on X and @news on Twitch
-- are different people, so the global handle uniqueness has to go; the
-- (provider, lower(handle)) unique index already covers correctness.
ALTER TABLE public.recipients DROP CONSTRAINT IF EXISTS recipients_handle_key;

-- Cached public profile snapshot from the platform's own API. Nullable
-- everywhere: a missing value stays null rather than being invented.
ALTER TABLE public.recipients
  ADD COLUMN IF NOT EXISTS follower_count integer,
  ADD COLUMN IF NOT EXISTS profile_url text,
  ADD COLUMN IF NOT EXISTS platform_verified boolean,
  ADD COLUMN IF NOT EXISTS profile_synced_at timestamptz;

ALTER TABLE public.recipients
  DROP CONSTRAINT IF EXISTS recipients_provider_check;
ALTER TABLE public.recipients
  ADD CONSTRAINT recipients_provider_check
  CHECK (provider IN ('x','tiktok','youtube','twitch','instagram'));

CREATE UNIQUE INDEX IF NOT EXISTS recipients_provider_user_key
  ON public.recipients (provider, provider_user_id)
  WHERE provider_user_id IS NOT NULL;

-- Payments and launches address a platform identity, not a bare string.
ALTER TABLE public.payments
  ADD COLUMN IF NOT EXISTS recipient_provider text NOT NULL DEFAULT 'x';
ALTER TABLE public.payments
  DROP CONSTRAINT IF EXISTS payments_recipient_provider_check;
ALTER TABLE public.payments
  ADD CONSTRAINT payments_recipient_provider_check
  CHECK (recipient_provider IN ('x','tiktok','youtube','twitch','instagram'));

ALTER TABLE public.social_identities
  DROP CONSTRAINT IF EXISTS social_identities_provider_check;
ALTER TABLE public.social_identities
  ADD CONSTRAINT social_identities_provider_check
  CHECK (provider IN ('x','tiktok','youtube','twitch','instagram'));

ALTER TABLE public.social_oauth_states
  DROP CONSTRAINT IF EXISTS social_oauth_states_provider_check;
ALTER TABLE public.social_oauth_states
  ADD CONSTRAINT social_oauth_states_provider_check
  CHECK (provider IN ('x','tiktok','youtube','twitch','instagram'));

CREATE INDEX IF NOT EXISTS payments_recipient_provider_idx
  ON public.payments (recipient_provider, recipient_handle);