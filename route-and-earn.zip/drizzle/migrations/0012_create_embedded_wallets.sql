CREATE TABLE public.embedded_wallets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  x_user_id text NOT NULL UNIQUE,
  handle text NOT NULL,
  user_id uuid,
  recipient_id uuid,
  provider text NOT NULL DEFAULT 'turnkey',
  sub_organization_id text NOT NULL,
  wallet_id text NOT NULL,
  address text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.embedded_wallets TO authenticated;
GRANT ALL ON public.embedded_wallets TO service_role;

ALTER TABLE public.embedded_wallets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owners can view their embedded wallet"
ON public.embedded_wallets
FOR SELECT
TO authenticated
USING (user_id = auth.uid());