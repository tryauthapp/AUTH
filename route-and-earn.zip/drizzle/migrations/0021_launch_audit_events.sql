-- Launch audit timeline: one immutable row per stage of a launch or smoke test.
-- Never stores secrets; detail is redacted before insert by the server.
CREATE TABLE IF NOT EXISTS public.launch_audit_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  launch_key TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'launch',
  stage TEXT NOT NULL,
  status TEXT NOT NULL,
  message TEXT,
  detail JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS launch_audit_events_key_idx
  ON public.launch_audit_events (launch_key, created_at);
CREATE INDEX IF NOT EXISTS launch_audit_events_user_idx
  ON public.launch_audit_events (user_id, created_at DESC);

GRANT SELECT ON public.launch_audit_events TO authenticated;
GRANT ALL ON public.launch_audit_events TO service_role;
ALTER TABLE public.launch_audit_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read their own launch audit events"
  ON public.launch_audit_events FOR SELECT TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins read all launch audit events"
  ON public.launch_audit_events FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

COMMENT ON TABLE public.launch_audit_events IS
  'Append-only launch audit timeline: configuration validation, transaction construction, signing, submission, confirmation and failure. Secrets are redacted server-side; private keys are never written here.';
