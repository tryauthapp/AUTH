-- Indexes for the read paths that every visitor hits: public claimable
-- balances, identity lookups by handle, fee ledger and activity feeds.

CREATE INDEX IF NOT EXISTS idx_recipients_provider_handle_lower
  ON public.recipients (provider, lower(handle));
CREATE INDEX IF NOT EXISTS idx_recipients_claimed_by
  ON public.recipients (claimed_by);

CREATE INDEX IF NOT EXISTS idx_payouts_recipient_status
  ON public.payouts (recipient_id, status);
CREATE INDEX IF NOT EXISTS idx_payouts_created_at
  ON public.payouts (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_payouts_fee_event
  ON public.payouts (fee_event_id);

CREATE INDEX IF NOT EXISTS idx_escrow_deposits_recipient_status
  ON public.escrow_deposits (recipient_id, status);
CREATE INDEX IF NOT EXISTS idx_escrow_deposits_recipient_handle_lower
  ON public.escrow_deposits (lower(recipient_handle));

CREATE INDEX IF NOT EXISTS idx_fee_events_occurred_at
  ON public.fee_events (occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_fee_events_recipient
  ON public.fee_events (recipient_id);
CREATE INDEX IF NOT EXISTS idx_fee_events_token
  ON public.fee_events (token_id);

CREATE INDEX IF NOT EXISTS idx_payments_created_at
  ON public.payments (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_payments_recipient
  ON public.payments (recipient_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_payments_recipient_handle_lower
  ON public.payments (lower(recipient_handle));
CREATE INDEX IF NOT EXISTS idx_payments_sender
  ON public.payments (sender_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_token_recipients_recipient
  ON public.token_recipients (recipient_id);
CREATE INDEX IF NOT EXISTS idx_token_recipients_token
  ON public.token_recipients (token_id);
CREATE INDEX IF NOT EXISTS idx_tokens_created_at
  ON public.tokens (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_routing_configs_recipient_active
  ON public.routing_configs (recipient_id, is_active);
CREATE INDEX IF NOT EXISTS idx_routing_splits_config
  ON public.routing_splits (config_id);

CREATE INDEX IF NOT EXISTS idx_social_identities_user
  ON public.social_identities (user_id);
CREATE INDEX IF NOT EXISTS idx_social_identities_recipient
  ON public.social_identities (recipient_id);

CREATE INDEX IF NOT EXISTS idx_claims_recipient
  ON public.claims (recipient_id, status);
CREATE INDEX IF NOT EXISTS idx_launch_attempts_user
  ON public.launch_attempts (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_wallets_user
  ON public.wallets (user_id);
