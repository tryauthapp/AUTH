-- Canonical social identity: one recipient row per (provider, immutable provider id)
CREATE UNIQUE INDEX IF NOT EXISTS recipients_provider_identity_key
  ON public.recipients (provider, provider_user_id)
  WHERE provider_user_id IS NOT NULL;

-- One primary embedded payout wallet per AUTH user (not per social identity)
ALTER TABLE public.embedded_wallets
  ADD COLUMN IF NOT EXISTS is_primary boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS purpose text NOT NULL DEFAULT 'user_payout';

UPDATE public.embedded_wallets w
   SET is_primary = true
 WHERE w.user_id IS NOT NULL
   AND w.id = (
     SELECT e.id FROM public.embedded_wallets e
      WHERE e.user_id = w.user_id
      ORDER BY e.created_at ASC
      LIMIT 1
   );

CREATE UNIQUE INDEX IF NOT EXISTS embedded_wallets_one_primary_per_user
  ON public.embedded_wallets (user_id)
  WHERE is_primary AND user_id IS NOT NULL;

-- Launch ownership accounting: launcher, execution wallet, dev buy, creator fee
ALTER TABLE public.launch_attempts
  ADD COLUMN IF NOT EXISTS recipient_id uuid REFERENCES public.recipients(id),
  ADD COLUMN IF NOT EXISTS creator_fee_recipient_id uuid REFERENCES public.recipients(id),
  ADD COLUMN IF NOT EXISTS social_identity_id uuid REFERENCES public.social_identities(id),
  ADD COLUMN IF NOT EXISTS execution_provider text,
  ADD COLUMN IF NOT EXISTS execution_wallet text,
  ADD COLUMN IF NOT EXISTS launcher_wallet text,
  ADD COLUMN IF NOT EXISTS dev_buy_sol numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS dev_buy_owner_user_id uuid,
  ADD COLUMN IF NOT EXISTS dev_buy_delivery_status text NOT NULL DEFAULT 'none',
  ADD COLUMN IF NOT EXISTS dev_buy_delivery_signature text,
  ADD COLUMN IF NOT EXISTS dev_buy_delivery_note text;

ALTER TABLE public.tokens
  ADD COLUMN IF NOT EXISTS launcher_user_id uuid,
  ADD COLUMN IF NOT EXISTS launcher_wallet text,
  ADD COLUMN IF NOT EXISTS creator_fee_recipient_id uuid REFERENCES public.recipients(id),
  ADD COLUMN IF NOT EXISTS execution_provider text,
  ADD COLUMN IF NOT EXISTS dev_buy_sol numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS dev_buy_owner_user_id uuid,
  ADD COLUMN IF NOT EXISTS dev_buy_delivery_status text NOT NULL DEFAULT 'none';

UPDATE public.tokens SET launcher_user_id = created_by WHERE launcher_user_id IS NULL;
UPDATE public.tokens t
   SET creator_fee_recipient_id = tr.recipient_id
  FROM public.token_recipients tr
 WHERE tr.token_id = t.id AND t.creator_fee_recipient_id IS NULL;

CREATE INDEX IF NOT EXISTS tokens_dev_buy_owner_idx ON public.tokens (dev_buy_owner_user_id);
CREATE INDEX IF NOT EXISTS tokens_creator_fee_recipient_idx ON public.tokens (creator_fee_recipient_id);
CREATE INDEX IF NOT EXISTS launch_attempts_recipient_idx ON public.launch_attempts (recipient_id);

COMMENT ON COLUMN public.tokens.launch_wallet IS 'Execution wallet that signed the launch (provider-hosted). Not an ownership claim.';
COMMENT ON COLUMN public.tokens.dev_buy_owner_user_id IS 'Beneficial owner of the dev-buy token allocation: always the launcher.';
COMMENT ON COLUMN public.tokens.creator_fee_recipient_id IS 'Canonical social identity that owns creator-fee entitlement.';