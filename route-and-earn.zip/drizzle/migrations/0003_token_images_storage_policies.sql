CREATE POLICY "token images auth upload"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'token-images' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "token images owner update"
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'token-images' AND (storage.foldername(name))[1] = auth.uid()::text)
WITH CHECK (bucket_id = 'token-images' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "token images owner delete"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'token-images' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "token images read"
ON storage.objects FOR SELECT TO authenticated, anon
USING (bucket_id = 'token-images');